Freedom POS 2.0 v0.40 — TEST ONLY

Modernised Home and module navigation cards, shared button styling, Treeview rows/headings, tabs and input styling. Existing register transaction and discount code preserved.

IMPORTANT: This is a FIRST UI PASS, not a complete redesign of every internal form. Legacy Hold/Recall/Stock/Customer form layouts remain pending full screen-by-screen modernisation.

Run START_FREEDOM_POS.bat. Use only test data. Staff PIN remains disabled as in v0.39. No live EFTPOS.
