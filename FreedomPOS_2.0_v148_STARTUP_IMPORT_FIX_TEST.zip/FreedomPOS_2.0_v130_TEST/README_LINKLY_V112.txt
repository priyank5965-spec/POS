Freedom POS v0.112 — LINKLY STATUS CHECK — TEST ONLY

Settings & Tools > EFTPOS — TEST / LIVE MODE > LINKLY STATUS > SAVE SETTINGS.
Then click EFTPOS on a test sale. Freedom POS sends ONLY a read-only Linkly status inquiry to localhost port 2011. It shows the Linkly response (including offline) and ALWAYS BLOCKS checkout. No sale, stock movement, purchase, refund or settlement occurs in this mode.

TEST mode continues to use simulated payment approvals. LIVE mode is locked.

This build does not integrate real card payments. No physical Linkly terminal was available for end-to-end verification. Tested with mock TCP Linkly replies only.
