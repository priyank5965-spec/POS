v0.63 TEST ONLY — Register Settings
Settings & Tools > Register Settings.
Functional settings: auto-scan enable/delay, default quantity, duplicate scan merge, register ID and saved opening float.
Other sections are visible with honest not-yet-connected descriptions. No real hardware or security changes.
TEST only; full Windows UI and regression testing outstanding.
