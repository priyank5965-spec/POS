"""v0.87 TEST: register quantity-prefix and keyboard cash tender, offline only."""
import re
import tkinter as tk
from tkinter import messagebox
from decimal import Decimal, InvalidOperation

MAX_QTY=9999

def parse_qty_prefix(raw):
    m=re.fullmatch(r'([1-9][0-9]{0,3})\*(.*)',str(raw).strip())
    if not m:return None
    return int(m.group(1)),m.group(2).strip()

def parse_tender(raw,total):
    raw=str(raw).strip()
    if not raw:return total
    try:d=Decimal(raw)
    except InvalidOperation:raise ValueError('Enter a valid cash amount')
    if not d.is_finite() or d<0 or d.as_tuple().exponent < -2 or d>Decimal('999999.99'):
        raise ValueError('Enter a valid amount with up to two decimal places')
    return int(d*100)

def install(cls):
    old_pos=cls.pos;old_scan=cls.scan;old_quick=cls.quick;old_department_sale=cls.department_sale
    def pos(self):
        old_pos(self)
        self._quantity_prefix=1
        self._quantity_hint=tk.StringVar(value='Qty × 1 — type 5* then scan or choose a product')
        # Display pending quantity without altering existing register layout.
        self._quantity_label=tk.Label(self.code.master,textvariable=self._quantity_hint,font=('Segoe UI',9),fg='#111111')
        self._quantity_label.pack(side='left',padx=4)
        self.code.bind('<Return>',lambda e:enter_scan(self,e))
        self.code.bind('<KP_Enter>',lambda e:enter_scan(self,e))
        self.code.bind('<Escape>',lambda e:cancel_quantity(self,e))
        self.sale_tree.bind('<Return>',lambda e:edit_selected(self,e))
        self.sale_tree.bind('<KP_Enter>',lambda e:edit_selected(self,e))
        self.sale_tree.bind('<Up>',lambda e:move_row(self,-1))
        self.sale_tree.bind('<Down>',lambda e:move_row(self,1))
        # Press Enter from a focused non-editable register control to open tender.
        self.root.bind('<Return>',lambda e:register_enter(self,e),add='+')
        self.root.bind('<KP_Enter>',lambda e:register_enter(self,e),add='+')
    def hint(self):
        if hasattr(self,'_quantity_hint'):
            self._quantity_hint.set('Qty × '+str(getattr(self,'_quantity_prefix',1)))
    def cancel_quantity(self,event=None):
        self._quantity_prefix=1
        if hasattr(self,'code') and self.code.winfo_exists():self.code.delete(0,'end');self.code.focus_set()
        hint(self)
        return 'break'
    def enter_scan(self,event=None):
        raw=self.code.get().strip()
        parsed=parse_qty_prefix(raw)
        if parsed:
            qty,code=parsed
            if not code:
                self._quantity_prefix=qty;self.code.delete(0,'end');hint(self);return 'break'
            self._quantity_prefix=qty
            self.code.delete(0,'end');self.code.insert(0,code)
            try:scan(self)
            finally:self._quantity_prefix=1;hint(self)
            return 'break'
        if not raw:
            if self.cart:self.register_cash()
            return 'break'
        scan(self);return 'break'
    def scan(self):
        raw=self.code.get().strip()
        parsed=parse_qty_prefix(raw)
        if parsed:
            qty,code=parsed
            if not code:
                self._quantity_prefix=qty;self.code.delete(0,'end');hint(self);return
            self._quantity_prefix=qty
            self.code.delete(0,'end');self.code.insert(0,code)
        try:
            code=self.code.get().strip()
            product=self.product_by_code(code)
            if product:
                self.code.delete(0,'end')
                self.add_to_cart(product,qty=self._quantity_prefix)
            else:
                old_scan(self)
        finally:
            self._quantity_prefix=1;hint(self)
    def quick(self,pid):
        qty=self._quantity_prefix
        raw=self.code.get().strip() if hasattr(self,'code') and self.code.winfo_exists() else ''
        parsed=parse_qty_prefix(raw)
        if parsed and not parsed[1]:qty=parsed[0]
        # Do not consume a typed department amount as a quantity prefix.
        try:
            if qty==1:return old_quick(self,pid)
            p=self.db.execute('SELECT * FROM products WHERE id=?',(pid,)).fetchone()
            if p:self.add_to_cart(p,qty=qty)
        finally:
            self._quantity_prefix=1
            if parsed and not parsed[1]:self.code.delete(0,'end')
            hint(self)
    def department_sale(self,department_id,amount):
        qty=self._quantity_prefix
        before=len(self.cart)
        old_department_sale(self,department_id,amount)
        if len(self.cart)>before and self.cart[-1].get('kind')=='DEPARTMENT SALE' and qty>1:
            self.cart[-1]['qty']=qty;self.refresh_cart()
        self._quantity_prefix=1;hint(self)
    def register_cash(self):
        if not self.cart:return self.warn('Add items before taking payment.')
        if any(x.get('epay_pending') or x.get('epay_unissued') for x in self.cart):
            return self.warn('Unissued E-PAY items cannot be paid for.')
        total=int(self.total())
        if total<=0:return self.warn('Keyboard cash tender requires a positive sale total.')
        w=tk.Toplevel(self.root);w.title('Cash Tender — KEYBOARD TEST ONLY');w.geometry('510x365');w.transient(self.root)
        try:w.grab_set()
        except tk.TclError:pass
        tk.Label(w,text='CASH TENDER — TEST ONLY',font=('Segoe UI',16,'bold'),fg='#111111').pack(pady=13)
        tk.Label(w,text='TOTAL DUE  ${:,.2f}'.format(total/100),font=('Segoe UI',19,'bold')).pack(pady=5)
        tk.Label(w,text='Leave empty and press Enter for exact cash.',font=('Segoe UI',10)).pack()
        amount=tk.StringVar(value='');field=tk.Entry(w,textvariable=amount,font=('Segoe UI',21),justify='right');field.pack(fill='x',padx=25,pady=12)
        feedback=tk.Label(w,font=('Segoe UI',13,'bold'));feedback.pack(pady=5)
        def update(*_):
            try:
                tender=parse_tender(amount.get(),total)
                feedback.config(text=('CHANGE ${:,.2f}'.format((tender-total)/100) if tender>=total else 'REMAINING ${:,.2f}'.format((total-tender)/100)),fg='#137a35' if tender>=total else '#a53a20')
            except ValueError:feedback.config(text='Invalid cash amount',fg='#a53a20')
        amount.trace_add('write',update);update()
        def pay(event=None):
            try:tender=parse_tender(amount.get(),total)
            except ValueError as ex:return messagebox.showwarning('Invalid cash tender',str(ex),parent=w)
            if tender<total:return messagebox.showwarning('Insufficient cash','Cash received is less than the sale total.',parent=w)
            # Keyboard cash tender: Enter records immediately (still TEST ONLY).
            self._pending_cash_tender=tender
            if self.checkout('CASH'):
                w.destroy()
            else:self._pending_cash_tender=None
        tk.Button(w,text='RECORD CASH (TEST)',command=pay,bg='#d9efdf',font=('Segoe UI',12,'bold')).pack(fill='x',padx=25,pady=8)
        tk.Button(w,text='CANCEL (ESC)',command=w.destroy).pack()
        field.bind('<Return>',pay);field.bind('<KP_Enter>',pay)
        w.bind('<Escape>',lambda e:(w.destroy(),'break')[1]);field.focus_set()
    def register_enter(self,event):
        try:
            if not self.code.winfo_exists() or not self.code.winfo_ismapped():return
            if event.widget.winfo_toplevel()!=self.root:return
            focused=self.root.focus_get()
            if focused is self.code:return # handled by code's binding
            if focused is self.sale_tree:return # grid editing
            if isinstance(focused,(tk.Entry,tk.Text,tk.Spinbox)):return
            if focused is self.root and self.cart:
                self.register_cash();return 'break'
        except tk.TclError:pass
    def move_row(self,direction):
        rows=self.sale_tree.get_children()
        if not rows:return 'break'
        selected=self.sale_tree.selection()
        idx=rows.index(selected[0]) if selected and selected[0] in rows else (0 if direction>0 else len(rows)-1)
        idx=max(0,min(len(rows)-1,idx+direction))
        self.sale_tree.selection_set(rows[idx]);self.sale_tree.focus(rows[idx]);self.sale_tree.see(rows[idx]);return 'break'
    def edit_selected(self,event):
        if self.sale_tree.selection():self.edit_line()
        return 'break'
    cls.pos=pos;cls.scan=scan;cls.quick=quick;cls.department_sale=department_sale;cls.register_cash=register_cash
