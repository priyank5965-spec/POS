import tkinter as tk
from PIL import ImageGrab
from freedom_pos import ExtendedApp
r=tk.Tk(); r.geometry('1548x930+0+0'); app=ExtendedApp(r); app.pos()
def snap():
 r.update(); ImageGrab.grab(bbox=(0,0,1548,930)).save('/mnt/data/FreedomPOS_v018_Register_Actual_Preview.png');r.destroy()
r.after(1400,snap);r.mainloop()
