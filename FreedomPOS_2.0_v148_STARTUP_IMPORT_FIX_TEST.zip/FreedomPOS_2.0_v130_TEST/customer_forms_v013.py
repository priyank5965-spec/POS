"""Full customer details form for Freedom POS offline test; no live billing."""
import tkinter as tk
from tkinter import ttk, messagebox
import re

FIELDS=[('name','Customer / Business Name *'),('contact','Contact Person'),('phone','Phone'),('mobile','Mobile'),('email','Email'),('address1','Address Line 1'),('address2','Address Line 2'),('suburb','Suburb / Town'),('state','State'),('postcode','Postcode'),('account_no','Customer Account Number'),('abn','ABN (optional)'),('delivery','Collection / Delivery'),('billing','Account Billing Method'),('terms','Payment Terms'),('notes','Customer Notes')]
EXTRA=[('contact','TEXT NOT NULL DEFAULT \'\''),('mobile','TEXT NOT NULL DEFAULT \'\''),('address1','TEXT NOT NULL DEFAULT \'\''),('address2','TEXT NOT NULL DEFAULT \'\''),('suburb','TEXT NOT NULL DEFAULT \'\''),('state','TEXT NOT NULL DEFAULT \'\''),('postcode','TEXT NOT NULL DEFAULT \'\''),('account_no','TEXT NOT NULL DEFAULT \'\''),('abn','TEXT NOT NULL DEFAULT \'\''),('delivery','TEXT NOT NULL DEFAULT \'Shop Collection\''),('billing','TEXT NOT NULL DEFAULT \'Manual\''),('terms','TEXT NOT NULL DEFAULT \'\''),('notes','TEXT NOT NULL DEFAULT \'\''),('active','INTEGER NOT NULL DEFAULT 1')]

def install(cls):
 old_init=cls.__init__
 def init(self,*args,**kwargs):
  old_init(self,*args,**kwargs)
  existing={r[1] for r in self.db.execute('PRAGMA table_info(customers)')}
  with self.db:
   for col,typ in EXTRA:
    if col not in existing:self.db.execute(f'ALTER TABLE customers ADD COLUMN {col} {typ}')
   self.db.execute("CREATE TABLE IF NOT EXISTS customer_emails(customer_id INTEGER PRIMARY KEY,email TEXT NOT NULL DEFAULT '')")
 cls.__init__=init
 def customers(self):
  self.clear();self.header('CUSTOMERS & ACCOUNTS')
  top=tk.Frame(self.root,bg='white');top.pack(fill='x',padx=12,pady=9)
  search=tk.StringVar();tk.Label(top,text='SEARCH',bg='white').pack(side='left',padx=5)
  tk.Entry(top,textvariable=search,font=('Segoe UI',12),width=26).pack(side='left',padx=5)
  body=tk.Frame(self.root,bg='white');body.pack(fill='both',expand=True,padx=10)
  cols=('ID','Account','Name','Phone','Mobile','Email','Suburb','Balance')
  t=ttk.Treeview(body,columns=cols,show='headings',selectmode='browse')
  widths=(55,105,250,135,135,250,125,125)
  for col,width in zip(cols,widths):t.heading(col,text=col);t.column(col,width=width,anchor='w')
  t.pack(side='left',fill='both',expand=True)
  scroll=ttk.Scrollbar(body,orient='vertical',command=t.yview);scroll.pack(side='right',fill='y');t.configure(yscrollcommand=scroll.set)
  def refresh(*_):
   t.delete(*t.get_children());term=search.get().lower().strip()
   sql="SELECT c.*,COALESCE(e.email,'') email FROM customers c LEFT JOIN customer_emails e ON e.customer_id=c.id ORDER BY c.name"
   for r in self.db.execute(sql):
    if term and term not in ' '.join(str(r[k] or '') for k in ('id','name','phone','mobile','account_no','email')).lower():continue
    t.insert('','end',iid=str(r['id']),values=(r['id'],r['account_no'],r['name'],r['phone'],r['mobile'],r['email'],r['suburb'],f'${r["balance"]/100:.2f}'))
  search.trace_add('write',refresh)
  def selected():
   ids=t.selection()
   if not ids:messagebox.showwarning('Select customer','Select a customer from the grid first.',parent=self.root);return None
   return int(ids[0])
  def form(cid=None):
   record=self.db.execute("SELECT c.*,COALESCE(e.email,'') email FROM customers c LEFT JOIN customer_emails e ON e.customer_id=c.id WHERE c.id=?",(cid,)).fetchone() if cid else None
   w=tk.Toplevel(self.root);w.title('EDIT CUSTOMER' if cid else 'ADD CUSTOMER — COMPLETE DETAILS');w.geometry('980x740');w.minsize(790,610);w.transient(self.root);w.grab_set()
   head=tk.Frame(w,bg='white');head.pack(fill='x');tk.Label(head,text='CUSTOMER DETAILS  •  '+('EDIT' if cid else 'NEW CUSTOMER'),bg='white',fg='#111111',font=('Segoe UI',17,'bold'),padx=20,pady=13).pack(anchor='w')
   area=tk.Frame(w,padx=20,pady=14);area.pack(fill='both',expand=True)
   for col in (1,3):area.columnconfigure(col,weight=1)
   entries={};errors=tk.StringVar()
   for i,(key,label) in enumerate(FIELDS):
    row=i//2;left=(i%2)*2
    tk.Label(area,text=label,anchor='w').grid(row=row,column=left,sticky='w',padx=(0,8),pady=8)
    if key in ('delivery','billing','state'):
     options={'delivery':['Shop Collection','Home Delivery','Subagent','Other'],'billing':['Manual','Automatic Account','Pay on Collection','Prepaid'],'state':['','QLD','NSW','VIC','SA','WA','TAS','NT','ACT']}[key]
     widget=ttk.Combobox(area,values=options,state='readonly' if key!='state' else 'normal',font=('Segoe UI',11))
     widget.set(str(record[key]) if record and record[key] is not None else ('Shop Collection' if key=='delivery' else 'Manual' if key=='billing' else ''))
    else:
     widget=tk.Entry(area,font=('Segoe UI',11))
     value=record[key] if record and key in record.keys() else ''
     if value:widget.insert(0,str(value))
    widget.grid(row=row,column=left+1,sticky='ew',padx=(0,16),pady=6)
    entries[key]=widget
   active=tk.BooleanVar(value=bool(record['active']) if record else True)
   ttk.Checkbutton(area,text='Active customer',variable=active).grid(row=9,column=0,columnspan=2,sticky='w',pady=9)
   tk.Label(area,text='Account balance is maintained by sales and payments; it cannot be changed in this form.',fg='#8b4a16').grid(row=9,column=2,columnspan=2,sticky='w')
   tk.Label(area,textvariable=errors,fg='#a51b1b',font=('Segoe UI',10,'bold')).grid(row=10,column=0,columnspan=4,sticky='w',pady=7)
   actions=tk.Frame(w,padx=18,pady=12);actions.pack(fill='x',side='bottom')
   def save():
    d={k:v.get().strip() for k,v in entries.items()}
    if not d['name']:errors.set('Customer / Business Name is required.');entries['name'].focus_set();return
    if d['email'] and not re.fullmatch(r'[^\s@]+@[^\s@]+\.[^\s@]+',d['email']):errors.set('Please enter a valid email address.');entries['email'].focus_set();return
    if d['postcode'] and not re.fullmatch(r'\d{4}',d['postcode']):errors.set('Australian postcode must be four digits.');entries['postcode'].focus_set();return
    if d['account_no']:
     dup=self.db.execute('SELECT id FROM customers WHERE account_no=? AND id!=?',(d['account_no'],cid or -1)).fetchone()
     if dup:errors.set('This customer account number is already in use.');return
    columns=['name','phone']+[key for key,_ in EXTRA if key!='active']
    values=[d['name'],d['phone']]+[d[k] for k in columns[2:]]
    try:
     with self.db:
      if cid:
       self.db.execute('UPDATE customers SET '+','.join(k+'=?' for k in columns)+',active=? WHERE id=?',values+[int(active.get()),cid]);customer_id=cid
      else:
       cur=self.db.execute('INSERT INTO customers('+','.join(columns)+',active) VALUES('+','.join('?' for _ in columns)+',?)',values+[int(active.get())]);customer_id=cur.lastrowid
      self.db.execute('INSERT INTO customer_emails(customer_id,email) VALUES(?,?) ON CONFLICT(customer_id) DO UPDATE SET email=excluded.email',(customer_id,d['email']))
     self.log('CUSTOMER',f'{"Updated" if cid else "Added"} customer #{customer_id}: {d["name"]}')
    except Exception as ex:errors.set('Unable to save: '+str(ex));return
    w.destroy();refresh()
   tk.Button(actions,text='SAVE CUSTOMER',command=save,bg='white',fg='#111111',font=('Segoe UI',12,'bold'),padx=20,pady=8).pack(side='right',padx=6)
   tk.Button(actions,text='CANCEL',command=w.destroy,font=('Segoe UI',11),padx=15,pady=8).pack(side='right',padx=6)
   entries['name'].focus_set()
  self.btn(top,'ADD CUSTOMER',lambda:form(),size=10,height=1).pack(side='left',padx=4)
  self.btn(top,'EDIT SELECTED',lambda:form(x) if (x:=selected()) is not None else None,size=10,height=1).pack(side='left',padx=4)
  self.btn(top,'RECORD PAYMENT',self.account_payment,size=10,height=1).pack(side='left',padx=4)
  self.btn(top,'CUSTOMER PUTAWAYS',self.putaways,size=10,height=1).pack(side='left',padx=4)
  if hasattr(self,'customer_email_center'):self.btn(top,'INVOICES / STATEMENTS',self.customer_email_center,size=10,height=1).pack(side='left',padx=4)
  t.bind('<Double-1>',lambda _:form(x) if (x:=selected()) is not None else None)
  tk.Label(self.root,text='TEST ONLY • Customer details and email addresses are saved. Full account billing and statements remain under development.',bg='white',fg='#98511a').pack(pady=9)
  refresh()
 cls.customers=customers
