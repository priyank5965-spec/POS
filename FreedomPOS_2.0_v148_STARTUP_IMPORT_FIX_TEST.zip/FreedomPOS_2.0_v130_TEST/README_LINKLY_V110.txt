Freedom POS 2.0 v0.110 — LINKLY CONNECTION PREPARATION — TEST ONLY

WHAT IS IMPLEMENTED
- Settings & Tools > Linkly EFTPOS — Connection Setup.
- Host/IP and port fields; connection test opens and closes a TCP socket without sending data.
- Default host 127.0.0.1 and port 2011 for Linkly EFT-Client TCP listener.
- UI test runs on a background thread so a slow connection does not freeze the register.
- No modifications to existing sales, invoice, stock or payment posting.

NOT IMPLEMENTED / NOT SAFE FOR LIVE PAYMENTS
- No Linkly transaction requests, terminal pairing, card purchase/refund, receipt or settlement processing.
- EFTPOS register buttons remain SIMULATED; do NOT use them for real payments.
- TCP connectivity does not prove EFT-Client readiness or card-terminal pairing.
- Real integration requires Linkly virtual PIN pad test environment, protocol/SDK work,
  explicit approval handling, recovery of uncertain transactions, split tenders, refunds,
  duplicate prevention, receipt handling and Linkly accreditation.

USER SETUP
1. Install Linkly On-Premises EFT-Client using official Linkly instructions.
2. Enable its TCP/IP listener (normally port 2011).
3. Open Settings & Tools > Linkly EFTPOS — Connection Setup and click TEST.
4. If the connection succeeds, report the result and your terminal model to continue integration.
Do not provide merchant passwords or credentials in chat.

OFFICIAL DOCUMENTATION
https://www.linkly.com.au/apidoc/TCPIP/
https://linkly.zendesk.com/hc/en-au/articles/45822679091609-Linkly-On-Premises-Development-Guide
