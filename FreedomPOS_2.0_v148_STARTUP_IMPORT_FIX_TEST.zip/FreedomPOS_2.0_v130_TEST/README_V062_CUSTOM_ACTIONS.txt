Freedom POS 2.0 v0.62 — TEST ONLY
Settings & Tools > Custom Register Actions
New > name > shortcut field (press keys) > select step type > barcode/quantity if relevant > Add Step > Save Action > Save All Changes.
Supported: open departments, stock lookup, last receipt, add product by barcode and quantity. Multi-step: one or more add-product steps followed optionally by one screen-opening step. No auto checkout, no refund, no untrusted code execution.
Duplicate detection checks both built-in and custom shortcuts. Custom actions are stored in custom_actions_v062.json.
Known limitations: Windows UI and physical scanner testing not performed. Changing a built-in shortcut later to collide with a custom shortcut is not yet checked by the built-in manager; custom dispatch gives built-ins priority.
