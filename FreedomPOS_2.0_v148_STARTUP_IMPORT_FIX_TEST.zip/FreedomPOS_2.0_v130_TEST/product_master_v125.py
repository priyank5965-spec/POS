"""Product Master v125: incremental schema + integrated keyboard-first editor."""
import tkinter as tk
from tkinter import ttk, messagebox
import sqlite3, secrets
from decimal import Decimal, InvalidOperation, ROUND_HALF_UP

FIELDS={'General':[('name','Description'),('barcode','Primary barcode'),('plu','SKU / PLU'),('category','Category / Department'),('supplier_name','Primary supplier'),('sales_tax','GST treatment'),('supplier_cost','Supplier cost ($ ex GST)'),('price','Selling price / RRP ($ incl GST)'),('last_cost','Last purchase cost ($ ex GST)'),('estimated_cost','Estimated cost ($ ex GST)'),('purchase_tax','Purchase GST code'),('subcategory','Subcategory'),('brand','Brand'),('product_type','Product type'),('status','Status'),('short_description','Receipt description'),('notes','Notes')],
'Pricing & GST':[],
'Inventory':[('minimum_stock','Minimum stock'),('target_stock','Target stock'),('maximum_stock','Maximum stock'),('stock_location','Stock location'),('track_stock','Track stock (1/0)')],
'Packs & Units':[('base_unit','Base stock unit'),('purchase_unit','Purchase unit'),('units_per_pack','Units per pack'),('pack_barcode','Pack barcode'),('pack_price','Pack selling price ($)')],
'POS Settings':[('quick_sell_code','Register Shortcut Key (A-Z)'),('pos_visible','Show on POS (1/0)'),('discount_allowed','Discount allowed (1/0)'),('price_override','Price override allowed (1/0)'),('serial_required','Serial number required (1/0)'),('age_check','Age verification (1/0)')],
'Special Products':[('publication_title','Publication title'),('issue_number','Issue number'),('issue_date','Issue date YYYY-MM-DD'),('on_sale','On sale YYYY-MM-DD'),('off_sale','Off sale YYYY-MM-DD'),('return_date','Return deadline YYYY-MM-DD'),('return_method','Return method'),('edition_type','Newspaper edition type'),('returnable','Returnable (1/0)')]}
DEFAULT={'category':'General','product_type':'Stocked','status':'Active','sales_tax':'GST 10%','purchase_tax':'GST 10%','base_unit':'Each','purchase_unit':'Each','units_per_pack':'1','track_stock':'1','pos_visible':'1','discount_allowed':'1','price_override':'1','returnable':'1','minimum_stock':'0','target_stock':'0','maximum_stock':'0'}
MONEY={'price','last_cost','estimated_cost','supplier_cost','pack_price'}
INTEGER={'minimum_stock','target_stock','maximum_stock','units_per_pack','track_stock','pos_visible','discount_allowed','price_override','serial_required','age_check','returnable'}

def _attach_autocomplete(widget, variable, page, window, quick_add=None):
    """Shared, anchored dropdown. Unmatched names offer full-form Quick Add."""
    state={'popup':None,'list':None,'matches':[],'selected':0,'add_label':None}
    widget._has_autocomplete=True
    def close():
        popup=state['popup']
        if popup is not None:
            try:popup.destroy()
            except tk.TclError:pass
        state.update(popup=None,list=None,matches=[],selected=0,add_label=None)
    def reposition():
        popup=state['popup']
        if popup is None:return
        try:
            if not widget.winfo_viewable():close();return
            height=min(len(state['matches']),7)*27+4
            popup.geometry(f"{max(100,widget.winfo_width())}x{height}+{widget.winfo_rootx()}+{widget.winfo_rooty()+widget.winfo_height()}")
            popup.lift()
        except tk.TclError:close()
    def move(back=False):
        close()
        step=getattr(widget,'_focus_step',None)
        if step:step(widget,back)
        else:(widget.tk_focusPrev() if back else widget.tk_focusNext()).focus_set()
        return 'break'
    def choose(move_after=False):
        if not state['matches']:return move() if move_after else 'break'
        choice=state['matches'][state['selected']]
        if state['add_label'] and choice==state['add_label']:
            close()
            if quick_add:quick_add(variable.get().strip())
            return 'break'
        variable.set(choice)
        close()
        return move() if move_after else 'break'
    def show(event=None):
        prefix=variable.get().strip()
        all_choices=getattr(widget,'_all_choices',[])
        matches=[v for v in all_choices if v and v.casefold().startswith(prefix.casefold())][:7] if prefix else []
        add_label=None
        if prefix and quick_add and not any(v.casefold()==prefix.casefold() for v in all_choices):
            add_label='+ Create new '+getattr(widget,'_master_kind','record')+': '+prefix
            matches=matches[:6]+[add_label]
        if not matches:close();return
        state['matches']=matches;state['selected']=0;state['add_label']=add_label
        if state['popup'] is None:
            popup=tk.Toplevel(window);popup.overrideredirect(True)
            popup.configure(bg='#263441')
            lb=tk.Listbox(popup,exportselection=False,activestyle='none',takefocus=0,
                font=('Segoe UI',10),bg='#263441',fg='white',selectbackground='#4f7190',
                selectforeground='white',highlightthickness=0,bd=1,relief='solid')
            lb.pack(fill='both',expand=True)
            state['popup']=popup;state['list']=lb
            def pick(e):
                idx=lb.nearest(e.y)
                if 0<=idx<len(state['matches']):
                    state['selected']=idx;choose()
                return 'break'
            lb.bind('<ButtonRelease-1>',pick)
        lb=state['list'];lb.delete(0,'end')
        for item in matches:lb.insert('end',item)
        lb.selection_set(0);reposition()
    def arrow(e):
        if state['popup'] is None:show()
        if not state['matches']:return 'break'
        state['selected']=(state['selected']+(1 if e.keysym=='Down' else -1))%len(state['matches'])
        lb=state['list'];lb.selection_clear(0,'end');lb.selection_set(state['selected']);lb.see(state['selected'])
        return 'break'
    def keyrelease(e):
        if e.keysym not in ('Return','Tab','ISO_Left_Tab','Escape','Up','Down','Left','Right','Shift_L','Shift_R'):show()
    widget.bind('<KeyRelease>',keyrelease,add='+')
    widget.bind('<Return>',lambda e:choose(move_after=True))
    widget.bind('<Tab>',lambda e:move() if state['add_label'] else (choose(move_after=True) if state['matches'] else move()))
    widget.bind('<ISO_Left_Tab>',lambda e:move(True))
    widget.bind('<Shift-Tab>',lambda e:move(True))
    widget.bind('<Down>',arrow);widget.bind('<Up>',arrow)
    widget.bind('<Escape>',lambda e:(close(),'break')[1])
    def on_focusout(e):
        window.after(200,lambda:close() if widget.winfo_exists() and window.focus_get()!=widget else None)
    widget.bind('<FocusOut>',on_focusout,add='+')
    widget.bind('<Configure>',lambda e:reposition(),add='+')
    window.bind('<Configure>',lambda e:reposition(),add='+')
    widget._suggestion_state=state

def schema(db):
    db.execute('CREATE TABLE IF NOT EXISTS product_master_extra(product_id INTEGER PRIMARY KEY REFERENCES products(id), payload TEXT NOT NULL DEFAULT "{}")')
    db.execute('CREATE TABLE IF NOT EXISTS product_barcodes(barcode TEXT PRIMARY KEY, product_id INTEGER NOT NULL REFERENCES products(id), kind TEXT NOT NULL DEFAULT "additional", quantity INTEGER NOT NULL DEFAULT 1)')
    db.execute('CREATE INDEX IF NOT EXISTS idx_product_barcodes_product ON product_barcodes(product_id)')
    db.execute('CREATE TABLE IF NOT EXISTS supplier_master_v125(id INTEGER PRIMARY KEY,name TEXT NOT NULL UNIQUE, capabilities TEXT NOT NULL DEFAULT "General Merchandise")')
    db.execute('CREATE TABLE IF NOT EXISTS product_supplier_v125(product_id INTEGER NOT NULL REFERENCES products(id),supplier_id INTEGER NOT NULL REFERENCES supplier_master_v125(id),supplier_code TEXT NOT NULL DEFAULT "",pack_qty INTEGER NOT NULL DEFAULT 1,cost_cents INTEGER NOT NULL DEFAULT 0,PRIMARY KEY(product_id,supplier_id))')
    db.execute('CREATE TABLE IF NOT EXISTS product_audit_v125(id INTEGER PRIMARY KEY,product_id INTEGER NOT NULL,stamp TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,action TEXT NOT NULL,details TEXT NOT NULL)')
    db.execute('CREATE TABLE IF NOT EXISTS stock_ledger_v125(id INTEGER PRIMARY KEY,product_id INTEGER NOT NULL REFERENCES products(id),stamp TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,quantity INTEGER NOT NULL,reason TEXT NOT NULL,source_ref TEXT NOT NULL DEFAULT "",cost_cents INTEGER NOT NULL DEFAULT 0)')
    db.execute('CREATE TABLE IF NOT EXISTS stock_arrivals_v125(id INTEGER PRIMARY KEY,supplier_id INTEGER REFERENCES supplier_master_v125(id),invoice_ref TEXT NOT NULL,stamp TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,status TEXT NOT NULL DEFAULT "DRAFT",UNIQUE(supplier_id,invoice_ref))')
    db.execute('CREATE TABLE IF NOT EXISTS stock_arrival_lines_v125(id INTEGER PRIMARY KEY,arrival_id INTEGER NOT NULL REFERENCES stock_arrivals_v125(id),product_id INTEGER NOT NULL REFERENCES products(id),quantity INTEGER NOT NULL,cost_cents INTEGER NOT NULL)')
    # Test suppliers are only added to an empty supplier list; existing records are untouched.
    if not db.execute('SELECT 1 FROM supplier_master_v125 LIMIT 1').fetchone():
        db.executemany('INSERT INTO supplier_master_v125(name,capabilities) VALUES(?,?)',[
            ('John Sands','Greeting Cards'),('Gordon & Gotch','Magazines'),
            ('Are Direct','Magazines,Newspapers'),('News Corp','Newspapers'),
            ('General Wholesale','General Merchandise')])
    db.commit()

def make_barcode(db):
    # Private store prefix 29; not for global retail distribution.
    for _ in range(100):
        first='29'+''.join(str(secrets.randbelow(10)) for _ in range(10))
        check=(10-sum(int(c)*(1 if i%2==0 else 3) for i,c in enumerate(first))%10)%10
        code=first+str(check)
        if not db.execute('SELECT 1 FROM products WHERE barcode=?',(code,)).fetchone() and not db.execute('SELECT 1 FROM product_barcodes WHERE barcode=?',(code,)).fetchone():return code
    raise RuntimeError('Could not allocate a unique barcode')

def install(cls):
    old_init=cls.__init__
    def init(self,*a,**k):
        old_init(self,*a,**k);schema(self.db)
    cls.__init__=init
    old_products=cls.products
    def products(self):
        old_products(self)
        bar=self.prod_tree.master
        tk.Button(bar,text='PRODUCT MASTER  (TABS)',command=lambda:self.product_master(),bg='#12324A',fg='white',font=('Segoe UI',10,'bold')).pack(side='bottom',anchor='w',padx=14,pady=4)
    cls.products=products
    def add_product(self):self.product_master()
    def edit_product(self):
        p=self.chosen_product()
        if p:self.product_master(p['id'])
        else:messagebox.showwarning('Product Master','Select a product first.',parent=self.root)
    cls.add_product=add_product;cls.edit_product=edit_product
    def product_master(self,pid=None):
        import json
        schema(self.db)
        p=self.db.execute('SELECT * FROM products WHERE id=?',(pid,)).fetchone() if pid else None
        extra=json.loads(self.db.execute('SELECT payload FROM product_master_extra WHERE product_id=?',(pid,)).fetchone()[0]) if pid and self.db.execute('SELECT 1 FROM product_master_extra WHERE product_id=?',(pid,)).fetchone() else {}
        win=tk.Toplevel(self.root);win.configure(bg='white');win.title('Freedom POS — Product Master'+(' — Edit '+str(pid) if pid else ' — New'));win.geometry('1180x735');win.minsize(990,620)
        style=ttk.Style(win)
        style.configure('PM.White.TFrame',background='white')
        style.configure('PM.White.TLabel',background='white',foreground='#111111',font=('Segoe UI',10))
        style.configure('PM.White.TNotebook',background='#f5f6f8',borderwidth=0)
        style.configure('PM.White.TNotebook.Tab',background='#f2f2f2',foreground='#111111',padding=(12,7),font=('Segoe UI',10))
        style.map('PM.White.TNotebook.Tab',background=[('selected','white')],foreground=[('selected','#000000')])
        style.configure('PM.White.TEntry',fieldbackground='white',foreground='#111111',padding=3)
        style.configure('PM.White.TCombobox',fieldbackground='white',foreground='#111111',padding=3)
        style.configure('PM.White.TButton',font=('Segoe UI',10),padding=4)
        # Modern navigation strip, with classic compact data-entry forms.
        nav=tk.Frame(win,bg='#253344',height=43);nav.pack(fill='x');nav.pack_propagate(False)
        tk.Label(nav,text='Freedom POS',bg='#253344',fg='white',font=('Segoe UI',12,'bold')).pack(side='left',padx=(15,24))
        tk.Label(nav,text='BACK OFFICE  /  PRODUCTS',bg='#253344',fg='#dbe3ec',font=('Segoe UI',9)).pack(side='left')
        head=tk.Frame(win,bg='white');head.pack(fill='x')
        tk.Label(head,text='Product Master',bg='white',fg='#111111',font=('Segoe UI',13,'bold')).pack(side='left',padx=(15,8),pady=10)
        tk.Label(head,text=('Edit product #'+str(pid) if pid else 'New product'),bg='white',fg='#5b6570',font=('Segoe UI',10)).pack(side='left')
        tk.Frame(win,bg='#d8dde3',height=1).pack(fill='x')
        nb=ttk.Notebook(win,style='PM.White.TNotebook');nb.pack(fill='both',expand=True,padx=12,pady=(10,6))
        vars={};frames={};general_widgets=[];focus_by_tab={}
        for tab,fields in FIELDS.items():
            page=ttk.Frame(nb,padding=(13,13),style='PM.White.TFrame');nb.add(page,text=tab);frames[tab]=page
            for i,(key,label) in enumerate(fields):
                ttk.Label(page,text=label,style='PM.White.TLabel').grid(row=i//2,column=(i%2)*2,sticky='w',padx=(7,5),pady=5)
                value=extra.get(key,DEFAULT.get(key,''))
                if p and key in ('name','barcode','category'):value=p[key]
                if key=='category' and not value:value='General'
                if p and key=='price':value=f'{p["price"]/100:.2f}'
                if p and key=='supplier_name':value=p['supplier'] or ''
                if p and key=='supplier_cost':
                    sc=self.db.execute('SELECT ps.cost_cents FROM product_supplier_v125 ps JOIN supplier_master_v125 sm ON sm.id=ps.supplier_id WHERE ps.product_id=? AND sm.name=?',(pid,p['supplier'] or '')).fetchone()
                    if sc:value=f'{sc[0]/100:.2f}'
                if key=='sales_tax' and value=='GST':value='GST 10%'
                if key=='quick_sell_code' and pid:
                    try:
                        q=self.db.execute('SELECT code FROM quick_sell_codes_v136 WHERE product_id=?',(pid,)).fetchone()
                        value=q[0] if q else ''
                    except sqlite3.Error:pass
                var=tk.StringVar(value=str(value));vars[key]=var
                if key in ('supplier_name','category'):
                    if key=='supplier_name':
                        choices=['']+[r[0] for r in self.db.execute('SELECT name FROM supplier_master_v125 ORDER BY name COLLATE NOCASE')]
                    else:
                        choices=['General','Gift','Stationery','Paper','Magazine','Newspaper','Greeting Cards','Books','Toys','Confectionery','Drinks','Other']
                        try:
                            choices=sorted(set(choices+[r[0] for r in self.db.execute('SELECT DISTINCT category FROM products WHERE category IS NOT NULL AND TRIM(category) != ')]),key=str.casefold)
                        except sqlite3.Error:pass
                    e=ttk.Combobox(page,textvariable=var,values=choices,state='normal',width=30,style='PM.White.TCombobox')
                    from shared_masters_v138 import choices as shared_choices
                    choices=shared_choices(self.db,'supplier' if key=='supplier_name' else 'department')
                    e.configure(values=choices)
                    e._all_choices=choices
                    # In-form dropdown: position relative to the actual entry, not the root window.
                    # Separate factory avoids late-binding closures across supplier/category fields.
                    _attach_autocomplete(e, var, page, win)
                    from shared_masters_v138 import create as quick_create
                    kind='supplier' if key=='supplier_name' else 'department'
                    def new_master(prefill=None,kind=kind,w=e,v=var):
                        def done(name):
                            v.set(name)
                            from shared_masters_v138 import choices as shared_choices
                            w._all_choices=shared_choices(self.db,kind);w.configure(values=w._all_choices)
                        quick_create(self,kind,done,win,initial_name=prefill or "")
                    e._quick_add=new_master
                    e._quick_add_kind=kind
                    e._master_kind=kind
                    _attach_autocomplete(e,var,page,win,quick_add=new_master)
                elif key in ('sales_tax','purchase_tax'):
                    e=ttk.Combobox(page,textvariable=var,values=['GST 10%','GST Free','GST Not Applicable'],state='readonly',width=30,style='PM.White.TCombobox')
                else:e=ttk.Entry(page,textvariable=var,width=30,style='PM.White.TEntry')
                e.grid(row=i//2,column=(i%2)*2+1,sticky='ew',padx=(7,5),pady=5)
                focus_by_tab.setdefault(tab,[]).append(e)
                if tab=='General':general_widgets.append(e)
                if key=='barcode':
                    e.bind('<Alt-r>',lambda event:(generate(), 'break')[1]);e.bind('<Alt-R>',lambda event:(generate(), 'break')[1])
            page.columnconfigure(1,weight=1);page.columnconfigure(3,weight=1)
        def generate():
            if vars['barcode'].get().strip() and not messagebox.askyesno('Replace barcode?','This product already has a barcode. Generate a replacement?',parent=win):return
            vars['barcode'].set(make_barcode(self.db))
        win.bind('<Alt-r>',lambda event:generate());win.bind('<Alt-R>',lambda event:generate())
        ttk.Button(frames['General'],text='Generate barcode  (Alt + R)',command=generate).grid(row=(len(FIELDS['General'])+1)//2,column=0,columnspan=2,sticky='w',pady=8)
        # Explicit visual row-major traversal; Tk's creation order otherwise jumps columns.
        def focus_step(widget, backwards=False):
            for items in focus_by_tab.values():
                if widget in items:
                    target=items[(items.index(widget)+(-1 if backwards else 1))%len(items)]
                    target.focus_set()
                    return 'break'
            return None
        for tab,items in focus_by_tab.items():
            for widget in items:
                if not getattr(widget,'_has_autocomplete',False):
                    widget.bind('<Tab>',lambda event,w=widget:focus_step(w),add='+')
                    widget.bind('<ISO_Left_Tab>',lambda event,w=widget:focus_step(w,True),add='+')
                    widget.bind('<Shift-Tab>',lambda event,w=widget:focus_step(w,True),add='+')
                    widget.bind('<Return>',lambda event,w=widget:focus_step(w),add='+')
                else:
                    widget._focus_step=focus_step
        if general_widgets:win.after_idle(general_widgets[0].focus_set)
        ttk.Label(frames['Pricing & GST'],text='Current supplier cost, last purchase cost, estimated cost, GST and retail price are all on General.\n\nThe register uses Selling Price / RRP only.',font=('Segoe UI',11),justify='left').pack(anchor='w',padx=8,pady=10)
        # Supplier tab: editable mapping for one primary supplier, additional mappings in database.
        sf=ttk.Frame(nb,padding=15,style='PM.White.TFrame');nb.insert(2,sf,text='Suppliers')
        for i,(key,label) in enumerate([('supplier_code','Supplier product code'),('supplier_pack','Supplier pack quantity')]):
            ttk.Label(sf,text=label).grid(row=i,column=0,sticky='w',padx=8,pady=10)
            val=(p['supplier'] if p and key=='supplier_name' else p['supplier_code'] if p and key=='supplier_code' else extra.get(key,''))
            vars[key]=tk.StringVar(value=val);ttk.Entry(sf,textvariable=vars[key],width=55).grid(row=i,column=1,sticky='ew',padx=8,pady=10)
        sf.columnconfigure(1,weight=1)
        ttk.Label(sf,text='Primary supplier and supplier cost are now edited on General. To add suppliers, use Supplier Master in a future release.',foreground='#111111').grid(row=3,column=0,columnspan=2,sticky='w',padx=8,pady=12)
        ttk.Label(sf,text='Existing supplier types: '+', '.join(r[0] for r in self.db.execute('SELECT name FROM supplier_master_v125 ORDER BY name')),wraplength=800).grid(row=4,column=0,columnspan=2,sticky='w',padx=8,pady=6)
        # Dedicated barcode tab: primary barcode stays on General, additional codes are stored separately.
        bf=ttk.Frame(nb,padding=16,style='PM.White.TFrame');nb.insert(1,bf,text='Barcodes')
        ttk.Label(bf,text='MULTIPLE BARCODES FOR ONE PRODUCT',font=('Segoe UI',12,'bold')).pack(anchor='w',pady=(0,8))
        ttk.Label(bf,text='Primary barcode is entered on General. Add any other supplier or package barcodes below, ONE BARCODE PER LINE. All these codes will find the same product at checkout.',wraplength=850).pack(anchor='w',pady=(0,12))
        btext=tk.Text(bf,height=10,width=70,font=('Consolas',11),undo=True)
        btext.pack(fill='both',expand=True,pady=5)
        if pid:
            btext.insert('1.0','\n'.join(r[0] for r in self.db.execute('SELECT barcode FROM product_barcodes WHERE product_id=? AND kind="additional"',(pid,))))
        bar_actions=ttk.Frame(bf);bar_actions.pack(fill='x',pady=8)
        def add_barcode_line():
            btext.focus_set()
            if btext.get('1.0','end-1c').strip():btext.insert('end-1c','\n')
        ttk.Button(bar_actions,text='+ Add another barcode',command=add_barcode_line).pack(side='left')
        ttk.Label(bar_actions,text='Example: 9312345678901  (press Enter for the next barcode)',foreground='#111111').pack(side='left',padx=14)
        hf=ttk.Frame(nb,padding=14,style='PM.White.TFrame');nb.add(hf,text='History')
        ht=ttk.Treeview(hf,columns=('Date','Action','Details'),show='headings')
        for col in ('Date','Action','Details'):ht.heading(col,text=col);ht.column(col,width=160 if col!='Details' else 580)
        ht.pack(fill='both',expand=True)
        if pid:
            for r in self.db.execute('SELECT stamp,action,details FROM product_audit_v125 WHERE product_id=? ORDER BY id DESC LIMIT 300',(pid,)):ht.insert('','end',values=tuple(r))
        footer=ttk.Frame(win,padding=10,style='PM.White.TFrame');footer.pack(fill='x')
        ttk.Label(footer,text='RRP = Selling price (register). Stock starts at zero; receive via arrivals.',foreground='#111111').pack(side='left')
        def save():
            try:
                data={key:var.get().strip() for key,var in vars.items()}
                if not data['name']:raise ValueError('Description is required')
                if not data['barcode']:data['barcode']=make_barcode(self.db)
                if not data['category']:data['category']='General'
                category_options=next((w._all_choices for w in general_widgets if hasattr(w,'_all_choices') and 'General' in w._all_choices),[])
                if data['category'] not in category_options:raise ValueError('Select an existing department or choose Create new from the suggestions')
                if data['sales_tax'] not in ('GST 10%','GST Free','GST Not Applicable'):raise ValueError('Choose a valid GST treatment')
                if data['supplier_name'] and not self.db.execute('SELECT 1 FROM supplier_master_v125 WHERE name=?',(data['supplier_name'],)).fetchone():raise ValueError('Select a supplier from the list')
                for key in INTEGER:
                    if data.get(key):
                        v=int(data[key]);
                        if v<0:raise ValueError(key+' cannot be negative')
                for key in MONEY:
                    if data.get(key) and Decimal(data[key])<0:raise ValueError(key+' cannot be negative')
                price=int((Decimal(data['price'] or '0')*100).quantize(Decimal('1'),rounding=ROUND_HALF_UP))
                additional=[s.strip() for s in btext.get('1.0','end').splitlines() if s.strip()]
                if len(set(additional+[data['barcode']]))!=len(additional)+1:raise ValueError('Duplicate barcode in product')
                for code in additional+[data['barcode']]:
                    conflict=self.db.execute('SELECT id FROM products WHERE barcode=? AND id!=?',(code,pid or -1)).fetchone()
                    conflict2=self.db.execute('SELECT product_id FROM product_barcodes WHERE barcode=? AND product_id!=?',(code,pid or -1)).fetchone()
                    if conflict or conflict2:raise ValueError('Barcode already assigned: '+code)
                from quick_sell_v136 import schema as quick_schema, validate_code
                quick_schema(self.db)
                quick=validate_code(self.db,data.get('quick_sell_code',''),exclude_pid=pid)
                payload={k:v for k,v in data.items() if k not in ('name','barcode','category','price','supplier_name','supplier_code')}
                payload['department']=data['category']  # legacy compatibility: single category/department classification
                with self.db:
                    if pid:
                        self.db.execute('UPDATE products SET barcode=?,name=?,price=?,category=?,supplier=?,supplier_code=? WHERE id=?',(data['barcode'],data['name'],price,data['category'],data['supplier_name'],data['supplier_code'],pid));id_=pid
                    else:
                        cur=self.db.execute('INSERT INTO products(barcode,name,price,stock,category,supplier,supplier_code) VALUES(?,?,?,0,?,?,?)',(data['barcode'],data['name'],price,data['category'],data['supplier_name'],data['supplier_code']));id_=cur.lastrowid
                    self.db.execute('INSERT OR REPLACE INTO product_master_extra(product_id,payload) VALUES(?,?)',(id_,json.dumps(payload)))
                    self.db.execute('DELETE FROM product_barcodes WHERE product_id=? AND kind="additional"',(id_,))
                    for code in additional:self.db.execute('INSERT INTO product_barcodes(barcode,product_id,kind) VALUES(?, ?,"additional")',(code,id_))
                    self.db.execute('DELETE FROM quick_sell_codes_v136 WHERE product_id=?',(id_,))
                    if quick:self.db.execute('INSERT INTO quick_sell_codes_v136(code,product_id) VALUES(?,?)',(quick,id_))
                    if data['supplier_name']:
                        sid=self.db.execute('SELECT id FROM supplier_master_v125 WHERE name=?',(data['supplier_name'],)).fetchone()[0]
                        qty=int(data['supplier_pack'] or '1');cost=int((Decimal(data['supplier_cost'] or '0')*100).quantize(Decimal('1'),rounding=ROUND_HALF_UP))
                        if qty<=0:raise ValueError('Supplier pack quantity must be positive')
                        self.db.execute('INSERT OR REPLACE INTO product_supplier_v125(product_id,supplier_id,supplier_code,pack_qty,cost_cents) VALUES(?,?,?,?,?)',(id_,sid,data['supplier_code'],qty,cost))
                    self.db.execute('INSERT INTO product_audit_v125(product_id,action,details) VALUES(?,?,?)',(id_,'EDIT' if pid else 'CREATE','Product Master saved'))
                win.destroy();self.products()
            except (ValueError,InvalidOperation,sqlite3.IntegrityError) as exc:messagebox.showerror('Check product',str(exc),parent=win)
        ttk.Button(footer,text='Cancel',command=win.destroy).pack(side='right',padx=6)
        ttk.Button(footer,text='Save Product  (Ctrl+S)',command=save).pack(side='right',padx=6)
        win.bind('<Control-s>',lambda e:save())
    cls.product_master=product_master
    # POS scan resolution supports alternate codes without modifying Linkly checkout.
    old_lookup=cls.product_by_code
    def lookup(self,code):
        p=old_lookup(self,code)
        if p:return p
        schema(self.db)
        row=self.db.execute('SELECT product_id FROM product_barcodes WHERE barcode=?',(code,)).fetchone()
        return self.db.execute('SELECT * FROM products WHERE id=?',(row[0],)).fetchone() if row else None
    cls.product_by_code=lookup
