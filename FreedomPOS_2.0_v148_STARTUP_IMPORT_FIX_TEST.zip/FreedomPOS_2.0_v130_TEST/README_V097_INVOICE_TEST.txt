Freedom POS 2.0 v0.97 TEST — Invoice Arrival first test

Open Purchasing > Supplier Invoices.
NEW STOCK RECEIPT: manual editable grid.
XCHANGE INCOMING: choose local incoming folder; refresh; preview a CSV/basic XML invoice; process selected into the SAME grid.
Finalise updates stock once and hides source file from incoming list. Save Draft does not post stock.
AI INVOICE: visible placeholder only; real AI extraction is NOT implemented.

TEST ONLY. EDI/DD2 proprietary formats are not parsed without sample files. Unmatched product rows are skipped with warning; do not finalise incomplete arrivals. Import requires existing products in stock database.
Use SAMPLE_INCOMING_INVOICE.csv for a simple test; change barcode to one of your existing products.
