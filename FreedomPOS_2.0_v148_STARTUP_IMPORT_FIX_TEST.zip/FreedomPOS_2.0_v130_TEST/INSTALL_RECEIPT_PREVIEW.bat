@echo off
setlocal
cd /d "%~dp0"
where py >nul 2>nul
if %errorlevel%==0 (set "PY=py -3") else (set "PY=python")
%PY% -m pip install --upgrade pymupdf pillow
if errorlevel 1 (
 echo Installation failed. Check your internet connection and Python setup.
 pause
 exit /b 1
)
echo Receipt preview dependencies installed. Restart Freedom POS.
pause
