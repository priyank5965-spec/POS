"""Register shortcut manager: key capture, conflict validation, safe scanner focus. TEST ONLY."""
import json
import tkinter as tk
from tkinter import ttk,messagebox
from pathlib import Path

FILE=Path(__file__).resolve().parent/'keyboard_shortcuts_v059.json'
ACTIONS=[('Stock Lookup','?'),('Quantity','F2'),('Discount','F3'),('Hold Sale','F4'),('Recall Sale','F5'),('Customer Lookup','F6'),('Cash Payment','F8'),('EFTPOS','F9'),('Delete Selected Item','Delete'),('Clear Sale','Ctrl+Delete'),('Edit Selected Item','F7'),('Previous Sales','F10'),('Refund / Exchange','F11'),('Last Receipt / Reprint','F12'),('Customer Account Sale','Ctrl+A'),('Customer Payment','Ctrl+P'),('Split Tender','Ctrl+T'),('Department Lookup',''),('Lottery','Ctrl+L'),('Total','Ctrl+Enter'),('Quick Cash $5',''),('Quick Cash $10',''),('Quick Cash $20',''),('Quick Cash $50',''),('Quick Cash $100','')]
DEFAULTS=dict(ACTIONS)

def canonical(value):
    s=str(value or '').strip().replace(' ','').replace('Control-','Ctrl+').replace('Control+','Ctrl+').replace('Ctrl-','Ctrl+')
    if not s:return ''
    parts=s.split('+');mods=[]
    for bit in parts[:-1]:
        m={'ctrl':'Ctrl','control':'Ctrl','alt':'Alt','shift':'Shift'}.get(bit.lower())
        if not m or m in mods:raise ValueError('Invalid or repeated modifier: '+bit)
        mods.append(m)
    key=parts[-1]
    if key.lower() in ('question','?'):key='?'
    elif key.lower() in ('delete','del'):key='Delete'
    elif key.lower() in ('return','enter','kp_enter'):key='Enter'
    elif key.lower().startswith('f') and key[1:].isdigit() and 1<=int(key[1:])<=12:key='F'+str(int(key[1:]))
    elif len(key)==1 and key.isalnum():key=key.upper()
    else:raise ValueError('Unsupported shortcut: '+s)
    if key=='?' and mods:raise ValueError('? cannot have modifiers')
    if key in ('Enter','Delete') and not mods and key=='Enter':raise ValueError('Enter is reserved for barcode scanning')
    if len(key)==1 and key.isalnum() and not mods:raise ValueError('Single letters and digits are reserved for barcode entry')
    if key=='Delete' and mods==['Shift']:raise ValueError('Shift+Delete is reserved for text editing')
    return '+'.join([x for x in ('Ctrl','Alt','Shift') if x in mods]+[key])

def validate(mapping):
    result={};seen={}
    for action in DEFAULTS:
        key=canonical(mapping.get(action,''))
        if key=='Ctrl+D':raise ValueError('Ctrl+D is reserved for Shift Sales Dashboard')
        if key and key in seen:raise ValueError(f'{key} is already assigned to {seen[key]} (conflicts with {action})')
        if key:seen[key]=action
        result[action]=key
    return result

def load():
    try:
        data=json.loads(FILE.read_text(encoding='utf-8'))
        if isinstance(data,dict):
            # Preserve all valid old v0.59 mappings, adding new actions without overwriting them.
            return validate({**DEFAULTS,**{k:('' if k=='Department Lookup' and str(v).upper().replace(' ','') in ('CTRL+D','CONTROL+D') else v) for k,v in data.items() if k in DEFAULTS}})
    except (OSError,ValueError,TypeError):pass
    return DEFAULTS.copy()

def _modifiers(event):
    """Read real modifier keys on Windows; Tk state can include stale Alt bits."""
    import sys
    if sys.platform == 'win32':
        try:
            import ctypes
            getkey=ctypes.windll.user32.GetKeyState
            return (bool(getkey(0x11)&0x8000), bool(getkey(0x12)&0x8000), bool(getkey(0x10)&0x8000))
        except (AttributeError, OSError):
            pass
    state=int(getattr(event,'state',0))
    return bool(state&0x0004), bool(state&0x0008), bool(state&0x0001)

def from_event(event):
    key=event.keysym
    if event.char=='?' or key=='question':key='?'
    elif key in ('Delete','KP_Delete'):key='Delete'
    elif key in ('Return','KP_Enter'):key='Enter'
    elif key.lower().startswith('f') and key[1:].isdigit():key='F'+key[1:]
    elif len(key)==1 and key.isalnum():key=key.upper()
    else:return None
    ctrl,alt,shift=_modifiers(event)
    mods=[]
    if ctrl:mods.append('Ctrl')
    if alt:mods.append('Alt')
    if shift and key!='?':mods.append('Shift')
    try:return canonical('+'.join(mods+[key]))
    except ValueError:return None

def install(cls):
    original_pos=cls.pos; original_settings=cls.settings
    def pos(self):
        original_pos(self)
        self._shortcut_mapping=load()
        def on_key(event):
            if not self.code.winfo_exists() or not self.sale_tree.winfo_exists():return
            focus=self.root.focus_get()
            if focus is None or focus.winfo_toplevel()!=self.root:return
            # Do not intercept typing in forms or editable fields (except the scanner field).
            if focus is not self.code and isinstance(focus,(tk.Entry,tk.Text,ttk.Entry,ttk.Combobox,tk.Spinbox)):return
            key=from_event(event)
            if not key:return
            action=next((a for a,k in self._shortcut_mapping.items() if k==key),None)
            if not action:return
            commands={
                'Stock Lookup':self.stock_lookup,
                'Quantity':lambda:__import__('register_tower_v022').quantity_dialog(self),
                'Discount':self.set_discount,'Hold Sale':self.hold,'Recall Sale':self.recall,
                'Customer Lookup':self.register_customer,'Cash Payment':self.register_cash,
                'EFTPOS':lambda:self.checkout('EFTPOS SIMULATED'),
                'Delete Selected Item':self.void,'Clear Sale':self.clear_cart,
                'Edit Selected Item':self.edit_line,'Previous Sales':self.previous,
                'Refund / Exchange':self.register_refund,'Last Receipt / Reprint':self.last_receipt,
                'Customer Account Sale':lambda:self.checkout('ACCOUNT'),
                'Customer Payment':self.register_account_payment,'Split Tender':self.split_payment,
                'Department Lookup':self.register_departments,'Lottery':self.lottery,
                'Total':lambda:__import__('register_tower_v022').show_total(self),
            }
            for amount in (5,10,20,50,100):
                commands[f'Quick Cash ${amount}']=lambda n=amount:__import__('register_tower_v022').quick_cash_checkout(self,n)
            # Scanner input is not cleared or interpreted as a product by shortcut dispatch.
            commands[action]()
            return 'break'
        self.code.bind('<KeyPress>',on_key,add='+')
        self.root.bind('<KeyPress>',on_key,add='+')
    def shortcut_settings(self):
        w=tk.Toplevel(self.root);w.title('Keyboard Shortcut Manager — TEST ONLY');w.transient(self.root)
        sw=w.winfo_screenwidth();sh=w.winfo_screenheight()
        w.geometry(f'{min(760,max(520,sw-90))}x{min(680,max(430,sh-140))}')
        w.configure(bg='white')
        tk.Label(w,text='KEYBOARD SHORTCUT MANAGER',bg='white',fg='#111111',font=('Segoe UI',16,'bold'),anchor='w',padx=15,pady=13).pack(fill='x')
        tk.Label(w,text='Click a shortcut field, then press the key combination. Clear removes a shortcut.',bg='white',anchor='w',padx=15,pady=8).pack(fill='x')
        footer=tk.Frame(w,bg='#e8eef2',padx=12,pady=10);footer.pack(side='bottom',fill='x')
        search=tk.StringVar();tk.Entry(w,textvariable=search,font=('Segoe UI',11)).pack(fill='x',padx=16,pady=5)
        body=tk.Frame(w,bg='white');body.pack(fill='both',expand=True,padx=12,pady=5)
        canvas=tk.Canvas(body,bg='white',highlightthickness=0)
        scroll=ttk.Scrollbar(body,orient='vertical',command=canvas.yview);scroll.pack(side='right',fill='y')
        canvas.pack(side='left',fill='both',expand=True);canvas.configure(yscrollcommand=scroll.set)
        rows=tk.Frame(canvas,bg='white');item=canvas.create_window((0,0),window=rows,anchor='nw')
        rows.bind('<Configure>',lambda e:canvas.configure(scrollregion=canvas.bbox('all')))
        canvas.bind('<Configure>',lambda e:canvas.itemconfigure(item,width=e.width))
        current=load();values={a:tk.StringVar(value=current[a]) for a in DEFAULTS}
        widgets={}
        for i,action in enumerate(DEFAULTS):
            label=tk.Label(rows,text=action,bg='white',anchor='w',font=('Segoe UI',10))
            label.grid(row=i,column=0,sticky='ew',pady=4,padx=(3,8))
            entry=ttk.Entry(rows,textvariable=values[action],width=22,justify='center',state='normal')
            entry.grid(row=i,column=1,sticky='ew',pady=4,padx=5)
            def capture(event,a=action):
                # Ignore modifier-only events while waiting for the final key.
                if event.keysym in ('Control_L','Control_R','Alt_L','Alt_R','Shift_L','Shift_R'):return 'break'
                key=from_event(event)
                if key:values[a].set(key)
                else:w.bell()
                return 'break'
            entry.bind('<KeyPress>',capture)
            entry.bind('<KeyRelease>',lambda e:'break')
            entry.bind('<<Paste>>',lambda e:'break')
            entry.bind('<FocusIn>',lambda e:e.widget.selection_range(0,'end'))
            clear=tk.Button(rows,text='Clear',command=lambda a=action:values[a].set(''),width=7)
            clear.grid(row=i,column=2,padx=5,pady=4)
            widgets[action]=(label,entry,clear)
        rows.columnconfigure(0,weight=1)
        def filter_rows(*_):
            q=search.get().lower().strip()
            for action,(label,entry,clear) in widgets.items():
                if q in action.lower():
                    label.grid();entry.grid();clear.grid()
                else:
                    label.grid_remove();entry.grid_remove();clear.grid_remove()
            canvas.yview_moveto(0)
        search.trace_add('write',filter_rows)
        def save():
            try:result=validate({a:v.get() for a,v in values.items()})
            except ValueError as e:messagebox.showerror('Shortcut conflict',str(e),parent=w);return
            try:FILE.write_text(json.dumps(result,indent=2),encoding='utf-8')
            except OSError as e:messagebox.showerror('Save failed',str(e),parent=w);return
            self._shortcut_mapping=result;w.destroy()
        tk.Button(footer,text='Cancel',command=w.destroy,width=11).pack(side='right',padx=4)
        tk.Button(footer,text='Save Shortcuts',command=save,width=16,bg='#50c1ce').pack(side='right',padx=4)
        tk.Button(footer,text='Restore Defaults',command=lambda:[v.set(DEFAULTS[a]) for a,v in values.items()],width=16).pack(side='left',padx=4)
        w.grab_set()
    def settings(self):
        original_layout=self.layout
        def patched_layout(title,items):
            if title=='SETTINGS & TOOLS':items=[('Keyboard Shortcuts',self.shortcut_settings)]+list(items)
            return original_layout(title,items)
        self.layout=patched_layout
        try:return original_settings(self)
        finally:self.layout=original_layout
    cls.pos=pos;cls.settings=settings;cls.shortcut_settings=shortcut_settings
