import unittest
from unittest.mock import patch
from linkly_status_v112 import frame,receive_frame,query_pinpad,LinklyStatusError

class FakeSocket:
 def __init__(self,payload):self.data=bytearray(payload);self.sent=[]
 def __enter__(self):return self
 def __exit__(self,*args):pass
 def settimeout(self,*args):pass
 def sendall(self,data):self.sent.append(data)
 def recv(self,n):
  x=bytes(self.data[:n]);del self.data[:n];return x

class LinklyTests(unittest.TestCase):
 def test_frame(self):self.assertEqual(frame('K00000'),b'#0011K00000')
 def test_online(self):
  sock=FakeSocket(frame('K 100PINPAD ONLINE       '))
  with patch('linkly_status_v112.socket.create_connection',return_value=sock):
   result=query_pinpad()
  self.assertTrue(result['online']);self.assertEqual(sock.sent,[b'#0011K00000'])
 def test_offline(self):
  sock=FakeSocket(frame('K 0P7PINPAD OFFLINE      '))
  with patch('linkly_status_v112.socket.create_connection',return_value=sock):
   result=query_pinpad()
  self.assertFalse(result['online']);self.assertEqual(result['code'],'P7')
 def test_no_listener(self):
  with patch('linkly_status_v112.socket.create_connection',side_effect=ConnectionRefusedError('refused')):
   with self.assertRaises(LinklyStatusError):query_pinpad()
 def test_truncated(self):
  with self.assertRaises(LinklyStatusError):receive_frame(FakeSocket(b'#0025K'))
if __name__=='__main__':unittest.main()
