Freedom POS 2.0 v0.48 — TEST ONLY

Changes:
- Test checkout no longer requires a staff PIN; no fake staff identity is assigned. Restore authentication before live use.
- Repeat scans of an identical standard product line increase Qty, not duplicate rows. Custom-priced/discounted lines are not silently merged.
- Four columns of uniform register buttons, with resizable left/right sash and visible handle.
- Quick cash still completes simulated eligible cash sales without payment dialog.

WARNING: TEST ONLY. No live EFTPOS. Do not use real transaction or stock data.
