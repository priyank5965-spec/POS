Freedom POS v139 — UI integration test

Changes from v138:
- Shared Supplier/Department autocomplete now uses a screen-positioned, dark dropdown attached directly below the active input in Product Master and Newspaper Product Setup.
- Supplier/Department + New buttons sit alongside their entry fields instead of overlapping labels.
- Keyboard autocomplete: arrows, Enter, Tab, Shift+Tab; weekday grid skips disabled fields.
- Main toolbar buttons have stronger borders and pressed/hover colour.
- Existing barcode generation (Alt+R), newspaper weekday pricing, quick-sell codes and master tables are retained.
- Existing launcher restored unchanged from v138.

Testing: 28 unittest tests passed; two Tk GUI smoke tests passed under virtual X server; compilation and ZIP integrity checked.
NOT verified: real Windows keyboard/scanner interaction, Linkly hardware, complete end-to-end workflows on all application screens. Keep your working version and database backed up. This is a TEST build.
