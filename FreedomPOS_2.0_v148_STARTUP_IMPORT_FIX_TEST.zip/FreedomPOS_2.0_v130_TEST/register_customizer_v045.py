"""Register layout/theme editor. TEST ONLY. Preserves existing button callbacks."""
import copy, json, os, shutil, uuid, tkinter as tk
from pathlib import Path
from tkinter import ttk, colorchooser, messagebox, filedialog
try:
 from PIL import Image, ImageTk, ImageOps
except ImportError:
 Image=ImageTk=ImageOps=None

THEMES={
 'Freedom Classic':dict(background='#ffffff',button='#c7c7c7',text='#1e1e1e',accent='#5bc5d3',border='#87939b'),
 'Aronium-Inspired Light':dict(background='#f6f7f9',button='#ffffff',text='#17212d',accent='#39a968',border='#d5dce3'),
 'Modern Touch':dict(background='#edf8f8',button='#ffffff',text='#12324a',accent='#1aa8a3',border='#a8d7d5'),
 'Modern Dark':dict(background='#1b2735',button='#304459',text='#ffffff',accent='#23b7c0',border='#435b6f'),
 'Clean Light':dict(background='#f0f3f7',button='#ffffff',text='#172c43',accent='#2563eb',border='#cbd5e1'),
 'High Contrast':dict(background='#121212',button='#151515',text='#ffffff',accent='#ffda40',border='#ffffff'),
}
CONFIG=Path(__file__).resolve().parent/'register_layout_v046.json'
ROWS,COLS=10,4
IMAGE_DIR=Path(__file__).resolve().parent/"register_button_images"
_IMAGE_CACHE={}

def image_for(path,size):
 """Return an owned PhotoImage; caller retains a reference."""
 if not path or Image is None:return None
 try:
  source=(IMAGE_DIR / Path(path).name).resolve()
  if not source.is_file() or IMAGE_DIR.resolve() not in source.parents:return None
  with Image.open(source) as raw:
   if raw.width*raw.height>16000000:return None
   im=ImageOps.fit(raw.convert("RGBA"),(max(32,int(size[0])),max(28,int(size[1]))),method=Image.Resampling.LANCZOS)
  return ImageTk.PhotoImage(im)
 except (OSError,ValueError):return None

def apply_button_image(button,path):
 if not path:
  button.configure(image="",compound="none");button._freedom_image=None;return
 def refresh(event=None):
  if not button.winfo_exists():return
  photo=image_for(path,(button.winfo_width(),button.winfo_height()))
  if photo is not None:
   button._freedom_image=photo
   button.configure(image=photo,compound="center")
 refresh()
 if getattr(button,"_freedom_image_path",None)!=path:
  button.bind("<Configure>",refresh,add="+")
  button._freedom_image_path=path


def load():
 try:
  obj=json.loads(CONFIG.read_text(encoding='utf-8'))
  return obj if isinstance(obj,dict) else {}
 except (OSError,ValueError):return {}

def defaults(tiles):
 return {k:dict(row=t['row'],col=t['col'],width=1,height=1) for k,t in tiles.items()}

def cells(box):
 return {(r,c) for r in range(box['row'],box['row']+box['height']) for c in range(box['col'],box['col']+box['width'])}

def valid(layout):
 used=set()
 for box in layout.values():
  if not (0<=box['row']<ROWS and 0<=box['col']<COLS and 1<=box['width']<=COLS and 1<=box['height']<=ROWS):return False
  if box['row']+box['height']>ROWS or box['col']+box['width']>COLS:return False
  occupied=cells(box)
  if used.intersection(occupied):return False
  used.update(occupied)
 return True

def build_layout(tiles,cfg):
 layout=defaults(tiles)
 for k,t in tiles.items():
  saved=cfg.get('buttons',{}).get(k,{})
  candidate=dict(layout[k])
  try:
   for field in ('row','col'):
    if field in saved:candidate[field]=int(saved[field])
  except (ValueError,TypeError):continue
  trial=dict(layout);trial[k]=candidate
  if valid(trial):layout[k]=candidate
 # Handle older saved position swaps, which can require simultaneous application.
 simultaneous=defaults(tiles)
 try:
  for k in tiles:
   x=cfg.get('buttons',{}).get(k,{})
   for f in ('row','col'):
    if f in x:simultaneous[k][f]=int(x[f])
  if valid(simultaneous):return simultaneous
 except (ValueError,TypeError):pass
 return layout

def relocate(layout,key,row,col):
 """Move to empty cells, or swap positions if the two footprints fit."""
 candidate=copy.deepcopy(layout);old=candidate[key].copy()
 candidate[key].update(row=row,col=col)
 if valid(candidate):return candidate
 targets=[k for k in layout if k!=key and cells(layout[k]) & cells(candidate[key])]
 if len(targets)==1:
  other=targets[0];candidate[other].update(row=old['row'],col=old['col'])
  if valid(candidate):return candidate
 return None

def resize(layout,key,width,height):
 candidate=copy.deepcopy(layout)
 candidate[key].update(width=width,height=height)
 return candidate if valid(candidate) else None

def install(cls):
 def apply(self):
  tiles=getattr(self,'_register_tiles',None)
  if not tiles:return
  cfg=load();pal=THEMES.get(cfg.get('theme'),THEMES['Freedom Classic']);layout=build_layout(tiles,cfg)
  parent=next(iter(tiles.values()))['widget'].master
  parent.configure(bg=cfg.get('background') or pal['background'])
  for key,t in tiles.items():
   b=t['widget'];saved=cfg.get('buttons',{}).get(key,{})
   pos=layout[key]
   b.grid_configure(row=pos['row'],column=pos['col'],columnspan=pos['width'],rowspan=pos['height'])
   bg=saved.get('bg') or (t['bg'] if t['bg'] not in ('#c7c7c7',) else pal['button'])
   fg=saved.get('fg') or (t['fg'] if t['fg'] not in ('#1e1e1e',) else pal['text'])
   b.configure(text=saved.get('label',t['label']),bg=bg,fg=fg,activebackground=pal['accent'],font=('Segoe UI',10,'bold'),wraplength=max(90,95*pos['width']))
   apply_button_image(b,saved.get('image',''))
  self._register_layout=cfg

 def editor(self):
  tiles=getattr(self,'_register_tiles',None)
  if not tiles:
   messagebox.showwarning('Register Settings','Open the register first.',parent=self.root);return
  cfg=copy.deepcopy(load());cfg.setdefault('buttons',{})
  layout=build_layout(tiles,cfg)
  win=tk.Toplevel(self.root);win.title('Freedom POS 2.0 — Advanced Layout & Themes — TEST ONLY')
  # Open at a comfortable, non-maximised size by default. Maximising previously
  # pushed the footer behind the taskbar on some Windows display configurations.
  screen_w=max(800,win.winfo_screenwidth())
  screen_h=max(600,win.winfo_screenheight())
  usable_w=max(700,screen_w-40)
  usable_h=max(520,screen_h-110)
  target_w=min(1640,usable_w)
  target_h=min(880,usable_h)
  win.minsize(min(920,target_w),min(590,target_h))
  win.geometry(f'{target_w}x{target_h}')
  win.transient(self.root);win.configure(bg='#ffffff');win.grab_set()
  header=tk.Frame(win,bg='white',height=66);header.pack(fill='x');header.pack_propagate(False)
  tk.Label(header,text='REGISTER THEME & BUTTON DESIGNER',font=('Segoe UI',18,'bold'),bg='white',fg='#111111').pack(side='left',padx=18,pady=15)
  tk.Label(header,text='TEST ONLY',bg='white',fg='#8de4ea',font=('Segoe UI',11,'bold')).pack(side='right',padx=18)
  top=tk.Frame(win,bg='white');top.pack(fill='x',padx=16,pady=12)
  tk.Label(top,text='Theme',bg='white',font=('Segoe UI',11,'bold')).pack(side='left')
  theme=tk.StringVar(value=cfg.get('theme','Freedom Classic'))
  if theme.get() not in THEMES:theme.set('Freedom Classic')
  tk.Label(top,text='Background',bg='white',font=('Segoe UI',10,'bold')).pack(side='left',padx=(10,3))
  background=tk.StringVar(value=cfg.get('background',''))
  def choose_background():
   result=colorchooser.askcolor(color=background.get() or THEMES[theme.get()]['background'],parent=win)[1]
   if result:background.set(result);paint()
  tk.Button(top,text='Choose colour',command=choose_background).pack(side='right',padx=6)
  tk.Button(top,text='Theme default',command=lambda:(background.set(''),paint())).pack(side='right',padx=6)
  selector=ttk.Combobox(top,textvariable=theme,values=list(THEMES),state='readonly',width=26,font=('Segoe UI',11));selector.pack(side='left',padx=12)
  tk.Label(top,text='Drag to move/swap • All buttons fixed size • Rename, recolour or add an image',bg='white',fg='#465668',font=('Segoe UI',10)).pack(side='left')
  body=tk.Frame(win,bg='white')

  # A canvas viewport isolates the grid's requested height from the window's
  # geometry calculation. Its contents scroll rather than hiding footer actions.
  grid_container=tk.Frame(body,bg='white')
  grid_container.pack(side='left',fill='both',expand=True,padx=(0,12))
  grid_canvas=tk.Canvas(grid_container,bg='white',highlightthickness=0,borderwidth=0)
  grid_scroll=ttk.Scrollbar(grid_container,orient='vertical',command=grid_canvas.yview)
  grid_canvas.configure(yscrollcommand=grid_scroll.set)
  grid_scroll.pack(side='right',fill='y')
  grid_canvas.pack(side='left',fill='both',expand=True)
  board=tk.Frame(grid_canvas,bg='white')
  board_window=grid_canvas.create_window((0,0),window=board,anchor='nw')
  def sync_grid_scroll(event=None):
   grid_canvas.configure(scrollregion=grid_canvas.bbox('all'))
  def sync_grid_width(event):
   grid_canvas.itemconfigure(board_window,width=max(1,event.width))
  board.bind('<Configure>',sync_grid_scroll)
  grid_canvas.bind('<Configure>',sync_grid_width)
  def wheel_grid(event):
   grid_canvas.yview_scroll(-1 if event.delta>0 else 1,'units')
  grid_canvas.bind('<MouseWheel>',wheel_grid)
  board.bind('<MouseWheel>',wheel_grid)
  for col in range(COLS):board.grid_columnconfigure(col,weight=1,uniform='buttons')
  for row in range(ROWS):board.grid_rowconfigure(row,weight=1,uniform='buttons',minsize=0)
  panel=tk.Frame(body,bg='white',width=350,highlightbackground='#cbd5e1',highlightthickness=1);panel.pack(side='right',fill='y');panel.pack_propagate(False)
  selected=tk.StringVar(value=next(iter(tiles)))
  label=tk.StringVar();bg=tk.StringVar();fg=tk.StringVar();image_path=tk.StringVar()
  controls={};drag={'key':None,'x':0,'y':0}
  notice=tk.StringVar(value='Drag buttons to swap positions. All buttons have the same fixed size.')
  def select(k):
   selected.set(k);x=cfg['buttons'].get(k,{})
   label.set(x.get('label',tiles[k]['label']));bg.set(x.get('bg',''));fg.set(x.get('fg',''))
   image_path.set(x.get('image',''))
   chosen.config(text='Selected: '+tiles[k]['label'])
  def paint():
   pal=THEMES[theme.get()];board.configure(bg=background.get() or pal['background'])
   for k,t in tiles.items():
    x=cfg['buttons'].get(k,{});pos=layout[k];b=controls[k]
    b.grid_configure(row=pos['row'],column=pos['col'],columnspan=1,rowspan=1,sticky='nsew',padx=2,pady=2)
    b.configure(text=x.get('label',t['label']),bg=x.get('bg') or (t['bg'] if t['bg']!='#c7c7c7' else pal['button']),fg=x.get('fg') or (t['fg'] if t['fg']!='#1e1e1e' else pal['text']),highlightbackground=pal['accent'] if k==selected.get() else pal['border'],highlightthickness=3 if k==selected.get() else 1,wraplength=max(80,95*pos['width']))
    apply_button_image(b,x.get('image',''))
  def down(event,k):drag.update(key=k,x=event.x_root,y=event.y_root);select(k);paint()
  def up(event,k):
   nonlocal layout
   if drag['key']!=k:return
   drag['key']=None
   if abs(event.x_root-drag['x'])+abs(event.y_root-drag['y'])<12:return
   target=None
   for other,b in controls.items():
    if b.winfo_rootx()<=event.x_root<b.winfo_rootx()+b.winfo_width() and b.winfo_rooty()<=event.y_root<b.winfo_rooty()+b.winfo_height():target=other;break
   if target==k:return
   if target:
    result=relocate(layout,k,layout[target]['row'],layout[target]['col'])
   elif board.winfo_rootx()<=event.x_root<board.winfo_rootx()+board.winfo_width() and board.winfo_rooty()<=event.y_root<board.winfo_rooty()+board.winfo_height():
    row=min(ROWS-1,max(0,(event.y_root-board.winfo_rooty())*ROWS//max(1,board.winfo_height())))
    col=min(COLS-1,max(0,(event.x_root-board.winfo_rootx())*COLS//max(1,board.winfo_width())))
    result=relocate(layout,k,row,col)
   else:return
   if result is not None:
    layout=result;notice.set('Button moved. Save Layout to keep changes.');paint()
   else:notice.set('Cannot move there: not enough space. Choose another position.')
  for k in tiles:
   b=tk.Label(board,font=('Segoe UI',10,'bold'),justify='center',cursor='hand2',padx=5,pady=5,relief='solid',borderwidth=1)
   b.bind('<MouseWheel>',wheel_grid)
   b.bind('<ButtonPress-1>',lambda e,key=k:down(e,key))
   b.bind('<ButtonRelease-1>',lambda e,key=k:up(e,key))
   controls[k]=b
  chosen=tk.Label(panel,text='Select a button',bg='white',fg='#111111',font=('Segoe UI',13,'bold'),wraplength=280);chosen.pack(fill='x',padx=14,pady=(18,14))
  def field(text,var):
   tk.Label(panel,text=text,bg='white',anchor='w',font=('Segoe UI',10,'bold')).pack(fill='x',padx=14,pady=(9,1))
   entry=tk.Entry(panel,textvariable=var,font=('Segoe UI',12));entry.pack(fill='x',padx=14,pady=4)
  field('Button display name',label)
  def pick(var):
   colour=colorchooser.askcolor(color=var.get() or '#5bc5d3',parent=win)[1]
   if colour:var.set(colour)
  for name,var in [('Background colour',bg),('Text colour',fg)]:
   tk.Label(panel,text=name,bg='white',anchor='w',font=('Segoe UI',10,'bold')).pack(fill='x',padx=14,pady=(8,1))
   r=tk.Frame(panel,bg='white');r.pack(fill='x',padx=14,pady=4)
   tk.Entry(r,textvariable=var,font=('Segoe UI',11),width=14).pack(side='left',fill='x',expand=True)
   tk.Button(r,text='Choose',command=lambda v=var:pick(v)).pack(side='left',padx=(5,0))
  tk.Label(panel,text='Button background image (optional)',bg='white',anchor='w',font=('Segoe UI',10,'bold')).pack(fill='x',padx=14,pady=(9,1))
  imgrow=tk.Frame(panel,bg='white');imgrow.pack(fill='x',padx=14,pady=3)
  tk.Label(imgrow,textvariable=image_path,bg='white',fg='#4a5568',anchor='w',width=17).pack(side='left',fill='x',expand=True)
  def choose_image():
   if Image is None:
    messagebox.showwarning('Image support','Pillow is required for button images. Install Pillow in this Python environment.',parent=win);return
   filename=filedialog.askopenfilename(parent=win,title='Select button image',filetypes=[('Images','*.png *.jpg *.jpeg *.webp'),('All files','*.*')])
   if not filename:return
   try:
    with Image.open(filename) as im:
     if im.width*im.height>16000000:raise ValueError('Image exceeds 16 megapixels')
     im.verify()
    IMAGE_DIR.mkdir(parents=True,exist_ok=True)
    dest=IMAGE_DIR/(uuid.uuid4().hex+Path(filename).suffix.lower())
    shutil.copy2(filename,dest)
    image_path.set(dest.name)
   except (OSError,ValueError) as e:messagebox.showerror('Image Error',str(e),parent=win)
  tk.Button(imgrow,text='Browse',command=choose_image).pack(side='left',padx=3)
  tk.Button(imgrow,text='Clear',command=lambda:image_path.set('')).pack(side='left',padx=3)
  tk.Label(panel,text='Solid colour remains available when no image is selected.',bg='white',fg='#64748b',wraplength=270).pack(fill='x',padx=14)
  def update_selected():
   nonlocal layout
   k=selected.get();name=label.get().strip()
   if not name:messagebox.showwarning('Button name','Enter a display name.',parent=win);return
   for var in (bg,fg):
    if var.get().strip():
     try:win.winfo_rgb(var.get().strip())
     except tk.TclError:messagebox.showwarning('Colour','Enter a valid colour.',parent=win);return
   cfg['buttons'].setdefault(k,{}).update(label=name,bg=bg.get().strip(),fg=fg.get().strip(),image=image_path.get())
   notice.set('Preview updated. Save Layout to keep your changes.');paint()

  tk.Label(panel,text='Button size is fixed. Image automatically fills the selected button. Sales functions stay connected.',bg='white',fg='#526477',wraplength=310,justify='left',font=('Segoe UI',10)).pack(fill='x',padx=14,pady=8)
  status=tk.Label(win,textvariable=notice,bg='#e9f4f5',fg='#111111',anchor='w',font=('Segoe UI',10),padx=16,pady=5,wraplength=950)
  def save():
   update_selected()
   if not valid(layout):messagebox.showerror('Layout Error','Button positions overlap.',parent=win);return
   cfg['theme']=theme.get();cfg['background']=background.get()
   for k,pos in layout.items():cfg['buttons'].setdefault(k,{}).update(pos)
   try:
    temp=CONFIG.with_suffix('.tmp');temp.write_text(json.dumps(cfg,indent=2),encoding='utf-8');os.replace(temp,CONFIG)
   except OSError as e:messagebox.showerror('Save Failed',str(e),parent=win);return
   self.apply_register_customization();win.destroy()
  def reset():
   nonlocal layout
   if not messagebox.askyesno('Restore Default','Reset names, positions, images and colours?',parent=win):return
   cfg['buttons'].clear();layout=defaults(tiles);theme.set('Freedom Classic');background.set('');select(next(iter(tiles)));paint()
  selector.bind('<<ComboboxSelected>>',lambda e:paint())
  # Reserve the bottom action area before allocating space to the designer grid.
  # Otherwise the grid can force Save/Apply below the screen on shorter displays.
  header.pack_forget();top.pack_forget()
  footer=tk.Frame(win,bg='white');footer.pack(side='bottom',fill='x',padx=16,pady=6)
  status.pack(side='bottom',fill='x',padx=16,pady=(3,0))
  header.pack(side='top',fill='x')
  top.pack(side='top',fill='x',padx=16,pady=6)
  body.pack(side='top',fill='both',expand=True,padx=16)
  body.pack_propagate(False)
  grid_container.pack_propagate(False)
  tk.Button(footer,text='RESTORE DEFAULT',command=reset,font=('Segoe UI',10,'bold'),padx=12,pady=10).pack(side='left')
  tk.Button(footer,text='CANCEL',command=win.destroy,font=('Segoe UI',10,'bold'),padx=20,pady=10).pack(side='right',padx=5)
  tk.Button(footer,text='APPLY TO PREVIEW',command=update_selected,bg='#d9edf0',font=('Segoe UI',10,'bold'),padx=12,pady=10).pack(side='right',padx=5)
  tk.Button(footer,text='SAVE LAYOUT',command=save,bg='#22b8bd',font=('Segoe UI',10,'bold'),padx=20,pady=10).pack(side='right',padx=5)
  select(next(iter(tiles)));paint();win.protocol('WM_DELETE_WINDOW',win.destroy)
 cls.apply_register_customization=apply
 cls.register_customizer=editor
