Freedom POS 2.0 v0.11 - Previous Sales bottom toolbar layout fix

Issue: The expanding Summary of Sales and Details tables consumed the available
height, pushing Delete / Preview / Reprint / Refund / Email below the window.

Fix: Search filters and action toolbar are now docked in a reserved bottom
footer before the expanding grids. The action toolbar remains visible when
the window is resized. A duplicate Open in Invoice Management action was
removed from the toolbar (it remains in the search section).

Start with START_FREEDOM_POS.bat or rebuild using BUILD_TEST_EXE.bat.
Extract into a NEW folder and do not run a previous dist EXE.

IMPORTANT: This is test-only software. Physical printing, Gmail OAuth and
refund/reversal workflows are not production-validated.
