"""Idempotent first-run demo newspaper setup; never overwrite existing stock or prices."""
from datetime import date
from newspaper_product_v134 import schema as newspaper_schema
from quick_sell_v136 import schema as quick_schema

WEEKDAYS=(("Monday",350),("Tuesday",350),("Wednesday",350),
          ("Thursday",350),("Friday",350),("Saturday",450))

def seed(db):
    newspaper_schema(db)
    quick_schema(db)
    db.execute("""CREATE TABLE IF NOT EXISTS setup_migrations_v140
                  (name TEXT PRIMARY KEY,applied_at TEXT DEFAULT CURRENT_TIMESTAMP)""")
    if db.execute("SELECT 1 FROM setup_migrations_v140 WHERE name='courier_mail'").fetchone():
        return
    with db:
        title="Courier Mail"
        db.execute("""INSERT OR IGNORE INTO newspaper_metadata_v135
             (title,plu,department,frequency,supplier,supplier_code)
             VALUES(?,?,?,?,?,?)""",(title,"","Newspaper","Daily","",""))
        for weekday,(day,price) in enumerate(WEEKDAYS):
            row=db.execute("SELECT product_id FROM newspaper_weekdays_v134 WHERE title=? AND day=?",
                           (title,weekday)).fetchone()
            if row:
                continue
            name=f"{title} - {day}"
            existing=db.execute("SELECT id FROM products WHERE name=?",(name,)).fetchone()
            if existing:
                pid=existing[0]
                # Existing prices and stock are intentionally preserved.
            else:
                # Internal placeholder is not a customer-facing barcode.
                barcode=f"INTERNAL-COURIER-V140-{weekday}"
                pid=db.execute("""INSERT INTO products
                    (barcode,name,price,stock,category,supplier,supplier_code)
                    VALUES(?,?,?,0,'Newspaper','','')""",
                    (barcode,name,price)).lastrowid
            db.execute("""INSERT OR IGNORE INTO newspaper_weekdays_v134
                       (title,day,product_id,cost_cents,active)
                       VALUES(?,?,?,0,1)""",(title,weekday,pid))
        # Only assign C if no other product owns it and no prefix conflict exists.
        codes=[r[0].upper() for r in db.execute("SELECT code FROM quick_sell_codes_v136")]
        if not any(code.startswith("C") or "C".startswith(code) for code in codes):
            db.execute("""INSERT INTO quick_sell_codes_v136(code,newspaper_title)
                          VALUES('C',?)""",(title,))
        db.execute("INSERT INTO setup_migrations_v140(name) VALUES('courier_mail')")

def install(cls):
    previous=cls.__init__
    def __init__(self,root):
        previous(self,root)
        seed(self.db)
    cls.__init__=__init__
