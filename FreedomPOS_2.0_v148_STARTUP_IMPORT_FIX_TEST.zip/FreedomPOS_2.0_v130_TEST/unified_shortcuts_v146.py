"""Unified register shortcut editor backed by the existing shared quick_sell_codes_v136 table."""
import tkinter as tk
from tkinter import ttk,messagebox
from quick_sell_v136 import schema,validate_code
import department_navigation_v067 as dept
from register_keyboard_v060 import load as load_actions

def install(cls):
    previous=cls.shortcut_settings
    def shortcut_settings(self):
        win=tk.Toplevel(self.root);win.title('Register Keyboard Shortcuts — Products, Newspapers & Actions')
        win.geometry('1020x690');win.minsize(800,530);win.configure(bg='white')
        tk.Label(win,text='REGISTER KEYBOARD SHORTCUTS',bg='#12324a',fg='white',font=('Segoe UI',17,'bold'),anchor='w',padx=18,pady=15).pack(fill='x')
        tabs=ttk.Notebook(win);tabs.pack(fill='both',expand=True,padx=14,pady=12)
        items=ttk.Frame(tabs,padding=12);tabs.add(items,text='Product & Newspaper Shortcuts')
        department_tab=ttk.Frame(tabs,padding=12);tabs.add(department_tab,text='Department Shortcuts')
        actions=ttk.Frame(tabs,padding=12);tabs.add(actions,text='Register Action Shortcuts')
        ttk.Label(actions,text='Configure function keys and register commands using the existing keyboard manager.').pack(anchor='w',pady=12)
        ttk.Button(actions,text='Open Register Action Shortcut Manager',command=previous.__get__(self,type(self))).pack(anchor='w')
        ttk.Label(department_tab,text='Assign a key to show a department in the register grid. Product keys add an item directly to the sale.').pack(anchor='w',pady=8)
        dept.seed_default_departments(self)
        drows=list(dept.departments(self))
        dlookup={f"{r['name']} (ID {r['id']})":str(r['id']) for r in drows}
        dform=ttk.Frame(department_tab);dform.pack(fill='x',pady=10)
        ttk.Label(dform,text='Department').grid(row=0,column=0,sticky='w')
        ttk.Label(dform,text='Shortcut key').grid(row=0,column=1,sticky='w',padx=12)
        dchoice=ttk.Combobox(dform,values=list(dlookup),state='readonly',width=55);dchoice.grid(row=1,column=0,sticky='ew')
        dkey=tk.StringVar();ttk.Entry(dform,textvariable=dkey,width=18).grid(row=1,column=1,padx=12)
        dform.columnconfigure(0,weight=1)
        dt=ttk.Treeview(department_tab,columns=('department','key'),show='headings')
        for c in ('department','key'):dt.heading(c,text=c.title())
        dt.pack(fill='both',expand=True,pady=12)
        def drefresh():
            dt.delete(*dt.get_children());cfg=dept.load()
            for name,ident in dlookup.items():dt.insert('','end',values=(name,cfg.get(ident,{}).get('shortcut','')))
        def dselect(event=None):dkey.set(dept.load().get(dlookup.get(dchoice.get(),''),{}).get('shortcut',''))
        dchoice.bind('<<ComboboxSelected>>',dselect)
        def dsave():
            ident=dlookup.get(dchoice.get())
            if not ident:return messagebox.showwarning('Department','Select a department.',parent=win)
            try:
                key=dept.department_key(dkey.get()) if dkey.get().strip() else ''
                if key and self.db.execute('SELECT 1 FROM quick_sell_codes_v136 WHERE UPPER(code)=?',(key,)).fetchone():
                    raise ValueError('Key already assigned to a product or newspaper.')
                cfg=dept.load();cfg.setdefault(ident,{});cfg[ident]['shortcut']=key
                dept.validate(cfg,load_actions())
                import json
                dept.FILE.write_text(json.dumps(cfg,indent=2),encoding='utf-8')
                drefresh()
            except Exception as exc:messagebox.showerror('Shortcut conflict',str(exc),parent=win)
        ttk.Button(department_tab,text='Save Department Shortcut',command=dsave).pack(side='right')
        ttk.Button(department_tab,text='Clear Shortcut',command=lambda:(dkey.set(''),dsave())).pack(side='right',padx=8)
        drefresh()
        ttk.Label(items,text='Assign 1–8 letters (A–Z). Press the code at the register to sell the product or today’s newspaper edition.').pack(anchor='w',pady=(0,10))
        schema(self.db)
        records=[]
        for row in self.db.execute('SELECT id,name FROM products ORDER BY name'):
            records.append(('Product',row[0],row[1]))
        for row in self.db.execute('SELECT title FROM newspaper_metadata_v135 ORDER BY title'):
            records.append(('Newspaper',row[0],row[0]))
        lookup={f'{kind}: {name}'+(f' (ID {ident})' if kind=='Product' else ''):(kind,ident) for kind,ident,name in records}
        form=ttk.Frame(items);form.pack(fill='x')
        ttk.Label(form,text='Product or newspaper').grid(row=0,column=0,sticky='w')
        ttk.Label(form,text='Register Shortcut Key').grid(row=0,column=1,sticky='w',padx=12)
        choice=ttk.Combobox(form,values=list(lookup),state='readonly',width=65);choice.grid(row=1,column=0,sticky='ew')
        key=tk.StringVar();entry=ttk.Entry(form,textvariable=key,width=15);entry.grid(row=1,column=1,padx=12)
        form.columnconfigure(0,weight=1)
        columns=('key','kind','name');table=ttk.Treeview(items,columns=columns,show='headings')
        for col,width in [('key',120),('kind',130),('name',520)]:table.heading(col,text=col.title());table.column(col,width=width)
        table.pack(fill='both',expand=True,pady=14)
        def refresh():
            table.delete(*table.get_children())
            for code,pid,title in self.db.execute('SELECT code,product_id,newspaper_title FROM quick_sell_codes_v136 ORDER BY code'):
                if pid is not None:
                    r=self.db.execute('SELECT name FROM products WHERE id=?',(pid,)).fetchone()
                    kind='Product';name=r[0] if r else '(missing product)'
                else:kind='Newspaper';name=title
                table.insert('','end',values=(code,kind,name))
        def selected(event=None):
            target=lookup.get(choice.get())
            if target is None:return
            kind,ident=target
            if kind=='Product':row=self.db.execute('SELECT code FROM quick_sell_codes_v136 WHERE product_id=?',(ident,)).fetchone()
            else:row=self.db.execute('SELECT code FROM quick_sell_codes_v136 WHERE newspaper_title=?',(ident,)).fetchone()
            key.set(row[0] if row else '')
        choice.bind('<<ComboboxSelected>>',selected)
        def save():
            target=lookup.get(choice.get())
            if target is None:return messagebox.showwarning('Select an item','Choose a product or newspaper first.',parent=win)
            kind,ident=target
            try:
                code=validate_code(self.db,key.get(),exclude_pid=ident if kind=='Product' else None,exclude_title=ident if kind=='Newspaper' else None)
                if code and any(dept.department_key(item.get('shortcut',''))==code for item in dept.load().values() if isinstance(item,dict)):
                    raise ValueError('Shortcut is already assigned to a department.')
                with self.db:
                    if kind=='Product':self.db.execute('DELETE FROM quick_sell_codes_v136 WHERE product_id=?',(ident,))
                    else:self.db.execute('DELETE FROM quick_sell_codes_v136 WHERE newspaper_title=?',(ident,))
                    if code:
                        if kind=='Product':self.db.execute('INSERT INTO quick_sell_codes_v136(code,product_id) VALUES(?,?)',(code,ident))
                        else:self.db.execute('INSERT INTO quick_sell_codes_v136(code,newspaper_title) VALUES(?,?)',(code,ident))
                refresh()
            except Exception as exc:messagebox.showerror('Shortcut conflict',str(exc),parent=win)
        buttons=ttk.Frame(items);buttons.pack(fill='x')
        ttk.Button(buttons,text='Save Shortcut',command=save).pack(side='right')
        ttk.Button(buttons,text='Clear Selected Shortcut',command=lambda:(key.set(''),save())).pack(side='right',padx=8)
        ttk.Button(buttons,text='Close',command=win.destroy).pack(side='left')
        refresh()
    cls.shortcut_settings=shortcut_settings
