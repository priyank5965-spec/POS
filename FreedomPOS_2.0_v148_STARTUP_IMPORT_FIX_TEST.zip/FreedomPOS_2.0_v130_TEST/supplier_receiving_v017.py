"""Test-only supplier invoice receiving workspace; atomic stock posting."""
import tkinter as tk
from tkinter import ttk,messagebox,filedialog
from datetime import date
from decimal import Decimal,InvalidOperation,ROUND_HALF_UP
import sqlite3
import csv, json, os, hashlib, xml.etree.ElementTree as ET
from pathlib import Path
import re
import invoice_mapping_engine_v103 as ime

def money(s):
    try:
        n=Decimal(str(s).replace('$','').replace(',','').strip())
        if not n.is_finite() or n<0:raise ValueError()
        return int((n*100).quantize(Decimal('1'),rounding=ROUND_HALF_UP))
    except (ValueError,InvalidOperation):raise ValueError('Enter a valid non-negative dollar amount')
def ensure(db):
    db.executescript('''CREATE TABLE IF NOT EXISTS receiving_headers(invoice_id INTEGER PRIMARY KEY,invoice_date TEXT NOT NULL,received_date TEXT NOT NULL,due_date TEXT DEFAULT '',reference TEXT DEFAULT '',notes TEXT DEFAULT '',expected_total INTEGER DEFAULT 0,finalised_at TEXT DEFAULT '');
    CREATE TABLE IF NOT EXISTS receiving_lines(id INTEGER PRIMARY KEY,invoice_id INTEGER NOT NULL,product_id INTEGER NOT NULL,barcode TEXT NOT NULL,description TEXT NOT NULL,qty_invoiced INTEGER NOT NULL,qty_received INTEGER NOT NULL,unit_cost INTEGER NOT NULL,gst_rate INTEGER NOT NULL DEFAULT 10,retail_snapshot INTEGER NOT NULL,UNIQUE(invoice_id,product_id));''')
    db.execute('''CREATE TABLE IF NOT EXISTS receiving_sources(source_hash TEXT PRIMARY KEY,invoice_id INTEGER NOT NULL,source_name TEXT NOT NULL)''')
    # Cross-module links use stable IDs; existing invoices remain compatible.
    for column,ctype in [('supplier_id','INTEGER'),('staff_id','INTEGER'),('freight_ex','INTEGER DEFAULT 0'),('freight_gst','INTEGER DEFAULT 0'),('difference_reason',"TEXT DEFAULT ''")]:
        if column not in {r[1] for r in db.execute('PRAGMA table_info(receiving_headers)')}:
            db.execute(f'ALTER TABLE receiving_headers ADD COLUMN {column} {ctype}')
    cols={r[1] for r in db.execute('PRAGMA table_info(receiving_lines)')}
    for name,kind in [('supplier_sku',"TEXT DEFAULT ''"),('discount_pct','REAL NOT NULL DEFAULT 0'),('markup_pct','REAL NOT NULL DEFAULT 0'),('is_new','INTEGER NOT NULL DEFAULT 0')]:
        if name not in cols:db.execute(f'ALTER TABLE receiving_lines ADD COLUMN {name} {kind}')
    db.execute('CREATE TABLE IF NOT EXISTS receiving_product_details(invoice_id INTEGER NOT NULL,barcode TEXT NOT NULL,details TEXT NOT NULL,PRIMARY KEY(invoice_id,barcode))')
    db.commit()


# Generic CSV/XML prototype importer. Real XchangeIT EDI mappings require representative files.
FIELDS={
 'barcode':('barcode','ean','gtin','upc','itembarcode','productbarcode'),
 'supplier_code':('suppliercode','sku','itemcode','productcode','stockcode'),
 'description':('description','productdescription','itemdescription','product','item','name'),
 'qty':('qty','quantity','quantityreceived','received','units','qtysupplied'),
 'cost':('cost','unitcost','price','unitprice','buyprice','netprice'),
 'gst':('gst','gstrate','taxrate'),
 'supplier':('supplier','suppliername','vendor'),
 'number':('invoicenumber','invoiceno','invoice','invno'),
 'invoice_date':('invoicedate','date'),
}
def norm(k):return ''.join(c for c in str(k).lower() if c.isalnum())
def mapped(d,key):
 lookup={norm(k):v for k,v in d.items()}
 for alias in FIELDS[key]:
  if alias in lookup and lookup[alias] is not None:return str(lookup[alias]).strip()
 return ''
def parse_incoming(path):
 path=Path(path); suffix=path.suffix.lower()
 if suffix=='.csv':
  with path.open('r',encoding='utf-8-sig',newline='') as f:
   sample=f.read(8192);f.seek(0)
   try:dialect=csv.Sniffer().sniff(sample,delimiters=',;\t|')
   except csv.Error:dialect=csv.excel
   rows=list(csv.DictReader(f,dialect=dialect))
 elif suffix=='.xml':
  root=ET.parse(path).getroot()
  def clean(tag):return tag.rsplit('}',1)[-1]
  candidates=[]
  for node in root.iter():
   children=list(node)
   if not children:continue
   data={clean(c.tag): (c.text or '').strip() for c in children if not list(c)}
   if mapped(data,'description') or (mapped(data,'barcode') and mapped(data,'qty')):candidates.append(data)
  rows=candidates
 else:raise ValueError('This prototype supports CSV and basic XML only. Other EDI layouts require supplier mapping.')
 if not rows:raise ValueError('No invoice product lines found.')
 first=rows[0]; lines=[]
 for i,row in enumerate(rows,1):
  code=mapped(row,'barcode');sc=mapped(row,'supplier_code');desc=mapped(row,'description')
  if not (code or sc or desc):continue
  raw_qty=mapped(row,'qty') or '1'
  try:
   qty=int(raw_qty)
   if qty<0:raise ValueError()
  except ValueError:raise ValueError(f'Row {i}: invalid integer quantity {raw_qty!r}')
  raw_cost=mapped(row,'cost');cost=money(raw_cost) if raw_cost else 0
  gst_raw=mapped(row,'gst')
  try:gst=int(float(gst_raw.replace('%',''))) if gst_raw else 10
  except ValueError:gst=10
  lines.append(dict(barcode=code,supplier_code=sc,description=desc,qty=qty,cost=cost,gst=gst,needs_cost=not bool(raw_cost)))
 if not lines:raise ValueError('No usable product rows found. Supplier mapping may be required.')
 return dict(supplier=mapped(first,'supplier'),number=mapped(first,'number'),invoice_date=mapped(first,'invoice_date'),lines=lines)

def incoming_dir(db):
 db.execute('CREATE TABLE IF NOT EXISTS receiving_settings(key TEXT PRIMARY KEY,value TEXT NOT NULL)')
 r=db.execute("SELECT value FROM receiving_settings WHERE key='xchange_incoming'").fetchone()
 return Path(r[0]) if r else Path.home()/'Xchange'/'Incoming'

def source_hash(path):
 h=hashlib.sha256()
 with open(path,'rb') as f:
  for block in iter(lambda:f.read(65536),b''):h.update(block)
 return h.hexdigest()

def install(cls):
    def supplier_invoices(self):
        ensure(self.db);self.clear();self.header('SUPPLIER INVOICES / STOCK RECEIVED')
        toolbar=tk.Frame(self.root,bg='white');toolbar.pack(fill='x',padx=12,pady=8)
        self.btn(toolbar,'NEW STOCK RECEIPT',lambda:editor(self),size=10,height=1).pack(side='left',padx=4)
        self.btn(toolbar,'REFRESH',self.supplier_invoices,size=10,height=1).pack(side='left',padx=4)
        self.btn(toolbar,'XCHANGE INCOMING',lambda:incoming(self),size=10,height=1).pack(side='left',padx=4)
        self.btn(toolbar,'AI INVOICE',lambda:ai_invoice(self),size=10,height=1).pack(side='left',padx=4)
        cols=('ID','Supplier','Invoice #','Created','Total','Status')
        tree=self.tree(self.root,cols,[65,260,180,180,130,140])
        for r in self.db.execute('SELECT * FROM supplier_invoices ORDER BY id DESC'):
            tree.insert('','end',iid=str(r['id']),values=(r['id'],r['supplier'],r['number'],r['created'],f'${r["amount"]/100:.2f}',r['status']))
        def open_selected(_=None):
            sel=tree.selection()
            if sel:editor(self,int(sel[0]))
        self.btn(toolbar,'OPEN SELECTED INVOICE',open_selected,size=10,height=1).pack(side='left',padx=4)
        tree.bind('<Double-1>',open_selected)
        tk.Label(self.root,text='TEST DATA ONLY • Double-click an invoice to review. Finalising posts received quantities once; no live supplier or accounting integration.',bg='white',fg='#9b3229').pack(pady=5)
    def editor(self,invoice_id=None,import_data=None,source_info=None):
        ensure(self.db)
        from stock_screen_v015 import ensure as ensure_stock
        ensure_stock(self.db)
        existing=self.db.execute('SELECT * FROM supplier_invoices WHERE id=?',(invoice_id,)).fetchone() if invoice_id else None
        hdr=self.db.execute('SELECT * FROM receiving_headers WHERE invoice_id=?',(invoice_id,)).fetchone() if existing else None
        locked=bool(existing and existing['status']=='FINALISED')
        win=tk.Toplevel(self.root);win.title('Freedom POS 2.0 — STOCK RECEIVED — TEST ONLY');win.geometry('1450x870');win.minsize(1060,680)
        win.configure(bg='white')
        bar=tk.Frame(win,bg='white');bar.pack(fill='x')
        tk.Label(bar,text='STOCK RECEIVED  /  SUPPLIER INVOICE',font=('Segoe UI',17,'bold'),bg='white',fg='#111111').pack(side='left',padx=15,pady=10)
        tk.Button(bar,text='CLOSE',command=win.destroy,width=12).pack(side='right',padx=12)
        footer=tk.Frame(win,bg='#e5edf1',height=104)
        footer.pack(side='bottom',fill='x')
        footer.pack_propagate(False)
        head=ttk.LabelFrame(win,text='1  Invoice Details — all fields together');head.pack(fill='x',padx=10,pady=6)
        fields=[('Supplier','supplier',existing['supplier'] if existing else ''),('Invoice number','number',existing['number'] if existing else ''),('Invoice date','invoice_date',hdr['invoice_date'] if hdr else str(date.today())),('Received date','received_date',hdr['received_date'] if hdr else str(date.today())),('Due date','due_date',hdr['due_date'] if hdr else ''),('Reference','reference',hdr['reference'] if hdr else ''),('Staff initials','staff_initials',''),('Supplier invoice total $','supplier_total','')]
        vars={k:tk.StringVar(value=v) for _,k,v in fields}
        vars['notes']=tk.StringVar(value=hdr['notes'] if hdr else '')
        if hdr and hdr['expected_total'] is not None:vars['supplier_total'].set(f"{hdr['expected_total']/100:.2f}")
        suppliers=[]
        try:suppliers=[r[0] for r in self.db.execute('SELECT name FROM suppliers_master WHERE active=1 ORDER BY name')]
        except sqlite3.Error:pass
        # Reuse supplier and staff master records, never arbitrary free-text identities.
        from linked_maintenance_v099 import ensure_links,quick_supplier
        ensure_links(self.db)
        staff_rows=self.db.execute('SELECT id,name,initials FROM staff WHERE active=1 ORDER BY name').fetchall()
        staff_options=[((r['initials'] or '').strip()+' — ' if (r['initials'] or '').strip() else '')+(r['name'] or '').strip() for r in staff_rows if (r['name'] or '').strip()]
        if hdr and hdr['staff_id']:
            match=next((r for r in staff_rows if r['id']==hdr['staff_id']),None)
            if match:vars['staff_initials'].set(((match['initials'] or '').strip()+' — ' if (match['initials'] or '').strip() else '')+(match['name'] or '').strip())
        for i,(label,key,_) in enumerate(fields):
            row,col=divmod(i,4);ttk.Label(head,text=label).grid(row=row*2,column=col,sticky='w',padx=9,pady=(6,0))
            widget=ttk.Combobox(head,textvariable=vars[key],values=suppliers) if key=='supplier' else (ttk.Combobox(head,textvariable=vars[key],values=staff_options) if key=='staff_initials' else ttk.Entry(head,textvariable=vars[key]))
            widget.grid(row=row*2+1,column=col,sticky='ew',padx=9,pady=(1,8));
            if locked:widget.configure(state='disabled')
        note_row=ttk.Frame(win);note_row.pack(fill='x',padx=12)
        ttk.Label(note_row,text='Invoice notes').pack(side='left',padx=5)
        note_entry=ttk.Entry(note_row,textvariable=vars['notes']);note_entry.pack(side='left',fill='x',expand=True)
        if locked:note_entry.configure(state='disabled')
        # Freight is an invoice charge, never added to product cost or retail prices.
        chargebar=ttk.Frame(win);chargebar.pack(fill='x',padx=12,pady=2)
        freight_ex=tk.StringVar(value=f'{hdr["freight_ex"]/100:.2f}' if hdr and 'freight_ex' in hdr.keys() else '0.00')
        freight_gst=tk.StringVar(value=str(hdr['freight_gst']) if hdr and 'freight_gst' in hdr.keys() else '10')
        difference_reason=tk.StringVar(value=(hdr['difference_reason'] or '') if hdr and 'difference_reason' in hdr.keys() else '')
        ttk.Label(chargebar,text='Freight ex GST $').pack(side='left',padx=5)
        ttk.Entry(chargebar,textvariable=freight_ex,width=12).pack(side='left')
        ttk.Label(chargebar,text='Freight GST %').pack(side='left',padx=5)
        ttk.Combobox(chargebar,textvariable=freight_gst,values=['0','10'],width=5,state='readonly').pack(side='left')
        ttk.Label(chargebar,text='Difference reason (if any)').pack(side='left',padx=5)
        ttk.Entry(chargebar,textvariable=difference_reason,width=40).pack(side='left',fill='x',expand=True)
        if locked:
            for child in chargebar.winfo_children():
                if isinstance(child,(ttk.Entry,ttk.Combobox)):child.configure(state='disabled')
        supplier_widget=next(c for c in head.winfo_children() if isinstance(c,ttk.Combobox) and str(c.cget('textvariable'))==str(vars['supplier']))
        staff_widget=next(c for c in head.winfo_children() if isinstance(c,ttk.Combobox) and str(c.cget('textvariable'))==str(vars['staff_initials']))
        def supplier_lookup(_=None):
            current=vars['supplier'].get().strip()
            if not current:return
            matches=[x for x in suppliers if current.casefold() in x.casefold()]
            supplier_widget.configure(values=matches or suppliers)
            if len(matches)==1 and matches[0].casefold()==current.casefold():
                vars['supplier'].set(matches[0]);return
            if current in suppliers:return
            if matches:
                supplier_widget.event_generate('<Down>');return
            if messagebox.askyesno('Supplier not found',f'No supplier matches {current!r}. Add this supplier?',parent=win):
                created=quick_supplier(self,win,initial_name=current)
                if created:
                    suppliers.append(created);suppliers.sort();vars['supplier'].set(created);supplier_widget.configure(values=suppliers)
        def supplier_type(_=None):
            q=vars['supplier'].get().strip().casefold()
            supplier_widget.configure(values=[x for x in suppliers if q in x.casefold()] if q else suppliers)
        supplier_widget.bind('<KeyRelease>',supplier_type)
        supplier_widget.bind('<Return>',supplier_lookup)
        supplier_widget.bind('<FocusOut>',lambda _ : win.after(100,supplier_lookup))
        def staff_lookup(_=None):
            q=vars['staff_initials'].get().strip()
            if not q:return
            exact=[r for r in staff_rows if (r['initials'] or '').casefold()==q.casefold() or (r['name'] or '').casefold()==q.casefold() or (((r['initials'] or '').strip()+' — ' if (r['initials'] or '').strip() else '')+(r['name'] or '').strip()).casefold()==q.casefold()]
            if len(exact)==1:vars['staff_initials'].set(((exact[0]['initials'] or '').strip()+' — ' if (exact[0]['initials'] or '').strip() else '')+(exact[0]['name'] or '').strip())
            else:
                matches=[x for x in staff_options if q.casefold() in x.casefold()]
                staff_widget.configure(values=matches)
        staff_widget.bind('<KeyRelease>',lambda _:staff_widget.configure(values=[x for x in staff_options if vars['staff_initials'].get().casefold() in x.casefold()]))
        staff_widget.bind('<Return>',staff_lookup)
        staff_widget.bind('<FocusOut>',lambda _:win.after(100,staff_lookup))
        for col in range(4):head.columnconfigure(col,weight=1)
        scan=tk.Frame(win,bg='white');scan.pack(fill='x',padx=10,pady=5)
        tk.Label(scan,text='Scan barcode / enter supplier SKU or product name:',bg='white',font=('Segoe UI',11,'bold')).pack(side='left')
        code=tk.StringVar();entry=ttk.Entry(scan,textvariable=code,width=44,font=('Segoe UI',12));entry.pack(side='left',padx=8)
        gridframe=ttk.LabelFrame(win,text='2  Stock Entry — double-click Qty, Cost or GST to edit; scan repeatedly to increase received quantity');gridframe.pack(fill='both',expand=True,padx=10,pady=5)
        cols=('barcode','sku','description','qty','cost','cost_mode','discount','gst','markup','retail','line_total')
        tree=ttk.Treeview(gridframe,columns=cols,show='headings',selectmode='browse')
        labels=('Barcode','Supplier SKU','Product Description','Qty','Unit Cost $','Cost GST','Discount %','GST %','Markup %','Retail $ inc GST','Line Total $')
        for col,label,width in zip(cols,labels,(140,110,270,75,100,90,90,65,90,120,120)):
            tree.heading(col,text=label);tree.column(col,width=width,minwidth=65,stretch=col=='description')
        sy=ttk.Scrollbar(gridframe,orient='vertical',command=tree.yview);tree.configure(yscrollcommand=sy.set)
        sy.pack(side='right',fill='y');tree.pack(fill='both',expand=True)
        lines={}
        def restore_details(l):
            if invoice_id:
                r=self.db.execute('SELECT details FROM receiving_product_details WHERE invoice_id=? AND barcode=?',(invoice_id,l['barcode'])).fetchone()
                if r:
                    try:l.update(json.loads(r[0]))
                    except (ValueError,TypeError):pass
            l.setdefault('cost_mode','EX GST');l.setdefault('extra',{})
            return l
        if existing:
            for r in self.db.execute('SELECT * FROM receiving_lines WHERE invoice_id=? ORDER BY id',(invoice_id,)):
                lines[r['product_id'] if r['product_id'] else -r['id']]=dict(pid=r['product_id'] if r['product_id']>0 else None,barcode=r['barcode'],sku=r['supplier_sku'] or '',name=r['description'],invoiced=r['qty_invoiced'],received=r['qty_received'],cost=r['unit_cost'],discount=r['discount_pct'],gst=r['gst_rate'],markup=r['markup_pct'],retail=r['retail_snapshot'],new=bool(r['is_new']),cost_mode='EX GST',extra={})
                restore_details(lines[r['product_id'] if r['product_id'] else -r['id']])
        # All import paths converge on the same editable arrival grid.
        if import_data and not existing:
            for key in ('supplier','number','invoice_date','supplier_total'):
                if import_data.get(key):vars[key].set(import_data[key])
            unmatched=[]
            for index,item in enumerate(import_data['lines'],1):
                code=item['barcode'];sc=item['supplier_code'];name=item['description']
                p=None
                if code:p=self.db.execute('SELECT * FROM products WHERE barcode=?',(code,)).fetchone()
                if not p and sc:p=self.db.execute('SELECT * FROM products WHERE supplier_code=?',(sc,)).fetchone()
                if not p and name:p=self.db.execute('SELECT * FROM products WHERE lower(name)=lower(?)',(name,)).fetchone()
                if not p:
                    key=-index
                    while key in lines:key-=100000
                    lines[key]=dict(pid=None,barcode=code or sc,sku=sc,name=name or 'NEW PRODUCT - ENTER DESCRIPTION',invoiced=item['qty'],received=item['qty'],cost=item['cost'],discount=0,gst=item['gst'] if item['gst'] in (0,10) else 10,markup=50,retail=item.get('rrp',0),new=True,cost_mode='EX GST',extra={'supplier_rrp':str(item.get('rrp',0)/100)})
                    continue
                pid=p['id']
                if pid in lines:
                    if lines[pid]['cost']!=item['cost']:unmatched.append(f'Line {index}: duplicate product with different cost: {name}');continue
                    lines[pid]['received']+=item['qty'];lines[pid]['invoiced']+=item['qty']
                else:
                    lines[pid]=dict(pid=pid,barcode=p['barcode'],sku=sc or p['supplier_code'],name=p['name'],invoiced=item['qty'],received=item['qty'],cost=item['cost'],discount=0,gst=item['gst'] if item['gst'] in (0,10) else 10,markup=0,retail=p['price'],new=False,cost_mode='EX GST',extra={})
            for l in lines.values():
                if l.get('new') and not l.get('retail'):l['retail']=int(Decimal(l['cost'])*(Decimal(100)+Decimal(l.get('markup',0)))/100*(Decimal(100)+Decimal(l['gst']))/100)
            if import_data.get('warnings'):
                messagebox.showwarning('Import checks','Review imported rows:\n'+'\n'.join(import_data['warnings'][:18]),parent=win)
            if import_data.get('charges'):
                messagebox.showwarning('Invoice charges','Freight and other invoice charges were NOT added to stock lines. Reconcile separately before finalising.',parent=win)
            if unmatched:
                messagebox.showwarning('Review unmatched lines','The following lines were NOT imported into the grid. Add products or match codes first; do not finalise until resolved:\n\n'+'\n'.join(unmatched[:18]),parent=win)
            if any(x['needs_cost'] for x in import_data['lines']):
                messagebox.showwarning('Review costs','Some imported lines have no unit cost. Check all prices before finalising.',parent=win)
        totals=tk.StringVar();status=tk.StringVar(value='FINALIZED — read only' if locked else 'Draft — stock has not been posted')
        def net_unit(l):
            n=Decimal(l['cost'])*(Decimal('100')-Decimal(str(l.get('discount',0))))/100
            if l.get('cost_mode')=='INC GST':n=n*100/(100+Decimal(l['gst']))
            return int(n.quantize(Decimal('1'),rounding=ROUND_HALF_UP))
        def line_total(l):
            ex=l['received']*net_unit(l)
            return int((Decimal(ex)*(Decimal(100)+Decimal(l['gst']))/100).quantize(Decimal('1'),rounding=ROUND_HALF_UP))
        def calc_rrp(l):
            n=Decimal(net_unit(l))*(Decimal('100')+Decimal(str(l.get('markup',0))))/100
            n=n*(Decimal('100')+Decimal(l['gst']))/100
            return int(n.quantize(Decimal('1'),rounding=ROUND_HALF_UP))
        def refresh():
            tree.delete(*tree.get_children());qty=0;total=0
            for pid,l in lines.items():
                sub=line_total(l);qty+=l['received'];total+=sub
                tree.insert('','end',iid=str(pid),values=(l['barcode'],l.get('sku',''),l['name'],l['received'],f'{l["cost"]/100:.2f}',l.get('cost_mode','EX GST'),f'{l.get("discount",0):g}',l['gst'],f'{l.get("markup",0):g}',f'{l["retail"]/100:.2f}',f'{sub/100:.2f}'))
            try:original=money(vars['supplier_total'].get()) if vars['supplier_total'].get().strip() else None
            except ValueError:original=None
            try:
                freight=money(freight_ex.get());freight_tax=int((Decimal(freight)*Decimal(freight_gst.get())/100).quantize(Decimal('1'),rounding=ROUND_HALF_UP))
            except (ValueError,InvalidOperation):freight=freight_tax=0
            total+=freight+freight_tax
            diff=f' | Difference: ${(total-original)/100:+.2f}' if original is not None else ' | Enter supplier total to reconcile'
            totals.set(f'{len(lines)} products | {qty} units | Calculated total: ${total/100:,.2f}'+diff)
        vars['supplier_total'].trace_add('write',lambda *_:refresh())
        freight_ex.trace_add('write',lambda *_:refresh())
        freight_gst.trace_add('write',lambda *_:refresh())
        def add_new_stock_item(query):
            """Pending stock master editor: no product is committed until invoice finalisation."""
            d=tk.Toplevel(win);d.title('Add New Stock Item — TEST ONLY');d.geometry('980x710');d.minsize(790,550);d.transient(win);d.grab_set()
            tabs=ttk.Notebook(d);tabs.pack(fill='both',expand=True,padx=10,pady=8)
            pages={}
            for label in ('General','Supplier','Pricing','Ordering'):
                f=ttk.Frame(tabs);tabs.add(f,text=label);pages[label]=f
            data={};inputs={}
            spec={
             'General':[('Description *','description',''),('Barcode','barcode',query if query.isdigit() and len(query)>=8 else ''),('Internal SKU','internal_sku',''),('Short Description','short_description',''),('Department','department',''),('Family','family',''),('Class','class',''),('Category','category',''),('Manufacturer','manufacturer',''),('Register Note','register_note',''),('Stock Type','stock_type','General'),('GST Rate %','gst','10'),('Discountable','discountable','Yes')],
             'Supplier':[('Supplier','supplier',vars['supplier'].get()),('Supplier SKU','supplier_sku',query if not (query.isdigit() and len(query)>=8) else ''),('Buy Pack Qty','pack_qty','1'),('Wholesale Cost $','cost','0.00'),('Cost includes GST?','cost_mode','EX GST'),('Wholesale Discount %','discount','0'),('Return Style','return_style','Not Applicable'),('Return Frequency','return_frequency','Not Set'),('Discontinued','discontinued','No')],
             'Pricing':[('Markup %','markup','50'),('Retail Price inc GST $','retail','0.00'),('Supplier RRP $','supplier_rrp','0.00'),('Additional Barcode','additional_barcode','')],
             'Ordering':[('Minimum Stock','minimum_stock','0'),('Target Stock','target_stock','0'),('Reorder Qty','reorder_qty','0'),('Lead Time Days','lead_time','0'),('Ordering Cycle','ordering_cycle','')]
            }
            for page,items in spec.items():
                frame=pages[page]
                for i,(label,key,default) in enumerate(items):
                    row,col=divmod(i,2)
                    ttk.Label(frame,text=label).grid(row=row*2,column=col,sticky='w',padx=12,pady=(8,0))
                    v=tk.StringVar(value=default);data[key]=v
                    choices={'cost_mode':['EX GST','INC GST'],'discountable':['Yes','No'],'discontinued':['No','Yes']}
                    w=ttk.Combobox(frame,textvariable=v,values=choices[key],state='readonly') if key in choices else ttk.Entry(frame,textvariable=v)
                    w.grid(row=row*2+1,column=col,sticky='ew',padx=12,pady=(0,8));inputs[key]=w
                frame.columnconfigure(0,weight=1);frame.columnconfigure(1,weight=1)
            result=[None]
            def auto_price(*_):
                try:
                    c=money(data['cost'].get());gst=Decimal(data['gst'].get());disc=Decimal(data['discount'].get());markup=Decimal(data['markup'].get())
                    if not 0<=gst<=100 or not 0<=disc<=100 or not 0<=markup<=10000:return
                    net=Decimal(c)*(100-disc)/100
                    if data['cost_mode'].get()=='INC GST':net=net*100/(100+gst)
                    retail=(net*(100+markup)/100*(100+gst)/100/100).quantize(Decimal('0.01'),rounding=ROUND_HALF_UP)
                    data['retail'].set(str(retail))
                except (ValueError,InvalidOperation,ZeroDivisionError):pass
            for k in ('cost','gst','discount','markup','cost_mode'):data[k].trace_add('write',auto_price)
            auto_price()
            def finish():
                try:
                    name=data['description'].get().strip();barcode=data['barcode'].get().strip();sku=data['supplier_sku'].get().strip()
                    if not name or not (barcode or sku):raise ValueError('Description and a barcode or supplier SKU are required.')
                    if not barcode:
                        import uuid
                        barcode='HOUSE-'+uuid.uuid4().hex[:12].upper()
                    if self.db.execute('SELECT 1 FROM products WHERE barcode=?',(barcode,)).fetchone():raise ValueError('Barcode already exists in Stock Master.')
                    cost=money(data['cost'].get());retail=money(data['retail'].get())
                    gst=int(data['gst'].get());discount=float(data['discount'].get());markup=float(data['markup'].get())
                    if gst not in (0,10) or not 0<=discount<=100 or not 0<=markup<=10000:raise ValueError('Check GST, discount and markup.')
                    if cost<=0:raise ValueError('Wholesale cost must be greater than zero.')
                    extra={k:v.get().strip() for k,v in data.items()}
                    result[0]=dict(pid=None,barcode=barcode,sku=sku,name=name,invoiced=1,received=1,cost=cost,discount=discount,gst=gst,markup=markup,retail=retail,new=True,cost_mode=data['cost_mode'].get(),extra=extra)
                    d.destroy()
                except (ValueError,InvalidOperation) as e:messagebox.showerror('Check stock item',str(e),parent=d)
            footer2=ttk.Frame(d);footer2.pack(side='bottom',fill='x',padx=12,pady=12)
            ttk.Button(footer2,text='ADD TO INVOICE GRID',command=finish).pack(side='right',padx=5)
            ttk.Button(footer2,text='CANCEL',command=d.destroy).pack(side='right',padx=5)
            inputs['description'].focus_set();d.wait_window();return result[0]
        def add():
            if locked:return
            q=code.get().strip()
            if not q:return
            selected_supplier=vars['supplier'].get().strip()
            p=self.db.execute('''SELECT p.* FROM products p LEFT JOIN stock_aliases a ON a.product_id=p.id LEFT JOIN stock_supplier_links sl ON sl.product_id=p.id AND sl.supplier=? WHERE p.barcode=? OR a.barcode=? OR p.sku=? OR (sl.stock_code=? AND sl.supplier=?) OR (p.supplier_code=? AND p.supplier=?) OR lower(p.name)=lower(?) ORDER BY CASE WHEN p.barcode=? THEN 0 WHEN a.barcode=? THEN 1 ELSE 2 END LIMIT 1''',(selected_supplier,q,q,q,q,selected_supplier,q,selected_supplier,q,q,q)).fetchone()
            if not p and not any(ch.isdigit() for ch in q):
                matches=self.db.execute('SELECT * FROM products WHERE name LIKE ? ORDER BY name LIMIT 2',('%'+q+'%',)).fetchall()
                if len(matches)==1:p=matches[0]
            if not p:
                new=add_new_stock_item(q)
                if new is None:return
                key=min([0]+[k for k in lines if k<0])-1
                lines[key]=new
                tree.after_idle(lambda:tree.selection_set(str(key)))
            else:
                pid=p['id']
                if pid in lines:lines[pid]['received']+=1;lines[pid]['invoiced']+=1
                else:
                    cost=p['cost'] if 'cost' in p.keys() and p['cost'] else 0
                    lines[pid]=dict(pid=pid,barcode=p['barcode'],sku=p['supplier_code'] or '',name=p['name'],invoiced=1,received=1,cost=cost,discount=0,gst=10,markup=0,retail=p['price'],new=False,cost_mode='EX GST',extra={})
            code.set('');refresh();entry.focus_set()
        entry.bind('<Return>',lambda _:add());ttk.Button(scan,text='ADD / SCAN',command=add).pack(side='left',padx=4)
        def edit_cell(event):
            if locked:return
            rid=tree.identify_row(event.y);col=tree.identify_column(event.x)
            keys={'#1':'barcode','#2':'sku','#3':'name','#4':'received','#5':'cost','#6':'cost_mode','#7':'discount','#8':'gst','#9':'markup','#10':'retail'}
            if not rid or col not in keys:return
            key=keys[col];bbox=tree.bbox(rid,col)
            if not bbox:return
            x,y,w,h=bbox;edit=ttk.Entry(tree);edit.place(x=x,y=y,width=w,height=h)
            l=lines[int(rid)];edit.insert(0,f'{l[key]/100:.2f}' if key in ('cost','retail') else str(l.get(key,'')));edit.focus_set();edit.select_range(0,'end')
            def commit(_=None):
                try:
                    raw=edit.get().strip()
                    if key in ('cost','retail'):v=money(raw)
                    elif key in ('invoiced','received','gst'):v=int(raw)
                    elif key=='cost_mode':
                        v=raw.upper()
                        if v not in ('EX GST','INC GST'):raise ValueError()
                    elif key in ('discount','markup'):v=float(raw)
                    else:v=raw
                    if key in ('invoiced','received') and not 0<=v<=100000:raise ValueError()
                    if key=='gst' and v not in (0,10):raise ValueError()
                    if key=='discount' and not 0<=v<=100:raise ValueError()
                    if key=='markup' and not 0<=v<=10000:raise ValueError()
                    if key=='barcode' and (not v or any(x.get('barcode')==v and x is not l for x in lines.values())):raise ValueError()
                    l[key]=v
                    if key=='received':l['invoiced']=v
                    if key in ('cost','cost_mode','discount','gst','markup') and (l.get('new') or l.get('markup',0)>0):l['retail']=calc_rrp(l)
                    edit.destroy();refresh()
                except (ValueError,InvalidOperation):messagebox.showerror('Invalid value','Check the value. GST must be 0 or 10; discount 0-100%.',parent=win);edit.focus_set()
            edit.bind('<Return>',commit);edit.bind('<Escape>',lambda _:edit.destroy())
        tree.bind('<Double-1>',edit_cell)
        markupbar=tk.Frame(win,bg='white');markupbar.pack(fill='x',padx=10)
        ttk.Label(markupbar,text='Apply markup % to ALL lines:').pack(side='left')
        allmarkup=tk.StringVar(value='50');ttk.Entry(markupbar,textvariable=allmarkup,width=8).pack(side='left',padx=5)
        def apply_markup():
            try:
                v=float(allmarkup.get())
                if not 0<=v<=10000:raise ValueError()
                for l in lines.values():l['markup']=v;l['retail']=calc_rrp(l)
                refresh()
            except ValueError:messagebox.showerror('Markup','Enter a markup between 0 and 10000%.',parent=win)
        ttk.Button(markupbar,text='APPLY MARKUP & RECALCULATE RRP',command=apply_markup).pack(side='left')
        bottom=tk.Frame(footer,bg='#e5edf1');bottom.pack(fill='x',padx=10,pady=2)
        ttk.Label(bottom,textvariable=totals,font=('Segoe UI',12,'bold')).pack(anchor='w',pady=3)
        ttk.Label(bottom,textvariable=status,foreground='#a04a28').pack(anchor='w',pady=3)
        def remove():
            if locked:return
            sel=tree.selection()
            if sel:lines.pop(int(sel[0]),None);refresh()
        def validate():
            supplier=vars['supplier'].get().strip();number=vars['number'].get().strip()
            if not supplier or not number:raise ValueError('Supplier and invoice number are required.')
            for k in ('invoice_date','received_date','due_date'):
                val=vars[k].get().strip()
                if val:
                    try:date.fromisoformat(val)
                    except ValueError:raise ValueError(f'{k.replace("_"," " ).title()} must be YYYY-MM-DD (or blank for Due Date).')
            supplier_row=self.db.execute('SELECT id FROM suppliers_master WHERE name=? AND active=1',(supplier,)).fetchone()
            if not supplier_row:raise ValueError('Select an existing supplier from Supplier Maintenance.')
            staff_value=vars['staff_initials'].get().strip()
            staff_id=next((r['id'] for r in staff_rows if staff_value and staff_value.casefold() in tuple(x.casefold() for x in ((r['initials'] or '').strip(),(r['name'] or '').strip(),((r['initials'] or '').strip()+' — ' if (r['initials'] or '').strip() else '')+(r['name'] or '').strip()) if x)),None)
            if staff_id is None:raise ValueError('Select staff initials from Staff Maintenance.')
            expected=money(vars['supplier_total'].get()) if vars['supplier_total'].get().strip() else 0
            for l in lines.values():
                if l['received']<0 or l['invoiced']<0:raise ValueError('Quantities must not be negative')
                if not l['barcode'] or not l['name'] or l['name'].startswith('NEW PRODUCT -'):raise ValueError('Complete barcode and description for all new products.')
                if l['new'] and l['cost']<=0:raise ValueError('Enter wholesale cost for every new product.')
            if len({l['barcode'] for l in lines.values()})!=len(lines):raise ValueError('Duplicate barcodes in invoice. Combine quantities or resolve the duplicate before finalising.')
            return supplier,number,expected,supplier_row,staff_id
        def save(final=False):
            nonlocal invoice_id,existing,locked
            if locked:return
            try:
                supplier,number,expected,supplier_row,staff_id=validate()
                if final and not lines:raise ValueError('Add at least one received product before finalising.')
                if final and not vars['supplier_total'].get().strip():raise ValueError('Enter the supplier invoice total to reconcile before finalising.')
                if source_info and final and self.db.execute('SELECT 1 FROM receiving_sources WHERE source_hash=?',(source_info[0],)).fetchone():raise ValueError('This source file was already finalised.')
                product_total=sum(line_total(l) for l in lines.values())
                freight=money(freight_ex.get())
                tax_rate=int(freight_gst.get())
                if tax_rate not in (0,10):raise ValueError('Freight GST must be 0 or 10%.')
                freight_tax=int((Decimal(freight)*Decimal(tax_rate)/100).quantize(Decimal('1'),rounding=ROUND_HALF_UP))
                total=product_total+freight+freight_tax
                if final and abs(total-expected)>1 and not difference_reason.get().strip():raise ValueError(f'Invoice difference ${(total-expected)/100:+.2f}. Enter a difference reason to finalise with the difference.')
                if final and not messagebox.askyesno('Confirm stock finalisation',f'Finalise invoice {number} for {supplier}?\n\n{len(lines)} lines, {sum(l["received"] for l in lines.values())} units\nProducts and freight: ${total/100:.2f}\nSupplier total: ${expected/100:.2f}\nDifference: ${(total-expected)/100:+.2f}\n\nStock will be posted once. Existing retail prices will not change.',parent=win):return
                with self.db:
                    if invoice_id:
                        old=self.db.execute('SELECT status FROM supplier_invoices WHERE id=?',(invoice_id,)).fetchone()
                        if not old or old['status']!='DRAFT':raise ValueError('Invoice is no longer editable.')
                        self.db.execute('UPDATE supplier_invoices SET supplier=?,number=?,amount=? WHERE id=?',(supplier,number,total,invoice_id))
                    else:
                        cur=self.db.execute('INSERT INTO supplier_invoices(supplier,number,created,amount,status) VALUES(?,?,?,?,?)',(supplier,number,str(date.today()),total,'DRAFT'))
                        invoice_id=cur.lastrowid
                    self.db.execute('INSERT INTO receiving_headers(invoice_id,invoice_date,received_date,due_date,reference,notes,expected_total) VALUES(?,?,?,?,?,?,?) ON CONFLICT(invoice_id) DO UPDATE SET invoice_date=excluded.invoice_date,received_date=excluded.received_date,due_date=excluded.due_date,reference=excluded.reference,notes=excluded.notes,expected_total=excluded.expected_total',(invoice_id,vars['invoice_date'].get(),vars['received_date'].get(),vars['due_date'].get(),vars['reference'].get(),vars['notes'].get(),expected))
                    self.db.execute('UPDATE receiving_headers SET supplier_id=?,staff_id=?,freight_ex=?,freight_gst=?,difference_reason=? WHERE invoice_id=?',(supplier_row['id'],staff_id,freight,freight_tax,difference_reason.get().strip(),invoice_id))
                    self.db.execute('DELETE FROM receiving_lines WHERE invoice_id=?',(invoice_id,))
                    self.db.execute('DELETE FROM receiving_product_details WHERE invoice_id=?',(invoice_id,))
                    for l in lines.values():
                        self.db.execute('INSERT INTO receiving_product_details(invoice_id,barcode,details) VALUES(?,?,?)',(invoice_id,l['barcode'],json.dumps({'cost_mode':l.get('cost_mode','EX GST'),'extra':l.get('extra',{})})))
                        self.db.execute('INSERT INTO receiving_lines(invoice_id,product_id,barcode,description,qty_invoiced,qty_received,unit_cost,gst_rate,retail_snapshot,supplier_sku,discount_pct,markup_pct,is_new) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)',(invoice_id,l['pid'] or -list(lines.values()).index(l)-1,l['barcode'],l['name'],l['invoiced'],l['received'],l['cost'],l['gst'],l['retail'],l.get('sku',''),l.get('discount',0),l.get('markup',0),int(l.get('new',False))))
                    if final:
                        updated=self.db.execute("UPDATE supplier_invoices SET status='FINALISED' WHERE id=? AND status='DRAFT'",(invoice_id,))
                        if updated.rowcount!=1:raise ValueError('Invoice already finalised')
                        for col,typ in [('family','TEXT'),('class_name','TEXT'),('manufacturer','TEXT'),('register_note','TEXT'),('stock_type','TEXT'),('gst_rate','INTEGER'),('pack_qty','INTEGER'),('target_stock','INTEGER'),('lead_time','INTEGER'),('cost_gst_mode','TEXT')]:
                            if col not in {r[1] for r in self.db.execute('PRAGMA table_info(products)')}:
                                self.db.execute(f'ALTER TABLE products ADD COLUMN {col} {typ}')
                        for l in lines.values():
                            if l.get('new'):
                                cur=self.db.execute('INSERT INTO products(barcode,name,price,stock,supplier,supplier_code,cost,rrp,sku) VALUES(?,?,?,?,?,?,?,?,?)',(l['barcode'],l['name'],l['retail'],l['received'],supplier,l.get('sku',''),net_unit(l),l['retail'],l.get('sku','')))
                                product_id=cur.lastrowid
                                x=l.get('extra',{})
                                self.db.execute('''UPDATE products SET short_name=?,sku=?,category=?,family=?,class_name=?,manufacturer=?,register_note=?,stock_type=?,gst_rate=?,pack_qty=?,target_stock=?,lead_time=?,reorder_point=?,reorder_qty=?,notes=?,cost_gst_mode=? WHERE id=?''',(x.get('short_description',''),x.get('internal_sku',''),x.get('department',''),x.get('family',''),x.get('class',''),x.get('manufacturer',''),x.get('register_note',''),x.get('stock_type',''),l['gst'],int(x.get('pack_qty') or 1),int(x.get('target_stock') or 0),int(x.get('lead_time') or 0),int(x.get('minimum_stock') or 0),int(x.get('reorder_qty') or 0),'',l.get('cost_mode','EX GST'),product_id))
                                if x.get('additional_barcode'):
                                    self.db.execute('INSERT INTO stock_aliases(barcode,product_id) VALUES(?,?)',(x['additional_barcode'],product_id))
                                self.db.execute('UPDATE receiving_lines SET product_id=? WHERE invoice_id=? AND barcode=?',(product_id,invoice_id,l['barcode']))
                            else:
                                self.db.execute('UPDATE products SET stock=stock+?,cost=? WHERE id=?',(l['received'],net_unit(l),l['pid']))
                        self.db.execute('CREATE TABLE IF NOT EXISTS stock_movement_journal(id INTEGER PRIMARY KEY,created TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,product_id INTEGER NOT NULL,qty_delta INTEGER NOT NULL,reason TEXT NOT NULL,source_id INTEGER,staff_id INTEGER,supplier_id INTEGER)')
                        for l in lines.values():
                            product_id=l['pid']
                            if not product_id:
                                found=self.db.execute('SELECT id FROM products WHERE barcode=?',(l['barcode'],)).fetchone()
                                product_id=found['id']
                            self.db.execute('INSERT INTO stock_movement_journal(product_id,qty_delta,reason,source_id,staff_id,supplier_id) VALUES(?,?,?,?,?,?)',(product_id,l['received'],'INVOICE ARRIVAL',invoice_id,staff_id,supplier_row['id']))
                            self.db.execute('INSERT OR REPLACE INTO stock_supplier_links(product_id,supplier,stock_code,preferred) VALUES(?,?,?,COALESCE((SELECT preferred FROM stock_supplier_links WHERE product_id=? AND supplier=?),0))',(product_id,supplier,l.get('sku',''),product_id,supplier))
                        self.db.execute('UPDATE receiving_headers SET finalised_at=datetime(\'now\') WHERE invoice_id=?',(invoice_id,))
                        if source_info:self.db.execute('INSERT INTO receiving_sources(source_hash,invoice_id,source_name) VALUES(?,?,?)',(source_info[0],invoice_id,source_info[1]))
                    self.db.execute('INSERT INTO events(created,category,description) VALUES(datetime(\'now\'),?,?)',('SUPPLIER RECEIVING',f'Invoice #{invoice_id} {"FINALISED" if final else "DRAFT SAVED"}: {supplier}/{number}; {len(lines)} lines; ${total/100:.2f}'))
                status.set('FINALIZED — received stock posted once' if final else f'Draft #{invoice_id} saved — no stock posted')
                if final:locked=True;entry.configure(state='disabled')
                messagebox.showinfo('Saved',status.get(),parent=win)
            except sqlite3.IntegrityError:messagebox.showerror('Duplicate invoice','This supplier/invoice number already exists.',parent=win)
            except (ValueError,sqlite3.Error) as e:messagebox.showerror('Check invoice',str(e),parent=win)
            except Exception as e:
                import traceback
                try:
                    with open('receiving_error.log','a',encoding='utf-8') as log:log.write(traceback.format_exc()+'\n')
                except OSError:pass
                messagebox.showerror('Invoice could not be saved',f'{type(e).__name__}: {e}\nSee receiving_error.log for details.',parent=win)
        buttons=tk.Frame(footer,bg='#e5edf1');buttons.pack(fill='x',padx=10,pady=(0,3))
        for label,fn in [('REMOVE SELECTED LINE',remove),('SAVE DRAFT',lambda:save(False)),('REVIEW & FINALISE',lambda:save(True)),('CLOSE',win.destroy)]:
            b=ttk.Button(buttons,text=label,command=fn);b.pack(side='left',padx=5,pady=4)
            if locked and label!='CLOSE':b.configure(state='disabled')
        # Remaining test limitations are documented in README_V101_TEST.txt.
        refresh();entry.focus_set()
    def incoming(self):
        ensure(self.db)
        win=tk.Toplevel(self.root);win.title('Xchange Incoming — Select & Preview — TEST ONLY');win.geometry('1280x780');win.minsize(1050,650);win.configure(bg='white')
        heading=tk.Frame(win,bg='white');heading.pack(fill='x')
        tk.Label(heading,text='XCHANGE INCOMING — ALL INVOICE FILES',font=('Segoe UI',16,'bold'),bg='white',fg='#111111').pack(anchor='w',padx=12,pady=12)
        folder=tk.StringVar(value=str(incoming_dir(self.db)))
        quick=tk.Frame(win,bg='white');quick.pack(fill='x',padx=10,pady=(8,0))
        ttk.Button(quick,text='MANUAL INVOICE',command=lambda:(win.destroy(),editor(self))).pack(side='left',padx=4)
        ttk.Button(quick,text='AI INVOICE',command=lambda:ai_invoice(self)).pack(side='left',padx=4)
        ttk.Button(quick,text='INVOICE HISTORY',command=lambda:(win.destroy(),self.supplier_invoices())).pack(side='left',padx=4)
        top=tk.Frame(win);top.pack(fill='x',padx=10,pady=8)
        ttk.Label(top,text='Incoming folder:').pack(side='left');ttk.Entry(top,textvariable=folder,width=80).pack(side='left',fill='x',expand=True,padx=6)
        def choose():
            chosen=filedialog.askdirectory(parent=win,initialdir=str(Path(folder.get()).parent))
            if chosen:
                folder.set(chosen)
                with self.db:self.db.execute("INSERT OR REPLACE INTO receiving_settings(key,value) VALUES('xchange_incoming',?)",(chosen,))
                refresh()
        ttk.Button(top,text='CHOOSE FOLDER',command=choose).pack(side='left',padx=4)
        cols=('file','type','supplier','invoice','lines','status');tree=ttk.Treeview(win,columns=cols,show='headings',selectmode='browse')
        for col,width in zip(cols,(300,75,190,150,70,120)):tree.heading(col,text=col.title());tree.column(col,width=width)
        tree.pack(fill='both',expand=True,padx=10,pady=5)
        preview=tk.Text(win,height=7,wrap='word');preview.pack(fill='x',padx=10,pady=5)
        files={}
        def map_spreadsheet(path):
            rows=ime.read_matrix(path)
            if not rows:raise ValueError('Spreadsheet is empty.')
            ime.ensure(self.db)
            guess_header,guess_mapping=ime.suggest(rows)
            result=[None]
            dlg=tk.Toplevel(win);dlg.title('Supplier Invoice Import Template — TEST ONLY');dlg.geometry('1080x690');dlg.transient(win);dlg.grab_set()
            top=tk.Frame(dlg);top.pack(fill='x',padx=10,pady=6)
            tk.Label(top,text='Supplier (existing supplier name)').grid(row=0,column=0,sticky='w')
            supplier_var=tk.StringVar();ttk.Entry(top,textvariable=supplier_var,width=34).grid(row=1,column=0,padx=5)
            tk.Label(top,text='Invoice number').grid(row=0,column=1,sticky='w')
            number_var=tk.StringVar(value=ime.invoice_number(rows));ttk.Entry(top,textvariable=number_var,width=25).grid(row=1,column=1,padx=5)
            tk.Label(top,text='Header row (1-based)').grid(row=0,column=2,sticky='w')
            header_var=tk.StringVar(value=str(guess_header+1));ttk.Entry(top,textvariable=header_var,width=8).grid(row=1,column=2,padx=5)
            mapping_vars={};mapping_box=ttk.LabelFrame(dlg,text='Map supplier columns to POS fields (choose Ignore if absent)');mapping_box.pack(fill='x',padx=10,pady=6)
            width=max(len(r) for r in rows)
            options=['Ignore']+[f'{j+1}: {rows[guess_header][j] if j<len(rows[guess_header]) else "Column"}' for j in range(width)]
            for idx,key in enumerate(ime.FIELDS):
                r,c=divmod(idx,5);ttk.Label(mapping_box,text=key.replace('_',' ').title()).grid(row=r*2,column=c,sticky='w',padx=8)
                v=tk.StringVar(value=options[guess_mapping[key]+1] if key in guess_mapping else 'Ignore')
                ttk.Combobox(mapping_box,textvariable=v,values=options,state='readonly',width=21).grid(row=r*2+1,column=c,padx=8,pady=(0,8));mapping_vars[key]=v
            prev=tk.Text(dlg,height=16,wrap='none');prev.pack(fill='both',expand=True,padx=10,pady=5)
            for n,row in enumerate(rows[:18],1):prev.insert('end',f'{n:>3}: '+' | '.join(row[:12])+'\n')
            def build_mapping():
                mapping={}
                for k,v in mapping_vars.items():
                    if v.get()!='Ignore':mapping[k]=int(v.get().split(':',1)[0])-1
                return mapping
            def load_template():
                name=supplier_var.get().strip()
                found=self.db.execute('SELECT header_row,mapping FROM receiving_import_templates WHERE supplier=?',(name,)).fetchone()
                if not found:return messagebox.showinfo('No template','No saved template for this supplier.',parent=dlg)
                header_var.set(str(found[0]+1));saved=json.loads(found[1])
                for k,v in mapping_vars.items():v.set(options[saved[k]+1] if k in saved and saved[k]<width else 'Ignore')
            def apply(save_template=False):
                try:
                    h=int(header_var.get())-1
                    if h<0 or h>=len(rows):raise ValueError('Header row outside spreadsheet')
                    mapping=build_mapping();supplier=supplier_var.get().strip()
                    data=ime.parse(rows,h,mapping,supplier,number_var.get().strip())
                    if save_template:
                        if not supplier:raise ValueError('Enter supplier name to save template')
                        with self.db:self.db.execute('INSERT OR REPLACE INTO receiving_import_templates(supplier,format,header_row,mapping) VALUES(?,?,?,?)',(supplier,path.suffix.lower(),h,json.dumps(mapping)))
                    result[0]=data;dlg.destroy()
                except Exception as e:messagebox.showerror('Import template',str(e),parent=dlg)
            actions=ttk.Frame(dlg);actions.pack(fill='x',padx=10,pady=8)
            ttk.Button(actions,text='LOAD SUPPLIER TEMPLATE',command=load_template).pack(side='left',padx=4)
            ttk.Button(actions,text='IMPORT THIS FILE',command=lambda:apply(False)).pack(side='left',padx=4)
            ttk.Button(actions,text='SAVE TEMPLATE & IMPORT',command=lambda:apply(True)).pack(side='left',padx=4)
            ttk.Button(actions,text='CANCEL',command=dlg.destroy).pack(side='right',padx=4)
            dlg.wait_window()
            return result[0]
        def refresh():
            tree.delete(*tree.get_children());files.clear();preview.delete('1.0','end')
            directory=Path(folder.get())
            if not directory.is_dir():preview.insert('end','Folder does not exist. Click CHOOSE FOLDER to select the incoming directory.');return
            for path in sorted(directory.iterdir(),key=lambda p:p.name.lower()):
                if not path.is_file() or path.suffix.lower() not in ('.csv','.xlsx','.xls','.xml','.edi','.dat','.txt','.ddo','.dd2','.pdf'):continue
                try:
                    digest=source_hash(path)
                    already_processed=bool(self.db.execute('SELECT 1 FROM receiving_sources WHERE source_hash=?',(digest,)).fetchone())
                    if path.suffix.lower() in ('.csv','.xlsx'):
                        rows=ime.read_matrix(path);h,m=ime.suggest(rows);supplier='—';number=ime.invoice_number(rows) or '—';count=max(0,len(rows)-h-1);status='Map / Preview'
                    elif path.suffix.lower()=='.xml':
                        data=parse_incoming(path);supplier=data['supplier'] or '—';number=data['number'] or '—';count=len(data['lines']);status='Ready'
                    else:supplier='—';number='—';count='—';status='Needs EDI mapping'
                    if already_processed:status='Already processed — view only'
                    rid=str(len(files));files[rid]=(path,digest)
                    tree.insert('','end',iid=rid,values=(path.name,path.suffix.lower(),supplier,number,count,status))
                except Exception as e:
                    rid=str(len(files));files[rid]=(path,source_hash(path));tree.insert('','end',iid=rid,values=(path.name,path.suffix.lower(),'—','—','—','Review format'))
            if not files:preview.insert('end','No invoice files found in this folder. Supported file types: XLSX, XLS, CSV, DDO, DD2, PDF, XML, EDI, DAT and TXT. Check the selected folder.')
        def selected():
            sel=tree.selection()
            if not sel:messagebox.showwarning('Select invoice','Select an invoice first.',parent=win);return None
            return files[sel[0]]
        def show_preview():
            value=selected()
            if not value:return
            path,digest=value;preview.delete('1.0','end')
            try:
                if path.suffix.lower() in ('.xlsx','.csv'):
                    rows=ime.read_matrix(path);h,m=ime.suggest(rows)
                    preview.insert('end',f'Spreadsheet: {len(rows)} rows; suggested header row {h+1}\n')
                    for r in rows[:12]:preview.insert('end',' | '.join(r[:10])+'\n')
                    return
                if path.suffix.lower()=='.pdf':
                    preview.insert('end',f'PDF invoice: {path.name}\nFile size: {path.stat().st_size:,} bytes\n\nPDF extraction is not connected in this TEST build. The file is visible but cannot yet be posted to stock.');return
                if path.suffix.lower() in ('.ddo','.dd2','.edi','.dat','.txt','.xls'):
                    preview.insert('end',f'Invoice file: {path.name}\nFormat: {path.suffix.upper()}\n\nA verified reader for this format is not connected in this TEST build. No stock will be posted.');return
                data=parse_incoming(path)
                preview.insert('end',f'Supplier: {data["supplier"] or "NOT DETECTED"}    Invoice: {data["number"] or "NOT DETECTED"}    Date: {data["invoice_date"] or "NOT DETECTED"}\n')
                for i,line in enumerate(data['lines'][:35],1):preview.insert('end',f'{i:>3}. {line["barcode"] or line["supplier_code"]:18}  {line["description"][:40]:40} Qty {line["qty"]:>5} Cost ${line["cost"]/100:.2f}\n')
                if len(data['lines'])>35:preview.insert('end',f'... and {len(data["lines"])-35} more lines')
            except Exception as e:preview.insert('end',f'Cannot map invoice automatically: {e}\n\nFile remains available; nothing has been posted.')
        def process():
            value=selected()
            if not value:return
            path,digest=value
            if self.db.execute('SELECT 1 FROM receiving_sources WHERE source_hash=?',(digest,)).fetchone():
                return messagebox.showwarning('Already processed','This file was already finalised. It remains visible for reference, but cannot be posted twice.',parent=win)
            if path.suffix.lower() not in ('.xlsx','.csv','.xml'):
                return messagebox.showwarning('Import reader pending',f'{path.suffix.upper()} files are detected and can be previewed, but automatic stock import for this format is not yet verified. No stock has been changed.',parent=win)
            try:
                if path.suffix.lower() in ('.xlsx','.csv'):
                    data=map_spreadsheet(path)
                    if data is None:return
                else:data=parse_incoming(path)
            except Exception as e:return messagebox.showerror('Import mapping required',str(e),parent=win)
            win.destroy();editor(self,import_data=data,source_info=(digest,path.name))
        for name,action in [('REFRESH',refresh),('1. PREVIEW INVOICE',show_preview),('2. IMPORT TO EDITABLE GRID',process),('CLOSE',win.destroy)]:ttk.Button(quick,text=name,command=action).pack(side='left',padx=5)
        ttk.Label(quick,text='CSV/XLSX/XML: import supported  |  PDF/DDO/DD2: reader pending',foreground='#a34a32').pack(side='left',padx=8)
        tree.bind('<Double-1>',lambda e:show_preview());refresh()
    def ai_invoice(self):
        messagebox.showinfo('AI Invoice — not yet connected','AI extraction of PDF, images and spreadsheets is not yet connected.\n\nFor this test, use XCHANGE INCOMING for CSV/basic XML invoices or NEW STOCK RECEIPT for manual entry. No document will be sent to an AI service.',parent=self.root)
    def incoming_invoices(self):
        incoming(self)
    cls.incoming_invoices=incoming_invoices
    cls.supplier_invoices=supplier_invoices
