"""Register v0.20: one-screen sale discount form and keyboard-safe cash handling."""
import tkinter as tk
from tkinter import ttk, messagebox
from decimal import Decimal, InvalidOperation, ROUND_HALF_UP

def install(cls):
    def discount_form(self):
        if not self.cart: return self.warn('Add an item before discounting.')
        if self.refund_origin: return self.warn('Discounts cannot be applied to linked refunds.')
        subtotal=sum(x['qty']*x['unit'] for x in self.cart)
        if subtotal <= 0: return self.warn('A positive subtotal is required.')
        w=tk.Toplevel(self.root); w.title('Sale Discount — TEST'); w.geometry('530x380'); w.transient(self.root); w.grab_set()
        tk.Label(w,text='SALE DISCOUNT',font=('Segoe UI',18,'bold')).pack(pady=12)
        tk.Label(w,text=f'Subtotal: ${subtotal/100:,.2f}',font=('Segoe UI',14)).pack()
        frame=tk.Frame(w); frame.pack(fill='x',padx=24,pady=12)
        tk.Label(frame,text='Discount type',width=18,anchor='w').grid(row=0,column=0,pady=9)
        mode=tk.StringVar(value='Amount ($)'); ttk.Combobox(frame,textvariable=mode,values=('Amount ($)','Percentage (%)'),state='readonly',width=23).grid(row=0,column=1)
        tk.Label(frame,text='Discount value',width=18,anchor='w').grid(row=1,column=0,pady=9)
        value=tk.StringVar(value=f'{self.discount/100:.2f}'); entry=tk.Entry(frame,textvariable=value,font=('Segoe UI',14),width=22); entry.grid(row=1,column=1)
        result=tk.Label(w,font=('Segoe UI',13,'bold')); result.pack(pady=8)
        def calculate():
            try:
                amount=Decimal(value.get().strip())
                if not amount.is_finite() or amount<0: raise ValueError()
                if mode.get()=='Percentage (%)':
                    if amount>100:raise ValueError()
                    amount=(Decimal(subtotal)*amount/100).quantize(Decimal('1'),rounding=ROUND_HALF_UP)
                    reduction=int(amount)
                else:reduction=int((amount*100).quantize(Decimal('1'),rounding=ROUND_HALF_UP))
                if reduction>subtotal:raise ValueError()
                result.config(text=f'Discount ${reduction/100:,.2f}    New total ${(subtotal-reduction)/100:,.2f}',fg='#111111')
                return reduction
            except (InvalidOperation,ValueError):
                result.config(text='Enter a valid discount within the sale total',fg='#a33');return None
        value.trace_add('write',lambda *_:calculate());mode.trace_add('write',lambda *_:calculate());calculate()
        buttons=tk.Frame(w);buttons.pack(fill='x',padx=24,pady=16)
        def save():
            reduction=calculate()
            if reduction is None:return
            self.discount=reduction;self.refresh_cart();w.destroy();self.code.focus_set()
        tk.Button(buttons,text='APPLY DISCOUNT',command=save,height=2,bg='#d9efdf').pack(side='left',expand=True,fill='x',padx=4)
        tk.Button(buttons,text='CANCEL',command=w.destroy,height=2).pack(side='left',expand=True,fill='x',padx=4)
        entry.focus_set()
    cls.set_discount=discount_form
