Freedom POS 2.0 v0.101 — LIMITED STOCK FOUNDATION TEST

Changes from v0.100:
- Fixed bottom Save Draft / Review & Finalise controls in Invoice Arrival.
- Supplier invoice total is compared with GST-inclusive calculated line totals, assuming unit cost EXCLUDES GST.
- Changing supplier invoice total refreshes difference display.
- Finalised arrivals record stock movement journal entries and supplier SKU links.

NOT IMPLEMENTED: Full 16-function stock suite, four-tab new product form, stock transfers, full stocktake reconciliation, reorder automation, advanced supplier catalogue mapping, accounting integration.
NOT TESTED: Windows GUI interactions, cross-module regression, hardware or live workflows.
Do not use for real business data.
