Freedom POS 2.0 v113 — TEST ONLY

Changes:
- New databases default to LINKLY STATUS instead of simulated payment approval.
- Added CHECK ACTUAL PINPAD STATUS (NO PAYMENT) to Linkly connection diagnostics.
- In LINKLY STATUS mode, clicking EFT queries the real Linkly client but ALWAYS blocks checkout.
- Existing databases preserve their saved mode. Select LINKLY STATUS under Settings > EFTPOS — TEST / LIVE MODE.
- Internal TEST simulator is still available by explicit selection. It can post simulated test sales, not bank payments.
- No Linkly financial request has been implemented; never interpret a TCP or status response as a payment approval.
- This build has not been tested with Windows Linkly hardware.
