FREEDOM POS 2.0 - WINDOWS TEST v0.4
====================================
THIS IS AN OFFLINE DEVELOPMENT TEST ONLY. DO NOT USE WITH REAL SHOP DATA.

INSTALL / START
1. Install Python 3 for Windows with tkinter (python.org), if not already installed.
2. Extract this ZIP to a NEW folder (do not overwrite v0.1 or v0.2).
3. Double-click START_FREEDOM_POS.bat.
4. Optionally double-click BUILD_TEST_EXE.bat to build a Windows EXE using PyInstaller (internet required for the first install).
5. Test data is saved in test_data/freedom_test_v03.db, separately from previous versions.

NEW IN v0.4
- Rebuilt Tower-inspired Previous Sales screen: summary grid, item details, payment details, 15 search fields, date/time and amount filters, two checkboxes, search/clear and CSV export.
- Working test receipt preview, gift receipt preview, and existing refund/exchange load.
- Fields not captured by existing v0.3 database (staff, serial, order number, source, terminal) display blank and non-empty filters for these return no matches.
- Reprint, email, invoice management and audited deletion/reversal are NOT implemented and explicitly report this.
- Same isolated v0.3 test database file within this extracted folder.

PREVIOUS v0.3 FEATURES
- Newspaper title/supplier setup and configured days of delivery.
- Newspaper standing orders with shop/home/subagent type.
- Express arrival screen automatically displays configured titles for the selected day; staff enter physical docket quantities.
- Future newspaper price changes saved and activated when due (newspaper setup prices only).
- Read-only preview of supplier DD2 CSV-structured files (no stock posting).
- CSV export of sale transaction lines.
- Retains v0.2's POS cash/account, lottery simulation, hold/recall, previous sales refund loading, product CSV import, basic magazine returns, blind stocktake, backup/restore and RustDesk launcher.

IMPORTANT LIMITATIONS / NOT COMPLETE
- Previous Sales is NOT the complete 16-function Tower workflow.
- Lottery and EFTPOS are simulations only, NOT connected to real terminals.
- DD2 preview is raw and field positions must be verified per supplier. No live DD2 receiving, RTF/RTD, SL2 or XchangeIT integration.
- Newspaper arrivals do NOT yet allocate copies or create provisional supplier invoices.
- Scheduled newspaper prices do NOT yet change all POS sale codes or customer billing.
- Stocktake owner PIN 9999 is a TEST DEMO only, not production-grade security.
- Android stocktake APK is NOT included.
- No full supplier invoice line-item receiving, customer statements, automatic owner email, Zebra labels, Linkly, live LAN multi-register or complete backup scheduling.
- Website integration is excluded at user's request.

Test only with sample data. This prototype is NOT ready for commercial or live retail use.
