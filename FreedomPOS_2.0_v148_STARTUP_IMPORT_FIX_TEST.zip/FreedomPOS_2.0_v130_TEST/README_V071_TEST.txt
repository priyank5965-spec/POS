Freedom POS 2.0 v0.71 — TEST ONLY

Department shortcuts: Settings & Tools > Department Buttons & Shortcuts. Click a shortcut field and press G, S, M, L, etc. Clear button removes shortcut. Choose inside (submenu) or popup for each department. Save Business Defaults.

Register: With empty barcode entry, department shortcut opens that department in its saved mode. With a valid dollar amount (e.g. 10 or 25.50) in barcode entry, pressing its shortcut adds a non-stock DEPARTMENT SALE line to the cart. The same applies to department buttons within the four-column department page. No automatic stock deduction. Payout departments are blocked from positive department sale entry; use lottery payout workflow.

IMPORTANT: No real payment integration. Department sale lines persist in sales and receipts but a separate aggregated department report and department-specific GST policy are NOT implemented. Test tax treatment before any live use. Do not use in production.

TESTED: Python compilation, shortcut parsing, duplicate validation, amount validation, ZIP integrity. Windows GUI and end-to-end checkout NOT tested.
