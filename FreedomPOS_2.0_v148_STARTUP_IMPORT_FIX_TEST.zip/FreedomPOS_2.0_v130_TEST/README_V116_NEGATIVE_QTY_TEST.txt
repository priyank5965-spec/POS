Freedom POS v116 TEST — Negative Quantity Grid

In Register, select a stock product line, choose EDIT LINE or tap its Qty cell twice.
Enter -1, -2, etc. Negative lines appear red and reduce the displayed total.
Enter a positive number to change the line back to a normal sale.

SAFETY: Negative lines entered manually in the grid are TEST RETURN LINES ONLY.
They cannot be posted as a sale, adjust inventory, or trigger a Linkly payment/refund.
For an actual linked refund workflow, use Previous Sales -> Refund / Exchange.

LINKLY TRAINING mode still does not post approved sales; this release changes only
negative grid quantity entry. No live refunds or payments are enabled.
