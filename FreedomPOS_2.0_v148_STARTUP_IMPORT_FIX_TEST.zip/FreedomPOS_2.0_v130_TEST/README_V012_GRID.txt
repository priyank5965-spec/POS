Freedom POS 2.0 — v0.12 PRODUCT GRID TEST

Products & Stock > Add Product now opens a multi-row spreadsheet-style entry form.
Enter barcode, name, selling price in dollars, opening stock, supplier and category.
Tab moves across fields. Ten rows are shown; Add 5 More Rows adds more.
Save All Products validates and saves the batch in one database transaction.
Existing/duplicate barcodes are rejected. Blank rows are ignored.

This replaces ONLY the Add Product popup sequence. Other forms are unfinished.
Test-only database. Do not use for real transactions.
Launch START_FREEDOM_POS.bat, or rebuild using BUILD_TEST_EXE.bat.
