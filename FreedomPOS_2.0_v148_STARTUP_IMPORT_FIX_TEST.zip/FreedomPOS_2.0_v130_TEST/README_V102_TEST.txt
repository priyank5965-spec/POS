Freedom POS v0.102 TEST — Invoice arrival correction

- Unknown barcode/SKU opens four-tab Add New Stock Item editor before adding to grid. New products remain pending until finalisation.
- Supplier and staff initials are editable autocomplete comboboxes.
- Single Qty column; costs can be INC GST or EX GST per invoice line.
- Supplier-aware SKU and barcode matching; product details persist in drafts.
- Original supplier invoice total is required for finalisation.
- Added product metadata to stock records at finalisation.

LIMITATIONS: Windows UI not executed in this Linux environment. Xchange EDI formats still require mapping. Supplier matching and product code ambiguities require operator review. No live accounting/EFTPOS. Always test with a disposable database.
