"""Owner-configurable register button labels, colours, themes and positions (test build)."""
import json, os, tkinter as tk
from tkinter import ttk, colorchooser, messagebox
from pathlib import Path

THEMES={
 'Freedom Classic':{'background':'#c7c7c7','button':'#c7c7c7','text':'#1e1e1e','header':'#5bc5d3'},
 'Modern Dark':{'background':'#273646','button':'#334b62','text':'#ffffff','header':'#12324a'},
 'Clean Light':{'background':'#f0f3f7','button':'#ffffff','text':'#172c43','header':'#dbeafe'},
 'High Contrast':{'background':'#121212','button':'#151515','text':'#ffffff','header':'#ffda40'},
}

# Store beside the installed program, not in the test sales database.
CONFIG=Path(__file__).resolve().parent/'register_layout_v044.json'

def load():
 try:
  x=json.loads(CONFIG.read_text(encoding='utf-8'))
  return x if isinstance(x,dict) else {}
 except (OSError,ValueError):return {}

def install(cls):
 def apply(self):
  tiles=getattr(self,'_register_tiles',None)
  if not tiles:return
  cfg=load(); theme=THEMES.get(cfg.get('theme'),THEMES['Freedom Classic'])
  right=next(iter(tiles.values()))['widget'].master
  right.configure(bg=theme['background'])
  positions={}; occupied=set()
  for key,t in tiles.items():
   x=cfg.get('buttons',{}).get(key,{})
   try:r,c=int(x.get('row',t['row'])),int(x.get('col',t['col']))
   except (TypeError,ValueError):r,c=t['row'],t['col']
   span=t['span']; cells={(r,k) for k in range(c,c+span)}
   if r<0 or r>6 or c<0 or c+span>5 or occupied.intersection(cells):
    r,c=t['row'],t['col'];cells={(r,k) for k in range(c,c+span)}
   occupied.update(cells);positions[key]=(r,c)
  for key,t in tiles.items():
   b=t['widget'];x=cfg.get('buttons',{}).get(key,{})
   b.grid_configure(row=positions[key][0],column=positions[key][1])
   bg=x.get('bg') or (t['bg'] if t['bg'] not in ('#c7c7c7',) else theme['button'])
   fg=x.get('fg') or (t['fg'] if t['fg'] not in ('#1e1e1e',) else theme['text'])
   b.configure(text=x.get('label',t['label']),bg=bg,fg=fg,activebackground=theme['header'])
  self._register_layout=cfg

 def editor(self):
  tiles=getattr(self,'_register_tiles',None)
  if not tiles:
   messagebox.showwarning('Register Settings','Open the register before editing its buttons.',parent=self.root);return
  cfg=load(); cfg.setdefault('buttons',{})
  win=tk.Toplevel(self.root);win.title('Register Layout & Theme Designer — TEST ONLY');win.geometry('1040x720');win.minsize(900,620);win.transient(self.root)
  win.configure(bg='#f1f5f9');win.grab_set()
  head=tk.Frame(win,bg='white',height=62);head.pack(fill='x');head.pack_propagate(False)
  tk.Label(head,text='REGISTER LAYOUT & THEME DESIGNER',font=('Segoe UI',17,'bold'),bg='white',fg='#111111').pack(side='left',padx=18,pady=12)
  tk.Label(head,text='TEST ONLY',font=('Segoe UI',10,'bold'),bg='white',fg='#78dbe6').pack(side='right',padx=18)
  top=tk.Frame(win,bg='#f1f5f9');top.pack(fill='x',padx=16,pady=12)
  tk.Label(top,text='Theme',font=('Segoe UI',11,'bold'),bg='#f1f5f9').pack(side='left')
  theme=tk.StringVar(value=cfg.get('theme','Freedom Classic'))
  cb=ttk.Combobox(top,textvariable=theme,values=list(THEMES),state='readonly',width=23,font=('Segoe UI',11));cb.pack(side='left',padx=10)
  tk.Label(top,text='Drag buttons to swap positions (same size). Click to rename or recolour.',font=('Segoe UI',10),bg='#f1f5f9').pack(side='left',padx=10)
  body=tk.Frame(win,bg='#f1f5f9');body.pack(fill='both',expand=True,padx=16)
  board=tk.Frame(body,bg='#d9e1e9');board.pack(side='left',fill='both',expand=True,padx=(0,14))
  panel=tk.Frame(body,bg='white',width=270,highlightbackground='#cbd5e1',highlightthickness=1);panel.pack(side='right',fill='y');panel.pack_propagate(False)
  for c in range(5):board.grid_columnconfigure(c,weight=1,uniform='c')
  for r in range(7):board.grid_rowconfigure(r,weight=1,uniform='r')
  selected=tk.StringVar(value='');label=tk.StringVar();bg=tk.StringVar();fg=tk.StringVar()
  controls={};layout={}
  for k,t in tiles.items():
   x=cfg['buttons'].get(k,{})
   layout[k]=(int(x.get('row',t['row'])),int(x.get('col',t['col'])))
  # Prevent malformed old layouts from breaking the editor.
  def valid():
   seen=set()
   for k,(r,c) in layout.items():
    span=tiles[k]['span'];cells={(r,i) for i in range(c,c+span)}
    if r<0 or r>6 or c<0 or c+span>5 or seen&cells:return False
    seen.update(cells)
   return True
  if not valid():layout.update({k:(t['row'],t['col']) for k,t in tiles.items()})
  def select(k):
   selected.set(k);x=cfg['buttons'].get(k,{})
   label.set(x.get('label',tiles[k]['label']));bg.set(x.get('bg',''));fg.set(x.get('fg',''))
   selection.config(text='Selected: '+tiles[k]['label'])
  def paint():
   pal=THEMES[theme.get()]
   board.configure(bg=pal['background'])
   for k,t in tiles.items():
    x=cfg['buttons'].get(k,{})
    b=controls[k];r,c=layout[k]
    b.grid_configure(row=r,column=c,columnspan=t['span'])
    b.configure(text=x.get('label',t['label']),bg=x.get('bg') or (t['bg'] if t['bg']!='#c7c7c7' else pal['button']),fg=x.get('fg') or (t['fg'] if t['fg']!='#1e1e1e' else pal['text']),relief='solid',bd=2 if selected.get()==k else 1)
  drag={'key':None,'x':0,'y':0}
  def press(event,k):drag.update(key=k,x=event.x_root,y=event.y_root);select(k);paint()
  def release(event,k):
   if drag['key']!=k:return
   drag['key']=None
   if abs(event.x_root-drag['x'])+abs(event.y_root-drag['y'])<15:return
   target=None
   for other,b in controls.items():
    if b.winfo_rootx()<=event.x_root<b.winfo_rootx()+b.winfo_width() and b.winfo_rooty()<=event.y_root<b.winfo_rooty()+b.winfo_height():target=other;break
   if target and target!=k and tiles[k]['span']==tiles[target]['span']:
    layout[k],layout[target]=layout[target],layout[k];paint()
   elif target and target!=k:messagebox.showwarning('Button Size','Only equal-width buttons can be swapped in this test build.',parent=win)
  for k,t in tiles.items():
   b=tk.Label(board,justify='center',font=('Segoe UI',9,'bold'),wraplength=110,cursor='hand2',padx=3,pady=3)
   b.bind('<ButtonPress-1>',lambda e,key=k:press(e,key))
   b.bind('<ButtonRelease-1>',lambda e,key=k:release(e,key))
   controls[k]=b
  selection=tk.Label(panel,text='Select a button',font=('Segoe UI',12,'bold'),bg='white',fg='#111111',wraplength=240);selection.pack(fill='x',padx=12,pady=(20,12))
  tk.Label(panel,text='Button display name',bg='white',anchor='w',font=('Segoe UI',10,'bold')).pack(fill='x',padx=12)
  ent=tk.Entry(panel,textvariable=label,font=('Segoe UI',12));ent.pack(fill='x',padx=12,pady=7)
  def pick(variable):
   chosen=colorchooser.askcolor(color=variable.get() or '#5bc5d3',parent=win)[1]
   if chosen:variable.set(chosen)
  for title,var in [('Button colour',bg),('Text colour',fg)]:
   tk.Label(panel,text=title,bg='white',anchor='w',font=('Segoe UI',10,'bold')).pack(fill='x',padx=12,pady=(10,0))
   row=tk.Frame(panel,bg='white');row.pack(fill='x',padx=12,pady=4)
   tk.Entry(row,textvariable=var,width=13,font=('Segoe UI',10)).pack(side='left',fill='x',expand=True)
   tk.Button(row,text='Choose',command=lambda v=var:pick(v)).pack(side='left',padx=(4,0))
  def update_selected():
   k=selected.get()
   if not k:return
   if not label.get().strip():messagebox.showwarning('Button Name','Enter a button name.',parent=win);return
   x=cfg['buttons'].setdefault(k,{})
   x['label']=label.get().strip()
   for key,var in [('bg',bg),('fg',fg)]:
    value=var.get().strip()
    if value:
     try:win.winfo_rgb(value)
     except tk.TclError:messagebox.showwarning('Colour','Invalid '+key+' colour.',parent=win);return
    x[key]=value
   paint()
  tk.Button(panel,text='APPLY TO PREVIEW',command=update_selected,bg='#5bc5d3',font=('Segoe UI',10,'bold'),height=2).pack(fill='x',padx=12,pady=18)
  tk.Label(panel,text='Renaming only changes the label.\nThe original POS function stays linked.',bg='white',fg='#526477',wraplength=230,justify='left').pack(fill='x',padx=12)
  def save():
   if not valid():messagebox.showerror('Layout Error','Button positions overlap.',parent=win);return
   cfg['theme']=theme.get()
   for k,(r,c) in layout.items():cfg['buttons'].setdefault(k,{}).update(row=r,col=c)
   try:
    temp=CONFIG.with_suffix('.tmp');temp.write_text(json.dumps(cfg,indent=2),encoding='utf-8');os.replace(temp,CONFIG)
   except OSError as e:messagebox.showerror('Save Failed',str(e),parent=win);return
   self.apply_register_customization();win.destroy()
  def reset():
   if not messagebox.askyesno('Restore Default','Restore original button names, positions and colours?',parent=win):return
   cfg['buttons'].clear();theme.set('Freedom Classic')
   layout.update({k:(t['row'],t['col']) for k,t in tiles.items()});select(next(iter(tiles)));paint()
  cb.bind('<<ComboboxSelected>>',lambda e:paint())
  foot=tk.Frame(win,bg='#f1f5f9');foot.pack(fill='x',padx=16,pady=12)
  tk.Button(foot,text='RESTORE DEFAULT',command=reset,font=('Segoe UI',10,'bold'),padx=12,pady=10).pack(side='left')
  tk.Button(foot,text='CANCEL',command=win.destroy,font=('Segoe UI',10,'bold'),padx=20,pady=10).pack(side='right',padx=5)
  tk.Button(foot,text='SAVE LAYOUT',command=save,bg='#5bc5d3',font=('Segoe UI',10,'bold'),padx=20,pady=10).pack(side='right',padx=5)
  select('CANCEL SALE' if 'CANCEL SALE' in tiles else next(iter(tiles)));paint()
  win.protocol('WM_DELETE_WINDOW',win.destroy)

 cls.apply_register_customization=apply
 cls.register_customizer=editor
 old_settings=cls.settings
 def settings(self,*a,**kw):
  result=old_settings(self,*a,**kw)
  try:
   tk.Button(self.root,text='REGISTER LAYOUT & THEMES',command=self.register_customizer,bg='#5bc5d3',fg='#111111',font=('Segoe UI',12,'bold'),height=2).pack(pady=8)
  except tk.TclError:pass
  return result
 cls.settings=settings
