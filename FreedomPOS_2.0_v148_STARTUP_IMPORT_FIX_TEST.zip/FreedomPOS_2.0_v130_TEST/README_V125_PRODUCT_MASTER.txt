Freedom POS 2.0 v125 TEST — PRODUCT MASTER FOUNDATION
Based on v124 silent Linkly test build. Linkly code was not edited.

Implemented:
- Products & Stock -> PRODUCT MASTER (TABS) / Add Product / Edit Product
- Full tabbed keyboard/mouse form and Ctrl+S save
- Alt+R internal-use 13-digit barcode generation with EAN-13 check digit
- Multiple barcodes per product; alternate scan lookup
- Product details, pricing, supplier mapping, inventory configuration,
  packs, POS settings, publication fields and basic product audit
- Supplier capability text (general, magazine, newspaper, etc.)
- New products start with stock = 0
- Additional database tables for stock ledger, supplier, arrivals and barcode mappings

NOT YET COMPLETED / INTEGRATED:
- Supplier invoice posting into new stock ledger and last-cost valuation
- Full publication issue delivery/return workflows
- Negative-stock warning policy across every sale path
- Pack quantity handling on scanned barcodes
- Full historical audit details and pricing history
- Full integration of new metadata with all older stock screens
- Live GUI/Linkly physical terminal tests (not available in this environment)

Test on a COPY of your test database. Do not use for production stock.
