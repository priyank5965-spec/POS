Freedom POS v121 TEST — Linked Refund Routing & Remembered Mode

New installations select LINKLY TRAINING automatically. Existing LINKLY STATUS selection is upgraded once to LINKLY TRAINING; future changes to mode are preserved.

Linked refund test: Previous Sales -> Refund / Exchange -> load return lines -> EFT. A negative net total uses Linkly R with positive cents; a positive net total uses purchase P. A zero net total does not send a Linkly transaction. Only a verified Linkly training response can post the return and clear the grid. The sale remains open on unknown/declined responses.

Standalone negative quantities are still intentionally blocked from posting without an original sale. Core Payments refunds require original-purchase RFN in production; this experimental offline virtual-pinpad test does not yet persist/send RFN, and may be rejected by Linkly. Do not use with real cards, physical terminals or bank connections. Do not retry an unknown result without reconciling transaction history.

Validation: automated source/unit tests and Python compilation only; Windows Virtual PINpad and end-to-end stock/receipt integration NOT verified.
