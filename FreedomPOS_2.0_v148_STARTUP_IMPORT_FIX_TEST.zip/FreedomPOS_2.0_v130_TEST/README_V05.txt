FREEDOM POS 2.0 — v0.5 OFFLINE TEST PROTOTYPE
================================================
Extract the ZIP. Open freedom_v04 and run START_FREEDOM_POS.bat.
Requires Windows 11 and Python 3 with tkinter (usually included in Windows Python installer).

DEMO STAFF LOGIN: 99 (Demo Owner). Change before entering any meaningful test data.

NEW IN THIS TEST BUILD
- Staff PIN popup when entering Point of Sale, and after a successful checkout.
- Staff management: add employee, choose role, unique two-digit PIN, disable employee.
- Staff audit: login, failed login, lottery entry, completed checkout, staff creation/deactivation.
- Sale-staff link stored for new completed test sales.
- Lottery popup has exactly four main functions. Lotto Sale has eleven individual game codes.
- Lotto payout 40, Scratch-It sale 30, Scratch-It payout 41.
- Lottery game codes saved against completed sale lines in lottery_sale_lines.

LIMITATIONS / WARNINGS
- TEST DATA ONLY. The two-digit PIN is NOT adequate for secure production authentication.
- Role management does NOT yet protect every legacy screen and operation.
- No real EFTPOS, The Lott, XchangeIT, email, printer, Android APK, multi-register or production backups.
- Previous Sales does not yet display all newly stored staff/game-code fields.
- Most of the 17-section specification is not yet fully implemented.
- Sale and lottery code associations are tested by source-level checks, not hardware or Windows UI testing.
- Database is local SQLite, not a production LAN/server setup.
- Original v0.4 data remains in the test_data folder if this folder is copied forward.

Files: freedom_pos.py, previous_sales_window.py, operations_v05.py, TEST_V05.py.
