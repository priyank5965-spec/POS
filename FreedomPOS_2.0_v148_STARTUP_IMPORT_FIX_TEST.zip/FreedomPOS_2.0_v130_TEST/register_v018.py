"""Register usability upgrade. Test-only: no real payment processing."""
import tkinter as tk
from tkinter import ttk, messagebox
from decimal import Decimal


def install(cls):
    old_pos = cls.pos
    old_refresh = cls.refresh_cart

    def pos(self):
        old_pos(self)
        self.root.title('Freedom POS 2.0 — v0.21 REGISTER LAYOUT TEST')
        # A persistent register toolbar and quick actions; keep the sale grid in view.
        main = self.sale_tree.master
        toolbar = tk.Frame(main, bg='#e4edf4', padx=6, pady=5)
        toolbar.pack(fill='x', before=self.sale_tree)
        tk.Label(toolbar, text='REGISTER  •  TEST MODE', bg='#e4edf4', fg='#111111', font=('Segoe UI', 10, 'bold')).pack(side='left', padx=5)
        for title, callback in [('FIND CUSTOMER', self.register_customer), ('REFUND', self.register_refund), ('DEPARTMENTS', self.register_departments), ('CASH TENDER', self.register_cash), ('ACCOUNT COLLECTION', self.register_account_payment)]:
            tk.Button(toolbar, text=title, command=callback, font=('Segoe UI', 9, 'bold'), bg='white', padx=5).pack(side='left', padx=3)
        # Extra sales-grid columns, matching register terminology.
        cols = ('Description', 'Qty', 'Price', 'Discount', 'Line Total')
        self.sale_tree.configure(columns=cols)
        for col, width in zip(cols, (310, 60, 95, 85, 110)):
            self.sale_tree.heading(col, text=col)
            self.sale_tree.column(col, width=width, anchor='w' if col == 'Description' else 'e')
        self.sale_tree.tag_configure('refund', foreground='#b51e29')
        self.sale_tree.configure(height=7)
        self.refresh_cart()
        # Numeric keypad for touchscreen barcode and quantity entry.
        pad = tk.LabelFrame(main, text='TOUCH KEYPAD', bg='white', fg='#111111')
        # Hide the keypad initially to avoid clipping register controls on 768p displays.
        # Staff can reveal it from the toolbar without disturbing the current sale.
        self.register_keypad = pad
        def toggle_keypad():
            if pad.winfo_manager():
                pad.pack_forget()
                keypad_toggle.configure(text='SHOW KEYPAD')
            else:
                pad.pack(fill='x', pady=3)
                keypad_toggle.configure(text='HIDE KEYPAD')
            self.code.focus_set()
        keypad_toggle = tk.Button(toolbar, text='SHOW KEYPAD', command=toggle_keypad, font=('Segoe UI',9,'bold'), bg='white', padx=5)
        keypad_toggle.pack(side='right',padx=4)
        for index, key in enumerate(('7','8','9','4','5','6','1','2','3','0','00','⌫')):
            def press(k=key):
                if k == '⌫':
                    current = self.code.get()
                    self.code.delete(0, 'end'); self.code.insert(0, current[:-1])
                else: self.code.insert('insert', k)
                self.code.focus_set()
            tk.Button(pad, text=key, command=press, width=6, height=1, bg='white', font=('Segoe UI', 10, 'bold')).grid(row=index//6, column=index%6, padx=2, pady=2, sticky='ew')
        for i in range(6): pad.columnconfigure(i, weight=1)
        self.code.focus_set()

    def refresh_cart(self):
        old_refresh(self)
        tree = getattr(self, 'sale_tree', None)
        if tree is None or not tree.winfo_exists() or len(tree['columns']) != 5: return
        tree.delete(*tree.get_children())
        for index, item in enumerate(self.cart):
            money = lambda n: f"${n/100:,.2f}"
            total = item['qty'] * item['unit']
            tree.insert('', 'end', iid=str(index), values=(item['description'], item['qty'], money(item['unit']), '—', money(total)), tags=('refund',) if item['qty'] < 0 else ())

    def register_customer(self):
        w = tk.Toplevel(self.root); w.title('Find Customer — Register'); w.geometry('800x560'); w.transient(self.root)
        tk.Label(w, text='FIND CUSTOMER / ACCOUNT', font=('Segoe UI', 16, 'bold')).pack(anchor='w', padx=14, pady=8)
        search = tk.StringVar(); tk.Entry(w, textvariable=search, font=('Segoe UI', 13)).pack(fill='x', padx=14)
        table = ttk.Treeview(w, columns=('id','name','phone','balance'), show='headings')
        for c, wd in [('id',60),('name',330),('phone',170),('balance',130)]: table.heading(c, text=c.title()); table.column(c, width=wd)
        table.pack(fill='both', expand=True, padx=14, pady=8)
        def load(*_):
            table.delete(*table.get_children())
            money = lambda n: f"${n/100:,.2f}"
            term = '%' + search.get().strip() + '%'
            for r in self.db.execute('SELECT id,name,phone,balance FROM customers WHERE name LIKE ? OR phone LIKE ? OR CAST(id AS TEXT) LIKE ? ORDER BY name LIMIT 200', (term,term,term)):
                table.insert('', 'end', iid=str(r['id']), values=(r['id'],r['name'],r['phone'],money(r['balance'])))
        def choose():
            selected = table.selection()
            if not selected: return
            self.customer = int(selected[0]); self.refresh_cart(); w.destroy(); self.code.focus_set()
        search.trace_add('write', load); load()
        tk.Button(w, text='SELECT CUSTOMER', command=choose, height=2).pack(side='left', padx=14, pady=8)
        tk.Button(w, text='CANCEL', command=w.destroy, height=2).pack(side='right', padx=14, pady=8)
        table.bind('<Double-1>', lambda e: choose()); search.set('')

    def register_departments(self):
        w = tk.Toplevel(self.root); w.title('Department Quick Products'); w.geometry('900x600'); w.transient(self.root)
        tk.Label(w, text='DEPARTMENTS & QUICK PRODUCTS', font=('Segoe UI', 16, 'bold')).pack(pady=10)
        left = tk.Listbox(w, width=27, font=('Segoe UI', 12)); left.pack(side='left', fill='y', padx=12, pady=12)
        right = tk.Frame(w); right.pack(side='left', fill='both', expand=True, padx=12, pady=12)
        cats = [r[0] or 'General' for r in self.db.execute('SELECT DISTINCT category FROM products ORDER BY category')]
        for c in cats: left.insert('end', c)
        def selected(_=None):
            for child in right.winfo_children(): child.destroy()
            if not left.curselection(): return
            category = cats[left.curselection()[0]]
            for index, p in enumerate(self.db.execute('SELECT id,name,price FROM products WHERE COALESCE(category,\'General\')=? ORDER BY name LIMIT 80',(category,))):
                money = lambda n: f"${n/100:,.2f}"
                def add(pid=p['id']): self.quick(pid); w.destroy(); self.code.focus_set()
                tk.Button(right, text=f"{p['name']}\n{money(p['price'])}", command=add, wraplength=145, height=3).grid(row=index//4,column=index%4,sticky='nsew',padx=4,pady=4)
            for col in range(4): right.columnconfigure(col,weight=1)
        left.bind('<<ListboxSelect>>',selected)
        if cats: left.selection_set(0); selected()

    def register_cash(self):
        if not self.cart: return self.warn('Add products before taking payment.')
        money = lambda n: f"${n/100:,.2f}"
        total = self.total()
        if total < 0: return self.warn('Use the existing refund payment workflow for negative totals.')
        w = tk.Toplevel(self.root); w.title('Cash Tender — TEST ONLY'); w.geometry('540x470'); w.transient(self.root)
        tk.Label(w, text=f'CASH DUE  {money(total)}', font=('Segoe UI', 20, 'bold')).pack(pady=14)
        value = tk.StringVar(value=f'{total/100:.2f}'); entry = tk.Entry(w,textvariable=value,font=('Segoe UI',18),justify='right'); entry.pack(fill='x',padx=24)
        change = tk.Label(w,font=('Segoe UI',15,'bold')); change.pack(pady=10)
        def update(*_):
            try:
                paid = cents(value.get()); change.configure(text=('CHANGE  '+money(paid-total)) if paid>=total else ('REMAINING  '+money(total-paid)))
            except ValueError: change.configure(text='Enter a valid amount')
        value.trace_add('write',update); update()
        buttons=tk.Frame(w); buttons.pack(fill='both',expand=True,padx=20)
        for i, denomination in enumerate((5,10,20,50,100, 'EXACT')):
            def choose(d=denomination): value.set(f'{(total if d=="EXACT" else d*100)/100:.2f}')
            tk.Button(buttons,text=('$'+str(denomination) if denomination!='EXACT' else 'EXACT'),command=choose,height=2).grid(row=i//3,column=i%3,sticky='ew',padx=4,pady=4)
        for i in range(3):buttons.columnconfigure(i,weight=1)
        def pay():
            try: paid=cents(value.get())
            except ValueError: return self.warn('Invalid tender amount')
            if paid<total: return self.warn('Cash tendered is less than the amount due.')
            if not messagebox.askyesno('Confirm TEST Cash',f'Due: {money(total)}\nTendered: {money(paid)}\nChange: {money(paid-total)}\n\nRecord simulated cash payment?',parent=w):return
            self._pending_cash_tender=paid
            w.destroy(); self.checkout('CASH')
        tk.Button(w,text='RECORD CASH PAYMENT (TEST)',command=pay,height=2,bg='#d9efdf').pack(fill='x',padx=24,pady=12)

    def register_refund(self):
        # Existing refund workflow retains its original-sale and quantity checks.
        self.previous()

    def register_account_payment(self):
        # Avoid duplicating collections as new revenue. Existing account-payment logic.
        self.account_payment()

    cls.pos = pos
    cls.refresh_cart = refresh_cart
    cls.register_customer = register_customer
    cls.register_departments = register_departments
    cls.register_cash = register_cash
    cls.register_refund = register_refund
    cls.register_account_payment = register_account_payment
