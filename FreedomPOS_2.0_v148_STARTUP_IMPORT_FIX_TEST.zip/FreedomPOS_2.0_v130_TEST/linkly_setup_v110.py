"""Linkly On-Premises connection preparation. NO financial transaction methods.
A TCP connect is not proof of an operational terminal or payment approval.
"""
import socket
import threading
from linkly_status_v112 import query_pinpad, LinklyStatusError
import tkinter as tk
from tkinter import ttk, messagebox

DEFAULT_HOST='127.0.0.1'
DEFAULT_PORT=2011


def probe(host, port, timeout=2.0):
    """Check only whether a Linkly TCP listener is reachable. Send no data."""
    host=(host or '').strip()
    if not host:raise ValueError('Enter the computer hostname or IP address.')
    try:port=int(port)
    except (TypeError, ValueError):raise ValueError('Port must be a number.')
    if not 1 <= port <= 65535:raise ValueError('Port must be between 1 and 65535.')
    with socket.create_connection((host,port),timeout=timeout):
        return 'TCP connection established. This does NOT verify the terminal, Linkly protocol, or payment approval.'


def install(cls):
    def linkly_settings(self):
        w=tk.Toplevel(self.root);w.title('Linkly EFTPOS — Connection Setup (TEST ONLY)')
        w.geometry('700x545');w.minsize(590,440);w.transient(self.root)
        outer=tk.Frame(w,padx=20,pady=15);outer.pack(fill='both',expand=True)
        tk.Label(outer,text='LINKLY EFTPOS — CONNECTION DIAGNOSTICS',font=('Segoe UI',15,'bold'),fg='#111111').pack(anchor='w',pady=(0,10))
        tk.Label(outer,text='No payment requests, refunds, or settlements can be sent from this build.',fg='#ad4022',wraplength=620,justify='left').pack(anchor='w',pady=(0,15))
        host=tk.StringVar(value=DEFAULT_HOST);port=tk.StringVar(value=str(DEFAULT_PORT))
        for title,var in [('Linkly EFT-Client computer / IP',host),('TCP listener port',port)]:
            tk.Label(outer,text=title,font=('Segoe UI',10,'bold')).pack(anchor='w')
            tk.Entry(outer,textvariable=var,font=('Segoe UI',12)).pack(fill='x',pady=(3,12))
        tk.Label(outer,text='Use 127.0.0.1 if Linkly EFT-Client is installed on this register. Default TCP port is 2011; the Linkly client must have its listener enabled.',wraplength=640,justify='left').pack(anchor='w',pady=(0,12))
        status=tk.StringVar(value='Not checked.');label=tk.Label(outer,textvariable=status,wraplength=640,justify='left',anchor='w',fg='#111111');label.pack(fill='x',pady=8)
        def check():
            h=host.get();p=port.get();status.set('Checking TCP connectivity (no payment will be sent)...')
            def worker():
                try:result=probe(h,p)
                except Exception as exc:result='Connection not established: '+str(exc)
                try:w.after(0,lambda:status.set(result))
                except RuntimeError:pass
            threading.Thread(target=worker,daemon=True).start()
        ttk.Button(outer,text='TEST LINKLY CONNECTION (NO PAYMENT)',command=check).pack(fill='x',pady=8)
        def pinpad_status():
            h=host.get();p=port.get()
            status.set('Requesting Linkly PINpad status (no payment)...')
            def worker():
                try:
                    result=query_pinpad(h,p,timeout=4.0)
                    if result['online']:
                        message='PINPAD ONLINE — Linkly status: '+result['message']+' (code '+result['code']+'). NO PAYMENT SENT.'
                    else:
                        message='PINPAD OFFLINE / NOT READY — '+result['message']+' (code '+result['code']+'). Sale must remain open.'
                except (LinklyStatusError,ValueError,OSError) as exc:
                    message='PINPAD STATUS FAILED — '+str(exc)+' — No payment sent.'
                try:w.after(0,lambda:status.set(message))
                except RuntimeError:pass
            threading.Thread(target=worker,daemon=True).start()
        ttk.Button(outer,text='CHECK ACTUAL PINPAD STATUS (NO PAYMENT)',command=pinpad_status).pack(fill='x',pady=8)
        tk.Label(outer,text='Safety: A successful connection is not a bank approval. EFTPOS checkout uses the selected TEST or LINKLY STATUS mode; neither sends a payment. Do not process real cards or mark sales as paid based on this check.',wraplength=640,justify='left',fg='#ad4022').pack(anchor='w',pady=(14,0))
        ttk.Button(outer,text='Close',command=w.destroy).pack(anchor='e',pady=(18,0))
    cls.linkly_settings=linkly_settings
    previous_settings=cls.settings
    def settings(self):
        self.layout('SETTINGS & TOOLS',[
            ('Linkly EFTPOS — Connection Setup (TEST ONLY)',self.linkly_settings),
            ('Email Settings',self.email_settings),('Email History',self.email_history),
            ('Backup & Restore',self.backup),('RustDesk Remote Support',self.rustdesk),
            ('XchangeIT Integration',lambda:self.info('XchangeIT','Integration not connected in this test build.')),
            ('Printers / EFTPOS',self.linkly_settings),
            ('Mobile Stocktake APK',lambda:self.info('Mobile Stocktake','Android APK is not built yet.')),
        ])
    cls.settings=settings
