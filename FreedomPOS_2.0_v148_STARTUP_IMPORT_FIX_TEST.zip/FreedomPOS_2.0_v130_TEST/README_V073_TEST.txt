Freedom POS 2.0 v0.73 TEST — Shift Sales Payment Breakdown

Shift Sales Dashboard now includes a Payments / Cash / Card / Account tab. Ctrl+D opens/raises the dashboard while the main POS window has keyboard focus. Payment data is sourced from saved payments and sales records; voided sales excluded. Split tenders are counted per payment method. Account sales are unpaid receivables; account collections are reported separately, not as new sales. All totals AUD. Export CSV includes both tabs. Existing department reporting and End of Shift preserved.

Limitations: no bank settlement reconciliation, no physical cash drawer reconciliation, no register filter. Windows GUI not tested in this environment. TEST DATA ONLY.
