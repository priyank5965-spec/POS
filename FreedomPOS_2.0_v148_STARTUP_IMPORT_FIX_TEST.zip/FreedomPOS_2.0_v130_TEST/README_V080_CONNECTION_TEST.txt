Freedom POS v0.80 — Safe e-pay Connection Tests

Open Register > E-PAY > Test e-pay Connection (Safe).
1. Load REST Component (Metadata): read-only PE inspection and separate-process .NET reflection-only metadata load. Does not instantiate e-pay components.
2. Test Server Connection: TCP + TLS handshake only, NO HTTP request, authentication, or transaction. Enter your authorised HTTPS endpoint manually.
3. Test Product Enquiry: disabled until vendor protocol, authorisation and non-transactional request signature are verified.
4. Save Diagnostic Report: remove sensitive information before sharing.

No DLLs or credentials are bundled. No vendor DLL registration, sales, cancellations, voucher printing, or other live transaction features are enabled. This is TEST ONLY.
A TLS handshake is not proof of e-pay server authentication.
Windows UI and component metadata load must be tested on user's Windows PC.
