"""Linked supplier/staff maintenance TEST UI; no claims of production-grade permissions."""
import tkinter as tk
from tkinter import ttk,messagebox
import sqlite3,secrets,hmac
from operations_v05 import pin_hash
BLUE='#12324A'
LEVELS=['1 - No Access','2 - Access Level','3 - Register User','4 - Middle Level Access','5 - Power User','6 - Managerial Access','7 - Full Admin Access']
PERMISSIONS=['Allow refunds','Allow no sales','Allow payouts','Allow price overrides','Allow system voids','Allow manual discounts','Allow customer payments','Allow invoice arrivals','Allow supplier maintenance','Allow staff maintenance','Allow sales reports','Allow stock cost changes']
def ensure_links(db):
    db.execute("""CREATE TABLE IF NOT EXISTS suppliers_master(id INTEGER PRIMARY KEY,name TEXT NOT NULL UNIQUE,code TEXT UNIQUE,contact TEXT DEFAULT '',phone TEXT DEFAULT '',mobile TEXT DEFAULT '',email TEXT DEFAULT '',abn TEXT DEFAULT '',address TEXT DEFAULT '',suburb TEXT DEFAULT '',state TEXT DEFAULT 'QLD',postcode TEXT DEFAULT '',terms TEXT DEFAULT '',account_number TEXT DEFAULT '',notes TEXT DEFAULT '',active INTEGER NOT NULL DEFAULT 1)""")
    db.execute("""CREATE TABLE IF NOT EXISTS staff(id INTEGER PRIMARY KEY,name TEXT NOT NULL,role TEXT NOT NULL,salt TEXT NOT NULL,pin_hash TEXT NOT NULL,active INTEGER NOT NULL DEFAULT 1)""")
    cols={r[1] for r in db.execute('PRAGMA table_info(staff)')}
    for name,kind in [('initials','TEXT'),('phone','TEXT'),('email','TEXT'),('comments','TEXT'),('security_level','INTEGER DEFAULT 3'),('shop',"TEXT DEFAULT 'Any Shop'")]:
        if name not in cols:db.execute('ALTER TABLE staff ADD COLUMN '+name+' '+kind)
    db.execute("""CREATE TABLE IF NOT EXISTS staff_permission_settings(staff_id INTEGER NOT NULL,permission TEXT NOT NULL,allowed INTEGER NOT NULL DEFAULT 0,PRIMARY KEY(staff_id,permission))""")
    db.execute("""CREATE TABLE IF NOT EXISTS staff_security_limits(staff_id INTEGER PRIMARY KEY,max_discount INTEGER NOT NULL DEFAULT 0,refund_limit_cents INTEGER NOT NULL DEFAULT 0)""")
    db.commit()
def quick_supplier(app,parent,initial_name=""):
    ensure_links(app.db)
    w=tk.Toplevel(parent);w.title('Quick Add Supplier — TEST');w.transient(parent);w.grab_set();w.geometry('620x340')
    fields=[('Supplier name *','name'),('Supplier code','code'),('Contact','contact'),('Phone','phone'),('Email','email'),('ABN','abn')]
    vars={}
    for i,(label,key) in enumerate(fields):
        ttk.Label(w,text=label).grid(row=i,column=0,sticky='w',padx=16,pady=7)
        v=tk.StringVar(value=initial_name if key=='name' else '');vars[key]=v;ttk.Entry(w,textvariable=v,width=48).grid(row=i,column=1,sticky='ew',padx=10)
    result=[None]
    def save():
        data={k:v.get().strip() for k,v in vars.items()}
        if not data['name']:return messagebox.showwarning('Required','Supplier name is required.',parent=w)
        try:
            with app.db:app.db.execute('INSERT INTO suppliers_master(name,code,contact,phone,email,abn) VALUES(?,?,?,?,?,?)',tuple(data[k] or None if k=='code' else data[k] for k in ('name','code','contact','phone','email','abn')))
            result[0]=data['name'];w.destroy()
        except sqlite3.IntegrityError:messagebox.showerror('Duplicate','Supplier name or code already exists.',parent=w)
    ttk.Button(w,text='SAVE SUPPLIER',command=save).grid(row=7,column=1,sticky='e',padx=15,pady=12)
    ttk.Button(w,text='CANCEL',command=w.destroy).grid(row=7,column=0,pady=12)
    w.wait_window();return result[0]
def staff_screen(app):
    ensure_links(app.db)
    w=tk.Toplevel(app.root);w.title('Freedom POS 2.0 — STAFF MAINTENANCE — TEST ONLY');w.geometry('1150x760');w.minsize(850,600)
    bar=tk.Frame(w,bg='white');bar.pack(fill='x');tk.Label(bar,text='STAFF MAINTENANCE',bg='white',fg='#111111',font=('Segoe UI',18,'bold')).pack(side='left',padx=14,pady=10)
    ttk.Button(bar,text='CLOSE',command=w.destroy).pack(side='right',padx=12)
    tabs=ttk.Notebook(w);tabs.pack(fill='both',expand=True,padx=12,pady=10)
    general=ttk.Frame(tabs);security=ttk.Frame(tabs);rf=ttk.Frame(tabs);attendance=ttk.Frame(tabs)
    for frame,label in [(general,'Staff Maintenance'),(security,'Security Level'),(rf,'RF Security'),(attendance,'Auto Attendance')]:tabs.add(frame,text=label)
    left=ttk.Frame(general);left.pack(side='left',fill='both',expand=True,padx=8,pady=8)
    right=ttk.Frame(general);right.pack(side='left',fill='both',expand=True,padx=8,pady=8)
    search=tk.StringVar();ttk.Label(left,text='Find staff').pack(anchor='w');ttk.Entry(left,textvariable=search).pack(fill='x',pady=5)
    tree=ttk.Treeview(left,columns=('initials','name','active'),show='headings');tree.pack(fill='both',expand=True)
    for c,title,width in [('initials','Initials',90),('name','Name',270),('active','Active',70)]:tree.heading(c,text=title);tree.column(c,width=width)
    names=[('initials','Staff initials'),('name','Staff name'),('phone','Telephone'),('email','Email'),('comments','Comments'),('shop','Default shop')]
    vars={}
    for i,(key,label) in enumerate(names):
        ttk.Label(right,text=label).grid(row=i*2,column=0,sticky='w',pady=(6,0))
        v=tk.StringVar();vars[key]=v;ttk.Entry(right,textvariable=v,width=46).grid(row=i*2+1,column=0,sticky='ew',pady=2)
    active=tk.BooleanVar(value=True);ttk.Checkbutton(right,text='Active',variable=active).grid(row=13,column=0,sticky='w',pady=6)
    pin=tk.StringVar();ttk.Label(right,text='New login PIN (only to create/change)').grid(row=14,column=0,sticky='w');ttk.Entry(right,textvariable=pin,show='*').grid(row=15,column=0,sticky='ew')
    level=tk.StringVar(value=LEVELS[2]);ttk.Label(right,text='Security level').grid(row=16,column=0,sticky='w');ttk.Combobox(right,textvariable=level,values=LEVELS,state='readonly').grid(row=17,column=0,sticky='ew')
    chosen=[None]
    flags={}
    ttk.Label(security,text='Staff-specific settings (stored for testing; not yet enforced across every POS action)',foreground='#9b3229').pack(anchor='w',padx=12,pady=10)
    grid=ttk.Frame(security);grid.pack(fill='x',padx=15)
    for i,perm in enumerate(PERMISSIONS):
        v=tk.BooleanVar();flags[perm]=v;ttk.Checkbutton(grid,text=perm,variable=v).grid(row=i//2,column=i%2,sticky='w',padx=20,pady=8)
    limits=ttk.Frame(security);limits.pack(anchor='w',padx=15,pady=15)
    disc=tk.StringVar(value='0');refund=tk.StringVar(value='0')
    ttk.Label(limits,text='Maximum discount %').grid(row=0,column=0,padx=6);ttk.Entry(limits,textvariable=disc,width=10).grid(row=0,column=1)
    ttk.Label(limits,text='Cash refund limit $').grid(row=0,column=2,padx=6);ttk.Entry(limits,textvariable=refund,width=10).grid(row=0,column=3)
    ttk.Label(rf,text='RF / barcode login integration is not connected in this TEST build.').pack(padx=20,pady=20)
    ttk.Label(attendance,text='Attendance integration is not connected in this TEST build.').pack(padx=20,pady=20)
    def refresh(*_):
        tree.delete(*tree.get_children());q='%'+search.get()+'%'
        for r in app.db.execute('SELECT * FROM staff WHERE name LIKE ? OR initials LIKE ? ORDER BY name',(q,q)):
            tree.insert('','end',iid=str(r['id']),values=(r['initials'] or '',r['name'],'Yes' if r['active'] else 'No'))
    def select(_=None):
        sel=tree.selection()
        if not sel:return
        sid=int(sel[0]);chosen[0]=sid;r=app.db.execute('SELECT * FROM staff WHERE id=?',(sid,)).fetchone()
        for k,v in vars.items():v.set(r[k] or '')
        active.set(bool(r['active']));level.set(LEVELS[max(1,min(7,r['security_level'] or 3))-1]);pin.set('')
        perms={r['permission']:r['allowed'] for r in app.db.execute('SELECT * FROM staff_permission_settings WHERE staff_id=?',(sid,))}
        for k,v in flags.items():v.set(bool(perms.get(k,0)))
        lim=app.db.execute('SELECT * FROM staff_security_limits WHERE staff_id=?',(sid,)).fetchone()
        disc.set(str(lim['max_discount']) if lim else '0');refund.set(str(lim['refund_limit_cents']/100) if lim else '0')
    def new():
        chosen[0]=None
        for v in vars.values():v.set('')
        active.set(True);pin.set('');level.set(LEVELS[2]);disc.set('0');refund.set('0')
        for v in flags.values():v.set(False)
    def save():
        name=vars['name'].get().strip();initials=vars['initials'].get().strip().upper()
        if not name or not initials:return messagebox.showwarning('Required','Staff name and initials are required.',parent=w)
        try:
            discount=int(disc.get());refc=int(round(float(refund.get())*100))
            if not 0<=discount<=100 or refc<0:raise ValueError()
        except ValueError:return messagebox.showerror('Invalid limits','Discount must be 0–100%; refund limit cannot be negative.',parent=w)
        sid=chosen[0];newpin=pin.get().strip()
        if not sid and (not newpin or not newpin.isdigit() or len(newpin)<2):return messagebox.showerror('PIN required','New staff must have a numeric PIN of at least two digits.',parent=w)
        if newpin and (not newpin.isdigit() or len(newpin)!=2):return messagebox.showerror('PIN format','Existing login currently supports exactly two numeric PIN digits.',parent=w)
        if newpin:
            for r in app.db.execute('SELECT id,salt,pin_hash FROM staff WHERE active=1'):
                if r['id']!=sid and hmac.compare_digest(pin_hash(newpin,r['salt']),r['pin_hash']):return messagebox.showerror('PIN in use','Another active staff member already uses this PIN.',parent=w)
        role='OWNER' if level.get().startswith('7') else 'MANAGER' if level.get().startswith('6') else 'SUPERVISOR' if level.get().startswith(('4','5')) else 'CASHIER'
        try:
            with app.db:
                if sid:
                    app.db.execute('UPDATE staff SET name=?,initials=?,phone=?,email=?,comments=?,shop=?,active=?,security_level=?,role=? WHERE id=?',(name,initials,vars['phone'].get(),vars['email'].get(),vars['comments'].get(),vars['shop'].get(),int(active.get()),int(level.get()[0]),role,sid))
                    if newpin:
                        salt=secrets.token_hex(16);app.db.execute('UPDATE staff SET salt=?,pin_hash=? WHERE id=?',(salt,pin_hash(newpin,salt),sid))
                else:
                    salt=secrets.token_hex(16);sid=app.db.execute('INSERT INTO staff(name,initials,phone,email,comments,shop,active,security_level,role,salt,pin_hash) VALUES(?,?,?,?,?,?,?,?,?,?,?)',(name,initials,vars['phone'].get(),vars['email'].get(),vars['comments'].get(),vars['shop'].get(),int(active.get()),int(level.get()[0]),role,salt,pin_hash(newpin,salt))).lastrowid
                for k,v in flags.items():app.db.execute('INSERT OR REPLACE INTO staff_permission_settings(staff_id,permission,allowed) VALUES(?,?,?)',(sid,k,int(v.get())))
                app.db.execute('INSERT OR REPLACE INTO staff_security_limits(staff_id,max_discount,refund_limit_cents) VALUES(?,?,?)',(sid,discount,refc))
            chosen[0]=sid;refresh();messagebox.showinfo('Saved','Staff record saved. Detailed permissions are not yet enforced throughout the POS.',parent=w)
        except sqlite3.IntegrityError as e:messagebox.showerror('Duplicate staff',str(e),parent=w)
    actions=ttk.Frame(right);actions.grid(row=18,column=0,sticky='e',pady=12)
    ttk.Button(actions,text='NEW',command=new).pack(side='left',padx=5);ttk.Button(actions,text='SAVE',command=save).pack(side='left',padx=5)
    tree.bind('<<TreeviewSelect>>',select);search.trace_add('write',refresh);refresh()
def install(cls):
    old_purchasing=cls.purchasing
    def purchasing(self):
        old_purchasing(self)
        self.btn(self.root,'SUPPLIERS',self.suppliers,size=10,height=1).pack(pady=3)
    old_management=cls.management
    def management(self):
        old_management(self)
        self.btn(self.root,'STAFF MAINTENANCE',lambda:staff_screen(self),size=10,height=1).pack(pady=5)
    cls.purchasing=purchasing;cls.management=management;cls.staff_maintenance_v099=staff_screen
