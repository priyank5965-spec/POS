Freedom POS v0.90 TEST ONLY
Previous Sales: choose 80mm receipt or A4 invoice-style sale summary for Email, Preview and Reprint.
Not a tax invoice: verified GST/tax information is not available in legacy test sales.
Email sends only after confirmation. Windows printer and Gmail delivery require hands-on testing.
