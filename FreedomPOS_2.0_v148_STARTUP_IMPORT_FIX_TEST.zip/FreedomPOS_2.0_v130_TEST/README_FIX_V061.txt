FREEDOM POS 2.0 v0.6.1 - REPORTLAB PACKAGING FIX

Your old v0.6 executable cannot load the ReportLab PDF module.
Do not keep launching the old EXE: it cannot be fixed by installing ReportLab on Windows alone.

Option A - run Python test source:
  1. Install Python 3 with 'Add Python to PATH' selected.
  2. Extract this entire ZIP to a NEW folder.
  3. Run START_FREEDOM_POS.bat (it installs ReportLab and Pillow if needed).

Option B - rebuild the Windows EXE:
  1. Extract the ZIP to a NEW folder.
  2. Run BUILD_TEST_EXE.bat (requires Python 3 and internet for package install).
  3. Use the NEW dist\FreedomPOS_Test_v061.exe.
  4. DO NOT run the old FreedomPOS_Test_v04.exe or the old v0.6 EXE.

This patch changes startup/build packaging only. It does not implement other missing features.
The program remains TEST SOFTWARE; do not use for live customer invoicing or payments.
