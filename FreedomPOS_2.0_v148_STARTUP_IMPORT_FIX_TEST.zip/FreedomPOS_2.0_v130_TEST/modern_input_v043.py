"""Touchscreen-friendly prompt for register Hold Sale and other short text prompts."""
import tkinter as tk
NAVY='#12324A'; TEAL='#51BDCB'; WHITE='#FFFFFF'; bg='white'

def install(cls):
    original=cls.prompt
    def prompt(self,title,label,initial=None):
        # Use the modern prompt for Hold Sale; do not change unrelated workflows.
        if title!='Hold Sale':return original(self,title,label,initial)
        host=self.root
        w=tk.Toplevel(host);w.withdraw();w.title('Freedom POS 2.0 — Hold Sale');w.configure(bg=BG)
        w.resizable(False,False);w.transient(host)
        result={'value':None}
        def finish(value):
            result['value']=value
            try:w.grab_release()
            except tk.TclError:pass
            w.destroy()
        w.protocol('WM_DELETE_WINDOW',lambda:finish(None))
        header=tk.Frame(w,bg=NAVY,height=74);header.pack(fill='x');header.pack_propagate(False)
        tk.Label(header,text='HOLD SALE',font=('Segoe UI',21,'bold'),bg=NAVY,fg=WHITE).pack(side='left',padx=24,fill='y')
        body=tk.Frame(w,bg=WHITE,padx=25,pady=24);body.pack(fill='both',expand=True)
        tk.Label(body,text='Reference / Customer Name',font=('Segoe UI',13,'bold'),bg=WHITE,fg=NAVY,anchor='w').pack(fill='x',pady=(0,10))
        entry=tk.Entry(body,font=('Segoe UI',17),bd=1,relief='solid',highlightthickness=1,highlightcolor=TEAL)
        entry.pack(fill='x',ipady=11);entry.insert(0,initial or '')
        tk.Label(body,text='Optional reference to identify this held sale later.',font=('Segoe UI',10),bg=WHITE,fg='#526776',anchor='w').pack(fill='x',pady=(11,0))
        footer=tk.Frame(w,bg=BG,padx=22,pady=17);footer.pack(fill='x')
        tk.Button(footer,text='HOLD SALE',font=('Segoe UI',12,'bold'),bg=TEAL,fg=NAVY,relief='flat',bd=0,width=15,height=2,command=lambda:finish(entry.get()),cursor='hand2').pack(side='right',padx=(12,0))
        tk.Button(footer,text='CANCEL',font=('Segoe UI',12,'bold'),bg=WHITE,fg=NAVY,relief='flat',bd=0,width=12,height=2,command=lambda:finish(None),cursor='hand2').pack(side='right')
        w.bind('<Return>',lambda e:finish(entry.get()))
        w.bind('<Escape>',lambda e:finish(None))
        w.update_idletasks();width=610;height=320
        x=max(0,(w.winfo_screenwidth()-width)//2);y=max(0,(w.winfo_screenheight()-height)//2)
        w.geometry(f'{width}x{height}+{x}+{y}');w.deiconify();w.lift();w.grab_set();entry.focus_set();entry.selection_range(0,'end');w.wait_window()
        return result['value']
    cls.prompt=prompt
