import unittest
from linkly_purchase_v114 import build_refund, parse_refund_response
class RefundTests(unittest.TestCase):
 def test_refund_wire(self):
  request=build_refund(599,'R123456')
  self.assertEqual(request[:5],b'#0161')
  self.assertEqual(request[9:10],b'R')
  self.assertEqual(request[21:30],b'000000599')
 def response(self,kind=b'R',code=b'00',amount=b'000000599',ref=b'R123456'):
  r=bytearray(b' '*257);r[:2]=b'M0';r[2:3]=b'1';r[3:5]=code;r[5:25]=b'APPROVED'.ljust(20);r[27:28]=kind;r[44:53]=amount;r[68:84]=ref.ljust(16);return bytes(r)
 def test_approval(self):
  self.assertTrue(parse_refund_response(self.response(),599,'R123456')['approved'])
  self.assertTrue(parse_refund_response(self.response(kind=b'r'),599,'R123456')['approved'])
 def test_rejections(self):
  self.assertFalse(parse_refund_response(self.response(kind=b'P'),599,'R123456')['approved'])
  self.assertFalse(parse_refund_response(self.response(code=b'05'),599,'R123456')['approved'])
  self.assertFalse(parse_refund_response(self.response(amount=b'000000500'),599,'R123456')['approved'])
  self.assertFalse(parse_refund_response(self.response(ref=b'R999'),599,'R123456')['approved'])
 def test_invalid_amount(self):
  with self.assertRaises(ValueError):build_refund(-599,'R123456')
if __name__=='__main__':unittest.main()
