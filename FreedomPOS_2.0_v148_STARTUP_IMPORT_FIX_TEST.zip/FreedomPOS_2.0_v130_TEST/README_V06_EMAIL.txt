FREEDOM POS 2.0 — EMAIL TEST v0.6

Run START_FREEDOM_POS.bat on Windows (Python 3 required). Install the PDF library first:
    py -m pip install reportlab

Settings & Tools > EMAIL SETTINGS
  Gmail SMTP default: smtp.gmail.com port 465 SSL/TLS
  Or use port 587 and STARTTLS.
  Enter a Google App Password, not your regular Google password.
  Password is NEVER saved; enter again each time the application starts.
  Non-secret settings are saved under test_data/email_settings.json.
  Use SEND TEST EMAIL to check the SMTP connection.

Customers > EMAIL INVOICES / STATEMENTS
  Select customer; edit email; preview account-sale invoice or account statement PDF;
  confirm sending to the saved email. Email history records SMTP acceptance or failure.
  Generated PDFs are saved under test_data/customer_pdf_archive.

LIMITATIONS — TEST SOFTWARE ONLY:
  * Invoice PDF is explicitly labelled TEST DOCUMENT, NOT a final tax invoice.
  * Statement shows available recorded account transactions; opening balance and
    all billing workflows are NOT reconciled.
  * No automatic batch email, retry worker, delivery confirmation, tax invoice
    numbering, immutable invoice revisions, owner alerts or production mail queue.
  * Email sends are real if you configure valid SMTP credentials and confirm.
  * Do not use real customer data or send test documents to real customers.
  * Build TEST EXE script may need reportlab bundling via PyInstaller.

See FEATURE_STATUS.csv and REQUIREMENTS_GAP_REVIEW_V06.md for missing modules.
