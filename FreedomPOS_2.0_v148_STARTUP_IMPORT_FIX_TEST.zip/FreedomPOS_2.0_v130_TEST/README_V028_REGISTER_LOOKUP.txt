Freedom POS 2.0 v0.28 — TEST ONLY

Changes:
- Existing register layout retained, including no Enter button.
- Unknown barcode automatically opens Stock Lookup with the scanned barcode prefilled.
- Stock Lookup offers prefix/similarity barcode suggestions when no exact match exists.
- SELL adds the selected stock product to the active register cart.
- QUICK ADD ITEM opens one complete Stock Add form (all fields together).
- SAVE & SELL saves the new product and adds it to the current sale.
- SAVE ONLY creates the product without adding to the sale.
- Stock Management Add Product now uses the same full Stock Add form.
- Staff PIN gate before opening the register is temporarily disabled for testing.

Important limitations:
- This is a TEST ONLY build, not approved for real transactions.
- No real EFTPOS, lottery or hardware integration has been tested.
- Real Windows GUI and scanner testing still required.
- Product opening stock is a test-data starting quantity, not a received-stock transaction.
- Staff login and transaction attribution must be restored and validated before production use.
