"""Google OAuth desktop integration for Freedom POS test build.
Requires user-supplied Google Desktop OAuth client JSON; never asks for Gmail password.
Tokens are stored in Windows Credential Manager via keyring, not in POS database.
"""
import base64
import datetime
import json
import threading
from pathlib import Path
from email.message import EmailMessage
import tkinter as tk
from tkinter import ttk, messagebox, filedialog

SCOPES=['https://www.googleapis.com/auth/gmail.send','https://www.googleapis.com/auth/gmail.metadata']
SERVICE='FreedomPOS-2-Gmail-OAuth-Test'
ACCOUNT='gmail-token'

def deps():
    import keyring
    from google.oauth2.credentials import Credentials
    from google_auth_oauthlib.flow import InstalledAppFlow
    from google.auth.transport.requests import Request
    from googleapiclient.discovery import build
    return keyring,Credentials,InstalledAppFlow,Request,build

def get_credentials():
    keyring,Credentials,_,Request,_=deps()
    raw=keyring.get_password(SERVICE,ACCOUNT)
    if not raw:raise RuntimeError('Not connected. Click Sign in with Google first.')
    creds=Credentials.from_authorized_user_info(json.loads(raw),SCOPES)
    if not creds.valid:
        if not creds.refresh_token:raise RuntimeError('Google session expired. Reconnect Google.')
        creds.refresh(Request())
        keyring.set_password(SERVICE,ACCOUNT,creds.to_json())
    return creds

def connected_address():
    keyring,_,_,_,_=deps()
    return keyring.get_password(SERVICE,'connected-email') or ''

def connect(client_path):
    keyring,_,InstalledAppFlow,_,build=deps()
    obj=json.loads(Path(client_path).read_text(encoding='utf-8'))
    if 'installed' not in obj:raise ValueError('Select a Google OAuth client JSON created for a Desktop app.')
    flow=InstalledAppFlow.from_client_secrets_file(str(client_path),SCOPES)
    creds=flow.run_local_server(port=0,open_browser=True,access_type='offline',prompt='consent',timeout_seconds=180)
    # Read signed-in identity from Gmail profile using metadata scope, rather than trusting typed sender.
    profile=build('gmail','v1',credentials=creds,cache_discovery=False).users().getProfile(userId='me').execute()
    address=profile['emailAddress']
    keyring.set_password(SERVICE,ACCOUNT,creds.to_json())
    keyring.set_password(SERVICE,'connected-email',address)
    return address

def disconnect():
    keyring,_,_,_,_=deps()
    for key in (ACCOUNT,'connected-email'):
        try:keyring.delete_password(SERVICE,key)
        except Exception:pass

def send(app,kind,recipient,subject,body,attachment,cid):
    """Replace SMTP send. API acceptance is not inbox delivery confirmation."""
    from email_workflows_v06 import valid_email
    import email_workflows_v06 as old
    if not valid_email(recipient):raise ValueError('Recipient email is invalid')
    try:
        creds=get_credentials()
        sender=connected_address()
        if not sender:raise RuntimeError('Connect a Gmail account first.')
        msg=EmailMessage()
        msg['From']=sender
        msg['To']=recipient
        msg['Subject']=subject
        reply=app.mail_cfg.get('reply_to','')
        if reply and valid_email(reply):msg['Reply-To']=reply
        msg.set_content(body)
        if attachment:
            p=Path(attachment)
            if p.suffix.lower()!='.pdf':raise ValueError('Only PDF attachments are supported in this test')
            msg.add_attachment(p.read_bytes(),maintype='application',subtype='pdf',filename=p.name)
        raw=base64.urlsafe_b64encode(msg.as_bytes()).decode('ascii')
        _,_,_,_,build=deps()
        result=build('gmail','v1',credentials=creds,cache_discovery=False).users().messages().send(userId='me',body={'raw':raw}).execute()
        status='ACCEPTED';detail='Gmail API accepted message id '+str(result.get('id','unknown'))
    except Exception as exc:
        status='FAILED';detail=str(exc)[:350]
        with app.db:app.db.execute('INSERT INTO email_history(created,customer_id,recipient,kind,status,detail,file) VALUES(?,?,?,?,?,?,?)',(datetime.datetime.now().isoformat(timespec='seconds'),cid,recipient,kind,status,detail,str(attachment or '')))
        raise
    with app.db:app.db.execute('INSERT INTO email_history(created,customer_id,recipient,kind,status,detail,file) VALUES(?,?,?,?,?,?,?)',(datetime.datetime.now().isoformat(timespec='seconds'),cid,recipient,kind,status,detail,str(attachment or '')))
    app.log('EMAIL',f'{kind} to {recipient}: Gmail API accepted')

def install(cls):
    import email_workflows_v06 as email_module
    email_module.send=send
    def email_settings(self):
        w=tk.Toplevel(self.root);w.title('EMAIL SETTINGS — GOOGLE SIGN-IN v0.9 TEST');w.geometry('900x730');w.transient(self.root)
        outer=ttk.Frame(w,padding=20);outer.pack(fill='both',expand=True)
        ttk.Label(outer,text='EMAIL SETTINGS  •  SIGN IN WITH GOOGLE',font=('Segoe UI',17,'bold')).pack(anchor='w',pady=(0,8))
        ttk.Label(outer,text='Use your regular Gmail login on Google’s own website. Freedom POS never asks for your Gmail password.\nA one-time Google Cloud Desktop OAuth client JSON is required. Email sends require your confirmation.',foreground='#8a381c').pack(anchor='w',pady=(0,12))
        client_path=tk.StringVar(value=str(self.mail_cfg.get('oauth_client_path','')))
        def line(label,default='',wide=35):
            f=ttk.Frame(outer);f.pack(fill='x',pady=4)
            ttk.Label(f,text=label,width=wide).pack(side='left')
            v=tk.StringVar(value=default);ttk.Entry(f,textvariable=v).pack(side='left',fill='x',expand=True)
            return v
        row=ttk.Frame(outer);row.pack(fill='x',pady=5)
        ttk.Label(row,text='Google OAuth Desktop client JSON',width=35).pack(side='left')
        ttk.Entry(row,textvariable=client_path).pack(side='left',fill='x',expand=True)
        ttk.Button(row,text='Browse',command=lambda:client_path.set(filedialog.askopenfilename(parent=w,filetypes=[('Google JSON','*.json')]) or client_path.get())).pack(side='left',padx=5)
        name=line('Sender display name',self.mail_cfg.get('sender_name','Freedom POS'))
        reply=line('Reply-to email',self.mail_cfg.get('reply_to',''))
        business=line('Business legal name',self.mail_cfg.get('business_name',''))
        abn=line('ABN',self.mail_cfg.get('abn',''))
        pay=line('Payment instructions',self.mail_cfg.get('payment_details',''))
        sig=line('Email signature',self.mail_cfg.get('signature',''))
        owner=line('Owner notification email',self.mail_cfg.get('owner_email',''))
        recipient=line('Test email recipient',self.mail_cfg.get('test_recipient',''))
        status=tk.StringVar(value='Checking Google connection…')
        ttk.Label(outer,textvariable=status,font=('Segoe UI',11,'bold')).pack(anchor='w',pady=10)
        def refresh():
            try:status.set('Connected Google account: '+connected_address() if connected_address() else 'Not connected')
            except Exception as e:status.set('Google dependencies unavailable: '+str(e))
        def save(silent=False):
            cfg=dict(self.mail_cfg)
            cfg.update({'oauth_client_path':client_path.get().strip(),'sender_name':name.get().strip(),'reply_to':reply.get().strip(),'business_name':business.get().strip(),'abn':abn.get().strip(),'payment_details':pay.get().strip(),'signature':sig.get().strip(),'owner_email':owner.get().strip(),'test_recipient':recipient.get().strip()})
            self.mail_cfg=cfg
            self.mail_cfg_path.parent.mkdir(exist_ok=True)
            self.mail_cfg_path.write_text(json.dumps(cfg,indent=2),encoding='utf-8')
            self.log('EMAIL SETTINGS','Google OAuth non-secret email settings saved')
            if not silent:messagebox.showinfo('Saved','Email settings saved. Gmail password and OAuth tokens are not stored in the POS database.',parent=w)
        def background(work,done):
            status.set('Working… please complete any Google sign-in in your browser.')
            def worker():
                try:result=work();error=None
                except Exception as exc:result=None;error=str(exc)
                w.after(0,lambda:done(result,error))
            threading.Thread(target=worker,daemon=True).start()
        def do_connect():
            save(True)
            if not Path(client_path.get()).is_file():return messagebox.showerror('Client JSON missing','Select your Google OAuth Desktop client JSON first.',parent=w)
            def done(result,error):
                refresh()
                if error:messagebox.showerror('Google sign-in failed',error,parent=w)
                else:messagebox.showinfo('Connected','Google account connected: '+result,parent=w)
            background(lambda:connect(client_path.get()),done)
        def do_disconnect():
            if messagebox.askyesno('Disconnect','Remove the saved Google connection from this Windows user?',parent=w):
                disconnect();refresh()
        def do_test():
            save(True)
            to=recipient.get().strip()
            if not to:return messagebox.showerror('Recipient missing','Enter a test email recipient.',parent=w)
            if not messagebox.askyesno('Confirm test email','Send a test email to '+to+'?',parent=w):return
            def done(result,error):
                refresh()
                if error:messagebox.showerror('Test email failed',error,parent=w)
                else:messagebox.showinfo('Accepted','Gmail API accepted the test message. Check the recipient inbox.',parent=w)
            try:
                send(self,'TEST',to,'Freedom POS Gmail test','Test email from Freedom POS v0.9. No customer data.',None,None)
            except Exception as exc:done(None,str(exc))
            else:done(True,None)
        bar=ttk.Frame(outer);bar.pack(anchor='w',pady=14)
        for title,cmd in [('SAVE SETTINGS',save),('SIGN IN WITH GOOGLE',do_connect),('DISCONNECT',do_disconnect),('SEND TEST EMAIL',do_test),('EMAIL HISTORY',self.email_history)]:
            ttk.Button(bar,text=title,command=cmd).pack(side='left',padx=3)
        ttk.Label(outer,text='TEST BUILD: Gmail API connection only. Customer invoicing and statement accounting are not production ready.',foreground='#8a381c').pack(anchor='w',pady=12)
        refresh()
    cls.email_settings=email_settings
