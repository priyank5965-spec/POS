Freedom POS v138 INTEGRATION TEST (NOT PRODUCTION READY)

Added: shared Supplier/Department master lookup and quick-add full forms in Product Master and Newspaper Product Setup; newspaper weekday barcode generation Alt+R; Product Master POS Settings Quick Sell Code; existing v137 Quick Sell and weekday price handling retained; only description required for stock product (department defaults to General); v136 working BAT launcher retained.

Still unverified / not complete: all-screen shared autocomplete, full Windows GUI regression, complete keyboard Tab order, consistent toolbar styling on every screen, full supplier/department management editing, real Linkly terminal testing. Keep a backup and do not use for live trading until verified.
