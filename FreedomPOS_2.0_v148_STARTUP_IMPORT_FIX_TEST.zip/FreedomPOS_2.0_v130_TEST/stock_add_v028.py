"""Shared complete Stock Add form used by register quick-add and stock management."""
import tkinter as tk
from tkinter import ttk, messagebox
import sqlite3
from stock_screen_v015 import ensure, amount

def install(cls):
    old_add=cls.add_product
    def stock_add_form(self,barcode='',on_saved=None):
        ensure(self.db)
        w=tk.Toplevel(self.root);w.title('Freedom POS 2.0 — ADD STOCK — TEST ONLY')
        w.geometry('1000x630');w.minsize(850,560);w.transient(self.root);w.grab_set()
        top=tk.Frame(w,bg='white');top.pack(fill='x')
        tk.Label(top,text='ADD STOCK — COMPLETE PRODUCT DETAILS',bg='white',fg='#111111',font=('Segoe UI',17,'bold')).pack(anchor='w',padx=18,pady=14)
        body=tk.Frame(w,padx=18,pady=15);body.pack(fill='both',expand=True)
        fields=[('barcode','Barcode *'),('name','Long Description *'),('short_name','Short Description'),('sku','SKU / Internal Stock Code'),('category','Department'),('supplier','Preferred Supplier'),('supplier_code','Supplier Stock Code'),('price','Selling Price ($) *'),('cost','Cost Price ($)'),('rrp','Supplier RRP ($)'),('stock','Opening Stock Quantity'),('reorder_point','Reorder Point'),('reorder_qty','Reorder Quantity'),('pos_warn','Low Stock Warning'),('notes','Product Notes')]
        defaults={'barcode':barcode,'price':'0.00','cost':'0.00','rrp':'0.00','stock':'0','reorder_point':'0','reorder_qty':'0','pos_warn':'0'}
        values={};entries={}
        for i,(key,label) in enumerate(fields):
            col=(i%2)*2;row=i//2
            tk.Label(body,text=label,font=('Segoe UI',10,'bold')).grid(row=row,column=col,sticky='w',padx=6,pady=7)
            var=tk.StringVar(value=defaults.get(key,''));values[key]=var
            widget=ttk.Entry(body,textvariable=var,font=('Segoe UI',11))
            widget.grid(row=row,column=col+1,sticky='ew',padx=(4,22),pady=6);entries[key]=widget
        body.columnconfigure(1,weight=1);body.columnconfigure(3,weight=1)
        error=tk.StringVar();tk.Label(w,textvariable=error,fg='#ad2525',font=('Segoe UI',10,'bold')).pack(anchor='w',padx=22)
        buttons=tk.Frame(w,padx=18,pady=12);buttons.pack(side='bottom',fill='x')
        def save(sell=False):
            data={k:v.get().strip() for k,v in values.items()}
            try:
                if not data['barcode'] or not data['name']:raise ValueError('Barcode and long description are required.')
                if not data['price']:raise ValueError('Selling price is required.')
                if self.db.execute('SELECT 1 FROM products WHERE barcode=?',(data['barcode'],)).fetchone() or self.db.execute('SELECT 1 FROM stock_aliases WHERE barcode=?',(data['barcode'],)).fetchone():
                    raise ValueError('Barcode already exists. Select the existing product in Stock Lookup.')
                if data['sku'] and self.db.execute('SELECT 1 FROM products WHERE sku=?',(data['sku'],)).fetchone():
                    raise ValueError('SKU already exists. Choose a different SKU.')
                money=[amount(data[k] or '0') for k in ('price','cost','rrp')]
                nums=[int(data[k] or '0') for k in ('stock','reorder_point','reorder_qty','pos_warn')]
                if min(nums)<0:raise ValueError('Stock and reorder values cannot be negative.')
                keys=['barcode','name','short_name','sku','category','supplier','supplier_code','price','cost','rrp','stock','reorder_point','reorder_qty','pos_warn','notes']
                vals=[data[k] for k in keys[:7]]+money+nums+[data['notes']]
                with self.db:
                    cur=self.db.execute('INSERT INTO products ('+','.join(keys)+') VALUES ('+','.join('?' for _ in keys)+')',vals)
                    pid=cur.lastrowid
                self.log('PRODUCT',f'Created product #{pid} barcode {data["barcode"]} via full Stock Add form')
                w.destroy()
                if on_saved:on_saved(pid,sell)
                elif hasattr(self,'products'):self.products()
            except (ValueError,sqlite3.Error) as exc:error.set(str(exc))
        tk.Button(buttons,text='CANCEL',command=w.destroy,font=('Segoe UI',11)).pack(side='right',padx=6)
        tk.Button(buttons,text='SAVE ONLY',command=lambda:save(False),font=('Segoe UI',11,'bold')).pack(side='right',padx=6)
        if on_saved:tk.Button(buttons,text='SAVE & SELL',command=lambda:save(True),bg='#d9f0df',font=('Segoe UI',11,'bold')).pack(side='right',padx=6)
        entries['name' if barcode else 'barcode'].focus_set()
        return w
    def add_product(self):return self.stock_add_form()
    cls.stock_add_form=stock_add_form
    cls.add_product=add_product
