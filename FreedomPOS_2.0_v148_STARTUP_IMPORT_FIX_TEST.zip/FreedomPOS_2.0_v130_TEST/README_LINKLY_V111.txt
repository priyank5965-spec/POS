Freedom POS 2.0 — v0.111 EFTPOS MODE TEST BUILD

This is a test-only POS application. Do not use with real sales or stock.

Settings & Tools -> EFTPOS — TEST / LIVE MODE
- TEST: choose next simulated EFTPOS result: APPROVED, DECLINED, CANCELLED, TIMEOUT, CONNECTION LOST.
- LIVE: intentionally disabled. All EFTPOS checkout requests are blocked.
- EFTPOS SIMULATED checkout: test outcome is checked before any sale/stock is posted.
- Split tender with an EFTPOS component also goes through the simulator.
- Test attempts are stored in the eft_test_attempts SQLite table.
- Simulate Refund is independent of sale/stock and transfers no money.

No real Linkly transaction protocol, terminal connection, bank processing, reversal, settlement or receipt integration exists yet.
Windows GUI, integration with a physical Linkly test harness and end-to-end checkout require testing.
Keep a backup of any prior TEST database and extract into a separate directory.
