"""Four-column department navigation, popup preference and department shortcuts. TEST ONLY."""
import json, tkinter as tk
from decimal import Decimal, InvalidOperation, ROUND_HALF_UP
from tkinter import ttk, messagebox
from pathlib import Path
from register_keyboard_v060 import canonical, from_event

FILE=Path(__file__).resolve().parent/'department_navigation_business.json'

def load():
    try:
        obj=json.loads(FILE.read_text(encoding='utf8'))
        if isinstance(obj,dict):
            # Ctrl+D belongs exclusively to Shift Sales Dashboard.
            for item in obj.values():
                if isinstance(item,dict) and str(item.get("shortcut","")).strip().upper().replace(" ","") in ("CTRL+D","CONTROL+D"):
                    item["shortcut"]=""
            return obj
    except (ValueError,OSError):pass
    return {}

DEFAULT_DEPARTMENTS = (
    ('INSTANTS', 'INSTANTS'),
    ('LOTTO', 'LOTTO'),
    ('NEWSPAPERS', 'NEWSPAPERS'),
    ('INSTANT PAYOUTS', 'INSTANT_PAYOUTS'),
    ('LOTTO PAYOUTS', 'LOTTO_PAYOUTS'),
    ('MAGAZINES', 'MAGAZINES'),
    ('STATIONERY', 'STATIONERY'),
    ('CARDS & WRAP', 'CARDS_WRAP'),
    ('SWEETS', 'SWEETS'),
    ('GIFTS', 'GIFTS'),
    ('Default Payment Dissection', 'DEFAULT_PAYMENT_DISSECTION'),
)

def seed_default_departments(app):
    # Idempotent: never modify existing departments or their active flags.
    app.db.execute("""CREATE TABLE IF NOT EXISTS departments_master(
        id INTEGER PRIMARY KEY, name TEXT NOT NULL UNIQUE, code TEXT NOT NULL UNIQUE,
        description TEXT DEFAULT '', gst TEXT DEFAULT 'GST 10%', markup TEXT DEFAULT '',
        label_policy TEXT DEFAULT 'Standard', notes TEXT DEFAULT '',
        active INTEGER NOT NULL DEFAULT 1)""")
    with app.db:
        for name, code in DEFAULT_DEPARTMENTS:
            if app.db.execute('SELECT 1 FROM departments_master WHERE name=?',(name,)).fetchone():
                continue
            if app.db.execute('SELECT 1 FROM departments_master WHERE code=?',(code,)).fetchone():
                continue
            app.db.execute('INSERT INTO departments_master(name,code) VALUES(?,?)',(name,code))

def departments(app):
    try:
        seed_default_departments(app)
        order={name:i for i,(name,_) in enumerate(DEFAULT_DEPARTMENTS)}
        rows=list(app.db.execute('SELECT id,name FROM departments_master WHERE active=1'))
        return sorted(rows,key=lambda d:(order.get(d['name'],len(order)),d['name']))
    except Exception:
        return []

def department_key(value):
    """Allow unmodified A-Z only for department actions; all other keys use normal rules."""
    value=str(value or '').strip()
    if len(value)==1 and value.isalpha() and value.isascii():
        return value.upper()
    return canonical(value)

def department_event(event):
    """Single letter capture must bypass global barcode shortcut canonicalisation."""
    from register_keyboard_v060 import _modifiers
    ctrl,alt,shift=_modifiers(event)
    k=str(getattr(event,'keysym',''))
    if len(k)==1 and k.isascii() and k.isalpha() and not (ctrl or alt or shift):
        return k.upper()
    return from_event(event)

def amount_cents(raw):
    """Amount entered in dollars; reject non-positive and unreasonably large values."""
    value=str(raw or '').strip().replace('$','')
    if not value:return None
    try: n=Decimal(value)
    except InvalidOperation:return None
    if not n.is_finite() or n<=0 or n>Decimal('999999.99'):return None
    if n.as_tuple().exponent < -2:return None
    return int((n*100).quantize(Decimal('1'),rounding=ROUND_HALF_UP))

def validate(cfg,builtin=None,custom=None):
    seen={}
    for name,key in (builtin or {}).items():
        if key:seen[canonical(key)]=name
    for action in custom or []:
        if action.get('enabled',True) and action.get('shortcut'):
            key=canonical(action['shortcut'])
            if key in seen:raise ValueError(f'{key} conflicts with {seen[key]}')
            seen[key]=action.get('name','Custom action')
    for ident,item in cfg.items():
        if not isinstance(item,dict) or item.get('mode','inside') not in ('inside','popup'):
            raise ValueError('Invalid department display setting')
        key=department_key(item.get('shortcut',''))
        if key=='CTRL+D':raise ValueError('Ctrl+D is reserved for the Shift Sales Dashboard. Choose another department shortcut.')
        if key in seen:raise ValueError(f'{key} conflicts with {seen[key]}')
        if key:seen[key]=f'Department {ident}'
    return True

def install(cls):
    original_pos=cls.pos
    original_departments=cls.register_departments
    original_settings=cls.settings

    def department_sale(self, department_id, amount):
        row=self.db.execute('SELECT name,code FROM departments_master WHERE id=? AND active=1',(int(department_id),)).fetchone()
        if row is None:return
        if amount is None or amount<=0:return
        # Department sale is a non-stock cart line, retained on saved sale lines/receipts.
        # Do not silently treat payout departments as ordinary positive sales.
        if 'PAYOUT' in row['name'].upper():
            messagebox.showwarning('Payout department','Payout departments require the dedicated payout workflow; no positive sale was posted.',parent=self.root)
            return
        self.cart.append(dict(product_id=None,description=row['name'],qty=1,unit=amount,kind='DEPARTMENT SALE',department_id=int(department_id),original_line=None))
        self.refresh_cart()
        self.code.delete(0,'end')
        self.code.focus_set()

    def department_popup(self, department_id):
        row=self.db.execute('SELECT name FROM departments_master WHERE id=?',(department_id,)).fetchone()
        if row is None:return
        w=tk.Toplevel(self.root);w.title(row['name']+' — Department Products');w.geometry('850x590');w.transient(self.root)
        tk.Label(w,text=row['name']+' — PRODUCTS',font=('Segoe UI',16,'bold'),pady=12).pack(fill='x')
        outer=tk.Frame(w);outer.pack(fill='both',expand=True,padx=12,pady=8)
        canvas=tk.Canvas(outer,highlightthickness=0);bar=ttk.Scrollbar(outer,orient='vertical',command=canvas.yview)
        bar.pack(side='right',fill='y');canvas.pack(side='left',fill='both',expand=True);canvas.configure(yscrollcommand=bar.set)
        body=tk.Frame(canvas);item=canvas.create_window((0,0),window=body,anchor='nw')
        body.bind('<Configure>',lambda e:canvas.configure(scrollregion=canvas.bbox('all')))
        canvas.bind('<Configure>',lambda e:canvas.itemconfigure(item,width=e.width))
        products=list(self.db.execute('SELECT id,name,price FROM products WHERE department_id=? ORDER BY name LIMIT 500',(department_id,)))
        for i,p in enumerate(products):
            def add(pid=p['id']):self.quick(pid);w.destroy();self.code.focus_set()
            tk.Button(body,text=f'{p["name"]}\n${p["price"]/100:.2f}',command=add,height=3,wraplength=150).grid(row=i//4,column=i%4,sticky='nsew',padx=4,pady=4)
        for i in range(4):body.columnconfigure(i,weight=1)
        if not products:tk.Label(body,text='No products assigned to this department.').grid(row=0,column=0,pady=24)
        tk.Button(w,text='CLOSE',command=w.destroy,height=2).pack(side='bottom',pady=8)

    def show_department(self,department_id=None,force_mode=None):
        ds=departments(self)
        if not ds:
            messagebox.showinfo('Departments','Create departments in Products & Stock first.',parent=self.root)
            return
        if department_id is None:
            self._department_page=('departments',None,None)
            return render(self)
        d=next((x for x in ds if x['id']==int(department_id)),None)
        if d is None:return
        # A number typed in the barcode/amount field turns a department button
        # into a department sale, regardless of popup/submenu preference.
        raw=self.code.get().strip() if hasattr(self,'code') and self.code.winfo_exists() else ''
        amount=amount_cents(raw)
        if amount is not None:
            return department_sale(self,d['id'],amount)
        mode=force_mode or load().get(str(d['id']),{}).get('mode','inside')
        if mode=='popup':return department_popup(self,int(d['id']))
        self._department_page=('groups',int(d['id']),None)
        render(self)

    def render(self):
        tiles=getattr(self,'_register_tiles',{})
        if not tiles:return
        page,dept,cat=getattr(self,'_department_page',('main',None,None))
        if page=='main':
            for key,t in tiles.items():
                b=t['widget']
                if b.winfo_exists():
                    b.configure(command=t.get('_original_command',b.cget('command')))
            if hasattr(self,'apply_register_customization'):self.apply_register_customization()
            return
        if not getattr(self,'_department_original',None):
            self._department_original={k:(t['widget'].cget('text'),t['widget'].cget('command'),t['widget'].cget('bg'),t['widget'].cget('fg')) for k,t in tiles.items()}
        buttons=[t['widget'] for t in tiles.values()]
        for b in buttons:
            b.configure(text='',command=lambda:None,bg='#eeeeee',fg='#172c43',image='')
        def setbutton(i,label,fn,bg='#e5eaf0'):
            if i>=len(buttons):return
            buttons[i].configure(text=label,command=fn,bg=bg,fg='#14283b',wraplength=125)
        setbutton(0,'◀ BACK',lambda:back(self),'#cce7f3')
        setbutton(1,'⌂ HOME',lambda:home(self),'#cce7f3')
        setbutton(2,'CASH',self.register_cash,'#d9f0df')
        setbutton(3,'EFTPOS (TEST)',lambda:self.checkout('EFTPOS SIMULATED'),'#d9f0df')
        if page=='departments':
            items=departments(self)
            for i,d in enumerate(items[:max(0,len(buttons)-4)],4):
                setbutton(i,d['name'],lambda did=d['id']:show_department(self,did))
        elif page=='groups':
            d=self.db.execute('SELECT name FROM departments_master WHERE id=?',(dept,)).fetchone()
            setbutton(4,'ALL PRODUCTS',lambda:open_products(self,dept,None),'#f7eac6')
            groups=list(self.db.execute('SELECT id,name FROM department_categories WHERE department_id=? AND active=1 ORDER BY name',(dept,)))
            for i,c in enumerate(groups[:max(0,len(buttons)-5)],5):
                setbutton(i,c['name'],lambda cid=c['id']:open_products(self,dept,cid))
            if not groups:setbutton(5,'PRODUCTS',lambda:open_products(self,dept,None))
        elif page=='products':
            sql='SELECT id,name,price FROM products WHERE department_id=?'
            params=[dept]
            if cat is not None:sql+=' AND category_id=?';params.append(cat)
            sql+=' ORDER BY name LIMIT 200'
            products=list(self.db.execute(sql,params))
            self._department_product_page=min(getattr(self,'_department_product_page',0),max(0,(len(products)-1)//max(1,len(buttons)-6)))
            size=max(1,len(buttons)-6)
            start=self._department_product_page*size
            for i,p in enumerate(products[start:start+size],4):
                setbutton(i,f'{p["name"]}\n${p["price"]/100:.2f}',lambda pid=p['id']:self.quick(pid))
            setbutton(len(buttons)-2,'◀ PAGE',lambda:page_move(self,-1),'#cce7f3')
            setbutton(len(buttons)-1,'PAGE ▶',lambda:page_move(self,1),'#cce7f3')

    def home(self):
        self._department_page=('main',None,None)
        self.pos()  # rebuild buttons, preserving saved designer appearance
        self._department_page=('main',None,None)
    def back(self):
        page,dept,cat=getattr(self,'_department_page',('main',None,None))
        if page=='products':self._department_page=('groups',dept,None);render(self)
        elif page=='groups':self._department_page=('departments',None,None);render(self)
        else:home(self)
    def open_products(self,dept,cat):
        self._department_page=('products',dept,cat);self._department_product_page=0;render(self)
    def page_move(self,delta):
        self._department_product_page=max(0,getattr(self,'_department_product_page',0)+delta);render(self)

    def pos(self):
        original_pos(self)
        self._department_page=('main',None,None)
        # Add a department navigation entry without changing the 40-button layout.
        for k,t in getattr(self,'_register_tiles',{}).items():
            if t['label']=='DEPARTMENTS':
                t['widget'].configure(command=lambda:show_department(self))
                break
        def handle(event):
            if not hasattr(self,'code') or not self.code.winfo_exists():return
            focus=self.root.focus_get()
            if focus is None or focus.winfo_toplevel()!=self.root:return
            if focus is not self.code and isinstance(focus,(tk.Entry,tk.Text,ttk.Entry,ttk.Combobox,tk.Spinbox)):return
            key=department_event(event)
            if not key:return
            raw=self.code.get().strip()
            # Never steal letters from a partial barcode, product code, or receipt barcode.
            if focus is self.code and raw and amount_cents(raw) is None:return
            cfg=load()
            try:
                if self.db.execute('SELECT 1 FROM quick_sell_codes_v136 WHERE code=?',(key,)).fetchone():return
            except Exception:pass
            for d in departments(self):
                item=cfg.get(str(d['id']),{})
                if department_key(item.get('shortcut',''))==key:
                    show_department(self,d['id']);return 'break'
        self._department_key_handler=handle
        # Entry widget-level binding executes before the Tk Entry class inserts
        # the typed letter, preventing '10G' and fixing bare G/S/M/L shortcuts.
        self.code.bind('<KeyPress>',lambda event:self._department_key_handler(event),add='+')
        if not getattr(self,'_department_keys_bound',False):
            self.root.bind('<KeyPress>',lambda event:self._department_key_handler(event),add='+')
            self._department_keys_bound=True

    def manager(self):
        w=tk.Toplevel(self.root);w.title('Department Buttons & Shortcuts — Business Defaults')
        sw=w.winfo_screenwidth();sh=w.winfo_screenheight()
        w.geometry(f'{min(900,sw-100)}x{min(620,sh-160)}')
        tk.Label(w,text='DEPARTMENT BUTTONS — BUSINESS DEFAULTS',font=('Segoe UI',16,'bold'),bg='white',fg='#111111',pady=14).pack(fill='x')
        tk.Label(w,text='Submenu = inside four-column Register. Popup = this department’s product window. Press G, S, M, L or Ctrl+letter in a shortcut field. Enter 10.00 then press a department shortcut to sell $10.00 (payouts excluded).',pady=10,wraplength=820).pack(fill='x')
        footer=tk.Frame(w,pady=10);footer.pack(side='bottom',fill='x')
        frame=tk.Frame(w);frame.pack(fill='both',expand=True,padx=18,pady=12)
        canvas=tk.Canvas(frame,highlightthickness=0);scroll=ttk.Scrollbar(frame,orient='vertical',command=canvas.yview)
        scroll.pack(side='right',fill='y');canvas.pack(side='left',fill='both',expand=True)
        canvas.configure(yscrollcommand=scroll.set)
        body=tk.Frame(canvas);win=canvas.create_window((0,0),window=body,anchor='nw')
        body.bind('<Configure>',lambda e:canvas.configure(scrollregion=canvas.bbox('all')))
        canvas.bind('<Configure>',lambda e:canvas.itemconfigure(win,width=e.width))
        for i,heading in enumerate(('Department','Display Mode','Shortcut')):
            tk.Label(body,text=heading,font=('Segoe UI',11,'bold')).grid(row=0,column=i,sticky='w',padx=10,pady=10)
        settings=load();rows={}
        for row,d in enumerate(departments(self),1):
            item=settings.get(str(d['id']),{})
            mode=tk.StringVar(value=item.get('mode','inside'))
            shortcut=tk.StringVar(value=item.get('shortcut',''))
            tk.Label(body,text=d['name'],anchor='w').grid(row=row,column=0,sticky='ew',padx=10,pady=7)
            ttk.Combobox(body,textvariable=mode,values=('inside','popup'),state='readonly',width=17).grid(row=row,column=1,padx=10)
            field=ttk.Entry(body,textvariable=shortcut,width=19,justify='center');field.grid(row=row,column=2,padx=10)
            def capture(event,v=shortcut):
                if event.keysym in ('Control_L','Control_R','Alt_L','Alt_R','Shift_L','Shift_R'):return 'break'
                if event.keysym in ('BackSpace','Delete'):
                    v.set('');return 'break'
                value=department_event(event)
                if value:v.set(value)
                else:w.bell()
                return 'break'
            field.bind('<KeyPress>',capture)
            field.bind('<KeyRelease>',lambda e:'break')
            field.bind('<FocusIn>',lambda e:e.widget.selection_range(0,'end'))
            tk.Button(body,text='Clear',command=lambda v=shortcut:v.set('')).grid(row=row,column=3,padx=5)
            rows[str(d['id'])]=(mode,shortcut)
        body.columnconfigure(0,weight=1)
        def save():
            proposed={k:{'mode':v[0].get(),'shortcut':v[1].get()} for k,v in rows.items()}
            try:
                from register_keyboard_v060 import load as builtin
                from custom_actions_v062 import load_actions
                validate(proposed,builtin(),load_actions())
                FILE.write_text(json.dumps(proposed,indent=2),encoding='utf8')
            except (ValueError,OSError) as exc:
                messagebox.showerror('Cannot save department settings',str(exc),parent=w);return
            w.destroy()
        tk.Button(footer,text='Save Business Defaults',command=save,bg='white',fg='#111111',font=('Segoe UI',11,'bold')).pack(side='right',padx=8)
        tk.Button(footer,text='Cancel',command=w.destroy).pack(side='right',padx=8)
        tk.Button(footer,text='Clear All Shortcuts',command=lambda:[v[1].set('') for v in rows.values()]).pack(side='left',padx=8)

    def settings(self):
        # Inject a full-size tile into the original responsive 3-column grid.
        # Intercept the layout call rather than packing a clipped extra row.
        original_layout=self.layout
        def patched_layout(title,items):
            if title=='SETTINGS & TOOLS':
                items=list(items)
                if not any(name=='Department Buttons & Shortcuts' for name,_ in items):
                    items.insert(0,('Department Buttons & Shortcuts',lambda:manager(self)))
            return original_layout(title,items)
        self.layout=patched_layout
        try:return original_settings(self)
        finally:self.layout=original_layout

    cls.pos=pos
    cls.render_department_navigation=render
    cls.register_departments=show_department
    cls.department_button_settings=manager
    cls.department_sale=department_sale
    cls.settings=settings
