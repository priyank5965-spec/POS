"""v0.83 touchscreen split tender; simulated payments only."""
import tkinter as tk
from tkinter import ttk,messagebox
from decimal import Decimal,InvalidOperation,ROUND_HALF_UP

METHODS=('Cash','EFTPOS','EFTPOS 2','EFTPOS 3','AMEX','Bank Card','Cheque','Gift Voucher','Direct Deposit')
def cents(value):
    return int((Decimal(str(value))*100).quantize(Decimal('1'),rounding=ROUND_HALF_UP))
def install(cls):
    def split_payment(self):
        if not self.cart:return self.warn('No items in sale')
        if any(x.get('epay_pending') or x.get('epay_unissued') for x in self.cart):
            return self.warn('Unissued E-PAY items cannot be paid for.')
        # self.total() is already stored as integer cents throughout Freedom POS.
        # Do not call cents() here: that multiplies the amount by 100 again.
        total=int(self.total())
        if total<0:return self.warn('Negative split refunds are not supported in this test')
        if total==0:return self.warn('There is no amount to allocate')
        win=tk.Toplevel(self.root);win.title('Part Payment — Split Tender (TEST ONLY)')
        win.geometry('850x690');win.minsize(720,560);win.transient(self.root)
        try:win.grab_set()
        except tk.TclError:pass
        bg='#eef2f6';win.configure(bg=bg)
        tk.Label(win,text='PART PAYMENT',font=('Segoe UI',17,'bold'),bg='#13324a',fg='white',anchor='w',padx=16,pady=12).pack(fill='x')
        tk.Label(win,text='SIMULATED ONLY — No EFTPOS, bank or gift voucher processing',bg=bg,fg='#b04a22',font=('Segoe UI',10,'bold')).pack(anchor='w',padx=16,pady=(8,2))
        content=tk.Frame(win,bg=bg);content.pack(fill='both',expand=True,padx=14,pady=8)
        left=tk.Frame(content,bg=bg);left.pack(side='left',fill='both',expand=True)
        right=tk.Frame(content,bg=bg,width=245);right.pack(side='right',fill='y',padx=(12,0));right.pack_propagate(False)
        entries={};active=tk.StringVar(value='Cash');status=tk.StringVar();error=tk.StringVar()
        headers=tk.Frame(left,bg='#85b2d1');headers.pack(fill='x')
        tk.Label(headers,text='Payment Method',font=('Segoe UI',11,'bold'),bg='#85b2d1',width=24,anchor='w',padx=8,pady=8).pack(side='left',fill='x',expand=True)
        tk.Label(headers,text='Amount $',font=('Segoe UI',11,'bold'),bg='#85b2d1',width=13).pack(side='right')
        listbox=tk.Frame(left,bg=bg);listbox.pack(fill='both',expand=True)
        for method in METHODS:
            line=tk.Frame(listbox,bg=bg);line.pack(fill='x',pady=1)
            tk.Button(line,text=method,anchor='w',bg='#91bbd9',font=('Segoe UI',11,'bold'),relief='flat',command=lambda m=method:focus(m)).pack(side='left',fill='x',expand=True,ipady=6)
            var=tk.StringVar(value='');entry=tk.Entry(line,textvariable=var,justify='right',font=('Segoe UI',13),width=12)
            entry.pack(side='right',fill='y',ipadx=4);entries[method]=(var,entry)
            entry.bind('<FocusIn>',lambda e,m=method:active.set(m))
            entry.bind('<KeyRelease>',lambda e:update())
        def focus(method):
            active.set(method);entries[method][1].focus_set();entries[method][1].icursor('end')
        summary=tk.Frame(left,bg=bg);summary.pack(fill='x',pady=(8,0))
        tk.Label(summary,textvariable=status,bg=bg,font=('Segoe UI',12,'bold'),justify='left',anchor='w').pack(fill='x')
        tk.Label(summary,textvariable=error,bg=bg,fg='#b00020',font=('Segoe UI',10),anchor='w',wraplength=480).pack(fill='x')
        tk.Label(right,text='AMOUNT ENTRY',font=('Segoe UI',12,'bold'),bg=bg).pack(pady=(0,5))
        display=tk.Label(right,text='0.00',bg='black',fg='#39ef32',font=('Segoe UI',24,'bold'),anchor='e',padx=8)
        display.pack(fill='x',pady=(0,7))
        keys=tk.Frame(right,bg=bg);keys.pack(fill='x')
        def press(value):
            method=active.get();var,entry=entries[method]
            current=var.get()
            if value=='Clear':var.set('')
            elif value=='Back':var.set(current[:-1])
            elif value=='Fill':
                try:other=sum(parse(v.get()) for m,(v,e) in entries.items() if m!=method)
                except ValueError:return update()
                var.set(f'{max(0,total-other)/100:.2f}')
            else:
                if value=='.' and '.' in current:return
                var.set(current+value)
            focus(method);update()
        for r,row in enumerate((('7','8','9'),('4','5','6'),('1','2','3'),('0','00','.'),('Back','Clear','Fill'))):
            for c,key in enumerate(row):
                tk.Button(keys,text=key,font=('Segoe UI',13,'bold'),bg='#a9cce5' if key not in ('Clear','Fill') else '#d9e1eb',command=lambda k=key:press(k)).grid(row=r,column=c,sticky='nsew',padx=2,pady=2,ipady=10)
        for c in range(3):keys.columnconfigure(c,weight=1)
        def parse(raw):
            if not raw.strip():return 0
            try:
                v=Decimal(raw)
                if not v.is_finite() or v<0 or v.as_tuple().exponent < -2:raise ValueError
                return cents(v)
            except (InvalidOperation,ValueError):raise ValueError('Enter positive amounts with no more than 2 decimal places')
        def allocations():return [(m,parse(v.get())) for m,(v,e) in entries.items()]
        def update():
            try:
                vals=allocations();allocated=sum(a for m,a in vals)
                remaining=total-allocated
                status.set(f'Transaction Total: ${total/100:.2f}     Allocated: ${allocated/100:.2f}\nRemaining: ${remaining/100:.2f}')
                error.set('Overallocated — reduce payment amounts' if remaining<0 else '')
            except ValueError as exc:error.set(str(exc))
            try:display.config(text=entries[active.get()][0].get() or '0.00')
            except Exception:pass
        def confirm():
            try:vals=allocations()
            except ValueError as exc:return messagebox.showerror('Invalid amount',str(exc),parent=win)
            if sum(a for _,a in vals)!=total:return messagebox.showwarning('Payment incomplete','Allocated amounts must equal the transaction total.',parent=win)
            payments=[(m.upper() if m=='Cash' else m.upper()+' SIMULATED',a) for m,a in vals if a>0]
            if not payments:return
            # No extra confirmation popup for completed TEST split allocations.
            self._skip_test_payment_confirmation=True
            try:
                completed=self.checkout('SPLIT TENDER SIMULATED',split=payments)
            finally:
                self._skip_test_payment_confirmation=False
            if completed:win.destroy()
        actions=tk.Frame(right,bg=bg);actions.pack(side='bottom',fill='x',pady=(10,0))
        tk.Button(actions,text='OK',bg='#8fb9d8',font=('Segoe UI',12,'bold'),command=confirm).pack(side='left',fill='x',expand=True,ipady=12,padx=2)
        tk.Button(actions,text='Cancel',bg='#d8e0e8',font=('Segoe UI',12),command=win.destroy).pack(side='left',fill='x',expand=True,ipady=12,padx=2)
        # Keyboard-first navigation, without affecting amount typing.
        def move_payment(event, direction):
            method=active.get()
            idx=METHODS.index(method) if method in METHODS else 0
            focus(METHODS[(idx+direction)%len(METHODS)])
            return 'break'
        def next_payment(event):
            return move_payment(event,1)
        def finish_keyboard(event):
            confirm()
            return 'break'
        for method,(_,entry) in entries.items():
            entry.bind('<Up>',lambda e:move_payment(e,-1))
            entry.bind('<Down>',lambda e:move_payment(e,1))
            entry.bind('<Return>',finish_keyboard)
            entry.bind('<KP_Enter>',finish_keyboard)
            entry.bind('<Control-Return>',finish_keyboard)
            entry.bind('<Control-KP_Enter>',finish_keyboard)
        win.bind('<Control-Return>',finish_keyboard)
        win.bind('<Control-KP_Enter>',finish_keyboard)
        win.bind('<Escape>',lambda e:(win.destroy(),'break')[1])
        update();focus('Cash')
    cls.split_payment=split_payment
