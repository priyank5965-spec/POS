"""Offline Linkly-style payment simulator; NEVER sends payment data to a bank.
LIVE mode is deliberately disabled until an accredited Linkly adapter exists.
"""
import datetime
import threading
import queue
from linkly_status_v112 import query_pinpad, LinklyStatusError
from linkly_purchase_v114 import test_purchase, test_refund, LinklyPurchaseError
import tkinter as tk
from tkinter import ttk, messagebox

MODES=('TEST','LINKLY STATUS','LINKLY TRAINING','LIVE')
OUTCOMES=('APPROVED','DECLINED','CANCELLED','TIMEOUT','CONNECTION LOST')

def setup(db):
    with db:
        db.execute('CREATE TABLE IF NOT EXISTS eft_settings (key TEXT PRIMARY KEY, value TEXT NOT NULL)')
        db.execute('CREATE TABLE IF NOT EXISTS eft_test_attempts (id INTEGER PRIMARY KEY, created TEXT NOT NULL, amount_cents INTEGER NOT NULL, transaction_type TEXT NOT NULL, outcome TEXT NOT NULL, sale_id INTEGER, note TEXT NOT NULL DEFAULT \'\')')
        db.execute("INSERT OR IGNORE INTO eft_settings(key,value) VALUES('mode','LINKLY TRAINING')")
        db.execute("INSERT OR IGNORE INTO eft_settings(key,value) VALUES('next_outcome','APPROVED')")
        # One-time v121 migration: preselect training for existing status-only installs.
        if not db.execute("SELECT 1 FROM eft_settings WHERE key='v121_mode_initialized'").fetchone():
            db.execute("UPDATE eft_settings SET value='LINKLY TRAINING' WHERE key='mode' AND value='LINKLY STATUS'")
            db.execute("INSERT INTO eft_settings(key,value) VALUES('v121_mode_initialized','1')")

def get(db,key,default=''):
    row=db.execute('SELECT value FROM eft_settings WHERE key=?',(key,)).fetchone()
    return row[0] if row else default

def set_value(db,key,value):
    if key=='mode' and value not in MODES:raise ValueError('Invalid mode')
    if key=='next_outcome' and value not in OUTCOMES:raise ValueError('Invalid test outcome')
    with db:db.execute('INSERT OR REPLACE INTO eft_settings(key,value) VALUES(?,?)',(key,value))

def simulate(db,amount_cents,transaction_type='PURCHASE'):
    if get(db,'mode','LINKLY STATUS')!='TEST':raise RuntimeError('LIVE EFTPOS is disabled: no accredited Linkly payment adapter is installed.')
    if transaction_type not in ('PURCHASE','REFUND'):raise ValueError('Unsupported transaction type')
    if not isinstance(amount_cents,int) or amount_cents<=0:raise ValueError('EFTPOS amount must be positive')
    outcome=get(db,'next_outcome','APPROVED')
    if outcome not in OUTCOMES:raise ValueError('Invalid test outcome')
    stamp=datetime.datetime.now().isoformat(timespec='seconds')
    with db:
        cur=db.execute('INSERT INTO eft_test_attempts(created,amount_cents,transaction_type,outcome,note) VALUES(?,?,?,?,?)',(stamp,amount_cents,transaction_type,outcome,'SIMULATION ONLY — no funds transferred'))
    return cur.lastrowid,outcome

def install(cls):
    original_init=cls.__init__
    def __init__(self,root):
        original_init(self,root)
        setup(self.db)
    cls.__init__=__init__
    original_checkout=cls.checkout
    def checkout(self,method,split=None):
        # Block any accidental use of LIVE mode even for legacy simulated EFTPOS buttons.
        eft_amount=0
        if split:
            eft_amount=sum(int(a) for m,a in split if 'EFTPOS' in m.upper())
        elif 'EFTPOS' in method.upper():
            eft_amount=self.total()
        if eft_amount:
            if getattr(self, '_linkly_verified_checkout', False):
                return original_checkout(self, method, split=split)
            if get(self.db,'mode','LINKLY STATUS')=='LINKLY TRAINING':
                is_refund = eft_amount < 0
                unlinked_returns = any(x.get('product_id') is not None and x['qty'] < 0 and not x.get('original_line') for x in self.cart)
                # Standalone negative quantities are allowed ONLY as verified offline training refunds.
                # Never allow them to silently become purchases or live transactions.
                if unlinked_returns and not is_refund:
                    self.warn('Unlinked negative product quantities require a net negative REFUND total. No request sent.')
                    return False
                if unlinked_returns and self.refund_origin:
                    self.warn('Do not mix linked and unlinked returns. No request sent.')
                    return False
                if split:
                    self.warn('Split EFTPOS is not supported in training mode. No sale posted.')
                    return False
                # No extra confirmation dialogs: pressing EFT begins the offline
                # training request. Keep status/error dialogs for uncertain results.
                # Never perform network I/O on Tk's UI thread.
                if getattr(self, '_linkly_training_busy', False):
                    self.warn('A Linkly training request is already pending. Check its result before retrying.')
                    return False
                self._linkly_training_busy = True
                # Capture the cart state to prevent checkout if it changes during payment.
                import copy
                cart_snapshot = copy.deepcopy(self.cart)
                total_snapshot = self.total()
                events = queue.Queue()
                # Silent EFT flow: no confirmation or processing popup.
                # Keep a subtle window-title indicator while the background worker runs.
                prior_title = self.root.title()
                self.root.title(prior_title + (' — EFTPOS REFUND PROCESSING' if is_refund else ' — EFTPOS PAYMENT PROCESSING'))
                def restore_title():
                    try:
                        self.root.title(prior_title)
                    except tk.TclError:
                        pass
                def worker():
                    try:
                        events.put(('result', test_refund(-eft_amount) if is_refund else test_purchase(eft_amount)))
                    except Exception as exc:
                        events.put(('error', str(exc)))
                threading.Thread(target=worker, daemon=True, name='LinklyTrainingTransaction').start()
                def poll():
                    try:
                        kind, value = events.get_nowait()
                    except queue.Empty:
                        try:
                            self.root.after(150, poll)
                        except tk.TclError:
                            self._linkly_training_busy = False
                        return
                    self._linkly_training_busy = False
                    restore_title()
                    if kind == 'result':
                        # Never use a displayed '00 APPROVED' string by itself as proof of payment.
                        if not value.get('approved'):
                            self.warn('LINKLY TRAINING: DECLINED OR UNVERIFIED\n'
                                      +'Response: '+value['code']+' '+value['message']+'\n'
                                      +'Reference: '+value['reference']+'\n\n'
                                      +'NO SALE POSTED. Check Linkly transaction history.\n'
                                      +'Response field diagnostics are in linkly_training_diagnostics.log.')
                            return
                        if self.cart != cart_snapshot or self.total() != total_snapshot:
                            self.warn('Linkly approved, but the sale changed during payment. '
                                      'NO SALE POSTED. Reconcile the payment before proceeding.')
                            return
                        # A durable unique reference prevents a second post on callbacks/retries.
                        ref = value['reference']
                        with self.db:
                            self.db.execute('CREATE TABLE IF NOT EXISTS linkly_training_posted '
                                            '(reference TEXT PRIMARY KEY, sale_id INTEGER, amount_cents INTEGER NOT NULL, status TEXT NOT NULL)')
                            existing = self.db.execute('SELECT status FROM linkly_training_posted WHERE reference=?',(ref,)).fetchone()
                            if existing:
                                self.warn('This Linkly reference has already been handled. No duplicate sale posted.')
                                return
                            self.db.execute('INSERT INTO linkly_training_posted(reference,amount_cents,status) VALUES(?,?,?)',
                                            (ref,eft_amount,'PENDING_CHECKOUT'))
                        previous = getattr(self,'_skip_test_payment_confirmation',False)
                        self._skip_test_payment_confirmation = True
                        self._linkly_verified_checkout = True
                        self._linkly_verified_refund = is_refund
                        try:
                            posted = original_checkout(self,method,split=None)
                        finally:
                            self._linkly_verified_checkout = False
                            self._linkly_verified_refund = False
                            self._skip_test_payment_confirmation = previous
                        sale_id = None
                        if posted:
                            row = self.db.execute('SELECT id FROM sales ORDER BY id DESC LIMIT 1').fetchone()
                            sale_id = row[0] if row else None
                        with self.db:
                            self.db.execute('UPDATE linkly_training_posted SET status=?, sale_id=? WHERE reference=?',
                                            ('POSTED' if posted else 'RECONCILE_REQUIRED',sale_id,ref))
                        if not posted:
                            self.warn('Linkly training transaction was verified, but POS checkout failed. '
                                      'Do not repeat payment; reconcile reference '+ref+'.')
                    else:
                        self.warn('LINKLY TRAINING: '+value+'\n\nNO SALE POSTED. '
                                  'Verify transaction history before retrying.')
                self.root.after(150, poll)
                return False
            if get(self.db,'mode','LINKLY STATUS')=='LINKLY STATUS':
                # Never post stock or sale: status inquiry cannot authorise a payment.
                try:
                    result=query_pinpad()
                    if result['online']:
                        self.warn('LINKLY PINPAD ONLINE\nStatus: '+result['message']+' ('+result['code']+')\n\nThis is a status check only. Real EFTPOS payments are not enabled. No sale was posted.')
                    else:
                        self.warn('PINPAD OFFLINE / LINKLY ERROR\n'+result['message']+' ('+result['code']+')\n\nNo payment sent. Sale remains open and stock unchanged.')
                except (LinklyStatusError,ValueError) as exc:
                    self.warn('LINKLY PINPAD OFFLINE OR UNAVAILABLE\n'+str(exc)+'\n\nNo payment sent. Sale remains open and stock unchanged.')
                return False
            if get(self.db,'mode','LINKLY STATUS')!='TEST':
                self.warn('LIVE LINKLY IS NOT AVAILABLE. No payment sent and no sale posted. Switch back to TEST mode.')
                return False
            if eft_amount<0:
                self.warn('EFTPOS refund simulation is available in EFTPOS settings; negative sale checkout is blocked.')
                return False
            if not messagebox.askyesno('SIMULATED EFTPOS',f'Simulate EFTPOS payment of ${eft_amount/100:.2f}?\nNo real funds will move.',parent=self.root):return False
            attempt,outcome=simulate(self.db,eft_amount)
            if outcome!='APPROVED':
                self.warn(f'Simulated EFTPOS result: {outcome}.\nNo sale or stock movement was posted.\nTest attempt #{attempt}')
                return False
            # Let existing checkout save stock and sale only after simulator approval.
            previous=getattr(self,'_skip_test_payment_confirmation',False)
            self._skip_test_payment_confirmation=True
            try:
                success=original_checkout(self,method,split=split)
            finally:
                self._skip_test_payment_confirmation=previous
            if success:
                row=self.db.execute('SELECT id FROM sales ORDER BY id DESC LIMIT 1').fetchone()
                with self.db:self.db.execute('UPDATE eft_test_attempts SET sale_id=? WHERE id=?',(row[0] if row else None,attempt))
            else:
                with self.db:self.db.execute("UPDATE eft_test_attempts SET note=? WHERE id=?",('SIMULATOR APPROVED, BUT POS CHECKOUT FAILED — NOT POSTED; investigate',attempt))
            return success
        return original_checkout(self,method,split=split)
    cls.checkout=checkout
    previous_settings=cls.settings
    def eft_mode_settings(self):
        setup(self.db)
        w=tk.Toplevel(self.root);w.title('EFTPOS — TEST / LIVE MODE');w.geometry('760x600');w.transient(self.root)
        f=tk.Frame(w,padx=22,pady=18);f.pack(fill='both',expand=True)
        tk.Label(f,text='LINKLY EFTPOS — PAYMENT MODE',font=('Segoe UI',16,'bold')).pack(anchor='w')
        tk.Label(f,text='LINKLY TRAINING posts TEST sales only after strict transaction verification. Requires OFFLINE Virtual PINpad. LIVE disabled.',wraplength=620,justify='left',fg='#9b3229').pack(anchor='w',pady=(8,18))
        mode=tk.StringVar(value=get(self.db,'mode','LINKLY STATUS'))
        tk.Label(f,text='Operating mode',font=('Segoe UI',11,'bold')).pack(anchor='w')
        for label,value in [('TEST — internal simulator (no Linkly request)','TEST'),('LINKLY STATUS — check connected PINpad and BLOCK checkout (recommended)','LINKLY STATUS'),('LINKLY TRAINING — verified offline test purchase/refund can complete sale','LINKLY TRAINING'),('LIVE — disabled; cannot process payments','LIVE')]:
            ttk.Radiobutton(f,text=label,variable=mode,value=value).pack(anchor='w',pady=4)
        outcome=tk.StringVar(value=get(self.db,'next_outcome','APPROVED'))
        tk.Label(f,text='Next simulated EFTPOS response',font=('Segoe UI',11,'bold')).pack(anchor='w',pady=(18,4))
        ttk.Combobox(f,textvariable=outcome,values=OUTCOMES,state='readonly').pack(fill='x')
        status=tk.StringVar(value='No real transactions are possible in this build.')
        tk.Label(f,textvariable=status,wraplength=610,justify='left',fg='#111111').pack(anchor='w',pady=13)
        def save():
            set_value(self.db,'mode',mode.get());set_value(self.db,'next_outcome',outcome.get())
            status.set('Settings saved. LIVE is blocked.' if mode.get()=='LIVE' else ('LINKLY STATUS selected. EFTPOS will query Linkly and BLOCK checkout; no money moves.' if mode.get()=='LINKLY STATUS' else ('LINKLY TRAINING selected: verified offline approvals can complete TEST sales.' if mode.get()=='LINKLY TRAINING' else 'TEST mode saved. Next response: '+outcome.get())))
        ttk.Button(f,text='SAVE SETTINGS',command=save).pack(fill='x',pady=5)
        def refund():
            if get(self.db,'mode','LINKLY STATUS')!='TEST':return status.set('Refund simulator requires TEST mode. No refund sent.')
            amount=self.ask_money('Simulated EFTPOS Refund','Enter refund amount ($):')
            if amount is None:return
            try:attempt,result=simulate(self.db,amount,'REFUND')
            except (ValueError,RuntimeError) as e:return status.set(str(e))
            status.set(f'Test refund #{attempt}: {result}. No real funds moved. This does not alter sales or stock.')
        ttk.Button(f,text='SIMULATE REFUND (NO STOCK CHANGE)',command=refund).pack(fill='x',pady=5)
        ttk.Button(f,text='CLOSE',command=w.destroy).pack(anchor='e',pady=12)
    cls.eft_mode_settings=eft_mode_settings
    def settings(self):
        previous_settings(self)
        # Add a prominent settings button to the existing settings screen.
        button=self.btn(self.root,'EFTPOS — TEST / LIVE MODE',self.eft_mode_settings,bg='#d9efdf')
        button.pack(fill='x',padx=22,pady=7)
    cls.settings=settings
