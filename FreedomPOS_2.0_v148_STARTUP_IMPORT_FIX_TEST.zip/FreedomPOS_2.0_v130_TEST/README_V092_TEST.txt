Freedom POS 2.0 v0.92 TEST ONLY
Previous Sales > Email > SEND RECEIPT now sends immediately without a second Yes/No confirmation. Recipient validation, PDF generation, Gmail status and errors remain. No real EFTPOS processing.
