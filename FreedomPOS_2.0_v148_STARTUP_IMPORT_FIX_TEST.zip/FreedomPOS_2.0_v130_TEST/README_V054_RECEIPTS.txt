Freedom POS 2.0 v0.54 TEST ONLY

- Settings > Business & Receipt Settings: edit business identity, ABN, contact details, A4 bank details; upload PNG/JPEG receipt logo.
- Both A4 and 80mm PDFs display a Code128 receipt barcode @ followed by ten-digit sale ID.
- Scan @receipt-number in the Register to open a transaction action menu.
- Reprint works; refund routes to existing Previous Sales refund workflow; account credit/payment remains unimplemented.
- GST is NOT reliably itemised by the current sales database, so PDFs explicitly say GST breakdown is not recorded. NOT VALID TAX INVOICE.
- Print opens external PDF viewer; Windows UI and printer integration untested.
- TEST ONLY; no live payments.
