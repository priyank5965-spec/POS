"""v0.38 discount scope/type selection and silent successful hold. TEST ONLY."""
import tkinter as tk
from tkinter import ttk
from decimal import Decimal, InvalidOperation, ROUND_HALF_UP
from register_grid_v034 import money_to_cents, net, popup

def install(cls):
    old_pos=cls.pos
    old_info=cls.info
    def pos(self):
        old_pos(self)
        self.root.title('Freedom POS 2.0 — Register Layout and Discount v0.39 — TEST ONLY')
    def info(self,title,text):
        # Suppress only successful hold acknowledgement; preserve other warnings/errors.
        if title=='Hold' and text=='Sale saved to the shared test database.':return
        return old_info(self,title,text)
    def set_discount(self):
        if not self.cart:return self.warn('Add an item first.')
        if self.refund_origin:return self.warn('Discount editing is disabled for refund transactions.')
        w=tk.Toplevel(self.root);w.title('Freedom POS — Discount Centre v0.39 — TEST ONLY')
        w.geometry('760x620');w.minsize(690,570);w.transient(self.root);w.grab_set()
        BG='#f0f4f7';NAVY='#12324a';CYAN='#24a9c0';WHITE='#ffffff'
        w.configure(bg=BG)
        head=tk.Frame(w,bg=NAVY,height=68);head.pack(fill='x');head.pack_propagate(False)
        tk.Label(head,text='DISCOUNT CENTRE',bg=NAVY,fg=WHITE,font=('Segoe UI',19,'bold')).pack(side='left',padx=22,pady=15)
        tk.Label(head,text='TEST MODE',bg=NAVY,fg='#aee9f1',font=('Segoe UI',10,'bold')).pack(side='right',padx=20)
        body=tk.Frame(w,bg=BG,padx=18,pady=14);body.pack(fill='both',expand=True)
        left=tk.Frame(body,bg=BG);left.pack(side='left',fill='both',expand=True,padx=(0,13))
        right=tk.Frame(body,bg=BG,width=240);right.pack(side='right',fill='y');right.pack_propagate(False)
        scope=tk.StringVar(value='Entire Sale');kind=tk.StringVar(value='Percentage (%)');value=tk.StringVar(value='10')
        def heading(parent,text):tk.Label(parent,text=text,bg=BG,fg=NAVY,font=('Segoe UI',11,'bold'),anchor='w').pack(fill='x',pady=(5,7))
        def choices(parent,options,var):
            row=tk.Frame(parent,bg=BG);row.pack(fill='x',pady=(0,10))
            buttons=[]
            def update(*_):
                for val,btn in buttons:
                    active=var.get()==val
                    btn.configure(bg=NAVY if active else WHITE,fg=WHITE if active else NAVY,relief='solid')
            for val,label in options:
                btn=tk.Button(row,text=label,font=('Segoe UI',10,'bold'),height=2,wraplength=145,bd=1,command=lambda v=val:var.set(v))
                btn.pack(side='left',fill='x',expand=True,padx=3);buttons.append((val,btn))
            var.trace_add('write',update);update()
        heading(left,'APPLY TO')
        choices(left,[('Entire Sale','ENTIRE SALE'),('Selected Item','SELECTED ITEM')],scope)
        heading(left,'DISCOUNT TYPE')
        choices(left,[('Percentage (%)','PERCENTAGE  %'),('Fixed Amount ($)','FIXED AMOUNT  $')],kind)
        heading(left,'DISCOUNT VALUE')
        entry=tk.Entry(left,textvariable=value,font=('Segoe UI',21,'bold'),relief='solid',bd=1,justify='right')
        entry.pack(fill='x',ipady=6,padx=3)
        error=tk.Label(left,text='',bg=BG,fg='#b3261e',anchor='w',wraplength=410,justify='left',font=('Segoe UI',10));error.pack(fill='x',pady=(7,2))
        heading(right,'TOUCH KEYPAD')
        keypad=tk.Frame(right,bg=BG);keypad.pack(fill='x')
        def key(k):
            if k=='C':value.set('')
            elif k=='⌫':value.set(value.get()[:-1])
            elif k=='.':
                if '.' not in value.get():value.set(value.get()+'.')
            else:value.set(value.get()+k)
            entry.focus_set();entry.icursor('end')
        for rowidx,keys in enumerate((('7','8','9'),('4','5','6'),('1','2','3'),('C','0','⌫'))):
            for col,k in enumerate(keys):
                tk.Button(keypad,text=k,command=lambda v=k:key(v),bg=WHITE,fg=NAVY,font=('Segoe UI',15,'bold'),height=2,relief='solid',bd=1).grid(row=rowidx,column=col,sticky='nsew',padx=2,pady=2)
        for i in range(3):keypad.grid_columnconfigure(i,weight=1)
        tk.Button(right,text='.',command=lambda:key('.'),bg=WHITE,fg=NAVY,font=('Segoe UI',16,'bold'),height=2).pack(fill='x',padx=2,pady=3)
        previewbox=tk.Frame(left,bg=WHITE,highlightbackground='#cbd5df',highlightthickness=1,padx=14,pady=10);previewbox.pack(fill='x',pady=(7,3))
        tk.Label(previewbox,text='LIVE DISCOUNT PREVIEW',bg=WHITE,fg=NAVY,font=('Segoe UI',10,'bold')).pack(anchor='w')
        detail=tk.Label(previewbox,text='',bg=WHITE,fg=NAVY,anchor='w',justify='left',font=('Consolas',12),pady=6);detail.pack(fill='x')
        def calc():
            index=self.selected_line() if scope.get()=='Selected Item' else None
            if scope.get()=='Selected Item' and index is None:raise ValueError('Select a sale line first.')
            x=self.cart[index] if index is not None else None
            if x is not None and x['qty']<=0:raise ValueError('Refund lines cannot be discounted.')
            base=x['qty']*x['unit'] if x is not None else sum(net(y) for y in self.cart)
            if base<=0:raise ValueError('No eligible amount to discount.')
            try:number=Decimal(value.get().strip())
            except InvalidOperation:raise ValueError('Enter a valid discount amount.')
            if not number.is_finite() or number<0:raise ValueError('Enter a non-negative discount.')
            if kind.get().startswith('Percentage'):
                if number>100:raise ValueError('Percentage must be between 0 and 100.')
                amount=int((Decimal(base)*number/100).quantize(Decimal('1'),rounding=ROUND_HALF_UP))
            else:amount=money_to_cents(value.get())
            if amount>base:raise ValueError('Discount exceeds the eligible amount.')
            if x is not None:
                remaining=sum(net(y) for y in self.cart)-int(x.get('line_discount',0))+amount
                if self.discount>remaining:raise ValueError('Reduce the whole-sale discount first.')
            return index,amount,base
        def preview(*_):
            try:
                _,amount,base=calc()
                detail.config(text=f'Original       ${base/100:>10,.2f}\nDiscount      -${amount/100:>10,.2f}\n────────────────────────\nAfter discount ${((base-amount)/100):>10,.2f}')
                error.config(text='')
            except ValueError as exc:detail.config(text='Enter a valid discount to preview.');error.config(text=str(exc))
        def close():w.destroy()
        def save():
            try:
                index,amount,_=calc()
                if index is None:self.discount=amount
                else:self.cart[index]['line_discount']=amount
                self.refresh_cart();close()
            except ValueError as exc:error.config(text=str(exc))
        def remove():
            index=self.selected_line() if scope.get()=='Selected Item' else None
            if scope.get()=='Selected Item' and index is None:error.config(text='Select a sale line first.');return
            if index is None:self.discount=0
            else:self.cart[index]['line_discount']=0
            self.refresh_cart();close()
        for var in (scope,kind,value):var.trace_add('write',preview)
        footer=tk.Frame(w,bg=BG,padx=18,pady=12);footer.pack(side='bottom',fill='x')
        for label,command,color,fg in [('APPLY DISCOUNT',save,CYAN,WHITE),('REMOVE DISCOUNT',remove,WHITE,NAVY),('CANCEL',close,'#dfe6ed',NAVY)]:
            tk.Button(footer,text=label,command=command,bg=color,fg=fg,font=('Segoe UI',11,'bold'),height=2,relief='solid',bd=1).pack(side='left',fill='x',expand=True,padx=4)
        w.bind('<Escape>',lambda e:close())
        w.bind('<Destroy>',lambda e:self.root.after_idle(lambda:self.code.focus_set() if self.code.winfo_exists() else None) if e.widget is w else None,add='+')
        preview();entry.focus_set();entry.selection_range(0,'end')
    cls.pos=pos;cls.info=info;cls.set_discount=set_discount
