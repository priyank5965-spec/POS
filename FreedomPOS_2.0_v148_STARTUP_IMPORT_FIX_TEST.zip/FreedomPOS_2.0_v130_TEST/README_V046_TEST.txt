FREEDOM POS 2.0 — v0.46 — TEST ONLY

Register layout changes:
- Entire right pane is a uniform button matrix; no subtotal/footer in the right pane.
- Change, Total Discount and Sub Total are shown in a 74px summary panel below the left sales grid.
- Five Quick Cash buttons ($5, $10, $20, $50, $100) open the existing test cash tender window with the selected amount prefilled. They do not complete a sale automatically.
- Existing barcode scanning, cart actions, discounts, and recall callbacks retained.
- Register layout editor settings for this new grid are stored in register_layout_v046.json to prevent old button-size settings from overlapping the new uniform default.
- Layout editor still permits custom resizing when deliberately selected; use Restore Default for uniform sizes.

Testing:
- Python compilation passed.
- Tkinter virtual-display smoke test passed: 29 uniform buttons, non-overlapping positions, summary under sale grid, cash presets present, no automatic sale on opening cash tender.
- Windows real scanner, touchscreen, cash drawer, and full checkout/regression tests have NOT been performed. Do not use for live transactions.

Keep your v0.45 package as a backup and extract v0.46 to a new folder.
