Freedom POS v0.87 — TEST ONLY

Quantity: type 5* and press Enter, then scan barcode; or type 5*BARCODE and Enter. 5* then click product button is supported. Quantity capped at 9999. Product stock checks retained.
Cash: from empty SCAN field press Enter to open tender; press Enter again with blank tender for exact cash. Type 20.0 and Enter for $20 cash, then confirm TEST payment. Escape cancels.
Grid: Up/Down selects rows when grid has focus; Enter opens line editor.
E-PAY: live transactions remain disabled.
NOTE: Department multiplier integration and keyboard focus across all register modes need additional Windows testing. No real EFTPOS.
