"""Register v0.34: single-click column editing and discounts. TEST ONLY."""
import tkinter as tk
from tkinter import ttk, messagebox
from decimal import Decimal, InvalidOperation, ROUND_HALF_UP

def money_to_cents(s):
    try:
        d=Decimal(str(s).strip())
        if not d.is_finite() or d<0: raise ValueError()
        return int((d*100).quantize(Decimal('1'),rounding=ROUND_HALF_UP))
    except (InvalidOperation,ValueError):raise ValueError('Enter a valid non-negative amount.')

def line_discount(x):
    return int(x.get('line_discount',0))

def gross(x):return x['qty']*x['unit']
def net(x):return gross(x)-line_discount(x)

def install(cls):
    old_pos=cls.pos
    def pos(self):
        old_pos(self)
        self.root.title('Freedom POS 2.0 — Delete Key Fix v0.36 — TEST ONLY')
        self.sale_tree.unbind('<Double-1>')
        self._armed_grid_row = None
        self.sale_tree.bind('<ButtonRelease-1>',lambda event:click_cell(self,event))
        # Bind on the register root because barcode focus is intentionally restored after row selection.
        # The handler checks that the register is visible and no modal dialog owns input.
        self.root.bind('<Delete>',lambda event:delete_selected_from_keyboard(self,event))
    def total(self):return sum(net(x) for x in self.cart)-self.discount
    def refresh_cart(self):
        tree=getattr(self,'sale_tree',None)
        if tree is None or not tree.winfo_exists():return
        previous=tree.selection()
        tree.delete(*tree.get_children())
        for i,x in enumerate(self.cart):
            d=line_discount(x)
            tree.insert('','end',iid=str(i),values=(x['qty'],x['description'],f"${x['unit']/100:,.2f}",f"${d/100:,.2f}",f"${net(x)/100:,.2f}"),tags=('refund',) if x['qty']<0 else ())
        if previous and previous[0] in tree.get_children():tree.selection_set(previous[0])
        self.total_label.config(text=f'Sub Total  ${self.total()/100:,.2f}')
        self.discount_label.config(text=f'Total Discount  ${(self.discount+sum(line_discount(x) for x in self.cart))/100:,.2f}')
        if hasattr(self,'customer_label') and self.customer_label.winfo_exists():
            row=self.db.execute('SELECT name FROM customers WHERE id=?',(self.customer,)).fetchone() if self.customer else None
            self.customer_label.config(text=f"Customer: {row['name'] if row else 'Walk-in'}   |   OFFLINE TEST MODE — No real EFTPOS processing")
    def edit_line(self):
        i=self.selected_line()
        if i is None:return self.warn('Select an item first.')
        edit(self,i,'Qty')
    def set_discount(self):
        if not self.cart:return self.warn('Add an item first.')
        if self.refund_origin:return self.warn('Discount editing is disabled for refund transactions.')
        popup(self,'Discount',None)
    cls.pos=pos;cls.total=total;cls.refresh_cart=refresh_cart;cls.edit_line=edit_line;cls.set_discount=set_discount

def delete_selected_from_keyboard(self,event):
    tree=getattr(self,'sale_tree',None)
    code=getattr(self,'code',None)
    if tree is None or code is None or not tree.winfo_exists() or not tree.winfo_ismapped():
        return None
    # Do not intercept Delete in stock search, product forms, or other text fields.
    # The barcode field is the one entry where Delete means remove selected sale line.
    focused=self.root.focus_get()
    if focused not in (code,tree,self.root):
        return None
    # Modal forms must retain normal Delete behaviour.
    grabbed=self.root.grab_current()
    if grabbed is not None and grabbed is not self.root:
        return None
    if not tree.selection():
        return None
    self.void()
    return 'break'

def focus_barcode(self):
    try:
        if self.code.winfo_exists():
            self.root.after_idle(lambda: self.code.focus_set() if self.code.winfo_exists() else None)
    except Exception:pass

def click_cell(self,event):
    tree=self.sale_tree
    row=tree.identify_row(event.y)
    region=tree.identify('region',event.x,event.y)
    if not row or region not in ('cell','tree'):
        self._armed_grid_row=None
        return
    col=tree.identify_column(event.x)
    previous=getattr(self,'_armed_grid_row',None)
    tree.selection_set(row)
    tree.focus(row)
    self._armed_grid_row=row
    if previous!=row:
        # First tap selects the line. A second tap on an editable cell opens its editor.
        return
    field={'#2':'Qty','#3':'Description','#4':'Unit Price','#5':'Unit Discount'}.get(col)
    if field:edit(self,int(row),field)

def edit(self,i,field):
    if i>=len(self.cart):return
    if self.refund_origin:return self.warn('Editing linked refunds is disabled in this test build.')
    x=self.cart[i]
    if x.get('original_line'):
        return self.warn('Linked refund quantities must be changed through the original-sale refund workflow.')
    popup(self,field,i)

def popup(self,field,i):
    x=self.cart[i] if i is not None else None
    w=tk.Toplevel(self.root);w.bind('<Destroy>',lambda e:focus_barcode(self) if e.widget is w else None,add='+');w.title('Freedom POS — '+('Sale Discount' if i is None else field));w.geometry('510x340' if field in ('Description','Unit Price','Discount') else '490x275');w.minsize(450,260);w.transient(self.root);w.grab_set()
    frame=tk.Frame(w,padx=22,pady=12);frame.pack(fill='both',expand=True)
    tk.Label(frame,text=('Sale Discount' if i is None else 'Edit '+field),font=('Segoe UI',17,'bold')).pack(anchor='w',pady=(0,8))
    if x:tk.Label(frame,text=x['description'],anchor='w',wraplength=430).pack(fill='x')
    if field=='Qty':tk.Label(frame,text='Negative quantity = TEST return line only. Use Previous Sales for a linked refund.\nUnlinked returns cannot be finalised or sent to Linkly.',fg='#a13d30',wraplength=440,justify='left').pack(anchor='w')
    kind=tk.StringVar(value='Temporary (this sale only)')
    if field in ('Description','Unit Price'):
        ttk.Combobox(frame,textvariable=kind,values=('Temporary (this sale only)','Permanent (stock master)'),state='readonly').pack(fill='x',pady=7)
    mode=tk.StringVar(value='Fixed amount ($)')
    if field in ('Discount','Unit Discount'):
        ttk.Combobox(frame,textvariable=mode,values=('Fixed amount ($)','Percentage (%)'),state='readonly').pack(fill='x',pady=7)
    initial=(str(x['qty']) if field=='Qty' else x['description'] if field=='Description' else f"{x['unit']/100:.2f}" if field=='Unit Price' else f"{line_discount(x)/100:.2f}" if x else f"{self.discount/100:.2f}")
    value=tk.StringVar(value=initial)
    entry=ttk.Entry(frame,textvariable=value,font=('Segoe UI',14));entry.pack(fill='x',pady=9)
    error=tk.Label(frame,text='',fg='#b3261e',anchor='w',wraplength=440);error.pack(fill='x')
    def save():
        try:
            v=value.get().strip()
            if field=='Qty':
                try:q=int(v)
                except ValueError:raise ValueError('Enter a whole-number quantity from -9999 to -1 or 1 to 9999.')
                if not -9999<=q<=9999 or q==0:raise ValueError('Quantity must be -9999 to -1 or 1 to 9999; zero is not allowed.')
                if x.get('original_line'):
                    raise ValueError('Use Previous Sales to edit linked refund quantities.')
                if q<0 and (x.get('kind')!='PRODUCT' or x.get('product_id') is None):
                    raise ValueError('Negative grid quantities are available for stock products only.')
                if q<0 and line_discount(x):
                    raise ValueError('Remove the line discount before entering a negative quantity.')
                if q>0 and x['product_id'] is not None:
                    p=self.db.execute('SELECT stock FROM products WHERE id=?',(x['product_id'],)).fetchone()
                    other=sum(z['qty'] for j,z in enumerate(self.cart) if j!=i and z['product_id']==x['product_id'] and z['qty']>0)
                    if p is None or p['stock']<q+other:raise ValueError('Not enough stock for the requested quantity.')
                x['qty']=q
                if q<0:x['training_return_unlinked']=True
                else:x.pop('training_return_unlinked',None)
            elif field=='Description':
                if not v:raise ValueError('Description cannot be empty.')
                if kind.get().startswith('Permanent'):
                    permanent(self,x,'name',v)
                x['description']=v
            elif field=='Unit Price':
                cents=money_to_cents(v)
                if cents>100000000:raise ValueError('Price is too large.')
                if cents*x['qty']<line_discount(x):raise ValueError('Remove or reduce the line discount first.')
                if kind.get().startswith('Permanent'):
                    permanent(self,x,'price',cents)
                x['unit']=cents
            elif field in ('Discount','Unit Discount'):
                number=Decimal(v)
                if not number.is_finite() or number<0:raise ValueError('Enter a valid discount.')
                base=gross(x) if x else sum(net(y) for y in self.cart)
                if base<=0:raise ValueError('No eligible positive sale amount.')
                if mode.get().startswith('Percentage'):
                    if number>100:raise ValueError('Percentage must be between 0 and 100.')
                    amount=int((Decimal(base)*number/100).quantize(Decimal('1'),rounding=ROUND_HALF_UP))
                else:amount=money_to_cents(v)
                if amount>base:raise ValueError('Discount exceeds the available amount.')
                if x:
                    if self.discount>sum(net(y) for y in self.cart)-line_discount(x)+amount:raise ValueError('Reduce the sale discount first.')
                    x['line_discount']=amount
                else:self.discount=amount
            self.refresh_cart();w.destroy();focus_barcode(self)
        except (ValueError,InvalidOperation) as e:error.config(text=str(e))
        except Exception as e:error.config(text='Unable to save: '+str(e))
    buttons=tk.Frame(frame);buttons.pack(fill='x',side='bottom',pady=8)
    tk.Button(buttons,text='SAVE',command=save,bg='#d9f0df',font=('Segoe UI',11,'bold'),height=2).pack(side='left',fill='x',expand=True,padx=4)
    tk.Button(buttons,text='CANCEL',command=w.destroy,height=2).pack(side='left',fill='x',expand=True,padx=4)
    entry.focus_set();entry.selection_range(0,'end')

def permanent(self,x,column,new_value):
    if x.get('product_id') is None:raise ValueError('This line has no stock master product.')
    # PIN authentication is disabled in the current test package; do not allow
    # unauthenticated writes to the stock master.
    raise ValueError('Permanent changes require manager authentication. Use Temporary for now; manager authorisation is not enabled in this test build.')
