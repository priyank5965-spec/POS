"""Freedom POS receipt preview v0.52 (offline/test only)."""
import os
import shutil
import tempfile
import tkinter as tk
from tkinter import ttk, filedialog, messagebox
from reportlab.pdfgen import canvas
from reportlab.lib.pagesizes import A4
from reportlab.lib.units import mm
from reportlab.graphics.barcode import code128
from receipt_business_v054 import load_business
from linkly_receipt_v119 import training_receipt_lines


def _money(cents):
    return f'${int(cents) / 100:,.2f}'


def build_pdf(db, sale_id, paper, path):
    if paper not in ('80mm', 'A4'):
        raise ValueError('Only 80mm and A4 are supported')
    sale = db.execute('SELECT * FROM sales WHERE id=?', (sale_id,)).fetchone()
    if sale is None:
        raise ValueError('Receipt not found')
    lines = db.execute('SELECT * FROM lines WHERE sale_id=? ORDER BY id', (sale_id,)).fetchall()
    payments = db.execute('SELECT method,amount FROM payments WHERE sale_id=? ORDER BY id', (sale_id,)).fetchall()
    settings = load_business()
    thermal = paper == '80mm'
    width = 80 * mm if thermal else A4[0]
    # Dynamic thermal paper length; enough for long names and payments.
    height = max(170 * mm, (145 + len(lines) * 15 + len(payments) * 7 + len(training_receipt_lines(db,sale_id)) * 6) * mm) if thermal else A4[1]
    c = canvas.Canvas(str(path), pagesize=(width, height))
    left = 5 * mm if thermal else 15 * mm
    right = width - left
    y = height - (9 * mm if thermal else 16 * mm)
    body = 8.6 if thermal else 10
    line_height = 12 if thermal else 16

    def txt(s, size=None, bold=False, align='left', x=None):
        nonlocal y
        c.setFont('Helvetica-Bold' if bold else 'Helvetica', size or body)
        s = str(s).encode('latin-1', 'replace').decode('latin-1')
        px = (left if align == 'left' else right if align == 'right' else width / 2) if x is None else x
        {'left': c.drawString, 'right': c.drawRightString, 'center': c.drawCentredString}[align](px, y, s)
        y -= line_height

    def rule():
        nonlocal y
        c.setLineWidth(.6)
        c.line(left, y + 4, right, y + 4)
        y -= 8

    # Business identity and optional logo are user-configurable TEST defaults.
    logo = settings.get('logo', '')
    if logo and os.path.isfile(logo):
        try:
            from reportlab.lib.utils import ImageReader
            from PIL import Image
            with Image.open(logo) as im:
                iw, ih = im.size
            max_w, max_h = (48*mm, 20*mm) if thermal else (60*mm, 24*mm)
            scale = min(max_w/iw, max_h/ih)
            w, h = iw*scale, ih*scale
            c.drawImage(ImageReader(logo), (width-w)/2, y-h+8, width=w, height=h, mask='auto')
            y -= h+9
        except Exception:
            pass
    txt(settings['business_name'], 12 if thermal else 15, True, 'center')
    if settings.get('trading_name') and settings['trading_name'] != settings['business_name']:
        txt(settings['trading_name'], 9, False, 'center')
    for key in ('abn','address','phone','email'):
        if settings.get(key):
            value = ('ABN: ' if key=='abn' else '') + settings[key]
            txt(value[:42 if thermal else 100], 7.5 if thermal else 9, False, 'center')
    y -= 5
    txt('Tax Invoice / Receipt', 10 if thermal else 14, True, 'center')
    txt('TEST ONLY - NOT A VALID TAX INVOICE', 7 if thermal else 9, True, 'center')
    y -= 9
    txt(f'Receipt No: {sale_id}', bold=True)
    txt(f'Date: {sale["created"]}')
    txt(f'Payment method: {sale["payment"]}')
    rule()
    if not thermal:
        txt('Description', bold=True)
    for item in lines:
        desc = str(item['description']).encode('latin-1', 'replace').decode('latin-1')
        max_chars = 29 if thermal else 75
        desc = desc[:max_chars]
        qty = int(item['qty'])
        amount = qty * int(item['unit'])
        if thermal:
            txt(f'{qty} x {desc}', bold=True)
            txt(f'   {_money(item["unit"])} each')
            # put amount on same line's right side without overlapping label
            y += line_height
            c.setFont('Helvetica-Bold', body)
            c.drawRightString(right, y, _money(amount))
            y -= line_height
        else:
            txt(desc)
            y += line_height
            c.setFont('Helvetica', body)
            c.drawRightString(right - 90, y, f'Qty {qty}')
            c.drawRightString(right, y, _money(amount))
            y -= line_height
    rule()
    if sale['discount']:
        txt('Discount')
        y += line_height
        c.drawRightString(right, y, _money(sale['discount']))
        y -= line_height
    txt('TOTAL', 12 if thermal else 14, True)
    y += line_height
    c.setFont('Helvetica-Bold', 12 if thermal else 14)
    c.drawRightString(right, y, _money(sale['total']))
    y -= line_height
    rule()
    for payment in payments:
        txt(f'{payment["method"]}')
        y += line_height
        c.setFont('Helvetica', body)
        c.drawRightString(right, y, _money(payment['amount']))
        y -= line_height
    eft_lines=training_receipt_lines(db,sale_id)
    if eft_lines:
        rule()
        for detail in eft_lines:txt(detail, 7 if thermal else 9)
    y -= 8
    txt('GST breakdown: not recorded in this test build', 7 if thermal else 9)
    if not thermal and any(settings.get(k) for k in ('bank_name','bsb','account_number','account_name')):
        y -= 10
        rule()
        txt('Bank payment details (for account payments)', bold=True)
        for label, key in [('Bank', 'bank_name'), ('Account name', 'account_name'), ('BSB', 'bsb'), ('Account number', 'account_number')]:
            if settings.get(key):txt(f'{label}: {settings[key]}')
    y -= 15
    # Code128 supports the @ prefix; scanner uses the exact value printed here.
    barcode_value = f'@{sale_id:010d}'
    bc = code128.Code128(barcode_value, barHeight=11*mm if thermal else 14*mm, barWidth=.28*mm if thermal else .42*mm)
    bx = (width-bc.width)/2
    if bx >= left-3:
        bc.drawOn(c, bx, y-(11*mm if thermal else 14*mm))
        y -= (15*mm if thermal else 18*mm)
        txt(f'{sale_id:010d}', 9, True, 'center')
    for footer_line in settings.get('receipt_footer','').splitlines():
        if footer_line.strip():
            txt(footer_line.strip()[:38 if thermal else 100], 8 if thermal else 10, align='center')
    txt('TEST ONLY', align='center')
    c.save()
    return path


def preview_receipt(app, sale_id):
    window = tk.Toplevel(app.root)
    window.title(f'Receipt #{sale_id} — Preview — TEST ONLY')
    # Fit on the available screen rather than hiding the footer below the taskbar.
    screen_w, screen_h = window.winfo_screenwidth(), window.winfo_screenheight()
    width = min(900, max(500, screen_w - 100))
    height = min(780, max(420, screen_h - 140))
    window.geometry(f'{width}x{height}')
    window.minsize(min(500, width), min(420, height))
    window.configure(bg='white')
    toolbar = tk.Frame(window, bg='white')
    toolbar.pack(fill='x')
    tk.Label(toolbar, text='RECEIPT PREVIEW', bg='white', fg='#111111', font=('Segoe UI', 15, 'bold')).pack(side='left', padx=12, pady=12)
    tk.Label(toolbar, text='Paper:', bg='white', fg='#111111').pack(side='left', padx=8)
    paper = tk.StringVar(value='80mm')
    selector = ttk.Combobox(toolbar, textvariable=paper, values=['80mm', 'A4'], state='readonly', width=9)
    selector.pack(side='left', padx=4)
    tk.Label(toolbar, text='Scroll to view full receipt', bg='white', fg='#111111').pack(side='right', padx=15)

    # Pack the footer BEFORE the expanding preview. Tk reserves space for it
    # even when the receipt window is resized smaller.
    actions = tk.Frame(window, bg='white')
    actions.pack(side='bottom', fill='x', padx=8, pady=(5, 8))
    status = tk.Label(window, text='', bg='white', fg='#111111', font=('Segoe UI', 10))
    status.pack(side='bottom', fill='x')
    viewport = tk.Frame(window, bg='#e8edf2')
    viewport.pack(side='top', fill='both', expand=True, padx=8, pady=6)
    scroll = tk.Scrollbar(viewport, orient='vertical')
    scroll.pack(side='right', fill='y')
    display = tk.Canvas(viewport, bg='#e8edf2', highlightthickness=0, yscrollcommand=scroll.set)
    display.pack(side='left', fill='both', expand=True)
    scroll.configure(command=display.yview)
    state = {'pdf': None, 'image': None, 'doc': None, 'render_error': None}

    def refresh(event=None):
        old = state['pdf']
        try:
            fd, path = tempfile.mkstemp(prefix='freedom_receipt_', suffix='.pdf')
            os.close(fd)
            build_pdf(app.db, sale_id, paper.get(), path)
            state['pdf'] = path
            if old:
                try: os.unlink(old)
                except OSError: pass
            display.delete('all')
            display.yview_moveto(0)
            try:
                import fitz
                from PIL import Image, ImageTk
                with fitz.open(path) as doc:
                    page = doc[0]
                    # A4 fit to width, thermal at legible ~2x screen scale.
                    available = max(350, display.winfo_width() - 35)
                    scale = min(2.2, available / page.rect.width) if paper.get() == 'A4' else 2.0
                    pix = page.get_pixmap(matrix=fitz.Matrix(scale, scale), alpha=False)
                    img = Image.frombytes('RGB', (pix.width, pix.height), pix.samples)
                photo = ImageTk.PhotoImage(img)
                state['image'] = photo
                display.create_image(max(10, (display.winfo_width()-photo.width())//2), 10, image=photo, anchor='nw', tags='page')
                display.configure(scrollregion=(0, 0, max(display.winfo_width(), photo.width()+20), photo.height()+20))
                state['render_error'] = None
                status.configure(text='Receipt displayed below. Save PDF or Print when ready.')
            except (ImportError, Exception) as exc:
                state['render_error'] = str(exc)
                display.create_text(30, 60, anchor='nw', width=540, font=('Segoe UI', 12), fill='#12324a',
                                    text='Inline preview requires PyMuPDF and Pillow. Run INSTALL_RECEIPT_PREVIEW.bat, then reopen this window.\n\n' + str(exc))
                status.configure(text='PDF created, but inline rendering is unavailable.')
        except Exception as exc:
            messagebox.showerror('Receipt Error', str(exc), parent=window)

    def save():
        if not state['pdf']: return
        destination = filedialog.asksaveasfilename(parent=window, defaultextension='.pdf',
                    filetypes=[('PDF files', '*.pdf')], initialfile=f'Receipt_{sale_id}_{paper.get()}.pdf')
        if destination: shutil.copy2(state['pdf'], destination)

    def open_pdf():
        if os.name == 'nt' and state['pdf']:
            os.startfile(state['pdf'])
        else:
            messagebox.showinfo('PDF Viewer', 'Save PDF to open it in your preferred PDF viewer.', parent=window)

    def print_pdf():
        if os.name != 'nt':
            return messagebox.showinfo('Print', 'Printing must be tested on Windows.', parent=window)
        open_pdf()
        messagebox.showinfo('Print', 'Press Ctrl+P in the PDF viewer to select your printer and paper settings.', parent=window)

    def cleanup():
        if state['pdf']:
            try: os.unlink(state['pdf'])
            except OSError: pass
        window.destroy()
    for title, fn in [('SAVE PDF', save), ('OPEN PDF', open_pdf), ('PRINT', print_pdf), ('CLOSE', cleanup)]:
        tk.Button(actions, text=title, command=fn, bg='#52bfca' if title=='SAVE PDF' else '#edf3f6',
                  font=('Segoe UI', 10, 'bold'), padx=8, pady=7).pack(side='left', padx=3)
    window.protocol('WM_DELETE_WINDOW', cleanup)
    selector.bind('<<ComboboxSelected>>', refresh)
    display.bind('<MouseWheel>', lambda e: display.yview_scroll(-int(e.delta/120), 'units'))
    window.after(250, refresh)
    # Centre the window without allowing its bottom edge to fall off-screen.
    window.update_idletasks()
    window.geometry(f'{width}x{height}+{max(0,(screen_w-width)//2)}+{max(0,(screen_h-height)//2)}')
