Freedom POS v0.108 — INVOICE RELIABILITY TEST ONLY

Fixes:
- Missing invoice notes field (KeyError prevented Save Draft and Finalise).
- Invoice notes visible and persisted.
- Supplier total restored on draft reopen.
- Finalisation confirmation shows quantities, freight-inclusive total and difference.
- Existing retail prices are NOT automatically overwritten when receiving stock.
- Clear date validation errors; unexpected errors logged to receiving_error.log.
- Spreadsheet numeric-only totals rows skipped.

Still requires testing on your Windows installation and actual data.
Important limitations: PDF/DDO/DD2 not fully supported; no new supplier-product database migration; new stock wizard still requires improvements.
Do not use with production/live data. Back up your existing test database first.
