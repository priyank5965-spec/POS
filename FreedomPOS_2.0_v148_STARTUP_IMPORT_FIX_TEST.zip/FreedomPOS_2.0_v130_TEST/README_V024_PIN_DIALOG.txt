v0.24: PIN setup window enlarged and centred so keypad OK/CLEAR/0 are visible; cashier name receives initial focus; Enter advances to PIN. Test with Windows scaling. Test build only.
