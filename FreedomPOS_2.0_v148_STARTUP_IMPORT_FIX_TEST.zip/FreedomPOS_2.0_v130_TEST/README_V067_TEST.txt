Freedom POS 2.0 v0.67 — TEST ONLY

New: Department Buttons & Shortcuts business-wide settings, four-column in-register department/category/product navigation, optional legacy popup per department, Back/Home/Cash/EFTPOS persistent buttons, direct department keyboard shortcuts with collision checking at department-settings save.

Open Settings & Tools > DEPARTMENT BUTTONS & SHORTCUTS to choose inside/popup and shortcut per department. In the Register, DEPARTMENTS opens the four-column browser. Departments and categories must already exist in Products & Stock.

LIMITATIONS: This is a staged implementation. Popup-mode opens the existing department selector, rather than automatically selecting the specified department. Dedicated group/submenu creation beyond existing categories, direct department actions inside the main Keyboard Shortcut Manager, designer custom images for submenu tiles, and reverse collision checks when editing old shortcuts are NOT implemented. Full Windows visual/functional regression testing is not completed. No live EFTPOS.

Back up the previous version and test with sample products and transactions only.
