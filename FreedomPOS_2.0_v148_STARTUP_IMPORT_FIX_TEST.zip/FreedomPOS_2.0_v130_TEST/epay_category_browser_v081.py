"""Offline e-pay category browser; selection stages unissued items in sale grid."""
import tkinter as tk
from tkinter import ttk,messagebox
from decimal import Decimal,InvalidOperation
from epay_catalog_v077 import search

def _price(row):
    try:
        value=Decimal(str(row.get('face_value') or ''))
        if not value.is_finite() or value<=0:return None
        # Catalogue face values are displayed as dollars; no surcharge is inferred.
        return int((value*100).quantize(Decimal('1')))
    except (InvalidOperation,ValueError):return None

def install(cls):
    old_window=cls.epay_window
    old_checkout=cls.checkout
    def checkout(self,*args,**kwargs):
        if any(line.get('kind')=='EPAY_UNISSUED' for line in self.cart):
            messagebox.showwarning('E-PAY NOT ACTIVATED','This sale contains an e-pay product that has NOT been issued or activated.\n\nRemove the e-pay line before checkout. Live e-pay sales remain disabled.',parent=self.root)
            return False
        return old_checkout(self,*args,**kwargs)
    def browser(self):
        existing=getattr(self,'_epay_category_browser',None)
        if existing and existing.winfo_exists():existing.lift();existing.focus_force();return
        w=tk.Toplevel(self.root);self._epay_category_browser=w
        w.title('E-PAY — Select Category / Provider / Product');w.geometry('920x680');w.minsize(650,480)
        top=tk.Frame(w,bg='white');top.pack(fill='x')
        tk.Label(top,text='E-PAY PRODUCT SELECTION',bg='white',fg='#111111',font=('Segoe UI',18,'bold'),pady=15).pack(anchor='w',padx=20)
        tk.Label(w,text='OFFLINE PREVIEW — Products can be added to the selling grid but cannot be checked out until e-pay activation is verified.',fg='#ad321f',wraplength=840,font=('Segoe UI',10,'bold')).pack(anchor='w',padx=18,pady=9)
        bar=ttk.Frame(w,padding=(15,4));bar.pack(fill='x')
        title=tk.StringVar(value='Categories');ttk.Label(bar,textvariable=title,font=('Segoe UI',14,'bold')).pack(side='left',padx=8)
        footer=ttk.Frame(w,padding=12);footer.pack(side='bottom',fill='x')
        body=tk.Frame(w);body.pack(fill='both',expand=True,padx=15,pady=8)
        canvas=tk.Canvas(body,highlightthickness=0);scroll=ttk.Scrollbar(body,orient='vertical',command=canvas.yview)
        canvas.configure(yscrollcommand=scroll.set);canvas.pack(side='left',fill='both',expand=True);scroll.pack(side='right',fill='y')
        inner=tk.Frame(canvas);canvas.create_window((0,0),window=inner,anchor='nw',tags='content')
        inner.bind('<Configure>',lambda e:canvas.configure(scrollregion=canvas.bbox('all')))
        canvas.bind('<Configure>',lambda e:canvas.itemconfigure('content',width=e.width))
        rows=search('',limit=10000)
        state={'category':None,'group':None}
        def draw():
            for child in inner.winfo_children():child.destroy()
            canvas.yview_moveto(0)
            category=state['category'];group=state['group']
            if category is None:
                title.set('Choose Category')
                options=[(v,v) for v in sorted({(r['category'] or 'Other').strip() for r in rows},key=str.casefold)]
            elif group is None:
                title.set('Category: '+category+'  →  Choose Provider / Group')
                options=[(v,v) for v in sorted({(r['group_name'] or 'Other').strip() for r in rows if (r['category'] or 'Other').strip()==category},key=str.casefold)]
            else:
                title.set(category+'  →  '+group+'  →  Choose Product')
                products=[r for r in rows if (r['category'] or 'Other').strip()==category and (r['group_name'] or 'Other').strip()==group]
                options=[(r['title']+('  —  $'+format(_price(r)/100,'.2f') if _price(r) is not None else '  —  PRICE NOT AVAILABLE'),r) for r in products]
            if not options:ttk.Label(inner,text='No products available. Import your e-pay CSV from the Products tab.',font=('Segoe UI',12)).pack(pady=20)
            for i,(label,value) in enumerate(options):
                def choose(v=value):
                    if category is None:state['category']=v;draw()
                    elif group is None:state['group']=v;draw()
                    else:
                        price=_price(v)
                        if price is None:
                            messagebox.showwarning('Price required','This product has no valid fixed face value. Variable-value products require verified pricing and cannot be staged.',parent=w);return
                        if not messagebox.askyesno('Add e-pay product',f"{v['title']}\nFace value: ${price/100:.2f}\n\nAdd as NOT ACTIVATED to selling grid?\nCheckout will remain blocked.",parent=w):return
                        self.cart.append(dict(product_id=None,description='E-PAY NOT ACTIVATED — '+v['title'],qty=1,unit=price,kind='EPAY_UNISSUED',epay_product_code=v['product_code'],original_line=None))
                        self.refresh_cart();w.destroy()
                btn=tk.Button(inner,text=label,command=choose,anchor='w',font=('Segoe UI',12,'bold'),bg='#e3edf3',fg='#111111',activebackground='#b7d8e9',relief='raised',padx=18,pady=14,wraplength=360)
                btn.grid(row=i//3,column=i%3,sticky='nsew',padx=6,pady=6)
            for c in range(3):inner.grid_columnconfigure(c,weight=1,uniform='epay')
            back.configure(state='normal' if category is not None else 'disabled')
        def go_back():
            if state['group'] is not None:state['group']=None
            elif state['category'] is not None:state['category']=None
            draw()
        back=ttk.Button(footer,text='← Back',command=go_back);back.pack(side='left',padx=5)
        ttk.Button(footer,text='Categories',command=lambda:(state.update(category=None,group=None),draw())).pack(side='left',padx=5)
        ttk.Button(footer,text='Manage Catalogue / Diagnostics',command=lambda:epay_management_window(self)).pack(side='right',padx=5)
        ttk.Button(footer,text='Close',command=w.destroy).pack(side='right',padx=5)
        draw()
    def epay_window(self):
        # Register E-PAY must open the category browser, not the maintenance tabs.
        return browser(self)
    def epay_management_window(self):
        # Existing offline catalogue/import and diagnostics remain available.
        return old_window(self)
    cls.epay_category_browser=browser
    cls.epay_window=epay_window
    cls.epay_management_window=epay_management_window
    cls.checkout=checkout
