Freedom POS 2.0 v0.16 — register keyboard shortcut

From the Point of Sale register, press Shift+/ (question mark '?') to open the full Find Stock / Stock Screen. Search has keyboard focus when it opens. The shortcut is not active on other main screens and will not reopen stock search while a separate dialog has focus.

Note: On keyboard layouts where ? is produced differently, use the key combination that types '?'. This is an offline test build. No Windows keyboard/hardware test was performed.
