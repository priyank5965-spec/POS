"""Safe, read-only e-pay component diagnostics. NEVER loads COM or sends requests."""
import os,sys,struct,platform,datetime
from pathlib import Path
NAMES=('epayREST.dll','epayREST.tlb','epayXML.dll','epayXML.tlb','EPAPICOM.dll','EpayMaintDoc.dll')

def pe_info(path):
    """Read PE header and CLR directory; no executable code is loaded."""
    with open(path,'rb') as f:
        if f.read(2)!=b'MZ':return 'not a PE executable'
        f.seek(0x3c);offset=struct.unpack('<I',f.read(4))[0]
        if offset>8*1024*1024:return 'invalid PE header'
        f.seek(offset)
        if f.read(4)!=b'PE\x00\x00':return 'invalid PE signature'
        machine,sections,_,_,_,optional_size,_=struct.unpack('<HHIIIHH',f.read(20))
        opt=f.read(optional_size)
        if len(opt)<2:return 'invalid optional header'
        magic=struct.unpack_from('<H',opt)[0]
        arch={0x14c:'x86',0x8664:'x64',0xaa64:'ARM64'}.get(machine,hex(machine))
        directory_offset={0x10b:96,0x20b:112}.get(magic)
        managed='unknown'
        if directory_offset is not None and len(opt)>=directory_offset+15*8:
            clr_rva,clr_size=struct.unpack_from('<II',opt,directory_offset+14*8)
            managed='yes' if clr_rva and clr_size else 'no'
        return f'PE architecture: {arch}; .NET/CLR metadata: {managed}; sections: {sections}'

def registered_com():
    if os.name!='nt':return ['Windows COM registration: check on Windows only']
    try:import winreg
    except ImportError:return ['Windows registry API unavailable']
    results=[]
    # Enumeration of existing COM ProgIDs only; no COM activation.
    try:
        with winreg.OpenKey(winreg.HKEY_CLASSES_ROOT,'') as root:
            count=winreg.QueryInfoKey(root)[0]
            for i in range(count):
                try:name=winreg.EnumKey(root,i)
                except OSError:break
                if any(k in name.lower() for k in ('epayrest','epayxml','epapicom','epaymaint')):
                    results.append('COM registry entry: '+name)
    except OSError:results.append('Unable to enumerate COM registrations')
    return results or ['No matching e-pay COM ProgID found (registration may use another name)']

def inspect(folder):
    root=Path(folder)
    lines=['FREEDOM POS — E-PAY READ-ONLY CONNECTION DIAGNOSTIC',
           'Time: '+datetime.datetime.now().astimezone().isoformat(timespec='seconds'),
           'Operating system: '+platform.system()+' '+platform.release(),
           'Python process: '+str(struct.calcsize('P')*8)+'-bit',
           'No DLL loading, COM activation, network traffic or voucher transaction is performed.','']
    if not root.is_dir():return '\n'.join(lines+['ERROR: Select an existing folder.'])
    for name in NAMES:
        file=root/name
        if not file.is_file():lines.append(name+': missing');continue
        try:
            info=pe_info(file) if file.suffix.lower()=='.dll' else 'Type library (not executed)'
            lines.append(name+': present; '+info+'; '+str(file.stat().st_size)+' bytes')
        except (OSError,ValueError,struct.error) as e:lines.append(name+': inspection failed ('+type(e).__name__+')')
    lines+=['',*registered_com(),'','RESULT: COMPONENT INSPECTION ONLY — NOT CONNECTED',
            'A live connection requires documented COM method signatures, terminal authorisation and a supervised test.',
            'Voucher sale, cancellation, refund, printing: DISABLED.']
    return '\n'.join(lines)

def open_diagnostic(parent):
    import tkinter as tk
    from tkinter import ttk,filedialog
    win=tk.Toplevel(parent);win.title('e-pay Connection Test — READ ONLY');win.geometry('920x640');win.minsize(680,430)
    win.transient(parent)
    ttk.Label(win,text='E-PAY COMPONENT CONNECTION TEST',font=('Segoe UI',15,'bold')).pack(anchor='w',padx=15,pady=(15,4))
    ttk.Label(win,text='SAFE TEST ONLY: No DLLs are loaded, no e-pay requests are sent and no transactions are created.',foreground='#9a351f',wraplength=840).pack(anchor='w',padx=15,pady=5)
    bar=ttk.Frame(win,padding=12);bar.pack(fill='x')
    path=tk.StringVar()
    ttk.Entry(bar,textvariable=path).pack(side='left',fill='x',expand=True)
    def browse():
        value=filedialog.askdirectory(parent=win,title='Choose folder containing e-pay DLLs')
        if value:path.set(value)
    ttk.Button(bar,text='Browse DLL Folder',command=browse).pack(side='left',padx=6)
    box=tk.Text(win,wrap='word',font=('Consolas',10));box.pack(fill='both',expand=True,padx=14,pady=8)
    box.insert('1.0','Select the folder containing epayREST.dll and click Inspect Components.\n');box.configure(state='disabled')
    def check():
        output=inspect(path.get());box.configure(state='normal');box.delete('1.0','end');box.insert('1.0',output);box.configure(state='disabled')
    footer=ttk.Frame(win,padding=12);footer.pack(fill='x')
    ttk.Button(footer,text='Inspect Components (Read Only)',command=check).pack(side='left')
    def save():
        target=filedialog.asksaveasfilename(parent=win,title='Save diagnostic report',defaultextension='.txt',filetypes=[('Text','*.txt')])
        if target:Path(target).write_text(box.get('1.0','end-1c'),encoding='utf-8')
    ttk.Button(footer,text='Save Report',command=save).pack(side='left',padx=8)
    ttk.Button(footer,text='Close',command=win.destroy).pack(side='right')
    return win

def install(cls):
    original=cls.epay_window
    def epay_window(self):
        original(self)
        w=getattr(self,'_epay_window',None)
        if not w or not w.winfo_exists():return
        # Add a clearly accessible standalone diagnostic button without modifying old tabs.
        for child in w.winfo_children():
            if child.winfo_class()=='TFrame':
                for widget in child.winfo_children():
                    if getattr(widget,'cget',None):
                        try:
                            if widget.cget('text')=='e-pay Settings':
                                ttk=__import__('tkinter.ttk',fromlist=['Button'])
                                ttk.Button(child,text='Test e-pay Components (Read Only)',command=lambda:open_diagnostic(w)).pack(side='left',padx=8)
                                return
                        except (Exception,):pass
    cls.epay_window=epay_window
