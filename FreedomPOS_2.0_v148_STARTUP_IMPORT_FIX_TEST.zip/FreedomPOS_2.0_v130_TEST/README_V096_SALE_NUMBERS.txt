Freedom POS v0.96 TEST ONLY
Sale numbers are now allocated from a persistent high-water counter, not MAX(sales.id). Deleting the latest sale never reuses its number.
Existing databases initialise the counter from the highest sale still present at first v0.96 launch. If the highest sale was already deleted before upgrading, that historic number cannot be recovered reliably.
Keep the test_data database folder when upgrading if you want numbering to persist.
