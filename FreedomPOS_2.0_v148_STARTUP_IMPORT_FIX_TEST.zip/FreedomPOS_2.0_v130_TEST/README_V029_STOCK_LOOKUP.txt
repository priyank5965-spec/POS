Freedom POS 2.0 v0.29 — TEST ONLY

Stock Lookup now starts at 1160 x 660, minimum 960 x 540, and remains resizable.
Added SKU to Stock Add and Stock Lookup product details, plus SKU search and result column.
Department is shown as a separate product field and in the result grid.
Stock Lookup search is intentionally limited to barcode, description, SKU and alternate barcode for now.
The register screen layout is unchanged.

TESTING: Python compile and database smoke tests performed. GUI layout and live barcode scanning require Windows testing.
Run START_FREEDOM_POS.bat in an extracted folder. Use test data only.
