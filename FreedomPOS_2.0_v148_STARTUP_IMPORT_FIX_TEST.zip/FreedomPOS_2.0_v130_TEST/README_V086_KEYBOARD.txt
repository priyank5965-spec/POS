v0.86 TEST ONLY
Split tender: Up/Down changes payment row; Enter goes to next row; Ctrl+Enter attempts confirmation; Escape closes popup.
Escape also closes the focused Tk popup without closing the main register.
Keyboard integration on Windows remains to be tested. Existing simulation restrictions remain.
