Freedom POS v0.58 TEST ONLY
Theme Designer now opens in a non-maximised, screen-fitted window by default, with the footer visible. Manual maximisation is still possible.
No sale logic changed.
