Freedom POS v0.100 TEST ONLY — invoice arrival work-in-progress.
New barcodes create editable pending invoice lines; double-click barcode/SKU/description/qty/cost/discount/GST/markup/RRP.
New products are inserted into stock master only on finalisation. Drafts preserve pending new lines.
Supplier not found prompts to create supplier on leaving field.
Supplier total is entered manually for reconciliation (prototype assumes cost lines ex-GST; GST treatment still requires supplier-specific mapping).
Markup adds percentage to net wholesale cost, then applies GST for retail.
IMPORTANT: not production-ready; verify with disposable test data.
