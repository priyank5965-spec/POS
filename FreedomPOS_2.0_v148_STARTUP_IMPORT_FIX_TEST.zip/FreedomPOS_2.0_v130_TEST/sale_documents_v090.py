"""Test-only PDFs for individual completed sales. No invented GST/tax details."""
import os, tempfile
from xml.sax.saxutils import escape
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, KeepTogether
from reportlab.lib import colors
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.enums import TA_CENTER, TA_RIGHT
from reportlab.lib.pagesizes import A4
from reportlab.lib.units import mm

def create_sale_pdf(app, sid, fmt='80mm', gift=False):
    """Reuse the exact PDF builder used by Receipt Preview (including Code128 barcode)."""
    if fmt not in ('80mm', 'A4'):
        raise ValueError('Unsupported document format')
    if gift:
        # Preview's shared renderer does not yet support price redaction.
        # Never send a price-bearing PDF marked as a gift receipt.
        raise ValueError('Gift / Exchange price-hiding is not yet supported by the shared PDF renderer. Untick Gift / Exchange to continue.')
    import tempfile
    from receipt_preview_v051 import build_pdf
    folder = os.path.join(tempfile.gettempdir(), 'FreedomPOS_Test_Receipts')
    os.makedirs(folder, exist_ok=True)
    path = os.path.join(folder, f'SALE_{int(sid)}_{fmt}_PREVIEW_MATCH.pdf')
    return build_pdf(app.db, sid, fmt, path)
