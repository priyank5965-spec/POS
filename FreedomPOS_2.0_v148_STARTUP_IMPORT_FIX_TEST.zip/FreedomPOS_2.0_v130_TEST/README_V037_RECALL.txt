v0.37 TEST ONLY: Recall by clicking row, checkbox multi-recall, numbered sale grid. Existing register buttons/layout preserved. Test data only. Do not use for live payments.
