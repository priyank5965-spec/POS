FREEDOM POS 2.0 v0.18 — REGISTER WORKSPACE TEST

Based on the Tower register demonstration, this update adds:
- Five-column sale grid (description, quantity, price, discount placeholder, line total)
- Negative/refund lines in red
- Persistent register toolbar for customer search, refunds, departments, cash tender, account collection
- Searchable customer-selection window
- Department and quick-product selection panel
- Touchscreen numeric keypad for barcode entry
- Cash tender screen with denominations, amount due and change preview
- Existing hold/recall, previous sales, stock shortcut, lottery and tender actions remain.

IMPORTANT LIMITATIONS
- TEST DATA ONLY. EFTPOS, cash, lottery and printing are not real integrations.
- Cash change is previewed before the existing test checkout, but tendered/change values are not persisted in the database.
- Discount column is a placeholder; existing sale-wide discount remains operational.
- Refund opens Previous Sales and uses the existing refund logic; it is not a new audited refund engine.
- Account collection currently calls the legacy sequential-dialog workflow.
- Staff PIN lockout, function-key mapping, configurable department buttons, full account ageing and receipt printer are NOT implemented.
- Do not use for live business transactions.

Launch: freedom_v04/START_FREEDOM_POS.bat
