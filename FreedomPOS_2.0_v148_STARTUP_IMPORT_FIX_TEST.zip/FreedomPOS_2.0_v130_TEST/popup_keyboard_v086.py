"""Keyboard Escape behaviour for Freedom POS popups (v0.86)."""
import tkinter as tk

def install(cls):
    old_init=cls.__init__
    def init(self,*args,**kwargs):
        old_init(self,*args,**kwargs)
        root=self.root
        def escape_popup(event):
            widget=event.widget
            try:
                window=widget.winfo_toplevel()
                if not isinstance(window,tk.Toplevel) or not window.winfo_exists():
                    return None
                # Only the active/focused popup is affected, never the register.
                if root.focus_get() is None:
                    return None
                window.destroy()
                return 'break'
            except tk.TclError:
                return None
        root.bind_all('<Escape>',escape_popup,add='+')
    cls.__init__=init
