Freedom POS 2.0 v0.103 — SUPPLIER INVOICE TEMPLATE ENGINE (TEST ONLY)

Purchasing > Incoming Invoices > Choose folder > select CSV/XLSX > PROCESS SELECTED.
Map fields in the supplier template window; save the template to reuse it later.
Imported rows flow to the existing editable invoice grid; Save Draft and Review & Finalise remain there.

IMPORTANT LIMITATIONS:
- PDF, DDO, DD2, images and AI extraction are NOT yet parsed automatically.
- Imported new products need complete review before posting; supplier charges require manual reconciliation.
- Supplier matching is still reviewed at invoice validation.
- Source files are TEST DATA ONLY. No live EFTPOS.
- Spreadsheet importer uses openpyxl (install with pip install openpyxl if missing).
- Templates are stored in the POS SQLite database, keyed by supplier name.
- Splosh Excel uses unusual incorrect worksheet dimensions; importer uses non-read-only openpyxl mode.
- No complete Windows GUI regression run has been performed.
