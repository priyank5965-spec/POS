Freedom POS 2.0 v0.15 — Find Stock / Stock Screen — TEST DATA ONLY

Launch START_FREEDOM_POS.bat, then Products & Stock > FIND STOCK / STOCK SCREEN.
Or use the Stock Lookup button on the POS screen.

Features: instant search across barcode, name, supplier, supplier stock code,
category, and alternate barcodes; selectable results; product overview and prices;
supplier links; reorder settings; sales and manual stock adjustment history;
reason-required stock adjustment; alternate barcode registration.

Known limitations: No verified barcode merge, no cost/margin calculations,
no owner email on stock changes, no supplier arrivals history, no live multi-register
synchronisation, no permission enforcement for price edits. Do not use for live trade.

Run BUILD_TEST_EXE.bat if you need a Windows executable. Do not run an older EXE.
