"""Freedom POS stock search/editor test module. No external hardware integrations."""
import tkinter as tk
from tkinter import ttk, messagebox
import sqlite3
from decimal import Decimal, InvalidOperation, ROUND_HALF_UP

FIELDS=['name','short_name','barcode','sku','supplier_code','supplier','category','price','cost','rrp','stock','reorder_point','reorder_qty','pos_warn','notes']

def ensure(db):
    existing={r[1] for r in db.execute('PRAGMA table_info(products)')}
    for name,typ,default in [('short_name','TEXT',"''"),('cost','INTEGER','0'),('rrp','INTEGER','0'),('reorder_point','INTEGER','0'),('reorder_qty','INTEGER','0'),('pos_warn','INTEGER','0'),('notes','TEXT',"''"),('sku','TEXT',"''")]:
        if name not in existing:db.execute(f'ALTER TABLE products ADD COLUMN {name} {typ} DEFAULT {default}')
    db.execute('CREATE INDEX IF NOT EXISTS idx_products_sku ON products(sku)')
    db.execute('CREATE TABLE IF NOT EXISTS stock_supplier_links(product_id INTEGER NOT NULL,supplier TEXT NOT NULL,stock_code TEXT NOT NULL DEFAULT \'\',preferred INTEGER NOT NULL DEFAULT 0,PRIMARY KEY(product_id,supplier))')
    db.execute('CREATE TABLE IF NOT EXISTS stock_aliases(barcode TEXT PRIMARY KEY,product_id INTEGER NOT NULL)')
    db.commit()

def amount(s):
    try:
        d=Decimal(s.replace('$','').replace(',','').strip())
        if not d.is_finite() or d<0:raise ValueError()
        return int((d*100).quantize(Decimal('1'),rounding=ROUND_HALF_UP))
    except (InvalidOperation,ValueError):raise ValueError('Enter a non-negative monetary amount')

def install(cls):
    old_products=cls.products
    def stock_screen(self,add_to_sale=False,initial_query=""):
        ensure(self.db)
        win=tk.Toplevel(self.root);win.title('Freedom POS 2.0 — FIND STOCK / STOCK SCREEN — TEST ONLY')
        sw=win.winfo_screenwidth();sh=win.winfo_screenheight()
        win.geometry(f'{min(1330,max(760,sw-110))}x{min(780,max(520,sh-160))}+35+35');win.minsize(760,480)
        win.configure(bg='white')
        header=tk.Frame(win,bg='white');header.pack(fill='x')
        tk.Label(header,text='FIND STOCK  /  STOCK SCREEN',bg='white',fg='#111111',font=('Segoe UI',17,'bold')).pack(side='left',padx=15,pady=12)
        tk.Button(header,text='CLOSE',command=win.destroy,width=13).pack(side='right',padx=15)
        # Persistent footer is packed before the expanding workspace.
        action_bar=tk.Frame(win,bg='#e5edf1',height=58);action_bar.pack(side='bottom',fill='x');action_bar.pack_propagate(False)
        outer=tk.PanedWindow(win,orient='horizontal',sashrelief='raised');outer.pack(fill='both',expand=True,padx=8,pady=8)
        left=tk.Frame(outer);right=tk.Frame(outer);outer.add(left,minsize=250,width=410);outer.add(right,minsize=410)
        search=tk.Frame(left);search.pack(fill='x',padx=5,pady=5)
        tk.Label(search,text='Search barcode, description or SKU:').pack(anchor='w')
        query=tk.StringVar(value=initial_query);searchbox=ttk.Entry(search,textvariable=query,font=('Segoe UI',12));searchbox.pack(fill='x',pady=4)
        count=tk.StringVar(value='');tk.Label(left,textvariable=count,anchor='w').pack(fill='x',padx=6)
        columns=('barcode','sku','name','price','stock','category')
        tree=ttk.Treeview(left,columns=columns,show='headings',selectmode='browse')
        for col,w in zip(columns,(115,90,160,65,55,100)):
            tree.heading(col,text=col.title());tree.column(col,width=w,minwidth=45,stretch=col in ('name','supplier'))
        sy=ttk.Scrollbar(left,orient='vertical',command=tree.yview);tree.configure(yscrollcommand=sy.set)
        sy.pack(side='right',fill='y');tree.pack(fill='both',expand=True,padx=(5,0),pady=5)
        top=tk.Frame(right);top.pack(fill='x',padx=10,pady=6)
        title=tk.StringVar(value='Select an item from the search results')
        tk.Label(top,textvariable=title,font=('Segoe UI',15,'bold'),fg='#111111').pack(side='left')
        notebook=ttk.Notebook(right);notebook.pack(fill='both',expand=True,padx=8,pady=3)
        general=ttk.Frame(notebook);supply=ttk.Frame(notebook);reorder=ttk.Frame(notebook);history=ttk.Frame(notebook)
        for tab,name in [(general,'Product Details & Prices'),(supply,'Suppliers & Barcodes'),(reorder,'Stock & Reorder'),(history,'Arrivals / Sales History')]:notebook.add(tab,text=name)
        vars={k:tk.StringVar() for k in FIELDS};current=[None]
        def field(parent,label,key,row,readonly=False):
            ttk.Label(parent,text=label).grid(row=row,column=0,sticky='w',padx=7,pady=4)
            entry=ttk.Entry(parent,textvariable=vars[key],width=49,state='readonly' if readonly else 'normal')
            entry.grid(row=row,column=1,sticky='ew',padx=7,pady=4)
            return entry
        general.columnconfigure(1,weight=1)
        for i,(label,key) in enumerate([('Long description','name'),('Short receipt / label description','short_name'),('Primary barcode (managed separately)','barcode'),('SKU / Internal stock code','sku'),('Department','category'),('Preferred supplier','supplier'),('Supplier stock code','supplier_code'),('Selling price ($ inc GST)','price'),('Cost price ($)','cost'),('Supplier RRP ($)','rrp'),('Product notes','notes')]):field(general,label,key,i,readonly=key=='barcode')
        reorder.columnconfigure(1,weight=1)
        for i,(label,key) in enumerate([('Current quantity on hand (read only)','stock'),('Reorder point','reorder_point'),('Preferred reorder quantity','reorder_qty'),('Warn at or below stock level','pos_warn')]):field(reorder,label,key,i,readonly=key=='stock')
        ttk.Label(reorder,text='Manual quantity changes require a reason and are audited.').grid(row=5,column=0,columnspan=2,sticky='w',padx=9,pady=12)
        supplier_cols=('supplier','stock_code','preferred')
        sup_tree=ttk.Treeview(supply,columns=supplier_cols,show='headings',height=8)
        for c,w in zip(supplier_cols,(210,220,90)):sup_tree.heading(c,text=c.replace('_',' ').title());sup_tree.column(c,width=w)
        sup_tree.pack(fill='both',expand=True,padx=8,pady=8)
        supform=tk.Frame(supply);supform.pack(fill='x',padx=8,pady=5)
        supname=tk.StringVar();supcode=tk.StringVar();pref=tk.BooleanVar()
        for label,var in [('Supplier',supname),('Supplier stock code',supcode)]:
            ttk.Label(supform,text=label).pack(side='left',padx=4);ttk.Entry(supform,textvariable=var,width=18).pack(side='left',padx=4)
        ttk.Checkbutton(supform,text='Preferred',variable=pref).pack(side='left',padx=5)
        hist_cols=('date','type','quantity','details');hist_tree=ttk.Treeview(history,columns=hist_cols,show='headings')
        for c,w in zip(hist_cols,(155,120,90,400)):hist_tree.heading(c,text=c.title());hist_tree.column(c,width=w)
        hist_tree.pack(fill='both',expand=True,padx=8,pady=8)
        ttk.Label(history,text='Sales and manual adjustments from local test data. Supplier arrivals history is not yet linked.',foreground='#a04a28').pack(anchor='w',padx=8,pady=5)
        def reload_results(*_):
            q=query.get().strip();tree.delete(*tree.get_children())
            if q:
                pat='%'+q+'%'
                rows=self.db.execute('''SELECT DISTINCT p.* FROM products p LEFT JOIN stock_aliases a ON a.product_id=p.id WHERE p.barcode LIKE ? OR p.name LIKE ? OR p.short_name LIKE ? OR p.sku LIKE ? OR a.barcode LIKE ? ORDER BY p.name LIMIT 500''',(pat,)*5).fetchall()
            else:rows=self.db.execute('SELECT * FROM products ORDER BY name LIMIT 500').fetchall()
            # Unknown barcodes must NOT show unrelated sample products.
            for p in rows:tree.insert('','end',iid=str(p['id']),values=(p['barcode'],p['sku'],p['name'],f'${p["price"]/100:.2f}',p['stock'],p['category']))
            count.set(f'{len(rows)} matching products (maximum 500 shown)' if rows else 'No matching products — use ADD NEW PRODUCT')
            if q and len(rows)==1 and (rows[0]['barcode']==q or self.db.execute('SELECT 1 FROM stock_aliases WHERE barcode=? AND product_id=?',(q,rows[0]['id'])).fetchone()):
                tree.selection_set(str(rows[0]['id']));tree.focus(str(rows[0]['id']));load_selected()
        def load_selected(_=None):
            s=tree.selection()
            if not s:return
            p=self.db.execute('SELECT * FROM products WHERE id=?',(int(s[0]),)).fetchone()
            if p is None:return
            current[0]=p['id'];title.set(f'{p["name"]}  |  {p["barcode"]}')
            for key in FIELDS:
                val=p[key] if key in p.keys() else ''
                vars[key].set(f'{val/100:.2f}' if key in ('price','cost','rrp') else str(val if val is not None else ''))
            sup_tree.delete(*sup_tree.get_children())
            for r in self.db.execute('SELECT * FROM stock_supplier_links WHERE product_id=? ORDER BY preferred DESC,supplier',(p['id'],)):
                sup_tree.insert('','end',iid=r['supplier'],values=(r['supplier'],r['stock_code'],'Yes' if r['preferred'] else 'No'))
            hist_tree.delete(*hist_tree.get_children())
            for r in self.db.execute('SELECT s.created,l.qty,s.id FROM lines l JOIN sales s ON s.id=l.sale_id WHERE l.product_id=? ORDER BY s.id DESC LIMIT 100',(p['id'],)):
                hist_tree.insert('','end',values=(r[0],'Sale / refund',r[1],f'Receipt #{r[2]}'))
            for r in self.db.execute('SELECT created,delta,reason FROM stock_adjustments WHERE product_id=? ORDER BY id DESC LIMIT 100',(p['id'],)):
                hist_tree.insert('','end',values=(r[0],'Manual adjustment',r[1],r[2]))
        def save():
            pid=current[0]
            if pid is None:return messagebox.showwarning('Select stock','Select a product first',parent=win)
            try:
                name=vars['name'].get().strip()
                if not name:raise ValueError('Long description is required')
                prices=[amount(vars[k].get()) for k in ('price','cost','rrp')]
                nums=[int(vars[k].get()) for k in ('reorder_point','reorder_qty','pos_warn')]
                if min(nums)<0:raise ValueError('Reorder quantities cannot be negative')
                sku=vars['sku'].get().strip()
                if sku and self.db.execute('SELECT 1 FROM products WHERE sku=? AND id<>?',(sku,pid)).fetchone():
                    raise ValueError('SKU already exists on another product.')
                old=self.db.execute('SELECT * FROM products WHERE id=?',(pid,)).fetchone()
                with self.db:
                    self.db.execute('''UPDATE products SET name=?,short_name=?,sku=?,category=?,supplier=?,supplier_code=?,price=?,cost=?,rrp=?,notes=?,reorder_point=?,reorder_qty=?,pos_warn=? WHERE id=?''',(name,vars['short_name'].get().strip(),vars['sku'].get().strip(),vars['category'].get().strip(),vars['supplier'].get().strip(),vars['supplier_code'].get().strip(),*prices,vars['notes'].get().strip(),*nums,pid))
                self.log('STOCK EDIT',f'Product #{pid}: name {old["name"]!r} -> {name!r}; price {old["price"]} -> {prices[0]}; category {old["category"]!r} -> {vars["category"].get()!r}')
                reload_results();tree.selection_set(str(pid));load_selected()
                messagebox.showinfo('Saved','Product details saved.',parent=win)
            except (ValueError,sqlite3.Error) as e:messagebox.showerror('Check details',str(e),parent=win)
        def add_supplier():
            pid=current[0];name=supname.get().strip();code=supcode.get().strip()
            if pid is None or not name:return messagebox.showwarning('Supplier','Select a product and enter a supplier.',parent=win)
            with self.db:
                if pref.get():self.db.execute('UPDATE stock_supplier_links SET preferred=0 WHERE product_id=?',(pid,))
                self.db.execute('INSERT INTO stock_supplier_links(product_id,supplier,stock_code,preferred) VALUES(?,?,?,?) ON CONFLICT(product_id,supplier) DO UPDATE SET stock_code=excluded.stock_code,preferred=excluded.preferred',(pid,name,code,int(pref.get())))
            self.log('STOCK SUPPLIER',f'Product #{pid}: supplier {name}, code {code}, preferred {pref.get()}');load_selected()
        ttk.Button(supform,text='Save Supplier',command=add_supplier).pack(side='left',padx=5)
        def select_supplier(_=None):
            sel=sup_tree.selection()
            if sel:
                vals=sup_tree.item(sel[0],'values');supname.set(vals[0]);supcode.set(vals[1]);pref.set(vals[2]=='Yes')
        sup_tree.bind('<<TreeviewSelect>>',select_supplier)
        def adjust():
            pid=current[0]
            if pid is None:return
            p=self.db.execute('SELECT * FROM products WHERE id=?',(pid,)).fetchone()
            dlg=tk.Toplevel(win);dlg.title('Audited Stock Adjustment');dlg.geometry('440x280');dlg.transient(win);dlg.grab_set()
            ttk.Label(dlg,text=f'{p["name"]}  •  Current: {p["stock"]}',font=('Segoe UI',12,'bold')).pack(pady=10)
            qty=tk.StringVar(value=str(p['stock']));reason=tk.StringVar()
            for label,var in [('New quantity on hand',qty),('Mandatory reason',reason)]:
                ttk.Label(dlg,text=label).pack(anchor='w',padx=20);ttk.Entry(dlg,textvariable=var,width=48).pack(padx=20,pady=4)
            def commit():
                try:
                    new=int(qty.get());why=reason.get().strip()
                    if new<0 or not why:raise ValueError('Enter a non-negative quantity and a reason')
                    delta=new-p['stock']
                    if delta==0:dlg.destroy();return
                    if not messagebox.askyesno('Confirm adjustment',f'Change stock from {p["stock"]} to {new}?\nReason: {why}',parent=dlg):return
                    from datetime import datetime
                    with self.db:
                        self.db.execute('UPDATE products SET stock=? WHERE id=?',(new,pid))
                        self.db.execute('INSERT INTO stock_adjustments(created,product_id,delta,reason) VALUES(?,?,?,?)',(datetime.now().isoformat(timespec='seconds'),pid,delta,why))
                    self.log('STOCK ADJUST',f'Product #{pid} {p["stock"]} -> {new}; {why}');dlg.destroy();reload_results();tree.selection_set(str(pid));load_selected()
                    messagebox.showwarning('Email not configured','Adjustment saved and logged. Owner notification email is NOT implemented in this screen.',parent=win)
                except ValueError as e:messagebox.showerror('Invalid adjustment',str(e),parent=dlg)
            ttk.Button(dlg,text='CONFIRM ADJUSTMENT',command=commit).pack(pady=12)
        def add_alias():
            pid=current[0]
            if pid is None:return
            dlg=tk.Toplevel(win);dlg.title('Add Alternate Barcode');dlg.geometry('420x170');dlg.transient(win);dlg.grab_set()
            value=tk.StringVar();ttk.Label(dlg,text='Additional barcode (original stays unchanged)').pack(pady=10)
            ent=ttk.Entry(dlg,textvariable=value,width=42);ent.pack();ent.focus_set()
            def save_alias():
                code=value.get().strip()
                if not code:return
                if self.db.execute('SELECT 1 FROM products WHERE barcode=?',(code,)).fetchone() or self.db.execute('SELECT 1 FROM stock_aliases WHERE barcode=?',(code,)).fetchone():return messagebox.showerror('Duplicate','Barcode already assigned.',parent=dlg)
                with self.db:self.db.execute('INSERT INTO stock_aliases(barcode,product_id) VALUES(?,?)',(code,pid))
                self.log('BARCODE',f'Added alias {code} for product #{pid}');dlg.destroy()
            ttk.Button(dlg,text='SAVE BARCODE',command=save_alias).pack(pady=12)
        def cancel_changes():
            if current[0] is not None:load_selected()
            else:
                for v in vars.values():v.set('')
        def add_new():
            self.stock_add_form(barcode=query.get().strip() if not tree.get_children() else '',on_saved=lambda pid,sell: (query.set(''),reload_results(),tree.selection_set(str(pid)),load_selected()))
        def sell_selected():
            if current[0] is None:return messagebox.showwarning('Select stock','Select a product first.',parent=win)
            if not (hasattr(self,'sale_tree') and self.sale_tree.winfo_exists()):return messagebox.showinfo('Register','Open the Register to sell this item.',parent=win)
            product=self.db.execute('SELECT * FROM products WHERE id=?',(current[0],)).fetchone()
            self.add_to_cart(product);win.destroy()
        def delete_selected():
            messagebox.showinfo('Product removal','Permanent product deletion is not enabled in this test build. Existing sales, inventory and barcode history must be preserved.',parent=win)
        footer=action_bar
        for label,fn in [('ADD NEW PRODUCT',add_new),('SAVE PRODUCT',save),('CANCEL CHANGES',cancel_changes),('ADJUST STOCK',adjust),('ADD BARCODE',add_alias),('SELL SELECTED',sell_selected)]:
            ttk.Button(footer,text=label,command=fn).pack(side='left',padx=3,pady=12)

        if add_to_sale:
            def quick_add():
                self.stock_add_form(barcode=initial_query or query.get().strip(), on_saved=lambda product_id, sell: (
                    (self.add_to_cart(self.db.execute('SELECT * FROM products WHERE id=?',(product_id,)).fetchone()), win.destroy()) if sell else reload_results()
                ))
            # ADD NEW PRODUCT is always available in the persistent action bar.
            def add_cart():
                pid=current[0]
                if pid is None:return
                p=self.db.execute('SELECT * FROM products WHERE id=?',(pid,)).fetchone()
                self.add_to_cart(p);win.destroy()
            # SELL SELECTED is already available in the persistent action bar.
        query.trace_add('write',reload_results);tree.bind('<<TreeviewSelect>>',load_selected)
        tree.bind('<Double-1>',lambda e:load_selected());reload_results();searchbox.focus_set()
        return win
    def stock_lookup(self,initial_query=''):return self.stock_screen(add_to_sale=hasattr(self,'sale_tree') and self.sale_tree.winfo_exists(),initial_query=initial_query)
    def products(self):
        old_products(self)
        bar=tk.Frame(self.root,bg='white');bar.pack(fill='x',padx=12,pady=5)
        self.btn(bar,'FIND STOCK / STOCK SCREEN',self.stock_screen,size=10,height=1).pack(side='left',padx=4)
    cls.stock_screen=stock_screen;cls.stock_lookup=stock_lookup;cls.products=products
