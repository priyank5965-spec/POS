Freedom POS 2.0 v0.33 TEST ONLY
Register barcode field accepts digits 0-9 and !@#$%^&*()_+ only.
Letters remain blocked. Question mark remains reserved for Stock Lookup shortcut (Shift+/).
Numeric barcode auto-scan is unchanged. Symbol-containing product codes require scanner Enter suffix or manual Enter because automatic completion currently targets standard numeric lengths.
Windows UI and hardware scanner tests remain outstanding.
