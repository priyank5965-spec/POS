Freedom POS 2.0 v0.56 — TEST ONLY

Global screen-size guard clamps Toplevel geometry and minimum sizes to detected screen dimensions, with taskbar allowance. Theme designer reserves footer before sizing its button grid so Save Layout, Apply, Cancel and Restore Default remain visible. Main window also clamps to screen.

LIMITATIONS: tkinter forms with rigid internal widgets may still need scrolling and reflow. Multi-monitor work areas, Windows DPI scaling and all UI flows are NOT verified in Windows. Please test at 100%, 125%, 150% display scaling and report affected forms.
