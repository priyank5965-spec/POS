Freedom POS 2.0 v0.47 TEST ONLY
Quick Cash $5/$10/$20/$50/$100 completes simulated CASH sale without opening tender dialog when tender >= due.
Displays last sale change below sales grid only after successful database checkout.
Regular CASH retains payment details window.
Insufficient denomination does not finalise sale; warns to use CASH or SPLIT TENDER.
No real cash drawer or EFTPOS integration is implemented.
