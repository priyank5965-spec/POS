Freedom POS 2.0 — v0.14 MASTER FORMS TEST ONLY

New: Purchasing -> Supplier Management: full add/edit form with business/contact/account/address details.
New: Products & Stock -> Department Management: full add/edit form with GST, markup, label policy.
Both include searchable lists, double-click edit, required-field and duplicate validation, and local SQLite storage.

NOT YET DONE: full-form conversion of all remaining workflows; live product/supplier references and invoice reconciliation; production permissions; Windows EXE validation.

Run START_FREEDOM_POS.bat from the extracted freedom_v04 folder. Test data only.
