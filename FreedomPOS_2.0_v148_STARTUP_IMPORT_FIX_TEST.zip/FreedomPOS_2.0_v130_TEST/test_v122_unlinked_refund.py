import unittest
from pathlib import Path
from linkly_purchase_v114 import build_refund

class UnlinkedRefundTests(unittest.TestCase):
    def test_refund_request_uses_r_and_positive_amount(self):
        message = build_refund(599, 'R123456789')
        self.assertEqual(message[9:10], b'R')
        self.assertIn(b'000000599', message)
    def test_unlinked_return_is_allowed_only_after_verified_refund(self):
        source = Path(__file__).with_name('freedom_pos.py').read_text()
        self.assertIn("getattr(self,'_linkly_verified_refund',False)", source)
        self.assertIn("getattr(self,'_linkly_verified_checkout',False)", source)
        self.assertIn("'UNLINKED TEST REFUND'", source)
    def test_mixed_positive_total_is_blocked_for_unlinked_return(self):
        source = Path(__file__).with_name('linkly_payment_v111.py').read_text()
        self.assertIn('if unlinked_returns and not is_refund:', source)
        self.assertIn('if unlinked_returns and self.refund_origin:', source)
