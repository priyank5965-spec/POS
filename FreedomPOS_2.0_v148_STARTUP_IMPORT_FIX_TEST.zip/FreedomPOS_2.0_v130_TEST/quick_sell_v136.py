"""Quick Sell v136: no Enter required; F-keys untouched."""
import re
import tkinter as tk
from tkinter import ttk,messagebox
from datetime import date

def schema(db):
    db.execute("""CREATE TABLE IF NOT EXISTS quick_sell_codes_v136 (code TEXT PRIMARY KEY COLLATE NOCASE, product_id INTEGER, newspaper_title TEXT, CHECK ((product_id IS NULL) != (newspaper_title IS NULL)))""")
    db.commit()

def validate_code(db,raw,exclude_title=None,exclude_pid=None):
    code=raw.strip().upper()
    if not code:return ''
    if not re.fullmatch('[A-Z]{1,8}',code):raise ValueError('Register Shortcut Key must contain 1–8 letters (A–Z), no function keys or Enter.')
    from department_navigation_v067 import load as department_load, department_key
    if any(department_key(item.get('shortcut',''))==code for item in department_load().values() if isinstance(item,dict)):
        raise ValueError('Register Shortcut Key is already assigned to a department.')
    row=db.execute('SELECT product_id,newspaper_title FROM quick_sell_codes_v136 WHERE code=?',(code,)).fetchone()
    for other,other_pid,other_title in db.execute('SELECT code,product_id,newspaper_title FROM quick_sell_codes_v136'):
        same=(exclude_title is not None and other_title==exclude_title) or (exclude_pid is not None and other_pid==exclude_pid)
        if not same and (other.upper().startswith(code) or code.startswith(other.upper())):
            raise ValueError('Register Shortcut Key conflicts with existing code '+other+' (prefix overlap).')
    if row and not ((exclude_title is not None and row[1]==exclude_title) or (exclude_pid is not None and row[0]==exclude_pid)):
        raise ValueError('Register Shortcut Key '+code+' is already assigned.')
    if db.execute('SELECT 1 FROM products WHERE UPPER(barcode)=?',(code,)).fetchone():
        raise ValueError('Register Shortcut Key conflicts with an existing product barcode.')
    if db.execute('SELECT 1 FROM product_barcodes WHERE UPPER(barcode)=?',(code,)).fetchone():
        raise ValueError('Register Shortcut Key conflicts with an additional barcode.')
    try:
        if db.execute('SELECT 1 FROM newspaper_metadata_v135 WHERE UPPER(plu)=? AND title<>?',(code,exclude_title or '')).fetchone():
            raise ValueError('Register Shortcut Key conflicts with a newspaper PLU.')
    except Exception as e:
        if isinstance(e,ValueError):raise
    return code

def editor(app):
    schema(app.db)
    win=tk.Toplevel(app.root);win.title('Product Register Shortcut Keys');win.geometry('770x480');win.transient(app.root)
    f=ttk.Frame(win,padding=16);f.pack(fill='both',expand=True)
    ttk.Label(f,text='Product Register Shortcut Keys',font=('Segoe UI',15,'bold')).pack(anchor='w',pady=(0,12))
    ttk.Label(f,text='Select an ordinary stock product and assign a 1–8 letter code. Newspaper title codes are set in Newspaper Product Setup.').pack(anchor='w')
    products=app.db.execute('SELECT id,name,barcode FROM products ORDER BY name').fetchall()
    lookup={f"{p['name']}  [{p['barcode']}]  (ID {p['id']})":p['id'] for p in products}
    row=ttk.Frame(f);row.pack(fill='x',pady=14)
    ttk.Label(row,text='Product').grid(row=0,column=0,sticky='w')
    choice=ttk.Combobox(row,values=list(lookup),width=65,state='readonly');choice.grid(row=1,column=0,padx=(0,14),sticky='ew')
    ttk.Label(row,text='Register Shortcut Key').grid(row=0,column=1,sticky='w')
    code=tk.StringVar();ttk.Entry(row,textvariable=code,width=12).grid(row=1,column=1)
    row.columnconfigure(0,weight=1)
    columns=('code','product');table=ttk.Treeview(f,columns=columns,show='headings',height=10)
    table.heading('code',text='Code');table.heading('product',text='Product');table.column('code',width=130);table.column('product',width=500)
    table.pack(fill='both',expand=True)
    def refresh():
        table.delete(*table.get_children())
        for q in app.db.execute("""SELECT q.code,p.name FROM quick_sell_codes_v136 q JOIN products p ON p.id=q.product_id ORDER BY q.code"""):
            table.insert('','end',values=(q[0],q[1]))
    def selected(event=None):
        pid=lookup.get(choice.get())
        if pid is not None:
            r=app.db.execute('SELECT code FROM quick_sell_codes_v136 WHERE product_id=?',(pid,)).fetchone()
            code.set(r[0] if r else '')
    choice.bind('<<ComboboxSelected>>',selected)
    def save():
        pid=lookup.get(choice.get())
        if pid is None:return messagebox.showwarning('Product','Select a product.',parent=win)
        try:
            value=validate_code(app.db,code.get(),exclude_pid=pid)
            with app.db:
                app.db.execute('DELETE FROM quick_sell_codes_v136 WHERE product_id=?',(pid,))
                if value:app.db.execute('INSERT INTO quick_sell_codes_v136(code,product_id) VALUES(?,?)',(value,pid))
            refresh()
        except Exception as ex:messagebox.showerror('Quick Sell',str(ex),parent=win)
    actions=ttk.Frame(f);actions.pack(fill='x',pady=8)
    ttk.Button(actions,text='Save Shortcut',command=save).pack(side='right',padx=5)
    ttk.Button(actions,text='Close',command=win.destroy).pack(side='right',padx=5)
    refresh()

def install(cls):
    old_pos=cls.pos
    def pos(self):
        old_pos(self)
        schema(self.db)
        self._qs_buffer='';self._qs_job=None
        # Capture only while the register is open; never take over dialog text fields.
        # Bind at the entry widget: Tk entry class bindings otherwise insert letters before root sees them.
        # Intercept alphabetic shortcuts before Entry class inserts text.
        # Tk's widget -> Entry -> toplevel binding order otherwise eats the key.
        tag='FreedomQuickSellV140'
        tags=self.code.bindtags()
        self.code.bindtags((tag,)+tuple(t for t in tags if t!=tag))
        self.root.bind_class(tag,'<KeyPress>',lambda event:keypress(self,event))
        self.root.bind('<KeyPress>',lambda event:keypress(self,event),add='+')
        self.root.bind('<FocusOut>',lambda event:clear(self),add='+')
    cls.pos=pos
    old_products=cls.products
    def products(self):
        old_products(self)
        toolbar=tk.Frame(self.root,bg='white');toolbar.pack(fill='x',padx=12,pady=4)
        tk.Button(toolbar,text='PRODUCT QUICK SELL CODES',command=lambda:editor(self),bg='#e1e9f0',fg='#172b40',relief='solid',bd=1,font=('Segoe UI',10,'bold'),padx=12,pady=7).pack(side='left')
    cls.products=products

def clear(app):
    if getattr(app,'_qs_job',None):
        try:app.root.after_cancel(app._qs_job)
        except tk.TclError:pass
    app._qs_job=None;app._qs_buffer=''

def perform(app,code):
    row=app.db.execute('SELECT product_id,newspaper_title FROM quick_sell_codes_v136 WHERE code=?',(code,)).fetchone()
    if row is None:return False
    pid,title=row
    if title is not None:
        try:
            rec=app.db.execute("""SELECT p.* FROM newspaper_weekdays_v134 w JOIN products p ON p.id=w.product_id
                 WHERE w.title=? AND w.day=? AND w.active=1""",(title,date.today().weekday())).fetchone()
        except Exception:rec=None
        if rec is None:
            messagebox.showwarning('Newspaper not available',title+' has no active edition for today.',parent=app.root)
            return True
        product=rec
    else:
        product=app.db.execute('SELECT * FROM products WHERE id=?',(pid,)).fetchone()
    if product:
        app.add_to_cart(product,qty=1)
        if hasattr(app,'code') and app.code.winfo_exists():app.code.focus_set()
    return True

def flush(app):
    code=getattr(app,'_qs_buffer','');clear(app)
    if code and app.db.execute('SELECT 1 FROM quick_sell_codes_v136 WHERE code=?',(code,)).fetchone():perform(app,code)

def keypress(app,event):
    if not hasattr(app,'code') or not app.code.winfo_exists() or not app.code.winfo_ismapped():return
    if event.widget.winfo_toplevel()!=app.root:return
    if getattr(app,'_qs_handling',False):return
    if event.state & 0x000C:return  # Ctrl or Alt: preserve existing commands
    if not event.char or not event.char.isascii() or not event.char.isalpha():return
    focused=app.root.focus_get()
    if focused is None:return
    # Do not intercept typing into any other editor, search, or quantity field.
    if focused is not app.code and isinstance(focused,(tk.Entry,tk.Text,tk.Spinbox,ttk.Entry,ttk.Combobox)):return
    if focused is app.code and app.code.get().strip():return
    if focused is not app.code and isinstance(focused,(tk.Entry,tk.Text,tk.Spinbox,ttk.Entry,ttk.Combobox)):return
    code=getattr(app,'_qs_buffer','')+event.char.upper()
    allcodes=[r[0].upper() for r in app.db.execute('SELECT code FROM quick_sell_codes_v136')]
    candidates=[x for x in allcodes if x.startswith(code)]
    if not candidates:
        # Unknown letters are not valid in the numeric-only barcode field.
        clear(app)
        return 'break' if focused is app.code else None
    clear(app);app._qs_buffer=code
    if code in candidates and not any(x!=code for x in candidates):
        flush(app)
    else:
        # Prefix codes (e.g. P and PB) wait briefly to disambiguate, never require Enter.
        app._qs_job=app.root.after(650,lambda:flush(app))
    return 'break'
