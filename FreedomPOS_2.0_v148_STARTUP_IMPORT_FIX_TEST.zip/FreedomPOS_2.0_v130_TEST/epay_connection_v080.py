"""Non-transactional Windows e-pay diagnostics. No COM activation or HTTP/API calls."""
from pathlib import Path
import os,sys,ssl,socket,subprocess,urllib.parse,datetime,platform,struct
from epay_connection_diagnostic_v079 import pe_info

DEFAULT_FOLDER=r'C:\Program Files (x86)\Posbrowser'

def component_test(folder):
    file=Path(folder)/'epayREST.dll'
    if not file.is_file():return 'NOT FOUND: '+str(file)
    try:
        metadata=pe_info(file)
    except Exception as exc:return 'ERROR inspecting file: '+str(exc)
    lines=['REST component file: FOUND',metadata]
    if os.name!='nt':return '\n'.join(lines+['Windows .NET metadata check unavailable on this OS.'])
    # ReflectionOnlyLoadFrom examines CLR metadata in a separate process; it never constructs a COM object.
    ps="$ErrorActionPreference='Stop'; try { $a=[Reflection.Assembly]::ReflectionOnlyLoadFrom($args[0]); 'ASSEMBLY: '+$a.FullName; 'METADATA LOAD: OK' } catch { 'METADATA LOAD FAILED: '+$_.Exception.Message; exit 2 }"
    # -File rather than interpolating user input in a script prevents PowerShell injection.
    import tempfile
    with tempfile.TemporaryDirectory(prefix='freedom_epay_diag_') as temp:
        script=Path(temp)/'metadata.ps1';script.write_text(ps,encoding='utf-8-sig')
        candidates=[Path(os.environ.get('WINDIR',r'C:\Windows'))/'SysWOW64'/'WindowsPowerShell'/'v1.0'/'powershell.exe',Path('powershell.exe')]
        for exe in candidates:
            try:
                proc=subprocess.run([str(exe),'-NoProfile','-NonInteractive','-ExecutionPolicy','Bypass','-File',str(script),str(file.resolve())],capture_output=True,text=True,timeout=12,creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0))
                lines.append((proc.stdout+'\n'+proc.stderr).strip()[:1800] or 'No metadata response')
                break
            except FileNotFoundError:continue
            except subprocess.TimeoutExpired:lines.append('Metadata check timed out');break
            except Exception as exc:lines.append('Metadata check error: '+str(exc));break
    lines.append('No COM activation, vendor transaction method, or e-pay request was performed.')
    return '\n'.join(lines)

def server_test(url):
    """TCP+TLS handshake only. No HTTP request and no credentials."""
    raw=url.strip()
    try:
        parsed=urllib.parse.urlsplit(raw)
        if parsed.scheme.lower()!='https' or not parsed.hostname or parsed.username or parsed.password or parsed.query or parsed.fragment:
            return 'INVALID: Enter an HTTPS URL without username, password, query or fragment.'
        host=parsed.hostname;port=parsed.port or 443
        if not 1<=port<=65535:return 'INVALID port'
    except ValueError as exc:return 'INVALID URL: '+str(exc)
    try:
        with socket.create_connection((host,port),timeout=5) as sock:
            sock.settimeout(5)
            with ssl.create_default_context().wrap_socket(sock,server_hostname=host) as tls:
                return 'TCP CONNECTION: OK\nTLS HANDSHAKE: OK\nTLS version: '+str(tls.version())+'\nNo HTTP request, login, product enquiry or transaction was sent.\nAuthentication: NOT TESTED.'
    except (OSError,ssl.SSLError) as exc:return 'CONNECTION FAILED: '+type(exc).__name__+': '+str(exc)[:350]+'\nNo e-pay request was sent.'

def open_window(parent):
    import tkinter as tk
    from tkinter import ttk,filedialog
    win=tk.Toplevel(parent);win.title('E-PAY — Connection Tests (NO TRANSACTIONS)');win.geometry('940x700');win.minsize(720,520)
    ttk.Label(win,text='E-PAY CONNECTION TESTS',font=('Segoe UI',16,'bold')).pack(anchor='w',padx=14,pady=(12,3))
    ttk.Label(win,text='TEST ONLY — no sales, cancellation, authentication, voucher issuance, or printer activity.',foreground='#a12e1b').pack(anchor='w',padx=14)
    form=ttk.Frame(win,padding=12);form.pack(fill='x')
    folder=tk.StringVar(value=DEFAULT_FOLDER);url=tk.StringVar(value='')
    ttk.Label(form,text='Existing DLL folder').grid(row=0,column=0,sticky='w',pady=5)
    ttk.Entry(form,textvariable=folder).grid(row=0,column=1,sticky='ew',padx=8)
    def browse():
        v=filedialog.askdirectory(parent=win,title='Select e-pay DLL folder')
        if v:folder.set(v)
    ttk.Button(form,text='Browse',command=browse).grid(row=0,column=2)
    ttk.Label(form,text='HTTPS endpoint').grid(row=1,column=0,sticky='w',pady=5)
    ttk.Entry(form,textvariable=url).grid(row=1,column=1,sticky='ew',padx=8)
    ttk.Label(form,text='Use your authorised endpoint; no password or query string.').grid(row=2,column=1,sticky='w')
    form.columnconfigure(1,weight=1)
    out=tk.Text(win,wrap='word',font=('Consolas',10));out.pack(fill='both',expand=True,padx=14,pady=7)
    out.insert('1.0','Choose a test below. A reachable server does not prove e-pay authentication.\n')
    def append(label,result):
        out.insert('end','\n['+datetime.datetime.now().strftime('%H:%M:%S')+'] '+label+'\n'+result+'\n');out.see('end')
    bar=ttk.Frame(win,padding=12);bar.pack(fill='x')
    def load():append('REST COMPONENT METADATA (no activation)',component_test(folder.get()))
    def network():
        if not url.get().strip():append('SERVER TEST','Enter your authorised HTTPS endpoint first.');return
        append('TCP/TLS SERVER TEST',server_test(url.get()))
    ttk.Button(bar,text='Load REST Component (Metadata)',command=load).pack(side='left',padx=3)
    ttk.Button(bar,text='Test Server Connection (TLS only)',command=network).pack(side='left',padx=3)
    ttk.Button(bar,text='Test Product Enquiry (Unavailable)',state='disabled').pack(side='left',padx=3)
    bottom=ttk.Frame(win,padding=(12,0,12,12));bottom.pack(fill='x')
    def save():
        name=filedialog.asksaveasfilename(parent=win,defaultextension='.txt',filetypes=[('Text files','*.txt')])
        if name:Path(name).write_text(out.get('1.0','end-1c'),encoding='utf-8')
    ttk.Button(bottom,text='Save Diagnostic Report',command=save).pack(side='left')
    ttk.Button(bottom,text='Close',command=win.destroy).pack(side='right')
    return win

def install(cls):
    original=cls.epay_window
    def epay_window(self):
        original(self)
        w=getattr(self,'_epay_window',None)
        if w is None or not w.winfo_exists():return
        from tkinter import ttk
        # Existing E-PAY footer is a frame containing the e-pay Settings button.
        for child in w.winfo_children():
            if isinstance(child,ttk.Frame):
                for widget in child.winfo_children():
                    try:label=widget.cget('text')
                    except Exception:continue
                    if label=='e-pay Settings':
                        ttk.Button(child,text='Test e-pay Connection (Safe)',command=lambda:open_window(w)).pack(side='left',padx=8)
                        return
    cls.epay_window=epay_window
