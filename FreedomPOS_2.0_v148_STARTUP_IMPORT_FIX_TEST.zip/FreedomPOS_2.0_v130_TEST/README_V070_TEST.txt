Freedom POS 2.0 v0.70 — TEST ONLY

FIXED: Department Buttons & Shortcuts is a full-size Settings & Tools tile, not a clipped button below the grid.
ADDED: Bare letter department shortcuts (G, S, M, L etc.) in the department shortcut editor; combinations remain supported. Duplicate department and existing action shortcuts are rejected.
SAFETY: Bare letter shortcuts only trigger with an empty barcode entry, to avoid interfering with manually typed product codes. Scanner devices that send characters individually may still need dedicated scanner handling; do not use this build for live trading.
Existing department navigation and Business Defaults storage retained.
NOT INCLUDED: Department amount-to-grid sale; full button add/remove editor; end-to-end Windows UI tests.
