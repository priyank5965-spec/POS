FREEDOM POS 2.0 — v0.13 CUSTOMER FORM TEST

Extract into a NEW folder, open freedom_v04, double-click START_FREEDOM_POS.bat.
Home > Customers > ADD CUSTOMER opens one full editable customer form.
Select a customer and choose EDIT SELECTED, or double-click the row.
Includes contact, phone, mobile, email, address, postcode, customer account number, ABN, delivery/billing preferences, payment terms, notes and active flag.
Email is also saved in customer_emails for the invoice/statement email centre.
Existing test customer rows are retained; missing columns are added automatically.
Account balances are deliberately not editable here.
Do NOT use live customer data: this is a test-only local SQLite prototype.
Windows GUI and live sending are not tested in this environment.
