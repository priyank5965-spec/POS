"""Register digit/symbol scan field and question-mark Stock Lookup shortcut."""

def install(cls):
    original_pos = cls.pos

    def pos(self):
        original_pos(self)
        code = self.code
        # Tk validation applies to typing and pasting, not only KeyPress events.
        allowed = frozenset('0123456789.!@#$%^&*()_+')
        def numeric(proposed):
            return all(char in allowed for char in proposed)
        validator = (code.register(numeric), '%P')
        code.configure(validate='key', validatecommand=validator)
        # The final register Entry must be the one validated.
        self._register_numeric_validator = validator

        # Shortcut handling is owned by the configurable v0.59 manager.

    cls.pos = pos
