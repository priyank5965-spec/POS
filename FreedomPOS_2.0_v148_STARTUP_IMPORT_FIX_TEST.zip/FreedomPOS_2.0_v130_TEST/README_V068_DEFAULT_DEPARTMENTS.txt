Freedom POS 2.0 v0.68 TEST — DEFAULT DEPARTMENTS

Starter departments: INSTANTS, LOTTO, NEWSPAPERS, MAGAZINES, STATIONERY, CARDS & WRAP, SWEETS, GIFTS.
Existing departments are preserved, including inactive ones. Business-wide mode and shortcuts retained.

The new amount-then-department sale behavior is NOT implemented in this build.
TEST ONLY. Windows GUI workflows not verified.
