"""Central Register Settings — TEST ONLY. Settings with no runtime implementation are clearly disabled."""
import json, tkinter as tk
from tkinter import ttk,messagebox
from pathlib import Path
PATH=Path(__file__).resolve().parent/'test_data'/'register_settings_v063.json'
DEFAULT={
 'auto_scan':True,'scan_delay':300,'scan_suffix':'Enter','receipt_prefix':'@',
 'default_qty':1,'merge_scans':True,'price_override':False,
 'discount_pct_limit':100,'discount_approval':False,
 'auto_print':False,'paper':'80mm','cash_rounding':False,
 'staff_login':False,'manager_approval':False,'audit_events':True,
 'display_theme':'Freedom Classic','customer_display':False,
 'register_id':'POS1','opening_float':'0.00','end_day_prompt':False,
}
def load():
 try:
  raw=json.loads(PATH.read_text(encoding='utf-8'))
  if not isinstance(raw,dict):raise ValueError('Invalid configuration')
  return {**DEFAULT,**{k:v for k,v in raw.items() if k in DEFAULT}}
 except (OSError,ValueError,TypeError):return dict(DEFAULT)

def install(cls):
 old_settings=cls.settings;old_add=cls.add_to_cart;old_pos=cls.pos
 def add_to_cart(self,p,qty=1,negative=False,origin_line=None):
  if not negative and origin_line is None and not load()['merge_scans']:
   # Preserve the original stock validation while disabling line merging.
   if qty<=0:return
   existing=sum(x['qty'] for x in self.cart if x.get('product_id')==p['id'] and x['qty']>0)
   # Negative stock allowed; sales may proceed.
   self.cart.append(dict(product_id=p['id'],description=p['name'],qty=qty,unit=p['price'],kind='PRODUCT',original_line=None))
   self.refresh_cart();return
  return old_add(self,p,qty,negative,origin_line)
 def pos(self):
  result=old_pos(self)
  if hasattr(self,'_register_qty'):
   n=load()['default_qty'];self._register_qty=n
   if hasattr(self,'qty_next'):self.qty_next.set(f'Qty {n}')
  return result
 def register_settings(self):
  w=tk.Toplevel(self.root);w.title('Register Settings — TEST ONLY');w.transient(self.root)
  sw=w.winfo_screenwidth();sh=w.winfo_screenheight();w.geometry(f'{min(1100,sw-100)}x{min(760,sh-130)}+40+35');w.minsize(680,460)
  bg='white';navy='#12324a';w.configure(bg=bg)
  header=tk.Frame(w,bg=navy,height=65);header.pack(fill='x');header.pack_propagate(False)
  tk.Label(header,text='REGISTER SETTINGS',bg=navy,fg='white',font=('Segoe UI',19,'bold')).pack(side='left',padx=20,pady=13)
  tk.Label(header,text='TEST ONLY',bg=navy,fg='#9de4ed',font=('Segoe UI',10,'bold')).pack(side='right',padx=20)
  footer=tk.Frame(w,bg='#e5edf1',height=62);footer.pack(side='bottom',fill='x');footer.pack_propagate(False)
  main=tk.Frame(w,bg=bg);main.pack(fill='both',expand=True,padx=14,pady=12)
  nav=tk.Listbox(main,font=('Segoe UI',11),width=24,exportselection=False,activestyle='none');nav.pack(side='left',fill='y',padx=(0,12))
  pane=tk.Frame(main,bg='white',bd=1,relief='solid');pane.pack(side='left',fill='both',expand=True)
  tabs=['Barcode Scanner','Sales','Discounts','Payments','Receipts','Security','Display','Keyboard Shortcuts','Custom Actions','Customer Display','Register Operations','Backup']
  for tab in tabs:nav.insert('end',tab)
  cfg=load();vars={k:(tk.BooleanVar(value=v) if isinstance(v,bool) else tk.StringVar(value=str(v))) for k,v in cfg.items()}
  definitions={
   'Barcode Scanner': [('check','auto_scan','Enable auto-scan for standard numeric barcodes'),('entry','scan_delay','Auto-scan delay (milliseconds, 100–2000)'),('choice','scan_suffix','Scanner suffix',['Enter','Tab','None']),('info',None,'Receipt barcodes beginning with @ remain recognised by the Register. Barcode commands are protected.')],
   'Sales':[('entry','default_qty','Default quantity (1–999)'),('check','merge_scans','Merge duplicate product scans into one line'),('info',None,'Price override permissions are not connected yet; existing Edit Line behaviour remains unchanged.')],
   'Discounts':[('info',None,'Discount Centre is already available. Maximum percentage and manager approvals require integration before these settings can be enabled.')],
   'Payments':[('info',None,'Cash, simulated EFTPOS and split tender are already available. Rounding and hardware configuration are not connected in this build.')],
   'Receipts':[('info',None,'80mm and A4 receipt preview, logo and footer are configured in Business & Receipt Settings. Printer selection and automatic printing are not yet connected.')],
   'Security':[('info',None,'Staff PIN is disabled for TEST checkout. Live staff login, manager approvals and audit configuration are not enabled here.')],
   'Display':[('info',None,'Use Register Theme & Button Designer for backgrounds, button images, colours and button positions. Shared font/grid sizing is not yet configurable.')],
   'Keyboard Shortcuts':[('info',None,'Open the existing Keyboard Shortcut Manager to configure all built-in Register actions.')],
   'Custom Actions':[('info',None,'Open Custom Register Actions to create or edit multi-step shortcuts.')],
   'Backup':[('info',None,'Use the existing Backup & Restore tool to protect your test data.')],
   'Customer Display':[('info',None,'Secondary monitor customer display is planned but not yet implemented. No customer-facing display will be activated.')],
   'Register Operations':[('entry','register_id','Register ID'),('entry','opening_float','Opening cash float ($) — saved for future use'),('info',None,'End-of-day processing is not connected yet; saving a float does not post a cash movement.')]
  }
  def render(_=None):
   for child in pane.winfo_children():child.destroy()
   idx=nav.curselection();section=tabs[idx[0] if idx else 0]
   tk.Label(pane,text=section,bg='white',fg=navy,font=('Segoe UI',17,'bold')).pack(anchor='w',padx=22,pady=(18,15))
   links={'Keyboard Shortcuts':('OPEN KEYBOARD SHORTCUTS','shortcut_settings'),
          'Custom Actions':('OPEN CUSTOM ACTIONS','custom_action_settings'),
          'Receipts':('BUSINESS & RECEIPT SETTINGS',None),
          'Display':('OPEN THEME & BUTTON DESIGNER','register_customizer'),
          'Backup':('OPEN BACKUP & RESTORE','backup')}
   if section in links:
    label,method=links[section]
    def launch(method=method):
     if method is None:
      from receipt_business_v054 import edit_business
      w.grab_release();edit_business(self)
     else:
      w.grab_release();getattr(self,method)()
    tk.Button(pane,text=label,command=launch,bg='#50c1ce',font=('Segoe UI',11,'bold'),pady=10).pack(anchor='w',padx=22,pady=9)
   for spec in definitions[section]:
    kind,key,label=spec[:3]
    if kind=='info':tk.Label(pane,text=label,bg='#fff5df',fg='#674c1d',font=('Segoe UI',10),wraplength=580,justify='left',padx=14,pady=12).pack(fill='x',padx=22,pady=9);continue
    row=tk.Frame(pane,bg='white');row.pack(fill='x',padx=22,pady=9)
    if kind=='check':tk.Checkbutton(row,text=label,variable=vars[key],bg='white',font=('Segoe UI',11),anchor='w').pack(anchor='w')
    else:
     tk.Label(row,text=label,bg='white',font=('Segoe UI',10),anchor='w').pack(fill='x',pady=(0,4))
     if kind=='choice':ttk.Combobox(row,textvariable=vars[key],values=spec[3],state='readonly',width=26).pack(anchor='w')
     else:tk.Entry(row,textvariable=vars[key],font=('Segoe UI',11),width=34).pack(anchor='w')
  def save():
   try:
    delay=int(vars['scan_delay'].get());qty=int(vars['default_qty'].get())
    if not 100<=delay<=2000:raise ValueError('Scan delay must be between 100 and 2000 milliseconds.')
    if not 1<=qty<=999:raise ValueError('Default quantity must be between 1 and 999.')
    if not vars['register_id'].get().strip():raise ValueError('Register ID is required.')
    from decimal import Decimal
    cash=Decimal(vars['opening_float'].get())
    if not cash.is_finite() or cash<0:raise ValueError('Opening float must be a non-negative amount.')
    updated=dict(cfg)
    for key in ('auto_scan','merge_scans'):updated[key]=bool(vars[key].get())
    updated.update(scan_delay=delay,default_qty=qty,scan_suffix=vars['scan_suffix'].get(),register_id=vars['register_id'].get().strip(),opening_float=str(cash))
    PATH.parent.mkdir(parents=True,exist_ok=True);temp=PATH.with_suffix('.tmp');temp.write_text(json.dumps(updated,indent=2),encoding='utf-8');temp.replace(PATH)
    w.destroy()
   except (ValueError,OSError) as e:messagebox.showerror('Settings validation',str(e),parent=w)
  tk.Button(footer,text='CANCEL',command=w.destroy,width=13).pack(side='right',padx=12,pady=11)
  tk.Button(footer,text='SAVE SETTINGS',command=save,width=18,bg='#50c1ce',font=('Segoe UI',10,'bold')).pack(side='right',padx=4,pady=11)
  def defaults():
   for k,v in DEFAULT.items():vars[k].set(v)
   render()
  tk.Button(footer,text='RESTORE DEFAULTS',command=defaults,width=19).pack(side='left',padx=12,pady=11)
  nav.bind('<<ListboxSelect>>',render);nav.selection_set(0);render();w.grab_set()
 def settings(self):
  original_layout=self.layout
  def patched(title,items):
   if title=='SETTINGS & TOOLS':items=[('Register Settings',self.register_settings)]+list(items)
   return original_layout(title,items)
  self.layout=patched
  try:return old_settings(self)
  finally:self.layout=original_layout
 cls.settings=settings;cls.register_settings=register_settings;cls.add_to_cart=add_to_cart;cls.pos=pos
