Freedom POS v0.77 TEST — e-pay CSV Catalogue

Open Register > E-PAY > Products > Import e-pay CSV.
The included Product_epay_SAMPLE_IMPORT.csv is the supplied catalogue.
Import is explicit, not automatic. Products are stored in test_data/epay_catalog_v077.sqlite3.
Repeated imports update changed products without duplicates; import history is retained.
No product is added to normal stock or sold. Live e-pay integration is DISABLED.
No voucher activation, recharge, settlement, transaction or PIN issuance is possible.
Never treat the catalogue price as proof of a successful e-pay transaction.
