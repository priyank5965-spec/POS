"""Full-screen-style master record forms for test supplier and department records."""
import tkinter as tk
from tkinter import ttk
import sqlite3, re

BLUE='#12324A'; bg='white'

def install(cls):
 def ensure(self):
  self.db.executescript('''CREATE TABLE IF NOT EXISTS suppliers_master(id INTEGER PRIMARY KEY,name TEXT NOT NULL UNIQUE,code TEXT UNIQUE,contact TEXT DEFAULT '',phone TEXT DEFAULT '',mobile TEXT DEFAULT '',email TEXT DEFAULT '',abn TEXT DEFAULT '',address TEXT DEFAULT '',suburb TEXT DEFAULT '',state TEXT DEFAULT 'QLD',postcode TEXT DEFAULT '',terms TEXT DEFAULT '',account_number TEXT DEFAULT '',notes TEXT DEFAULT '',active INTEGER NOT NULL DEFAULT 1);
  CREATE TABLE IF NOT EXISTS departments_master(id INTEGER PRIMARY KEY,name TEXT NOT NULL UNIQUE,code TEXT NOT NULL UNIQUE,description TEXT DEFAULT '',gst TEXT DEFAULT 'GST 10%',markup TEXT DEFAULT '',label_policy TEXT DEFAULT 'Standard',notes TEXT DEFAULT '',active INTEGER NOT NULL DEFAULT 1);''')
  self.db.commit()
 def master_screen(self,kind):
  ensure(self)
  supplier=kind=='supplier'
  table='suppliers_master' if supplier else 'departments_master'
  fields=([('name','Supplier / Business Name *'),('code','Supplier Code'),('contact','Contact Person'),('phone','Phone'),('mobile','Mobile'),('email','Email'),('abn','ABN'),('account_number','Our Account Number'),('address','Street Address'),('suburb','Suburb'),('state','State'),('postcode','Postcode'),('terms','Payment Terms'),('notes','Notes')] if supplier else [('name','Department Name *'),('code','Department Code *'),('description','Description'),('gst','Default GST'),('markup','Default Markup %'),('label_policy','Label Policy'),('notes','Notes')])
  self.clear();self.header('SUPPLIER MANAGEMENT' if supplier else 'DEPARTMENT MANAGEMENT')
  toolbar=tk.Frame(self.root,bg=BG);toolbar.pack(fill='x',padx=12,pady=8)
  query=tk.StringVar();tk.Label(toolbar,text='SEARCH',bg=BG).pack(side='left');search=tk.Entry(toolbar,textvariable=query,width=28,font=('Segoe UI',11));search.pack(side='left',padx=8)
  t=self.tree(self.root,(['ID','Name','Code','Contact','Phone','Email','Status'] if supplier else ['ID','Name','Code','GST','Markup','Status']),height=14)
  def refresh(*_):
   for item in t.get_children():t.delete(item)
   needle='%'+query.get().strip()+'%'
   for r in self.db.execute(f'SELECT * FROM {table} WHERE name LIKE ? OR code LIKE ? ORDER BY name',(needle,needle)):
    values=(r['id'],r['name'],r['code'],r['contact'],r['phone'],r['email'],'Active' if r['active'] else 'Inactive') if supplier else (r['id'],r['name'],r['code'],r['gst'],r['markup'],'Active' if r['active'] else 'Inactive')
    t.insert('','end',iid=str(r['id']),values=values)
  def chosen():
   s=t.selection();return self.db.execute(f'SELECT * FROM {table} WHERE id=?',(int(s[0]),)).fetchone() if s else None
  def form(row=None):
   w=tk.Toplevel(self.root);w.title(('Edit ' if row else 'Add ')+('Supplier' if supplier else 'Department'));w.geometry('1000x740' if supplier else '920x580');w.minsize(760,520);w.transient(self.root);w.grab_set()
   banner=tk.Frame(w,bg='white');banner.pack(fill='x');tk.Label(banner,text=('SUPPLIER DETAILS' if supplier else 'DEPARTMENT DETAILS'),bg='white',fg='#111111',font=('Segoe UI',17,'bold'),padx=20,pady=12).pack(anchor='w')
   body=tk.Frame(w,padx=20,pady=12);body.pack(fill='both',expand=True)
   entries={}
   for i,(key,label) in enumerate(fields):
    col=(i%2)*2;rr=i//2
    tk.Label(body,text=label,font=('Segoe UI',10,'bold')).grid(row=rr,column=col,sticky='w',padx=(4,10),pady=9)
    var=tk.StringVar(value=str(row[key] or '') if row else ('QLD' if key=='state' else 'GST 10%' if key=='gst' else 'Standard' if key=='label_policy' else ''))
    if key in ('gst','label_policy'):
     options=['GST 10%','GST Free','Input Taxed'] if key=='gst' else ['Standard','No ordinary labels','Putaway only']
     widget=ttk.Combobox(body,textvariable=var,values=options,state='readonly')
    else:widget=tk.Entry(body,textvariable=var,font=('Segoe UI',11))
    widget.grid(row=rr,column=col+1,sticky='ew',padx=(0,18),pady=7)
    entries[key]=var
   body.columnconfigure(1,weight=1);body.columnconfigure(3,weight=1)
   active=tk.IntVar(value=int(row['active']) if row else 1)
   tk.Checkbutton(body,text='Active',variable=active,font=('Segoe UI',11)).grid(row=(len(fields)+1)//2,column=0,columnspan=2,sticky='w',pady=10)
   error=tk.StringVar();tk.Label(w,textvariable=error,fg='#a51b1b',font=('Segoe UI',10,'bold')).pack(anchor='w',padx=25)
   actions=tk.Frame(w,padx=20,pady=15);actions.pack(fill='x',side='bottom')
   def save():
    data={key:v.get().strip() for key,v in entries.items()}
    if not data['name']:error.set('Name is required.');return
    if not supplier and not data['code']:error.set('Department code is required.');return
    if data.get('email') and not re.fullmatch(r'[^\s@]+@[^\s@]+\.[^\s@]+',data['email']):error.set('Invalid email address.');return
    if data.get('postcode') and not re.fullmatch(r'\d{4}',data['postcode']):error.set('Postcode must be four digits.');return
    if data.get('abn') and not re.fullmatch(r'\d{11}',re.sub(r'\s','',data['abn'])):error.set('ABN must have 11 digits.');return
    if data.get('markup'):
     try:
      if not 0<=float(data['markup'])<=1000:raise ValueError()
     except ValueError:error.set('Markup must be a number between 0 and 1000.');return
    cols=list(data)
    try:
     with self.db:
      if row:self.db.execute(f'UPDATE {table} SET '+','.join(f'{k}=?' for k in cols)+',active=? WHERE id=?',[data[k] for k in cols]+[active.get(),row['id']])
      else:self.db.execute(f'INSERT INTO {table} ('+','.join(cols)+',active) VALUES ('+','.join('?' for _ in cols)+',?)',[data[k] for k in cols]+[active.get()])
     self.log('MASTER DATA',f'{"Updated" if row else "Created"} {kind}: {data["name"]}');w.destroy();refresh()
    except sqlite3.IntegrityError:error.set('Duplicate name or code. Please use a unique value.')
    except Exception as exc:error.set('Unable to save: '+str(exc))
   tk.Button(actions,text='SAVE '+('SUPPLIER' if supplier else 'DEPARTMENT'),command=save,bg='white',fg='#111111',font=('Segoe UI',11,'bold'),padx=16,pady=9).pack(side='right',padx=5)
   tk.Button(actions,text='CANCEL',command=w.destroy,font=('Segoe UI',11),padx=16,pady=9).pack(side='right',padx=5)
   w.bind('<Escape>',lambda _:w.destroy())
  self.btn(toolbar,'ADD '+('SUPPLIER' if supplier else 'DEPARTMENT'),lambda:form(),size=10,height=1).pack(side='left',padx=4)
  self.btn(toolbar,'EDIT SELECTED',lambda:form(r) if (r:=chosen()) else None,size=10,height=1).pack(side='left',padx=4)
  t.bind('<Double-1>',lambda _:form(r) if (r:=chosen()) else None)
  query.trace_add('write',refresh);refresh()
  tk.Label(self.root,text='TEST ONLY • Supplier and department master records are saved locally. Automatic links to products and invoices are not yet complete.',bg=BG,fg='#98511a').pack(pady=8)
 def suppliers(self):return master_screen(self,'supplier')
 def departments(self):return master_screen(self,'department')
 old_products=cls.products
 old_purchasing=cls.purchasing
 def products(self):
  old_products(self)
  self.btn(self.root,'DEPARTMENT MANAGEMENT',self.departments,size=10,height=1).pack(pady=4)
 def purchasing(self):
  old_purchasing(self)
  self.btn(self.root,'SUPPLIER MANAGEMENT',self.suppliers,size=10,height=1).pack(pady=4)
 cls.suppliers=suppliers;cls.departments=departments;cls.products=products;cls.purchasing=purchasing
