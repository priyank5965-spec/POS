Freedom POS 2.0 v0.39 TEST ONLY
Register: 50/50 sales grid / shortcut grid initial split, user-resizable sash.
Discount Centre: new touchscreen UI, keypad, live preview, same underlying calculations.
Known limitations: live EFTPOS, Windows touchscreen, printer and GST verification not performed.
Do not use for real transactions.
