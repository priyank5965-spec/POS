Freedom POS 2.0 v0.20 — Register foundation test

Changes:
- Discount opens a full form with amount/percentage, live preview and validation.
- Both CASH PAYMENT and CASH TENDER open the cash tender screen.
- Cash tendered and change are recorded in payments.note, while payments.amount remains the actual sale amount.
- One cash confirmation (no duplicate confirmation popup).

Limitations: TEST DATA ONLY. No Linkly, cash drawer or physical receipt printer. No completed staff PIN, account ageing, or line discounts.
Extract in a new folder, run START_FREEDOM_POS.bat, Point of Sale.
