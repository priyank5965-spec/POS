"""v0.40 UI theme and navigation: no database/business logic modifications."""
import tkinter as tk
from tkinter import ttk
NAVY='#12324A'; TEAL='#51BDCB'; BG='#FFFFFF'; WHITE='#FFFFFF'; MUTED='#637889'

def install(cls):
    original_init=cls.__init__
    def init(self,root):
        original_init(self,root)
        root.title('Freedom POS 2.0 — Modern UI v0.40 — TEST ONLY')
        style=ttk.Style(root)
        style.configure('Treeview',font=('Segoe UI',11,'bold'),rowheight=38,background=WHITE,foreground='#000000',fieldbackground=WHITE,borderwidth=0)
        style.configure('Treeview.Heading',font=('Segoe UI',11,'bold'),background='#DDE7EC',foreground='#000000',padding=(8,10))
        style.map('Treeview',background=[('selected',TEAL)],foreground=[('selected','#000000')])
        style.configure('TNotebook.Tab',font=('Segoe UI',10,'bold'),padding=(14,10))
        style.configure('TEntry',padding=6)
        style.configure('TCombobox',padding=6)
    cls.__init__=init

    def make_tile(parent,title,command,accent=False):
        tile=tk.Frame(parent,bg=WHITE,highlightbackground='#D4E1E8',highlightthickness=1,cursor='hand2')
        line=tk.Frame(tile,bg=TEAL if accent else NAVY,height=5);line.pack(fill='x')
        label=tk.Label(tile,text=title,bg=WHITE,fg=NAVY,font=('Segoe UI',15,'bold'),wraplength=240,cursor='hand2')
        label.pack(fill='both',expand=True,padx=14,pady=12)
        for widget in (tile,line,label):widget.bind('<Button-1>',lambda e,fn=command:fn())
        return tile

    def home(self):
        self.clear()
        self.root.configure(bg=BG)
        banner=tk.Frame(self.root,bg=NAVY,height=105);banner.pack(fill='x');banner.pack_propagate(False)
        tk.Label(banner,text='FREEDOM POS 2.0',bg=NAVY,fg=WHITE,font=('Segoe UI',25,'bold')).pack(anchor='w',padx=26,pady=(17,0))
        tk.Label(banner,text='RETAIL MANAGEMENT  /  TEST ONLY',bg=NAVY,fg='#8EDCE2',font=('Segoe UI',11,'bold')).pack(anchor='w',padx=28,pady=(1,8))
        notice=tk.Frame(self.root,bg='#E2F4F4',height=46);notice.pack(fill='x',padx=22,pady=(17,6))
        tk.Label(notice,text='OFFLINE TEST DATA ONLY  •  NO LIVE EFTPOS OR LOTTERY INTEGRATION',bg='#E2F4F4',fg=NAVY,font=('Segoe UI',10,'bold')).pack(anchor='w',padx=16,pady=12)
        content=tk.Frame(self.root,bg=BG);content.pack(fill='both',expand=True,padx=22,pady=(8,12))
        modules=[('POINT OF SALE','Point of Sale'),('STOCK MANAGEMENT','Products & Stock'),('PURCHASING','Purchasing'),('NEWSAGENCY','Newsagency'),('CUSTOMERS','Customers'),('SALES & REPORTS','Sales & Reports'),('ORDERS & INVOICES','Orders & Invoices'),('MANAGEMENT','Management'),('SETTINGS','Settings & Tools')]
        for i,(label,key) in enumerate(modules):
            make_tile(content,label,lambda n=key:self.module(n),i==0).grid(row=i//3,column=i%3,sticky='nsew',padx=8,pady=8)
        for i in range(3):content.columnconfigure(i,weight=1);content.rowconfigure(i,weight=1)
        tk.Label(self.root,text='v0.40  •  UI TEST BUILD  •  Keep all real transactions outside this prototype',bg=BG,fg=MUTED,font=('Segoe UI',10)).pack(pady=(0,10))
    cls.home=home

    def layout(self,title,buttons):
        self.clear();self.root.configure(bg=BG)
        header=tk.Frame(self.root,bg=NAVY,height=80);header.pack(fill='x');header.pack_propagate(False)
        tk.Label(header,text=title.upper(),bg=NAVY,fg=WHITE,font=('Segoe UI',21,'bold')).pack(side='left',padx=25,pady=18)
        tk.Button(header,text='HOME',command=self.home,bg=WHITE,fg=NAVY,font=('Segoe UI',11,'bold'),padx=22,pady=7,relief='flat').pack(side='right',padx=20)
        grid=tk.Frame(self.root,bg=BG);grid.pack(fill='both',expand=True,padx=22,pady=22)
        for i,(label,fn) in enumerate(buttons):make_tile(grid,label,fn).grid(row=i//3,column=i%3,sticky='nsew',padx=9,pady=9)
        for col in range(3):grid.columnconfigure(col,weight=1)
        for row in range((len(buttons)+2)//3):grid.rowconfigure(row,weight=1)
    cls.layout=layout

    original_header=cls.header
    def header(self,title):
        original_header(self,title)
        # Retain register header and all working navigation handlers.
    cls.header=header

    original_btn=cls.btn
    def btn(self,parent,title,fn,**kw):
        button=original_btn(self,parent,title,fn,**kw)
        button.configure(relief='raised',bd=1,bg='#E8ECEF',fg='#111111',highlightthickness=1,highlightbackground='#9AA5AF',activebackground='#CFD9E2',activeforeground='#111111',padx=12,pady=7)
        return button
    cls.btn=btn
