Freedom POS 2.0 v0.64 — TEST ONLY

Stock screen: fixed bottom action bar; Add New Product (existing full form), Save Product, Cancel Changes, Adjust Stock, Add Barcode and Sell Selected. Unknown barcode search no longer suggests unrelated sample products; unique exact matches auto-select.
Register Settings: access to Keyboard Shortcuts, Custom Actions, Receipt Business Settings, Theme Designer and Backup. Existing settings preserved.

LIMITATIONS: Delete/deactivate, duplicate, print label and supplier arrivals posting are not implemented in this build. These have not been exposed as non-working buttons. No live EFTPOS. Windows GUI and end-to-end workflows not verified.
