Freedom POS 2.0 Register Numeric Scanner + Stock Shortcut v0.31 — TEST ONLY

Register scanner field accepts ASCII digits 0-9 only (including pasted text).
Shift+/ (?) opens Stock Lookup while the register is active, even when the
scanner field is focused. The register design remains unchanged.

IMPORTANT: This is a numeric-only test configuration. Alphanumeric SKU scans,
PLU prefixes, and scanner control sequences other than Enter are not supported
in the register entry field. Search alphanumeric SKUs in Stock Lookup instead.

Retains automatic barcode detection and existing lookup/quick-add workflow.
Staff PIN remains bypassed in test mode. No live EFTPOS testing performed.
