import sqlite3
import unittest
from linkly_payment_v111 import setup,get,set_value,simulate

class EFTTests(unittest.TestCase):
 def setUp(self):
  self.db=sqlite3.connect(':memory:');setup(self.db)
 def tearDown(self):self.db.close()
 def test_default(self):self.assertEqual(get(self.db,'mode'),'LINKLY TRAINING')
 def test_outcomes(self):
  set_value(self.db,'mode','TEST')
  for outcome in ('APPROVED','DECLINED','CANCELLED','TIMEOUT','CONNECTION LOST'):
   set_value(self.db,'next_outcome',outcome)
   _,actual=simulate(self.db,1234)
   self.assertEqual(actual,outcome)
  self.assertEqual(self.db.execute('SELECT COUNT(*) FROM eft_test_attempts').fetchone()[0],5)
 def test_live_blocks(self):
  set_value(self.db,'mode','LIVE')
  with self.assertRaises(RuntimeError):simulate(self.db,100)
 def test_bad_amount(self):
  set_value(self.db,'mode','TEST')
  with self.assertRaises(ValueError):simulate(self.db,0)
 def test_refund_is_only_a_simulation(self):
  set_value(self.db,'mode','TEST')
  attempt,outcome=simulate(self.db,250,'REFUND')
  self.assertEqual(self.db.execute('SELECT transaction_type FROM eft_test_attempts WHERE id=?',(attempt,)).fetchone()[0],'REFUND')

if __name__=='__main__':unittest.main()
