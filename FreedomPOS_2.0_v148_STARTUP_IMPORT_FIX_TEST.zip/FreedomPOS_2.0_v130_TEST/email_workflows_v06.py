"""Customer PDF and SMTP workflows for offline Freedom POS test. No automatic emails."""
import json, os, re, smtplib, ssl, datetime
from pathlib import Path
from email.message import EmailMessage
from tkinter import ttk, messagebox, simpledialog
import tkinter as tk
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle
from reportlab.lib import colors
from reportlab.lib.styles import getSampleStyleSheet
from reportlab.lib.pagesizes import A4
from xml.sax.saxutils import escape

DEFAULT={'sender':'','sender_name':'Freedom POS','host':'smtp.gmail.com','port':'465','security':'SSL/TLS','reply_to':'','business_name':'','abn':'','payment_details':'','signature':'','owner_email':''}

def install(cls):
 old_init=cls.__init__;old_settings=cls.settings;old_customers=cls.customers;old_orders=cls.orders
 def init(self,root):
  self.smtp_password=None
  old_init(self,root)
  self.db.execute('CREATE TABLE IF NOT EXISTS customer_emails(customer_id INTEGER PRIMARY KEY,email TEXT NOT NULL DEFAULT \'\')')
  self.db.execute('CREATE TABLE IF NOT EXISTS email_history(id INTEGER PRIMARY KEY,created TEXT NOT NULL,customer_id INTEGER,recipient TEXT NOT NULL,kind TEXT NOT NULL,status TEXT NOT NULL,detail TEXT NOT NULL DEFAULT \'\',file TEXT NOT NULL DEFAULT \'\')')
  self.db.commit()
  self.mail_cfg_path=Path(__file__).resolve().parent/'test_data'/'email_settings.json'
  self.mail_cfg=DEFAULT.copy()
  if self.mail_cfg_path.exists():
   try:self.mail_cfg.update({k:v for k,v in json.loads(self.mail_cfg_path.read_text(encoding='utf8')).items() if k in DEFAULT})
   except (OSError,ValueError):pass
 def settings(self):
  old_settings(self)
  self.btn(self.root,'EMAIL SETTINGS',self.email_settings,size=11,height=1).pack(pady=5)
 def orders(self):
  old_orders(self)
  self.btn(self.root,'CUSTOMER INVOICES & STATEMENTS',self.customer_email_center,size=11,height=1).pack(pady=5)
 def customers(self):
  old_customers(self)
  self.btn(self.root,'EMAIL INVOICES / STATEMENTS',self.customer_email_center,size=10,height=1).pack(pady=5)
 def email_settings(self):
  w=tk.Toplevel(self.root);w.title('EMAIL SETTINGS — TEST ONLY');w.geometry('780x720');w.transient(self.root)
  outer=tk.Frame(w);outer.pack(fill='both',expand=True,padx=18,pady=12)
  tk.Label(outer,text='EMAIL SETTINGS  •  SMTP',font=('Segoe UI',17,'bold')).pack(anchor='w')
  tk.Label(outer,text='Gmail: smtp.gmail.com / 465 SSL/TLS or 587 STARTTLS. Use a Google App Password, never your normal password.\nPassword is held in memory only; enter it again after restarting. No email is sent without clicking Send.',justify='left',fg='#8a381c').pack(anchor='w',pady=6)
  fields=[('sender','Sender email'),('sender_name','Sender name'),('host','SMTP server'),('port','SMTP port'),('security','Encryption: SSL/TLS or STARTTLS'),('reply_to','Reply-to email (optional)'),('business_name','Business legal name'),('abn','ABN'),('payment_details','Payment / banking instructions'),('signature','Email signature'),('owner_email','Owner notification email'),('test_recipient','Test email recipient')]
  vars={}
  for key,label in fields:
   row=tk.Frame(outer);row.pack(fill='x',pady=2)
   tk.Label(row,text=label,width=31,anchor='w').pack(side='left')
   var=tk.StringVar(value=str(self.mail_cfg.get(key,'')));vars[key]=var
   tk.Entry(row,textvariable=var).pack(side='left',fill='x',expand=True)
  row=tk.Frame(outer);row.pack(fill='x',pady=8)
  tk.Label(row,text='Gmail App Password (session only)',width=31,anchor='w').pack(side='left')
  password=tk.StringVar(value=self.smtp_password or '')
  tk.Entry(row,textvariable=password,show='*').pack(side='left',fill='x',expand=True)
  def save():
   cfg={k:v.get().strip() for k,v in vars.items()}
   if cfg['security'] not in ('SSL/TLS','STARTTLS'):return messagebox.showerror('Encryption','Choose SSL/TLS or STARTTLS',parent=w)
   try:port=int(cfg['port']);assert 1<=port<=65535
   except (ValueError,AssertionError):return messagebox.showerror('Port','Invalid SMTP port',parent=w)
   self.mail_cfg=cfg;self.smtp_password=password.get().replace(' ','') or None
   self.mail_cfg_path.parent.mkdir(exist_ok=True)
   self.mail_cfg_path.write_text(json.dumps(cfg,indent=2),encoding='utf8')
   try:os.chmod(self.mail_cfg_path,0o600)
   except OSError:pass
   self.log('EMAIL SETTINGS','Non-secret email settings updated')
   messagebox.showinfo('Saved','SMTP settings saved. Password remains in memory only.',parent=w)
  def test():
   save()
   target=vars['test_recipient'].get().strip() or self.mail_cfg['sender']
   if not target:return
   try:
    send(self,'TEST',target,'Freedom POS test email','SMTP test message. No customer information.',None,None)
    messagebox.showinfo('Test sent','SMTP server accepted the test message.',parent=w)
   except Exception as exc:messagebox.showerror('Email failed',str(exc),parent=w)
  row=tk.Frame(outer);row.pack(pady=10)
  tk.Button(row,text='SAVE SETTINGS',command=save).pack(side='left',padx=5)
  tk.Button(row,text='SEND TEST EMAIL',command=test).pack(side='left',padx=5)
  tk.Button(row,text='EMAIL HISTORY',command=self.email_history).pack(side='left',padx=5)
 def customer_email_center(self):
  w=tk.Toplevel(self.root);w.title('CUSTOMER INVOICES & STATEMENTS — TEST');w.geometry('920x650')
  tk.Label(w,text='CUSTOMER INVOICES & STATEMENTS',font=('Segoe UI',16,'bold')).pack(pady=8)
  tk.Label(w,text='Choose a customer. Invoices are generated from completed account sales; statements use recorded account sales and payments.\nReview the PDF before emailing. Do not use this test build for live customer billing.',fg='#8a381c',justify='left').pack(pady=4)
  t=ttk.Treeview(w,columns=('ID','Customer','Email','Balance'),show='headings',height=13)
  for c,width in [('ID',65),('Customer',270),('Email',300),('Balance',140)]:t.heading(c,text=c);t.column(c,width=width)
  t.pack(fill='both',expand=True,padx=12,pady=8)
  def refresh():
   t.delete(*t.get_children())
   for r in self.db.execute('SELECT c.id,c.name,c.balance,COALESCE(e.email,\'\') email FROM customers c LEFT JOIN customer_emails e ON c.id=e.customer_id ORDER BY c.name'):
    t.insert('','end',iid=str(r['id']),values=(r['id'],r['name'],r['email'],f'${r["balance"]/100:.2f}'))
  def selected():
   if not t.selection():messagebox.showwarning('Select customer','Select a customer first',parent=w);return None
   return int(t.selection()[0])
  def edit_email():
   cid=selected()
   if cid is None:return
   row=self.db.execute('SELECT email FROM customer_emails WHERE customer_id=?',(cid,)).fetchone()
   value=simpledialog.askstring('Customer email','Customer email address:',initialvalue=row['email'] if row else '',parent=w)
   if value is None:return
   if value.strip() and not valid_email(value.strip()):return messagebox.showerror('Invalid email','Enter a valid email address.',parent=w)
   with self.db:self.db.execute('INSERT INTO customer_emails(customer_id,email) VALUES(?,?) ON CONFLICT(customer_id) DO UPDATE SET email=excluded.email',(cid,value.strip()))
   self.log('CUSTOMER EMAIL',f'Customer {cid} email updated');refresh()
  def do_document(kind,send_now=False):
   cid=selected()
   if cid is None:return
   sales=self.db.execute("SELECT id,created,total FROM sales WHERE customer_id=? AND kind='SALE' AND payment='ACCOUNT' AND voided=0 ORDER BY id DESC",(cid,)).fetchall()
   if kind=='INVOICE':
    if not sales:return messagebox.showwarning('No invoices','No completed account sale available for this customer.',parent=w)
    choices=', '.join(str(r['id']) for r in sales[:20]);sid=simpledialog.askinteger('Invoice','Account sale receipt number (available: '+choices+'):',initialvalue=sales[0]['id'],parent=w)
    if sid is None:return
    if sid not in [r['id'] for r in sales]:return messagebox.showerror('Invoice','Select a completed account sale for this customer.',parent=w)
   else:sid=None
   try:path=build_pdf(self,cid,kind,sid)
   except Exception as exc:return messagebox.showerror('PDF error',str(exc),parent=w)
   if not send_now:
    messagebox.showinfo('PDF created',f'PDF created at:\n{path}\n\nReview the PDF before sending.',parent=w)
    try:os.startfile(str(path))
    except (AttributeError,OSError):pass
    return
   recipient=self.db.execute('SELECT email FROM customer_emails WHERE customer_id=?',(cid,)).fetchone()
   if not recipient or not valid_email(recipient['email']):return messagebox.showerror('Email missing','Add a valid customer email address first. PDF saved locally.',parent=w)
   if not messagebox.askyesno('Confirm email',f'Send {kind.lower()} PDF to {recipient["email"]}?\n\nFile: {path.name}',parent=w):return
   try:
    send(self,kind,recipient['email'],f'{self.mail_cfg["business_name"] or "Freedom POS"} {kind.title()}',f'Please find your {kind.lower()} attached.\n\n{self.mail_cfg["signature"]}',path,cid)
    messagebox.showinfo('Sent','SMTP server accepted the email. Delivery to inbox is not guaranteed.',parent=w)
   except Exception as exc:messagebox.showerror('Email not sent',str(exc),parent=w)
  bar=tk.Frame(w);bar.pack(pady=10)
  for label,fn in [('EDIT EMAIL',edit_email),('PREVIEW INVOICE',lambda:do_document('INVOICE')),('EMAIL INVOICE',lambda:do_document('INVOICE',True)),('PREVIEW STATEMENT',lambda:do_document('STATEMENT')),('EMAIL STATEMENT',lambda:do_document('STATEMENT',True))]:tk.Button(bar,text=label,command=fn).pack(side='left',padx=3)
  refresh()
 def email_history(self):
  w=tk.Toplevel(self.root);w.title('EMAIL HISTORY — SMTP ACCEPTANCE');w.geometry('1000x500')
  t=ttk.Treeview(w,columns=('Date','Recipient','Type','Status','Detail'),show='headings')
  for col,width in [('Date',160),('Recipient',210),('Type',100),('Status',110),('Detail',380)]:t.heading(col,text=col);t.column(col,width=width)
  t.pack(fill='both',expand=True)
  for r in self.db.execute('SELECT created,recipient,kind,status,detail FROM email_history ORDER BY id DESC LIMIT 500'):t.insert('','end',values=tuple(r))
 cls.__init__=init;cls.settings=settings;cls.orders=orders;cls.customers=customers;cls.email_settings=email_settings;cls.customer_email_center=customer_email_center;cls.email_history=email_history

def valid_email(s):return bool(re.fullmatch(r'[^\s@]+@[^\s@]+\.[^\s@]+',s or ''))

def send(app,kind,recipient,subject,body,attachment,cid):
 cfg=app.mail_cfg
 if not valid_email(cfg['sender']) or not valid_email(recipient):raise ValueError('Configure valid sender and recipient email addresses')
 if not app.smtp_password:raise ValueError('Open Email Settings and enter the Google App Password for this session')
 msg=EmailMessage();msg['From']=f'{cfg["sender_name"]} <{cfg["sender"]}>' if cfg['sender_name'] else cfg['sender'];msg['To']=recipient;msg['Subject']=subject
 if cfg['reply_to'] and valid_email(cfg['reply_to']):msg['Reply-To']=cfg['reply_to']
 msg.set_content(body)
 if attachment:
  msg.add_attachment(Path(attachment).read_bytes(),maintype='application',subtype='pdf',filename=Path(attachment).name)
 try:
  host=cfg['host'];port=int(cfg['port']);context=ssl.create_default_context()
  if cfg['security']=='SSL/TLS':
   with smtplib.SMTP_SSL(host,port,timeout=15,context=context) as smtp:smtp.login(cfg['sender'],app.smtp_password);smtp.send_message(msg)
  elif cfg['security']=='STARTTLS':
   with smtplib.SMTP(host,port,timeout=15) as smtp:smtp.ehlo();smtp.starttls(context=context);smtp.ehlo();smtp.login(cfg['sender'],app.smtp_password);smtp.send_message(msg)
  else:raise ValueError('Unencrypted SMTP is not supported')
  status,detail='ACCEPTED','SMTP server accepted message (not proof of inbox delivery)'
 except Exception as exc:
  status,detail='FAILED',str(exc)[:350]
  with app.db:app.db.execute('INSERT INTO email_history(created,customer_id,recipient,kind,status,detail,file) VALUES(?,?,?,?,?,?,?)',(datetime.datetime.now().isoformat(timespec='seconds'),cid,recipient,kind,status,detail,str(attachment or '')))
  raise
 with app.db:app.db.execute('INSERT INTO email_history(created,customer_id,recipient,kind,status,detail,file) VALUES(?,?,?,?,?,?,?)',(datetime.datetime.now().isoformat(timespec='seconds'),cid,recipient,kind,status,detail,str(attachment or '')))
 app.log('EMAIL',f'{kind} to {recipient}: SMTP accepted')

def build_pdf(app,cid,kind,sid=None):
 customer=app.db.execute('SELECT * FROM customers WHERE id=?',(cid,)).fetchone()
 if not customer:raise ValueError('Customer not found')
 archive=Path(__file__).resolve().parent/'test_data'/'customer_pdf_archive';archive.mkdir(parents=True,exist_ok=True)
 stamp=datetime.datetime.now().strftime('%Y%m%d_%H%M%S_%f')
 path=archive/f'{kind}_Customer{cid}_{sid or "account"}_{stamp}.pdf'
 styles=getSampleStyleSheet();story=[]
 def para(txt,style='Normal'):story.append(Paragraph(escape(str(txt)),styles[style]));story.append(Spacer(1,8))
 para(app.mail_cfg['business_name'] or 'Freedom POS — TEST DOCUMENT','Title')
 if app.mail_cfg['abn']:para('ABN: '+app.mail_cfg['abn'])
 para(kind.title()+' — TEST DATA ONLY','Heading2');para('Customer: '+customer['name']);para('Generated: '+datetime.datetime.now().strftime('%d/%m/%Y %H:%M'))
 def addtable(rows):
  table=Table(rows,repeatRows=1,hAlign='LEFT',colWidths=[115,250,90,80]);table.setStyle(TableStyle([('BACKGROUND',(0,0),(-1,0),colors.lightgrey),('GRID',(0,0),(-1,-1),.3,colors.grey),('VALIGN',(0,0),(-1,-1),'TOP'),('FONTSIZE',(0,0),(-1,-1),8),('BOTTOMPADDING',(0,0),(-1,-1),7)]));story.append(table)
 if kind=='INVOICE':
  sale=app.db.execute("SELECT * FROM sales WHERE id=? AND customer_id=? AND kind='SALE' AND payment='ACCOUNT' AND voided=0",(sid,cid)).fetchone()
  if not sale:raise ValueError('Invoice source sale not found')
  para(f'Account sale receipt: {sid} | Sale date: {sale["created"]}')
  rows=[['Item','Description','Qty','Amount']]
  for r in app.db.execute('SELECT description,qty,unit FROM lines WHERE sale_id=?',(sid,)):
   rows.append(['',r['description'][:65],str(r['qty']),f'${r["qty"]*r["unit"]/100:.2f}'])
  addtable(rows);para(f'Original sale total: ${sale["total"]/100:.2f}')
  para('This test document is a copy of an account sale, not an issued tax invoice. GST breakdown and invoice numbering are not yet verified.')
 else:
  rows=[['Date','Transaction','Reference','Amount']]
  for r in app.db.execute("SELECT created,id,total FROM sales WHERE customer_id=? AND kind='SALE' AND payment='ACCOUNT' AND voided=0 ORDER BY created,id",(cid,)):
   rows.append([r['created'][:10],'Account sale',str(r['id']),f'${r["total"]/100:.2f}'])
  for r in app.db.execute('SELECT created,id,amount,method FROM payments WHERE customer_id=? AND sale_id IS NULL ORDER BY created,id',(cid,)):
   rows.append([r['created'][:10],f'Payment ({r["method"]})',str(r['id']),f'-${r["amount"]/100:.2f}'])
  addtable(rows)
  para(f'Current account balance: ${customer["balance"]/100:.2f} (negative means credit)')
  para('TEST STATEMENT: no opening balance reconciliation, date-range selection, reversals or delivery charges verification.')
 if app.mail_cfg['payment_details']:para('Payment details: '+app.mail_cfg['payment_details'])
 SimpleDocTemplate(str(path),pagesize=A4,rightMargin=35,leftMargin=35,topMargin=35,bottomMargin=35).build(story)
 return path
