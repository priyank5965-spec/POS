"""Shared window size guard for Freedom POS 2.0 TEST ONLY.
Clamp requested dimensions and minimums to the actual screen work area.
This does not replace layout management inside individual forms.
"""
import re
import tkinter as tk

_installed=False

def install():
    global _installed
    if _installed:return
    _installed=True
    original_geometry=tk.Toplevel.geometry
    original_minsize=tk.Toplevel.minsize
    original_init=tk.Toplevel.__init__
    def available(w):
        try:
            sw=max(480,int(w.winfo_screenwidth()))
            sh=max(360,int(w.winfo_screenheight()))
            # Conservative Windows taskbar allowance; do not occupy the last screen rows.
            return max(480,sw-24),max(360,sh-100)
        except tk.TclError:return 1024,640
    def geometry(self,newGeometry=None):
        if newGeometry is None:return original_geometry(self)
        if isinstance(newGeometry,str):
            m=re.match(r'^(\d+)x(\d+)([+-]\d+[+-]\d+)?$',newGeometry)
            if m:
                maxw,maxh=available(self)
                w=min(int(m.group(1)),maxw);h=min(int(m.group(2)),maxh)
                # Always center dialogs inside the visible work area.
                x=max(0,(self.winfo_screenwidth()-w)//2)
                y=max(0,(self.winfo_screenheight()-100-h)//2)
                newGeometry=f'{w}x{h}+{x}+{y}'
        return original_geometry(self,newGeometry)
    def minsize(self,width=None,height=None):
        if width is None and height is None:return original_minsize(self)
        maxw,maxh=available(self)
        return original_minsize(self,min(int(width),maxw),min(int(height),maxh))
    def init(self,*args,**kwargs):
        original_init(self,*args,**kwargs)
        # Never allow a hard-coded minimum larger than the display.
        maxw,maxh=available(self)
        original_minsize(self,1,1)
        self._freedom_screen_limit=(maxw,maxh)
    tk.Toplevel.__init__=init
    tk.Toplevel.geometry=geometry
    tk.Toplevel.minsize=minsize
