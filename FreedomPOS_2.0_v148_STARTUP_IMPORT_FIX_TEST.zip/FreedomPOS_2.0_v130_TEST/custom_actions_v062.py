"""User-created, bounded Register actions. TEST ONLY. No automatic checkout/refund."""
import json, re, tkinter as tk
from tkinter import ttk, messagebox
from pathlib import Path
from register_keyboard_v060 import canonical, from_event, load as load_builtin

PATH=Path(__file__).resolve().parent/'custom_actions_v062.json'
TYPES={'Open department':'department','Open stock lookup':'stock','Open last receipt':'receipt','Add product by barcode':'product'}

def load_actions():
    try:
        data=json.loads(PATH.read_text(encoding='utf-8'))
        if not isinstance(data,list):return []
        return [x for x in data if isinstance(x,dict) and isinstance(x.get('name'),str) and isinstance(x.get('steps'),list)][:100]
    except (OSError,ValueError):return []

def check(actions,builtin=None):
    seen={v:k for k,v in (builtin or load_builtin()).items() if v}
    names=set()
    for a in actions:
        name=str(a.get('name','')).strip()
        if not name or len(name)>60:raise ValueError('Action name must be 1–60 characters.')
        if name.casefold() in names:raise ValueError('Duplicate action name: '+name)
        names.add(name.casefold())
        shortcut=canonical(a.get('shortcut',''))
        if shortcut in seen:raise ValueError(f'{shortcut} is already assigned to {seen[shortcut]}')
        if shortcut:seen[shortcut]=name
        steps=a.get('steps',[])
        if not steps or len(steps)>12:raise ValueError(name+': choose 1–12 steps.')
        for step in steps:
            if not isinstance(step,dict) or step.get('type') not in TYPES.values():raise ValueError(name+': invalid step type.')
            if step['type']=='product':
                code=str(step.get('barcode','')).strip()
                if not code or len(code)>100 or code.startswith(('@','~')):raise ValueError(name+': enter a valid product barcode (not a receipt barcode).')
                try:qty=int(step.get('qty',1))
                except (ValueError,TypeError):raise ValueError(name+': invalid quantity.')
                if not 1<=qty<=9999:raise ValueError(name+': quantity must be 1–9999.')
    return True

def run_action(app,action):
    # Validate the whole sequence before running; no payments or stock mutations outside the normal cart path.
    check([action],{})
    steps=action['steps']
    # Dialog-opening steps must be last so that a subsequent step never runs behind an open popup.
    if any(s['type']!='product' for s in steps[:-1]):
        messagebox.showwarning('Custom action','Opening a window must be the final step in a multi-step action.',parent=app.root);return
    for step in steps:
        kind=step['type']
        if kind=='product':
            product=app.product_by_code(str(step['barcode']).strip())
            if not product:
                messagebox.showwarning('Product not found',f"Barcode {step['barcode']} is not in the product catalogue.",parent=app.root);return
            app.add_to_cart(product,qty=int(step.get('qty',1)))
        elif kind=='department':app.register_departments()
        elif kind=='stock':app.stock_lookup()
        elif kind=='receipt':app.last_receipt()

def install(cls):
    old_pos=cls.pos;old_settings=cls.settings
    def pos(self):
        old_pos(self)
        self._custom_actions=load_actions()
        def on_key(event):
            focus=self.root.focus_get()
            if focus is None or focus.winfo_toplevel()!=self.root:return
            if focus is not self.code and isinstance(focus,(tk.Entry,tk.Text,ttk.Entry,ttk.Combobox,tk.Spinbox)):return
            shortcut=from_event(event)
            if not shortcut:return
            action=next((a for a in self._custom_actions if a.get('enabled',True) and a.get('shortcut')==shortcut),None)
            if not action:return
            # Built-in shortcuts always take priority if a file was edited externally.
            if shortcut in load_builtin().values():return
            run_action(self,action)
            return 'break'
        self.root.bind('<KeyPress>',on_key,add='+')
    def custom_action_settings(self):
        w=tk.Toplevel(self.root);w.title('Custom Register Actions — TEST ONLY');w.transient(self.root)
        sw=w.winfo_screenwidth();sh=w.winfo_screenheight();w.geometry(f'{min(930,sw-70)}x{min(700,sh-130)}')
        w.configure(bg='white')
        tk.Label(w,text='CUSTOM REGISTER ACTIONS',bg='white',fg='#111111',font=('Segoe UI',16,'bold'),anchor='w',padx=18,pady=12).pack(fill='x')
        tk.Label(w,text='Create named shortcuts for products and screens. Multi-step actions can add products, then open one screen. No automatic payment.',bg='white',anchor='w',padx=15,pady=10,wraplength=850).pack(fill='x')
        footer=tk.Frame(w,bg='#e8eef2',pady=9);footer.pack(side='bottom',fill='x')
        data=load_actions();selected=tk.IntVar(value=-1)
        body=tk.Frame(w,bg='white');body.pack(fill='both',expand=True,padx=12,pady=8)
        left=tk.Frame(body,bg='white');left.pack(side='left',fill='both',expand=True)
        right=tk.Frame(body,bg='white',width=470);right.pack(side='right',fill='both',expand=True,padx=(12,0))
        tk.Label(left,text='Saved actions',font=('Segoe UI',11,'bold'),bg='white').pack(anchor='w')
        lst=tk.Listbox(left,font=('Segoe UI',10),exportselection=False);lst.pack(fill='both',expand=True,pady=5)
        name=tk.StringVar();shortcut=tk.StringVar();enabled=tk.BooleanVar(value=True)
        tk.Label(right,text='Action name',bg='white').pack(anchor='w');tk.Entry(right,textvariable=name,font=('Segoe UI',11)).pack(fill='x',pady=(0,8))
        tk.Label(right,text='Shortcut — click and press keys',bg='white').pack(anchor='w')
        sr=tk.Frame(right,bg='white');sr.pack(fill='x')
        se=ttk.Entry(sr,textvariable=shortcut,width=22,justify='center');se.pack(side='left',fill='x',expand=True)
        def capture(e):
            if e.keysym in ('Control_L','Control_R','Alt_L','Alt_R','Shift_L','Shift_R'):return 'break'
            key=from_event(e)
            if key:shortcut.set(key)
            else:w.bell()
            return 'break'
        se.bind('<KeyPress>',capture);se.bind('<KeyRelease>',lambda e:'break');se.bind('<<Paste>>',lambda e:'break')
        tk.Button(sr,text='Clear',command=lambda:shortcut.set('')).pack(side='left',padx=5)
        tk.Checkbutton(right,text='Enabled',variable=enabled,bg='white').pack(anchor='w',pady=7)
        tk.Label(right,text='Steps (in execution order)',bg='white',font=('Segoe UI',11,'bold')).pack(anchor='w')
        steps=tk.Listbox(right,height=7,font=('Segoe UI',10),exportselection=False);steps.pack(fill='both',expand=True,pady=4)
        tk.Label(right,text='Step type',bg='white').pack(anchor='w')
        st=tk.StringVar(value='Add product by barcode');ttk.Combobox(right,textvariable=st,values=list(TYPES),state='readonly').pack(fill='x')
        tk.Label(right,text='Product barcode (for Add product)',bg='white').pack(anchor='w',pady=(7,0))
        barcode=tk.StringVar();tk.Entry(right,textvariable=barcode).pack(fill='x')
        tk.Label(right,text='Quantity',bg='white').pack(anchor='w',pady=(7,0))
        qty=tk.StringVar(value='1');tk.Entry(right,textvariable=qty).pack(fill='x')
        pending=[]
        def draw_steps():
            steps.delete(0,'end')
            for i,s in enumerate(pending):
                label=next((k for k,v in TYPES.items() if v==s['type']),s['type'])
                if s['type']=='product':label+=f" — {s['barcode']} × {s['qty']}"
                steps.insert('end',f'{i+1}. {label}')
        def add_step():
            kind=TYPES[st.get()];s={'type':kind}
            if kind=='product':
                s['barcode']=barcode.get().strip()
                try:s['qty']=int(qty.get())
                except ValueError:messagebox.showerror('Quantity','Enter a whole-number quantity.',parent=w);return
                if not s['barcode'] or not 1<=s['qty']<=9999:messagebox.showerror('Product','Enter a product barcode and quantity from 1 to 9999.',parent=w);return
            if len(pending)>=12:messagebox.showerror('Steps','Maximum 12 steps.',parent=w);return
            pending.append(s);draw_steps()
        def remove_step():
            s=steps.curselection()
            if s:pending.pop(s[0]);draw_steps()
        controls=tk.Frame(right,bg='white');controls.pack(fill='x',pady=6)
        tk.Button(controls,text='Add Step',command=add_step).pack(side='left')
        tk.Button(controls,text='Remove Selected Step',command=remove_step).pack(side='left',padx=6)
        def refresh():
            lst.delete(0,'end')
            for a in data:lst.insert('end',a['name']+('  ['+a.get('shortcut','')+']' if a.get('shortcut') else '')+(' (disabled)' if not a.get('enabled',True) else ''))
        def choose(*_):
            ix=lst.curselection()
            if not ix:return
            i=ix[0];selected.set(i);a=data[i]
            name.set(a['name']);shortcut.set(a.get('shortcut',''));enabled.set(a.get('enabled',True))
            pending[:]=[dict(s) for s in a['steps']];draw_steps()
        lst.bind('<<ListboxSelect>>',choose)
        def fresh():
            selected.set(-1);lst.selection_clear(0,'end');name.set('');shortcut.set('');enabled.set(True);pending.clear();draw_steps()
        def save_action():
            action={'name':name.get().strip(),'shortcut':shortcut.get(),'enabled':bool(enabled.get()),'steps':[dict(s) for s in pending]}
            ix=selected.get();candidate=data[:]
            if 0<=ix<len(candidate):candidate[ix]=action
            else:candidate.append(action)
            try:check(candidate)
            except ValueError as e:messagebox.showerror('Action validation',str(e),parent=w);return
            data[:]=candidate;selected.set(len(data)-1 if ix<0 else ix);refresh()
            lst.selection_clear(0,'end');lst.selection_set(selected.get());lst.see(selected.get())
        def delete_action():
            ix=selected.get()
            if not 0<=ix<len(data):return
            if not messagebox.askyesno('Delete action',f"Delete '{data[ix]['name']}'?",parent=w):return
            data.pop(ix);refresh();fresh()
        def persist():
            try:check(data);PATH.write_text(json.dumps(data,indent=2),encoding='utf-8')
            except (ValueError,OSError) as e:messagebox.showerror('Cannot save',str(e),parent=w);return
            self._custom_actions=load_actions();w.destroy()
        tk.Button(footer,text='Close',command=w.destroy,width=11).pack(side='right',padx=8)
        tk.Button(footer,text='Save All Changes',command=persist,bg='#50c1ce',width=18).pack(side='right',padx=8)
        tk.Button(footer,text='New',command=fresh,width=9).pack(side='left',padx=6)
        tk.Button(footer,text='Save Action',command=save_action,width=14).pack(side='left',padx=6)
        tk.Button(footer,text='Delete',command=delete_action,width=10).pack(side='left',padx=6)
        refresh();w.grab_set()
    def settings(self):
        original_layout=self.layout
        def patched_layout(title,items):
            if title=='SETTINGS & TOOLS':items=[('Custom Register Actions',self.custom_action_settings)]+list(items)
            return original_layout(title,items)
        self.layout=patched_layout
        try:return old_settings(self)
        finally:self.layout=original_layout
    cls.pos=pos;cls.settings=settings;cls.custom_action_settings=custom_action_settings
