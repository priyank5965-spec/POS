Freedom POS 2.0 v0.61 — TEST ONLY
Fixes: Lottery button no longer requires a staff PIN in test mode. Keyboard shortcut capture reads actual modifier key states on Windows to avoid spurious Alt, and uses a focusable editable capture field.
No live lottery/EFTPOS integration. Windows GUI validation is still required.
