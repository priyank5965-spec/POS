"""Offline e-pay product catalogue. Never activates or sells vouchers."""
import csv, sqlite3, hashlib, datetime
from pathlib import Path
ROOT=Path(__file__).resolve().parent
DB=ROOT/'test_data'/'epay_catalog_v077.sqlite3'
HEADERS=('ProductTypeCode','ProductTypeTitle','ProductCategoryCode','ProductCategoryTitle','SupplierAccCode','SupplierAccTitle','ProductGroupCode','ProductGroupTitle','ProductCode','ProductTitle','Value','VariableValue','MinValue','MaxValue','DivValue','ETUTrack1IINFieldNo','ETUTrack1IINPosition','ETUTrack1IIN','ETUTrack2IIN','ETUPANTrack','ETUPANTrackFieldNo','ETUPANTrackPosition','ETUPANTrackSize','BarCode','PRODUCTID','ReceiptLogo1','ReceiptLogo2','MenuTemplateItemTitle','FeatureOptions','ItemFlags','Reserved4','Reserved5')
def connect(db=DB):
 db=Path(db);db.parent.mkdir(parents=True,exist_ok=True)
 con=sqlite3.connect(str(db));con.row_factory=sqlite3.Row
 con.execute('CREATE TABLE IF NOT EXISTS products (product_code TEXT PRIMARY KEY, product_id TEXT, title TEXT NOT NULL, barcode TEXT, category TEXT, group_name TEXT, supplier TEXT, product_type TEXT, face_value TEXT, variable_value TEXT, min_value TEXT, max_value TEXT, source_json TEXT NOT NULL, updated_at TEXT NOT NULL)')
 con.execute('CREATE TABLE IF NOT EXISTS import_history (id INTEGER PRIMARY KEY AUTOINCREMENT, imported_at TEXT NOT NULL, filename TEXT, sha256 TEXT, created INTEGER, updated INTEGER, unchanged INTEGER, total INTEGER)')
 con.commit();return con
def parse_csv(path):
 with open(path,'r',encoding='utf-8-sig',newline='') as fh:
  rows=list(csv.reader(fh))
 if not rows:raise ValueError('Empty catalogue')
 idx=next((i for i,row in enumerate(rows[:10]) if tuple(row)==HEADERS),None)
 if idx is None:raise ValueError('Unrecognised e-pay CSV columns; import cancelled.')
 parsed=[];seen=set()
 for line,row in enumerate(rows[idx+1:],idx+2):
  if not any(x.strip() for x in row):continue
  if len(row)!=len(HEADERS):raise ValueError(f'Line {line}: expected {len(HEADERS)} columns, got {len(row)}.')
  obj=dict(zip(HEADERS,[v.strip() for v in row]));code=obj['ProductCode']
  if not code:raise ValueError(f'Line {line}: ProductCode missing.')
  if code in seen:raise ValueError(f'Line {line}: duplicate ProductCode {code}.')
  seen.add(code)
  for field in ('Value','MinValue','MaxValue'):
   if obj[field]:
    try:float(obj[field])
    except ValueError:raise ValueError(f'Line {line}: invalid {field}.')
  parsed.append(obj)
 return parsed
def import_file(path,db=DB):
 from json import dumps
 path=Path(path);items=parse_csv(path);digest=hashlib.sha256(path.read_bytes()).hexdigest()
 con=connect(db);counts={'created':0,'updated':0,'unchanged':0,'total':len(items)}
 now=datetime.datetime.now(datetime.timezone.utc).isoformat()
 try:
  with con:
   for o in items:
    code=o['ProductCode'];payload=dumps(o,sort_keys=True,ensure_ascii=False)
    prior=con.execute('SELECT source_json FROM products WHERE product_code=?',(code,)).fetchone()
    if prior and prior['source_json']==payload:counts['unchanged']+=1;continue
    vals=(code,o['PRODUCTID'],o['ProductTitle'],o['BarCode'],o['ProductCategoryTitle'],o['ProductGroupTitle'],o['SupplierAccTitle'],o['ProductTypeTitle'],o['Value'],o['VariableValue'],o['MinValue'],o['MaxValue'],payload,now)
    con.execute('INSERT INTO products VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?) ON CONFLICT(product_code) DO UPDATE SET product_id=excluded.product_id,title=excluded.title,barcode=excluded.barcode,category=excluded.category,group_name=excluded.group_name,supplier=excluded.supplier,product_type=excluded.product_type,face_value=excluded.face_value,variable_value=excluded.variable_value,min_value=excluded.min_value,max_value=excluded.max_value,source_json=excluded.source_json,updated_at=excluded.updated_at',vals)
    counts['updated' if prior else 'created']+=1
   con.execute('INSERT INTO import_history(imported_at,filename,sha256,created,updated,unchanged,total) VALUES(?,?,?,?,?,?,?)',(now,path.name,digest,counts['created'],counts['updated'],counts['unchanged'],counts['total']))
 finally:con.close()
 return counts
def search(term='',limit=500,db=DB):
 con=connect(db)
 try:
  term=term.strip()
  if term:
   pattern='%'+term+'%'
   rows=con.execute('SELECT * FROM products WHERE title LIKE ? OR product_code LIKE ? OR barcode LIKE ? OR category LIKE ? OR group_name LIKE ? ORDER BY category,group_name,title LIMIT ?',(pattern,)*5+(limit,)).fetchall()
  else:rows=con.execute('SELECT * FROM products ORDER BY category,group_name,title LIMIT ?',(limit,)).fetchall()
  return [dict(r) for r in rows]
 finally:con.close()
def history(db=DB):
 con=connect(db)
 try:return [dict(r) for r in con.execute('SELECT * FROM import_history ORDER BY id DESC LIMIT 30')]
 finally:con.close()
