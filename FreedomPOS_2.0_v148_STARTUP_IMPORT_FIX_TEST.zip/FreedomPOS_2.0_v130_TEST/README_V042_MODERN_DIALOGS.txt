Freedom POS 2.0 v0.42 TEST ONLY
Modernised standard info, warning, error and confirmation message boxes across application. Existing messagebox return values preserved. No business logic or database changes.
Windows GUI and regression testing required before live use.
