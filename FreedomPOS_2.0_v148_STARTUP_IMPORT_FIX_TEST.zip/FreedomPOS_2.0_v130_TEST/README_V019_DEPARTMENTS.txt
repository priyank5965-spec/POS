FREEDOM POS 2.0 v0.19 — DEPARTMENTS & CATEGORIES TEST BUILD

Start: freedom_v04/START_FREEDOM_POS.bat
Products & Stock -> DEPARTMENTS & CATEGORIES -> ADD CATEGORY.
Products & Stock -> ASSIGN PRODUCT DEPARTMENT to assign an existing product.
Products & Stock -> DEPARTMENT MANAGEMENT to create departments.
Point of Sale -> DEPARTMENTS to browse departments, categories and products, or enter a miscellaneous department sale.

All data is local test data. No real EFTPOS, accounting, tax, or lottery integration.
Existing product prices do not change when assigning departments/categories or changing markup defaults.
Category GST, markup and label policies are saved as defaults, but NOT YET applied to pricing, tax, receipt or label processing.
Department sales are identified as kind DEPARTMENT SALE on sales lines, with no inventory adjustment.
Not implemented: register PLU shortcut, discount restrictions, payout/agency controls, category newsagency codes, category label-on-arrival processing, tax/GL mappings, end-to-end permissions, real GST reporting.
Windows UI has not been tested in this environment.
