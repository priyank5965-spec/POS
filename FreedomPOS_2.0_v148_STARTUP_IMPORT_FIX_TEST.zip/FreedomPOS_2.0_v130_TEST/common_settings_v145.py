"""Single visible settings entry point; existing setting handlers remain authoritative."""
import tkinter as tk
from tkinter import ttk, messagebox

CATEGORIES = [
 ('Register Settings', [('Register behaviour','register_settings'),('Keyboard Shortcuts','shortcut_settings'),('Register Buttons & Theme','register_customizer'),('Department Buttons & Shortcuts','department_button_settings'),('Custom Register Actions','custom_action_settings')]),
 ('Product & Stock', [('Product Master','product_master'),('Stocktake','stocktake')]),
 ('Newspapers', [('Newspaper Product Setup','newspaper_product_setup')]),
 ('Supplier & Purchasing', []),
 ('Payments & EFTPOS', []),
 ('Hardware & Printing', []),
 ('Users & Security', []),
 ('Backup & Database', [('Backup & Restore','backup')]),
]

def install(cls):
    original_pos=cls.pos
    def common_settings(self):
        win=tk.Toplevel(self.root)
        win.title('Freedom POS 2.0 — Settings')
        win.configure(bg='white')
        sw,sh=win.winfo_screenwidth(),win.winfo_screenheight()
        win.geometry(f'{min(1120,sw-60)}x{min(750,sh-90)}')
        win.minsize(780,530)
        header=tk.Frame(win,bg='#12324a',height=65)
        header.pack(fill='x');header.pack_propagate(False)
        tk.Label(header,text='SETTINGS',bg='#12324a',fg='white',font=('Segoe UI',20,'bold')).pack(side='left',padx=22,pady=15)
        tk.Button(header,text='CLOSE',command=win.destroy,bg='white',fg='#12324a',font=('Segoe UI',10,'bold')).pack(side='right',padx=18)
        content=tk.Frame(win,bg='white');content.pack(fill='both',expand=True,padx=15,pady=15)
        nav=tk.Listbox(content,width=29,exportselection=False,font=('Segoe UI',11),activestyle='none')
        nav.pack(side='left',fill='y',padx=(0,14))
        pane=tk.Frame(content,bg='white');pane.pack(side='left',fill='both',expand=True)
        for title,_ in CATEGORIES:nav.insert('end',title)
        def launch(method):
            fn=getattr(self,method,None)
            if not callable(fn):
                messagebox.showwarning('Not available','This settings screen is not implemented in this test build.',parent=win)
                return
            try:fn()
            except Exception as exc:messagebox.showerror('Settings',f'Unable to open {method}: {exc}',parent=win)
        def render(event=None):
            for child in pane.winfo_children():child.destroy()
            idx=nav.curselection()[0] if nav.curselection() else 0
            title,entries=CATEGORIES[idx]
            tk.Label(pane,text=title,bg='white',fg='#12324a',font=('Segoe UI',18,'bold')).pack(anchor='w',pady=(6,20))
            available=0
            for label,method in entries:
                if not callable(getattr(self,method,None)):continue
                tk.Button(pane,text=label,anchor='w',bg='#e9f0f4',fg='#111111',relief='flat',font=('Segoe UI',12),padx=15,pady=13,command=lambda m=method:launch(m)).pack(fill='x',pady=5)
                available+=1
            if not available:
                tk.Label(pane,text='No dedicated settings screen is available for this category yet. Existing features have not been changed.',bg='white',fg='#586775',wraplength=510,justify='left',font=('Segoe UI',11)).pack(anchor='w')
        nav.bind('<<ListboxSelect>>',render);nav.selection_set(0);render()
        return win
    def settings(self):return self.common_settings()
    def pos(self):
        result=original_pos(self)
        # One persistent settings entry point on the register, separate from the sale grid.
        bar=tk.Frame(self.root,bg='#12324a')
        bar.pack(side='bottom',fill='x')
        tk.Button(bar,text='⚙ SETTINGS',command=self.common_settings,bg='#ffffff',fg='#12324a',font=('Segoe UI',11,'bold'),padx=18,pady=5).pack(side='right',padx=12,pady=5)
        return result
    cls.common_settings=common_settings
    cls.settings=settings
    cls.pos=pos
