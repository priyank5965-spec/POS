"""Batch product entry grid for Freedom POS test environment."""
import tkinter as tk
from tkinter import ttk, messagebox
import sqlite3
from decimal import Decimal

FIELDS = [('Barcode', 19), ('Product name', 31), ('Selling price ($)', 16), ('Opening stock', 13), ('Supplier', 19), ('Category', 18)]

def install(cls):
    def add_product_grid(self):
        win = tk.Toplevel(self.root)
        win.title('Add Products — Grid Entry | TEST ONLY')
        win.geometry('1260x690')
        win.minsize(950,480)
        win.transient(self.root)
        main = tk.Frame(win, bg='white')
        main.pack(fill='both', expand=True)
        tk.Label(main, text='ADD PRODUCTS — GRID ENTRY', bg='white', fg='#111111', font=('Segoe UI',18,'bold'), anchor='w', padx=18, pady=13).pack(fill='x')
        tk.Label(main, text='Scan or type barcode → Tab to the next cell. Enter multiple products, then Save All. Blank rows are ignored.', bg='white', font=('Segoe UI',11)).pack(anchor='w', padx=14,pady=(12,4))
        tk.Label(main, text='Opening stock is for new products only. Existing barcodes are rejected; no existing products are overwritten.', bg='white', fg='#8a4c10').pack(anchor='w',padx=14,pady=(0,8))
        wrap=tk.Frame(main)
        wrap.pack(fill='both',expand=True,padx=12)
        canvas=tk.Canvas(wrap,highlightthickness=0)
        scroll=ttk.Scrollbar(wrap,orient='vertical',command=canvas.yview)
        canvas.configure(yscrollcommand=scroll.set)
        scroll.pack(side='right',fill='y');canvas.pack(side='left',fill='both',expand=True)
        grid=tk.Frame(canvas,bg='white');window=canvas.create_window((0,0),window=grid,anchor='nw')
        grid.bind('<Configure>',lambda e:canvas.configure(scrollregion=canvas.bbox('all')))
        canvas.bind('<Configure>',lambda e:canvas.itemconfigure(window,width=e.width))
        for c,(label,width) in enumerate([('#',4)]+FIELDS):
            tk.Label(grid,text=label,bg='#dce8ef',fg='#111111',font=('Segoe UI',10,'bold'),anchor='w',padx=5,pady=8).grid(row=0,column=c,sticky='ew',padx=1,pady=1)
        grid.columnconfigure(2,weight=2)
        rows=[]
        status=tk.StringVar(value='Ready. Enter products in the grid.')
        def append_row():
            n=len(rows)+1
            tk.Label(grid,text=str(n),bg='white',padx=5).grid(row=n,column=0,sticky='nsew',padx=1,pady=2)
            vars=[];entries=[]
            for c,(label,width) in enumerate(FIELDS,1):
                v=tk.StringVar();vars.append(v)
                if c==4:v.set('0')
                e=tk.Entry(grid,textvariable=v,font=('Segoe UI',11),width=width,relief='solid',bd=1)
                e.grid(row=n,column=c,sticky='ew',padx=3,pady=3,ipady=6)
                entries.append(e)
            rows.append((vars,entries))
            return entries[0]
        for _ in range(10):append_row()
        def validate():
            staged=[];problems=[];seen=set()
            for number,(vars,entries) in enumerate(rows,1):
                for e in entries:e.configure(bg='white')
                values=[v.get().strip() for v in vars]
                if not any(values[i] for i in (0,1,2,4,5)):continue
                barcode,name,price,stock,supplier,category=values
                def err(idx,msg):
                    entries[idx].configure(bg='#ffe1df');problems.append(f'Row {number}: {msg}')
                if not barcode:err(0,'barcode required')
                elif barcode in seen:err(0,'duplicate barcode in grid')
                elif self.db.execute('SELECT 1 FROM products WHERE barcode=?',(barcode,)).fetchone():err(0,'barcode already exists')
                if not name:err(1,'product name required')
                try:
                    from freedom_pos import cents
                    price_cents=cents(price)
                    if price_cents<0:raise ValueError()
                except (ValueError,TypeError):err(2,'invalid selling price');price_cents=0
                try:
                    count=int(stock or '0')
                    if count<0:raise ValueError()
                except ValueError:err(3,'opening stock must be a non-negative whole number');count=0
                seen.add(barcode)
                staged.append((barcode,name,price_cents,count,supplier,category or 'General'))
            return staged,problems
        def save():
            staged,errors=validate()
            if errors:
                status.set(f'{len(errors)} error(s): '+ '; '.join(errors[:3]))
                messagebox.showwarning('Please correct highlighted cells','\n'.join(errors[:18]),parent=win)
                return
            if not staged:
                status.set('No products entered.');return
            if not messagebox.askyesno('Confirm new products',f'Create {len(staged)} new product(s) in the TEST database?',parent=win):return
            try:
                with self.db:
                    self.db.executemany('INSERT INTO products(barcode,name,price,stock,supplier,category) VALUES(?,?,?,?,?,?)',staged)
                self.log('PRODUCT',f'Grid created {len(staged)} products')
            except sqlite3.IntegrityError as ex:
                messagebox.showerror('Could not save','Duplicate barcode or invalid data. No partial batch was saved.\n'+str(ex),parent=win)
                return
            self.products();win.destroy()
        actions=tk.Frame(main,bg='white');actions.pack(fill='x',padx=12,pady=8)
        tk.Button(actions,text='ADD 5 MORE ROWS',command=lambda:[append_row() for _ in range(5)],font=('Segoe UI',10,'bold'),padx=10,pady=7).pack(side='left',padx=4)
        tk.Button(actions,text='SAVE ALL PRODUCTS',command=save,bg='white',fg='#111111',font=('Segoe UI',11,'bold'),padx=12,pady=7).pack(side='right',padx=5)
        tk.Button(actions,text='CANCEL',command=win.destroy,font=('Segoe UI',10),padx=12,pady=7).pack(side='right',padx=5)
        tk.Label(main,textvariable=status,bg='white',fg='#8a4c10',anchor='w').pack(fill='x',padx=15,pady=(0,8))
        rows[0][1][0].focus_set()
    cls.add_product=add_product_grid
