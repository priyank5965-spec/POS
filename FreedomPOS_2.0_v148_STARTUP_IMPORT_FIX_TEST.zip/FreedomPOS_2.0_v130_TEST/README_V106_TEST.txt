Freedom POS 2.0 v0.106 TEST ONLY
Changes: separate freight ex GST + GST 0/10; mismatch finalisation with mandatory reason; invoice total includes freight; Excel summary-row filtering.
CSV/XLSX/XML use existing import mapping. PDF/DDO/DD2 readers are NOT implemented or verified. They remain visible but cannot be posted. Do not use for live business.
Windows GUI and actual supplier-file import not tested in this environment.
