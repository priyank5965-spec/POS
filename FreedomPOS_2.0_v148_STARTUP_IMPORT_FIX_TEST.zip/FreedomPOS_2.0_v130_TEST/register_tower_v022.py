"""Tower-video-inspired register workspace. Test data only; not a production POS."""
import tkinter as tk
from tkinter import ttk, messagebox, simpledialog
from decimal import Decimal, InvalidOperation

AQUA='#5bc5d3'; GRID='#c7c7c7'; DARK='#292929'; PALE='#eeeeee'

def install(cls):
    def pos(self):
        self.clear()
        self.root.title('Freedom POS 2.0 — Register Four-Column Quick Cash v0.48 — TEST ONLY')
        self.root.configure(bg='#e5e5e5')
        # Maximise the register only; other modules retain their own window behaviour.
        try:self.root.state('zoomed')
        except tk.TclError:
            try:self.root.attributes('-zoomed', True)
            except tk.TclError:pass
        # Entire register is a single resizable workspace, not a vertical stack.
        shell=tk.Frame(self.root,bg='#dedede');shell.pack(fill='both',expand=True)
        header=tk.Frame(shell,bg=AQUA,height=46);header.pack(fill='x');header.pack_propagate(False)
        self.reg_mode=tk.StringVar(value='CASH SALE')
        tk.Label(header,textvariable=self.reg_mode,bg=AQUA,fg='#132d39',font=('Segoe UI',19,'bold')).pack(side='left',padx=12)
        for label,action in [('RECEIPT',self.last_receipt),('HOME',self.home),('STOCK',self.stock_lookup),('⚙',self.register_customizer),('✕',self.home)]:
            tk.Button(header,text=label,command=action,bg='#f7f7f7',fg='#17384a',font=('Segoe UI',9,'bold'),relief='flat',padx=9).pack(side='right',padx=2,pady=7)
        # One uninterrupted scanner / PLU field above the sale and touch buttons.
        scanbar=tk.Frame(shell,bg='#eeeeee',height=44);scanbar.pack(fill='x',padx=5,pady=(4,2));scanbar.pack_propagate(False)
        self.qty_next=tk.StringVar(value='Qty 1')
        tk.Button(scanbar,textvariable=self.qty_next,width=9,command=lambda:quantity_dialog(self),font=('Segoe UI',11,'bold')).pack(side='left',padx=(2,6),fill='y')
        self.code=tk.Entry(scanbar,font=('Segoe UI',17),relief='solid',bd=1)
        self.code.pack(side='left',fill='both',expand=True,pady=2)
        self._barcode_scan_job = None
        self.code.bind('<Return>',lambda event: finish_barcode_scan(self))
        self.code.bind('<KP_Enter>',lambda event: finish_barcode_scan(self))
        self.code.bind('<KeyRelease>',lambda event: schedule_barcode_scan(self, event))
        # No ENTER button: scanners with an Enter suffix process immediately;
        # scanners without a suffix process after a short input pause.

        workspace=tk.PanedWindow(shell,orient='horizontal',sashwidth=3,sashrelief='flat',bg='#c7c7c7',bd=0,relief='flat',showhandle=False)
        workspace.pack(fill='both',expand=True,padx=5)
        self.register_splitter=workspace
        left=tk.Frame(workspace,bg='white');right=tk.Frame(workspace,bg=GRID)
        workspace.add(left,minsize=360,stretch='always');workspace.add(right,minsize=360,stretch='always',width=630)
        cols=('Qty','Description','Unit Price','Unit Discount','Total')
        self.sale_tree=ttk.Treeview(left,columns=cols,show='headings',selectmode='browse',height=13)
        for name,width,anchor in [('Qty',54,'center'),('Description',330,'w'),('Unit Price',100,'e'),('Unit Discount',105,'e'),('Total',105,'e')]:
            self.sale_tree.heading(name,text=name)
            self.sale_tree.column(name,width=width,minwidth=45,anchor=anchor,stretch=(name=='Description'))
        self.sale_tree.tag_configure('refund',foreground='#c41f28')
        self.sale_tree.tag_configure('selected',background='#e3e3f7')
        yscroll=ttk.Scrollbar(left,orient='vertical',command=self.sale_tree.yview)
        self.sale_tree.configure(yscrollcommand=yscroll.set)
        yscroll.pack(side='right',fill='y')
        # All transaction totals belong beneath the sales grid, not beneath the button area.
        summary=tk.Frame(left,bg=DARK,height=74);summary.pack(side='bottom',fill='x');summary.pack_propagate(False)
        top_line=tk.Frame(summary,bg=DARK);top_line.pack(fill='x',padx=12,pady=(6,1))
        self.change_label=tk.Label(top_line,text='Last Sale Change $0.00',bg=DARK,fg='white',font=('Segoe UI',14,'bold'));self.change_label.pack(side='left')
        self.discount_label=tk.Label(top_line,text='Total Discount $0.00',bg=DARK,fg='white',font=('Segoe UI',14,'bold'));self.discount_label.pack(side='right')
        self.total_label=tk.Label(summary,text='Sub Total $0.00',bg=DARK,fg='white',font=('Segoe UI',20,'bold'),anchor='e');self.total_label.pack(fill='x',padx=12)
        self.sale_tree.pack(fill='both',expand=True)
        self.sale_tree.bind('<Double-1>',lambda event:self.edit_line())
        # Uniform button matrix: all controls are the same visible size.
        # The right pane is exclusively for register actions and quick cash.
        right.grid_columnconfigure(tuple(range(4)),weight=1,uniform='tile')
        for r in range(10):right.grid_rowconfigure(r,weight=1,uniform='tile')
        self._register_tiles={}
        next_cell=[0]
        def tile(label,command,bg=GRID,fg='#1e1e1e'):
            i=next_cell[0];next_cell[0]+=1
            row,col=divmod(i,4)
            b=tk.Button(right,text=label,command=command,bg=bg,fg=fg,font=('Segoe UI',10,'bold'),
                        relief='solid',bd=1,wraplength=115,activebackground='#a9e1e7',cursor='hand2')
            b.grid(row=row,column=col,sticky='nsew',padx=2,pady=2)
            key=label if label not in self._register_tiles else label+' #2'
            self._register_tiles[key]={'widget':b,'label':label,'row':row,'col':col,'span':1,'bg':bg,'fg':fg}
            return b
        quick=self.db.execute('SELECT id,name FROM products ORDER BY id LIMIT 10').fetchall()
        for p in quick:
            tile(p['name'],lambda pid=p['id']:self.quick(pid))
        tile('DEPARTMENTS',self.register_departments)
        tile('CUSTOMER',self.register_customer)
        tile('STOCK LOOKUP',self.stock_lookup)
        tile('QUANTITY',lambda:quantity_dialog(self))
        tile('EDIT LINE',self.edit_line)
        tile('HOLD SALE',self.hold)
        tile('RECALL SALE',self.recall)
        tile('LOTTERY',self.lottery)
        tile('CANCEL SALE',self.clear_cart,bg='#151515',fg='white')
        tile('DELETE ITEM',self.void,bg='#151515',fg='white')
        tile('DISCOUNT',self.set_discount,bg='#151515',fg='white')
        tile('PREVIOUS SALES',self.previous,bg='#151515',fg='white')
        tile('REFUND',self.register_refund,bg='#fff0f0')
        tile('CUSTOMER PAYMENT',self.register_account_payment)
        tile('ACCOUNT SALE',lambda:self.checkout('ACCOUNT'))
        tile('EFTPOS (TEST)',lambda:self.checkout('EFTPOS SIMULATED'))
        tile('SPLIT TENDER',self.split_payment)
        tile('CASH',self.register_cash,bg='#d9f0df')
        tile('TOTAL',lambda:show_total(self),bg=DARK,fg='white')
        # Quick cash presets complete TEST cash sales when sufficient tender is provided.
        for denomination in (5,10,20,50,100):
            tile(f'QUICK ${denomination}',lambda amount=denomination:quick_cash_checkout(self,amount),bg='#d9f0df')
        if hasattr(self,'apply_register_customization'): self.apply_register_customization()
        # No global footer: totals are displayed only beneath the sale grid.
        self.customer_label=tk.Label(shell,text='Customer: Walk-in   |   OFFLINE TEST MODE — No real EFTPOS processing',bg='#dedede',fg='#39434a',anchor='w',font=('Segoe UI',9))
        self.customer_label.pack(fill='x',padx=10,pady=2)
        self.refresh_cart();self.code.focus_set()
        self.change_label.config(text=f'Last Sale Change ${getattr(self, "_last_sale_change", 0)/100:,.2f}')
        self._register_qty=1
        # Responsive sash position; never hide buttons below the screen.
        self.root.after_idle(lambda: workspace.sash_place(0,max(360,int(workspace.winfo_width()*.50)),0) if workspace.winfo_exists() and workspace.winfo_width()>750 else None)

    def refresh_cart(self):
        tree=getattr(self,'sale_tree',None)
        if tree is None or not tree.winfo_exists():return
        tree.delete(*tree.get_children())
        for i,item in enumerate(self.cart):
            qty=item['qty'];price=item['unit'];total=qty*price
            tree.insert('','end',iid=str(i),values=(qty,item['description'],f'${price/100:,.2f}','$0.00',f'${total/100:,.2f}'),tags=('refund',) if qty<0 else ())
        total=self.total()
        self.total_label.config(text=f'Sub Total  ${total/100:,.2f}')
        if hasattr(self,'discount_label') and self.discount_label.winfo_exists():self.discount_label.config(text=f'Total Discount  ${self.discount/100:,.2f}')
        if hasattr(self,'customer_label') and self.customer_label.winfo_exists():
            row=self.db.execute('SELECT name FROM customers WHERE id=?',(self.customer,)).fetchone() if self.customer else None
            self.customer_label.config(text=f"Customer: {row['name'] if row else 'Walk-in'}   |   OFFLINE TEST MODE — No real EFTPOS processing")

    def quick(self,pid):
        p=self.db.execute('SELECT * FROM products WHERE id=?',(pid,)).fetchone()
        if p:self.add_to_cart(p,qty=getattr(self,'_register_qty',1))
        self._register_qty=1
        if hasattr(self,'qty_next') and self.qty_next:self.qty_next.set('Qty 1')
        self.code.focus_set()

    def scan(self):
        scan_or_command(self)

    def register_cash(self):
        # Reuse existing tested test-mode tender dialog and checkout implementation.
        return cash_tender(self)

    cls._video_original_register_cash=cls.register_cash
    cls.pos=pos;cls.refresh_cart=refresh_cart;cls.quick=quick;cls.scan=scan;cls.register_cash=register_cash


def quantity_dialog(self):
    qty=simpledialog.askinteger('Change Quantity','Quantity for next scanned or quick product:',initialvalue=getattr(self,'_register_qty',1),minvalue=1,maxvalue=9999,parent=self.root)
    if qty is not None:
        self._register_qty=qty;self.qty_next.set(f'Qty {qty}')
    self.code.focus_set()


def finish_barcode_scan(self):
    job=getattr(self,'_barcode_scan_job',None)
    if job is not None:
        self.root.after_cancel(job)
        self._barcode_scan_job=None
    scan_or_command(self)
    return 'break'

def schedule_barcode_scan(self,event):
    if event.keysym in ('Return','KP_Enter','Tab'):
        return
    job=getattr(self,'_barcode_scan_job',None)
    if job is not None:
        self.root.after_cancel(job)
        self._barcode_scan_job=None
    code=self.code.get().strip()
    # Do not auto-submit partial manually entered codes or department commands.
    # EAN-8, UPC-A, EAN-13 and GTIN-14 are common retail formats.
    from register_settings_v063 import load as load_register_settings
    settings=load_register_settings()
    if settings['auto_scan'] and code.isdigit() and len(code) in (8,12,13,14):
        self._barcode_scan_job=self.root.after(settings['scan_delay'],lambda:finish_barcode_scan(self))

def scan_or_command(self):
    code=self.code.get().strip();self.code.delete(0,'end')
    if not code:return
    if code.startswith('@'):
        from receipt_business_v054 import receipt_barcode_action
        receipt_barcode_action(self, code)
        self._register_qty=1;self.qty_next.set('Qty 1');self.code.focus_set()
        return
    if code.startswith('~'):
        # Do not invent department-sale posting without verified GST/audit handling.
        messagebox.showinfo('Department PLU', 'Department PLU posting is not yet enabled in this test build. Use Departments for stock items.',parent=self.root)
        return
    p=self.product_by_code(code)
    if p:self.add_to_cart(p,qty=getattr(self,'_register_qty',1))
    else:self.stock_lookup(initial_query=code)
    self._register_qty=1;self.qty_next.set('Qty 1');self.code.focus_set()


def show_total(self):
    amount=self.total();messagebox.showinfo('Sale Total',f'Total: ${amount/100:,.2f}\nDiscount: ${self.discount/100:,.2f}',parent=self.root)


def cash_tender(self,preset=None):
    if not self.cart:return self.warn('Add products before payment.')
    due=self.total()
    if due<0:return self.warn('Use the refund workflow for a negative total.')
    w=tk.Toplevel(self.root);w.title('Payment Details — Cash (TEST ONLY)');w.geometry('520x450');w.transient(self.root);w.grab_set()
    tk.Label(w,text=f'AMOUNT DUE   ${due/100:,.2f}',font=('Segoe UI',19,'bold')).pack(pady=12)
    val=tk.StringVar(value=f'{(preset if preset is not None else due/100):.2f}')
    tk.Label(w,text='Cash tendered',font=('Segoe UI',11)).pack()
    entry=tk.Entry(w,textvariable=val,font=('Segoe UI',19),justify='right');entry.pack(fill='x',padx=22,pady=7)
    output=tk.Label(w,font=('Segoe UI',15,'bold'));output.pack(pady=10)
    def calculate():
        try:
            amount=Decimal(val.get().strip());assert amount.is_finite() and amount>=0
            paid=int((amount*100).quantize(Decimal('1')))
            output.config(text=(f'CHANGE  ${(paid-due)/100:,.2f}' if paid>=due else f'REMAINING  ${(due-paid)/100:,.2f}'),fg=('#116d37' if paid>=due else '#ad3030'))
            return paid
        except (InvalidOperation,ValueError,AssertionError):output.config(text='Invalid amount');return None
    val.trace_add('write',lambda *_:calculate());calculate()
    grid=tk.Frame(w);grid.pack(fill='both',expand=True,padx=22)
    for i,denom in enumerate((5,10,20,50,100,'EXACT')):
        tk.Button(grid,text=('$'+str(denom) if denom!='EXACT' else 'EXACT'),height=2,command=lambda d=denom:val.set(f'{(due if d=="EXACT" else d*100)/100:.2f}')).grid(row=i//3,column=i%3,sticky='nsew',padx=3,pady=3)
    for i in range(3):grid.columnconfigure(i,weight=1)
    def complete():
        paid=calculate()
        if paid is None or paid<due:return
        if not messagebox.askyesno('Confirm test cash payment',f'Due: ${due/100:,.2f}\nTendered: ${paid/100:,.2f}\nChange: ${(paid-due)/100:,.2f}\n\nRecord TEST payment?',parent=w):return
        self._pending_cash_tender=paid
        w.destroy();self.checkout('CASH')
    tk.Button(w,text='COMPLETE TEST CASH SALE',bg='#d9f0df',font=('Segoe UI',12,'bold'),command=complete,height=2).pack(fill='x',padx=22,pady=12)
    entry.focus_set()


def quick_cash_checkout(self, denomination):
    """One-touch simulated cash payment, without the tender dialog."""
    if not self.cart:
        self.warn('Add products before payment.')
        self.code.focus_set()
        return False
    due=self.total()
    tender=int(denomination)*100
    if due<0:
        self.warn('Use the refund workflow for a negative total.')
        self.code.focus_set()
        return False
    if due>tender:
        self.warn(f'Amount due ${due/100:,.2f} exceeds QUICK ${denomination}. Use CASH or SPLIT TENDER for the remaining payment.')
        self.code.focus_set()
        return False
    # checkout is transactional: only display change if it reports success.
    before_sale=self.db.execute('SELECT COALESCE(MAX(id),0) FROM sales').fetchone()[0]
    self._pending_cash_tender=tender
    try:
        self.checkout('CASH')
    except Exception:
        self._pending_cash_tender=None
        raise
    after_sale=self.db.execute('SELECT COALESCE(MAX(id),0) FROM sales').fetchone()[0]
    if after_sale>before_sale:
        change=tender-due
        self._last_sale_change=change
        if hasattr(self,'change_label') and self.change_label.winfo_exists():
            self.change_label.config(text=f'Last Sale Change ${change/100:,.2f}')
        self.code.focus_set()
        return True
    self._pending_cash_tender=None
    self.code.focus_set()
    return False
