"""Business-wide settings management (TEST ONLY).
Only business defaults are active; historical register/user records are ignored.
Changes are validated, audited and stored in SQLite.
"""
import sqlite3, json, datetime, tkinter as tk
from tkinter import ttk, filedialog, messagebox
from pathlib import Path
from decimal import Decimal
from register_settings_v063 import DEFAULT, PATH as LEGACY_PATH
DB_PATH=Path(__file__).resolve().parent/'test_data'/'settings_v065.sqlite3'
ALLOWED={
 'auto_scan':('bool',None),'scan_delay':('int',(100,2000)),
 'scan_suffix':('choice',('Enter','Tab','None')),'receipt_prefix':('fixed','@'),
 'default_qty':('int',(1,999)),'merge_scans':('bool',None),
 'register_id':('string',64),'opening_float':('money',None),
}
# Other v063 defaults remain preserved, but are not exposed as active runtime controls.
REGISTER_KEYS={'register_id','opening_float','scan_suffix','scan_delay','auto_scan','default_qty','merge_scans'}
USER_KEYS={'display_theme'}

def connect():
 DB_PATH.parent.mkdir(parents=True,exist_ok=True)
 con=sqlite3.connect(DB_PATH,timeout=10)
 con.execute('PRAGMA journal_mode=WAL')
 con.execute('CREATE TABLE IF NOT EXISTS settings (scope TEXT NOT NULL, owner TEXT NOT NULL, name TEXT NOT NULL, value TEXT NOT NULL, PRIMARY KEY(scope,owner,name))')
 con.execute('CREATE TABLE IF NOT EXISTS audit (id INTEGER PRIMARY KEY AUTOINCREMENT, time_utc TEXT NOT NULL, event TEXT NOT NULL, scope TEXT NOT NULL, owner TEXT NOT NULL, details TEXT NOT NULL)')
 con.commit();return con

def validate(key,val):
 if key not in DEFAULT:raise ValueError('Unknown setting: '+str(key))
 if key not in ALLOWED:return val
 typ,rule=ALLOWED[key]
 if typ=='fixed':
  if val!=rule:raise ValueError('Receipt prefix must remain @')
  return val
 if typ=='bool':
  if not isinstance(val,bool):raise ValueError(key+' must be true or false')
  return val
 if typ=='int':
  if isinstance(val,bool):raise ValueError(key+' must be a number')
  try:n=int(val)
  except (TypeError,ValueError):raise ValueError(key+' must be a whole number')
  if not rule[0]<=n<=rule[1]:raise ValueError(key+f' must be between {rule[0]} and {rule[1]}')
  return n
 if typ=='choice':
  if val not in rule:raise ValueError(key+' must be one of '+', '.join(rule))
  return val
 if typ=='money':
  try:n=Decimal(str(val))
  except Exception:raise ValueError('Opening float must be a valid amount')
  if not n.is_finite() or n<0 or n.as_tuple().exponent < -2:raise ValueError('Opening float must be a non-negative amount with up to 2 decimals')
  return str(n)
 if typ=='string':
  if not isinstance(val,str) or not val.strip() or len(val.strip())>rule:raise ValueError(key+' must be 1–'+str(rule)+' characters')
  return val.strip()
 return val

def rows(con,scope,owner):
 return {k:json.loads(v) for k,v in con.execute('SELECT name,value FROM settings WHERE scope=? AND owner=?',(scope,owner))}

def effective(register='POS1',user=''):
 with connect() as con:
  result=dict(DEFAULT)
  result.update(rows(con,'business','default'))
  return result

def save_scope(scope,owner,values,event='save'):
 if scope!='business' or owner!='default':raise ValueError('Only business defaults are supported')
 if not owner.strip():raise ValueError('Scope identifier is required')
 clean={k:validate(k,v) for k,v in values.items()}
 with connect() as con:
  before=rows(con,scope,owner)
  for k,v in clean.items():
   con.execute('INSERT OR REPLACE INTO settings(scope,owner,name,value) VALUES(?,?,?,?)',(scope,owner,k,json.dumps(v)))
  changes={k:{'before':before.get(k),'after':v} for k,v in clean.items() if before.get(k)!=v}
  con.execute('INSERT INTO audit(time_utc,event,scope,owner,details) VALUES(?,?,?,?,?)',(datetime.datetime.now(datetime.timezone.utc).isoformat(),event,scope,owner,json.dumps(changes,sort_keys=True)))
  con.commit()
 return changes

def replace_scope(scope,owner,values,event='restore_defaults'):
 if scope!='business' or owner!='default':raise ValueError('Only business defaults are supported')
 clean={k:validate(k,v) for k,v in values.items()}
 with connect() as con:
  previous=rows(con,scope,owner)
  con.execute('DELETE FROM settings WHERE scope=? AND owner=?',(scope,owner))
  for k,v in clean.items():con.execute('INSERT INTO settings VALUES(?,?,?,?)',(scope,owner,k,json.dumps(v)))
  con.execute('INSERT INTO audit(time_utc,event,scope,owner,details) VALUES(?,?,?,?,?)',(datetime.datetime.now(datetime.timezone.utc).isoformat(),event,scope,owner,json.dumps({'before':previous,'after':clean},sort_keys=True)))
  con.commit()

def export_json(path):
 with connect() as con:
  records=[{'scope':s,'owner':o,'name':k,'value':json.loads(v)} for s,o,k,v in con.execute("SELECT scope,owner,name,value FROM settings WHERE scope='business' AND owner='default' ORDER BY name")]
 doc={'format':'FreedomPOS.settings','version':1,'records':records}
 path=Path(path);temp=path.with_suffix(path.suffix+'.tmp');temp.write_text(json.dumps(doc,indent=2),encoding='utf-8');temp.replace(path)

def import_json(path):
 doc=json.loads(Path(path).read_text(encoding='utf-8'))
 if doc.get('format')!='FreedomPOS.settings' or doc.get('version')!=1 or not isinstance(doc.get('records'),list):raise ValueError('Not a compatible Freedom POS settings export')
 if len(doc['records'])>2000:raise ValueError('Too many settings in import')
 parsed=[];seen=set()
 for r in doc['records']:
  if not isinstance(r,dict):raise ValueError('Invalid settings record')
  scope=r.get('scope');owner=r.get('owner');key=r.get('name')
  if scope!='business' or owner!='default':raise ValueError('Only business defaults may be imported')
  if (scope,owner,key) in seen:raise ValueError('Duplicate setting in import')
  seen.add((scope,owner,key));parsed.append((scope,owner,key,json.dumps(validate(key,r.get('value')))))
 with connect() as con:
  con.execute('BEGIN IMMEDIATE')
  for row in parsed:con.execute('INSERT OR REPLACE INTO settings VALUES(?,?,?,?)',row)
  con.execute('INSERT INTO audit(time_utc,event,scope,owner,details) VALUES(?,?,?,?,?)',(datetime.datetime.now(datetime.timezone.utc).isoformat(),'import','system','all',json.dumps({'count':len(parsed)})))
  con.commit()
 return len(parsed)

def migrate():
 with connect() as con:
  if con.execute('SELECT COUNT(*) FROM settings').fetchone()[0]:return
 if LEGACY_PATH.exists():
  try:
   old=json.loads(LEGACY_PATH.read_text(encoding='utf-8'))
   clean={k:validate(k,v) for k,v in old.items() if k in DEFAULT}
   save_scope('business','default',clean,event='migrate_v063')
  except (ValueError,TypeError,KeyError,json.JSONDecodeError):pass

def sync_legacy(register='POS1',user=''):
 """Keep existing Register runtime (which still reads v063 JSON) working.
 Limitation: current runtime uses one active register, not concurrent register sessions.
 """
 config=effective(register,user)
 LEGACY_PATH.parent.mkdir(parents=True,exist_ok=True)
 temp=LEGACY_PATH.with_suffix('.tmp')
 temp.write_text(json.dumps(config,indent=2),encoding='utf-8');temp.replace(LEGACY_PATH)

FIELDS=[('auto_scan','Auto-scan barcodes','bool'),('scan_delay','Scan delay (ms)','int'),('scan_suffix','Scanner suffix','choice'),('default_qty','Default quantity','int'),('merge_scans','Merge duplicate scans','bool'),('register_id','Register ID','text'),('opening_float','Opening float ($)','text')]

def install(cls):
 old=cls.register_settings
 def show(self):
  migrate()
  win=tk.Toplevel(self.root);win.title('Business Default Settings — TEST ONLY')
  win.geometry(f'{min(1000,win.winfo_screenwidth()-100)}x{min(730,win.winfo_screenheight()-150)}+45+35')
  win.minsize(690,490);win.configure(bg='white')
  top=tk.Frame(win,bg='white',height=65);top.pack(fill='x');top.pack_propagate(False)
  tk.Label(top,text='REGISTER SETTINGS — BUSINESS DEFAULTS',bg='white',fg='#111111',font=('Segoe UI',16,'bold')).pack(side='left',padx=18,pady=16)
  foot=tk.Frame(win,bg='#e4edf1',height=66);foot.pack(side='bottom',fill='x');foot.pack_propagate(False)
  body=tk.Frame(win,bg='white');body.pack(fill='both',expand=True,padx=12,pady=12)
  control=tk.Frame(body,bg='white');control.pack(fill='x',padx=12,pady=10)
  scope=tk.StringVar(value='Business defaults');owner=tk.StringVar(value='default')
  tk.Label(control,text='Settings apply to the entire business',bg='white',font=('Segoe UI',11,'bold')).pack(anchor='w')
  hint=tk.Label(body,text='Only business-wide defaults are active. All registers use the same values. Historical register/user overrides are ignored, not deleted.',bg='#fff5df',fg='#6a4e20',wraplength=840,justify='left',padx=12,pady=8)
  hint.pack(fill='x',padx=12)
  grid=tk.Frame(body,bg='white');grid.pack(fill='both',expand=True,padx=18,pady=12)
  variables={};dirty={'flag':False};status=tk.StringVar(value='')
  def scope_id():return 'business'
  def selected_owner():return 'default'
  def load_form(*_):
   for child in grid.winfo_children():child.destroy()
   variables.clear();dirty['flag']=False
   s=scope_id();o=selected_owner()
   with connect() as con:stored=rows(con,s,o)
   eff=effective(o if s=='register' else 'POS1',o if s=='user' else '')
   tk.Label(grid,text='Setting',bg='white',font=('Segoe UI',11,'bold')).grid(row=0,column=0,sticky='w',pady=8)
   tk.Label(grid,text='Value (inherited values shown)',bg='white',font=('Segoe UI',11,'bold')).grid(row=0,column=1,sticky='w',pady=8)
   allowed=FIELDS
   for i,(key,label,kind) in enumerate(allowed,1):
    tk.Label(grid,text=label,bg='white',font=('Segoe UI',10)).grid(row=i,column=0,sticky='w',padx=(0,25),pady=9)
    value=stored.get(key,eff.get(key,DEFAULT[key]));v=tk.BooleanVar(value=value) if kind=='bool' else tk.StringVar(value=str(value));variables[key]=v
    if kind=='bool':widget=tk.Checkbutton(grid,variable=v,bg='white')
    elif kind=='choice':widget=ttk.Combobox(grid,textvariable=v,values=['Enter','Tab','None'],state='readonly',width=25)
    else:widget=tk.Entry(grid,textvariable=v,width=30)
    widget.grid(row=i,column=1,sticky='w',pady=7)
    tk.Label(grid,text='Override' if key in stored else 'Inherited',bg='white',fg='#237681' if key in stored else '#777777').grid(row=i,column=2,padx=15)
   status.set(f'{scope.get()} — {o or "enter an identifier"}')
  def collect():
   if not selected_owner():raise ValueError('Enter a register ID or user ID')
   return {k:validate(k,v.get()) for k,v in variables.items()}
  def save():
   try:
    vals=collect();save_scope(scope_id(),selected_owner(),vals)
    sync_legacy()
    status.set('Settings saved and audited');load_form()
   except (ValueError,OSError,sqlite3.Error) as exc:messagebox.showerror('Invalid settings',str(exc),parent=win)
  def reset():
   if not messagebox.askyesno('Restore defaults','Remove overrides for this settings level? This change will be audited.',parent=win):return
   try:
    replace_scope(scope_id(),selected_owner(),{})
    sync_legacy();load_form()
   except (ValueError,OSError,sqlite3.Error) as exc:messagebox.showerror('Restore failed',str(exc),parent=win)
  def export():
   path=filedialog.asksaveasfilename(parent=win,defaultextension='.json',filetypes=[('JSON settings','*.json')],initialfile='freedom_settings_export.json')
   if path:
    try:export_json(path);status.set('Exported settings successfully')
    except (OSError,ValueError) as exc:messagebox.showerror('Export failed',str(exc),parent=win)
  def import_():
   path=filedialog.askopenfilename(parent=win,filetypes=[('JSON settings','*.json')])
   if not path:return
   if not messagebox.askyesno('Import settings','Import validated settings? Existing matching values will be replaced and the action audited.',parent=win):return
   try:
    n=import_json(path);sync_legacy();load_form();status.set(f'Imported {n} settings')
   except (OSError,ValueError,TypeError,sqlite3.Error) as exc:messagebox.showerror('Import failed',str(exc),parent=win)
  def legacy():old(self)
  tk.Button(foot,text='CLOSE',command=win.destroy,width=10).pack(side='right',padx=8,pady=14)
  tk.Button(foot,text='SAVE SETTINGS',command=save,bg='#50c1ce',width=17).pack(side='right',padx=6,pady=14)
  tk.Button(foot,text='RESTORE DEFAULTS',command=reset,width=18).pack(side='left',padx=8,pady=14)
  tk.Button(foot,text='EXPORT',command=export,width=10).pack(side='left',padx=5,pady=14)
  tk.Button(foot,text='IMPORT',command=import_,width=10).pack(side='left',padx=5,pady=14)
  tk.Button(foot,text='OTHER REGISTER OPTIONS',command=legacy,width=23).pack(side='left',padx=5,pady=14)
  tk.Label(body,textvariable=status,bg='white',fg='#166b78').pack(side='bottom',anchor='w',padx=16,pady=5)
  load_form();win.transient(self.root)
 cls.register_settings=show
