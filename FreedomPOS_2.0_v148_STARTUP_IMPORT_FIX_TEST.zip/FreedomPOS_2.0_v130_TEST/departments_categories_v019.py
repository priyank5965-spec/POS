"""Department/category management and controlled department sales (test build)."""
import tkinter as tk
from tkinter import ttk, messagebox
import sqlite3
from decimal import Decimal, InvalidOperation, ROUND_HALF_UP

BLUE='#12324A'
def install(cls):
    old_products=cls.products
    old_register_departments=cls.register_departments
    def ensure(self):
        self.db.execute('''CREATE TABLE IF NOT EXISTS departments_master(id INTEGER PRIMARY KEY,name TEXT NOT NULL UNIQUE,code TEXT NOT NULL UNIQUE,description TEXT DEFAULT '',gst TEXT DEFAULT 'GST 10%',markup TEXT DEFAULT '',label_policy TEXT DEFAULT 'Standard',notes TEXT DEFAULT '',active INTEGER NOT NULL DEFAULT 1)''')
        self.db.execute('''CREATE TABLE IF NOT EXISTS department_categories(id INTEGER PRIMARY KEY,department_id INTEGER NOT NULL REFERENCES departments_master(id),name TEXT NOT NULL,code TEXT NOT NULL,markup TEXT DEFAULT '',gst TEXT DEFAULT 'Inherit',label_policy TEXT DEFAULT 'Inherit',active INTEGER NOT NULL DEFAULT 1,UNIQUE(department_id,name),UNIQUE(department_id,code))''')
        cols=[r[1] for r in self.db.execute('PRAGMA table_info(products)')]
        for name in ('department_id','category_id'):
            if name not in cols:self.db.execute('ALTER TABLE products ADD COLUMN '+name+' INTEGER')
        self.db.commit()
    def categories_screen(self):
        ensure(self)
        self.clear();self.header('DEPARTMENTS & CATEGORIES')
        top=tk.Frame(self.root);top.pack(fill='x',padx=12,pady=9)
        departments=list(self.db.execute('SELECT * FROM departments_master ORDER BY name'))
        selection=tk.StringVar(value=departments[0]['name'] if departments else '')
        tk.Label(top,text='DEPARTMENT',font=('Segoe UI',11,'bold')).pack(side='left')
        combo=ttk.Combobox(top,textvariable=selection,values=[r['name'] for r in departments],state='readonly',width=35);combo.pack(side='left',padx=10)
        def current():return next((r for r in departments if r['name']==selection.get()),None)
        t=self.tree(self.root,['ID','Category','Code','GST','Markup %','Labels','Status'],[65,260,130,130,120,150,110],13)
        def refresh(*_):
            t.delete(*t.get_children());d=current()
            if not d:return
            for r in self.db.execute('SELECT * FROM department_categories WHERE department_id=? ORDER BY name',(d['id'],)):
                t.insert('','end',iid=str(r['id']),values=(r['id'],r['name'],r['code'],r['gst'],r['markup'],r['label_policy'],'Active' if r['active'] else 'Inactive'))
        combo.bind('<<ComboboxSelected>>',refresh)
        def form(row=None):
            d=current()
            if not d:return self.warn('Create a department first in Department Management.')
            w=tk.Toplevel(self.root);w.title('Category Details');w.geometry('760x475');w.transient(self.root);w.grab_set()
            tk.Label(w,text='CATEGORY DETAILS  /  '+d['name'],bg='white',fg='#111111',font=('Segoe UI',15,'bold'),pady=12).pack(fill='x')
            body=tk.Frame(w,padx=25,pady=15);body.pack(fill='both',expand=True)
            fields=[('name','Category name *'),('code','Category code *'),('gst','GST (Inherit / GST 10% / GST Free)'),('markup','Suggested markup % (optional)'),('label_policy','Label policy (Inherit / Standard / None)')]
            values={}
            for i,(key,label) in enumerate(fields):
                tk.Label(body,text=label).grid(row=i,column=0,sticky='w',pady=7)
                var=tk.StringVar(value=str(row[key] if row else ('Inherit' if key in ('gst','label_policy') else '')))
                tk.Entry(body,textvariable=var,font=('Segoe UI',11),width=42).grid(row=i,column=1,sticky='ew',padx=12)
                values[key]=var
            active=tk.IntVar(value=int(row['active']) if row else 1)
            tk.Checkbutton(body,text='Active',variable=active).grid(row=5,column=1,sticky='w')
            error=tk.Label(w,fg='#ad1d1d');error.pack()
            def save():
                v={k:x.get().strip() for k,x in values.items()}
                if not v['name'] or not v['code']:error.config(text='Name and code are required.');return
                if v['markup']:
                    try:
                        n=Decimal(v['markup']);assert n.is_finite() and 0<=n<=1000
                    except (InvalidOperation,AssertionError):error.config(text='Markup must be between 0 and 1000%.');return
                try:
                    with self.db:
                        if row:self.db.execute('UPDATE department_categories SET name=?,code=?,gst=?,markup=?,label_policy=?,active=? WHERE id=?',(v['name'],v['code'],v['gst'],v['markup'],v['label_policy'],active.get(),row['id']))
                        else:self.db.execute('INSERT INTO department_categories(department_id,name,code,gst,markup,label_policy,active) VALUES(?,?,?,?,?,?,?)',(d['id'],v['name'],v['code'],v['gst'],v['markup'],v['label_policy'],active.get()))
                    self.log('CATEGORY',f'{"Edited" if row else "Created"} {d["name"]} / {v["name"]}')
                    w.destroy();refresh()
                except sqlite3.IntegrityError:error.config(text='Category name/code already exists in this department.')
            tk.Button(w,text='SAVE CATEGORY',command=save,bg='white',fg='#111111',font=('Segoe UI',11,'bold'),pady=9).pack(side='right',padx=22,pady=12)
            tk.Button(w,text='CANCEL',command=w.destroy,pady=9).pack(side='right')
        def edit():
            s=t.selection()
            if s:form(self.db.execute('SELECT * FROM department_categories WHERE id=?',(int(s[0]),)).fetchone())
        actions=tk.Frame(self.root);actions.pack(fill='x',padx=16,pady=6)
        self.btn(actions,'ADD CATEGORY',lambda:form(),height=1,size=10).pack(side='left',padx=5)
        self.btn(actions,'EDIT SELECTED',edit,height=1,size=10).pack(side='left',padx=5)
        self.btn(actions,'ASSIGN PRODUCTS',self.assign_products,height=1,size=10).pack(side='left',padx=5)
        self.btn(actions,'DEPARTMENT MANAGEMENT',self.departments,height=1,size=10).pack(side='left',padx=5)
        t.bind('<Double-1>',lambda _:edit());refresh()
    def assign_products(self):
        ensure(self)
        self.clear();self.header('PRODUCT DEPARTMENT / CATEGORY ASSIGNMENT')
        top=tk.Frame(self.root);top.pack(fill='x',padx=14,pady=10)
        search=tk.StringVar();tk.Label(top,text='SEARCH BARCODE / NAME').pack(side='left')
        tk.Entry(top,textvariable=search,font=('Segoe UI',12),width=35).pack(side='left',padx=9)
        t=self.tree(self.root,['ID','Barcode','Product','Department','Category','Price'],[55,175,320,190,180,100],16)
        def refresh(*_):
            t.delete(*t.get_children())
            q='%'+search.get()+'%'
            rows=self.db.execute('''SELECT p.*,d.name AS department_name,c.name AS category_name FROM products p LEFT JOIN departments_master d ON d.id=p.department_id LEFT JOIN department_categories c ON c.id=p.category_id WHERE p.barcode LIKE ? OR p.name LIKE ? ORDER BY p.name LIMIT 500''',(q,q))
            for r in rows:t.insert('','end',iid=str(r['id']),values=(r['id'],r['barcode'],r['name'],r['department_name'] or 'Unassigned',r['category_name'] or '',f'${r["price"]/100:.2f}'))
        def assign():
            s=t.selection()
            if not s:return self.warn('Select a product.')
            pid=int(s[0]);w=tk.Toplevel(self.root);w.title('Assign Department / Category');w.geometry('650x360');w.transient(self.root);w.grab_set()
            p=self.db.execute('SELECT * FROM products WHERE id=?',(pid,)).fetchone()
            tk.Label(w,text=p['name'],font=('Segoe UI',16,'bold')).pack(pady=15)
            ds=list(self.db.execute('SELECT * FROM departments_master WHERE active=1 ORDER BY name'))
            dvar=tk.StringVar(value=next((d['name'] for d in ds if d['id']==p['department_id']),''))
            cvar=tk.StringVar();tk.Label(w,text='Department').pack();dc=ttk.Combobox(w,textvariable=dvar,values=[d['name'] for d in ds],state='readonly',width=45);dc.pack(pady=6)
            tk.Label(w,text='Category (optional)').pack();cc=ttk.Combobox(w,textvariable=cvar,state='readonly',width=45);cc.pack(pady=6)
            def update(*_):
                d=next((d for d in ds if d['name']==dvar.get()),None)
                cs=list(self.db.execute('SELECT * FROM department_categories WHERE department_id=? AND active=1 ORDER BY name',(d['id'],))) if d else []
                cc['values']=['']+[c['name'] for c in cs]
                cvar.set(next((c['name'] for c in cs if c['id']==p['category_id']),''))
            dc.bind('<<ComboboxSelected>>',update);update()
            def save():
                d=next((d for d in ds if d['name']==dvar.get()),None)
                if not d:return self.warn('Choose a department.')
                c=self.db.execute('SELECT id FROM department_categories WHERE department_id=? AND name=? AND active=1',(d['id'],cvar.get())).fetchone() if cvar.get() else None
                with self.db:self.db.execute('UPDATE products SET department_id=?,category_id=? WHERE id=?',(d['id'],c['id'] if c else None,pid))
                self.log('PRODUCT',f'Assigned product #{pid} to {d["name"]} / {cvar.get()} (price unchanged)')
                w.destroy();refresh()
            tk.Button(w,text='SAVE ASSIGNMENT',command=save,bg='white',fg='#111111',font=('Segoe UI',12,'bold'),height=2).pack(pady=12)
        self.btn(top,'ASSIGN SELECTED',assign,height=1,size=10).pack(side='left',padx=5)
        self.btn(top,'DEPARTMENTS & CATEGORIES',self.categories_screen,height=1,size=10).pack(side='left',padx=5)
        t.bind('<Double-1>',lambda _:assign());search.trace_add('write',refresh);refresh()
    def register_departments(self):
        ensure(self)
        w=tk.Toplevel(self.root);w.title('Department / Category / Product');w.geometry('1100x700');w.transient(self.root)
        bar=tk.Frame(w,bg='white');bar.pack(fill='x')
        tk.Label(bar,text='REGISTER  /  DEPARTMENTS & CATEGORIES',bg='white',fg='#111111',font=('Segoe UI',16,'bold'),pady=13).pack(side='left',padx=15)
        body=tk.Frame(w);body.pack(fill='both',expand=True,padx=12,pady=10)
        left=tk.Frame(body,width=235);left.pack(side='left',fill='y');left.pack_propagate(False)
        mid=tk.Frame(body,width=225);mid.pack(side='left',fill='y',padx=9);mid.pack_propagate(False)
        right=tk.Frame(body);right.pack(side='left',fill='both',expand=True)
        ds=list(self.db.execute('SELECT * FROM departments_master WHERE active=1 ORDER BY name'))
        tk.Label(left,text='DEPARTMENTS',font=('Segoe UI',12,'bold')).pack(anchor='w')
        dl=tk.Listbox(left,font=('Segoe UI',12),exportselection=False);dl.pack(fill='both',expand=True)
        for d in ds:dl.insert('end',d['name'])
        tk.Label(mid,text='CATEGORIES',font=('Segoe UI',12,'bold')).pack(anchor='w')
        cl=tk.Listbox(mid,font=('Segoe UI',11),exportselection=False);cl.pack(fill='both',expand=True)
        tk.Label(right,text='PRODUCTS / DEPARTMENT SALE',font=('Segoe UI',12,'bold')).pack(anchor='w')
        buttons=tk.Frame(right);buttons.pack(fill='both',expand=True)
        def add_department_sale(d):
            if not d:return
            popup=tk.Toplevel(w);popup.title('Department Sale — Test');popup.geometry('480x310');popup.transient(w);popup.grab_set()
            tk.Label(popup,text='DEPARTMENT SALE  /  '+d['name'],font=('Segoe UI',14,'bold')).pack(pady=12)
            tk.Label(popup,text='For miscellaneous sales only. Does not reduce product stock.').pack()
            v=tk.StringVar();tk.Label(popup,text='Sale amount ($)').pack(pady=(14,0))
            e=tk.Entry(popup,textvariable=v,font=('Segoe UI',18),justify='center');e.pack();e.focus_set()
            error=tk.Label(popup,fg='red');error.pack(pady=5)
            def save():
                try:
                    n=(Decimal(v.get().replace('$',''))*100).quantize(Decimal('1'),rounding=ROUND_HALF_UP)
                    if not n.is_finite() or n<=0 or n>100000000:raise ValueError()
                    amount=int(n)
                except (InvalidOperation,ValueError):error.config(text='Enter a valid positive dollar amount.');return
                self.cart.append(dict(product_id=None,description='Department sale: '+d['name'],qty=1,unit=amount,kind='DEPARTMENT SALE',original_line=None))
                self.refresh_cart();popup.destroy();w.destroy()
                if hasattr(self,'code') and self.code.winfo_exists():self.code.focus_set()
            tk.Button(popup,text='ADD TO CURRENT SALE',command=save,bg='white',fg='#111111',height=2).pack(fill='x',padx=45,pady=9)
        def show_products(d,cat=None):
            for child in buttons.winfo_children():child.destroy()
            if not d:return
            self.btn(buttons,'MISC '+d['name'].upper()+' SALE',lambda:add_department_sale(d),height=2,size=10,bg='#f6e5bf').grid(row=0,column=0,columnspan=3,sticky='ew',pady=5)
            sql='SELECT id,name,price FROM products WHERE department_id=?'
            params=[d['id']]
            if cat:sql+=' AND category_id=?';params.append(cat['id'])
            sql+=' ORDER BY name LIMIT 60'
            for i,p in enumerate(self.db.execute(sql,params)):
                self.btn(buttons,p['name']+'\n$'+format(p['price']/100,'.2f'),lambda pid=p['id']:(self.quick(pid),w.destroy()),height=2,size=9).grid(row=1+i//3,column=i%3,sticky='nsew',padx=3,pady=3)
            for i in range(3):buttons.columnconfigure(i,weight=1)
        def select_department(_=None):
            if not dl.curselection():return
            d=ds[dl.curselection()[0]]
            cs=list(self.db.execute('SELECT * FROM department_categories WHERE department_id=? AND active=1 ORDER BY name',(d['id'],)))
            cl.delete(0,'end');cl.insert('end','All products')
            for c in cs:cl.insert('end',c['name'])
            cl.selection_set(0);show_products(d)
        def select_category(_=None):
            if not dl.curselection() or not cl.curselection():return
            d=ds[dl.curselection()[0]];i=cl.curselection()[0]
            cat=None
            if i:
                cs=list(self.db.execute('SELECT * FROM department_categories WHERE department_id=? AND active=1 ORDER BY name',(d['id'],)))
                if i<=len(cs):cat=cs[i-1]
            show_products(d,cat)
        dl.bind('<<ListboxSelect>>',select_department);cl.bind('<<ListboxSelect>>',select_category)
        if ds:dl.selection_set(0);select_department()
        else:tk.Label(buttons,text='No departments configured. Add departments in Products & Stock.',fg='#9a3412').pack(pady=35)
    def products(self):
        old_products(self)
        bar=tk.Frame(self.root);bar.pack(fill='x',padx=12,pady=5)
        self.btn(bar,'DEPARTMENTS & CATEGORIES',self.categories_screen,size=10,height=1).pack(side='left',padx=4)
        self.btn(bar,'ASSIGN PRODUCT DEPARTMENT',self.assign_products,size=10,height=1).pack(side='left',padx=4)
    cls.categories_screen=categories_screen
    cls.assign_products=assign_products
    cls.register_departments=register_departments
    cls.products=products
