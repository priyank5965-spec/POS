Freedom POS 2.0 v114 — EXPERIMENTAL LINKLY TRAINING PROBE

Settings > EFTPOS — TEST / LIVE MODE > LINKLY TRAINING > SAVE SETTINGS.
Add an item, click EFT, and confirm ONLY when Linkly is configured for OFFLINE DEVELOPMENT with the Virtual PINpad.

This mode sends Linkly TCP/IP command M0 with TrainingMode=1 to localhost:2011. It attempts to parse the final M0 response, including success flag, response code, transaction type, amount, and unique reference.

IMPORTANT:
- TrainingMode=1 alone is NOT proof that the terminal is disconnected from a real bank. Confirm your Linkly installation is OFFLINE DEVELOPMENT before testing.
- This mode NEVER POSTS THE SALE, even if Linkly returns approval. This is deliberate while transaction recovery, receipt event acknowledgement, persistent attempt logging, split tenders, and integration testing remain incomplete.
- On timeout or lost connection, result is UNKNOWN. Check Linkly transaction history before retrying.
- LIVE mode remains disabled. TEST is the internal simulator. LINKLY STATUS remains read-only.
- No real Windows Linkly instance was available in the build environment. This is NOT an accredited payment integration.

Automated tests: 14 pass (including training request formatting, validation and response handling). Full POS functional and Windows Virtual PINpad end-to-end tests NOT performed.
Documentation: https://www.linkly.com.au/apidoc/TCPIP/ (Transaction command)
