Freedom POS 2.0 v0.21 — Register layout correction

Open START_FREEDOM_POS.bat, then Point of Sale.
The window title should show v0.21. The keypad starts hidden; press SHOW KEYPAD to reveal it.
The sale grid uses fewer fixed rows so important register controls remain visible on smaller screens.
Cash tender money formatting bug in v0.20 also corrected.

This is test software only. No physical EFTPOS/Windows printing verified.
