Freedom POS v0.88 TEST ONLY
Cash Tender: Enter records valid cash tender without an extra YES/NO popup.
Split Tender: Enter confirms allocation instead of moving down; no extra YES/NO popup.
Split allocations must equal the total. Esc cancels. E-PAY unissued restrictions remain.
Windows UI and complete integration require user testing.
