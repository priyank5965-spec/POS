"""Shared supplier/department master records and compact quick-add forms."""
import tkinter as tk
from tkinter import ttk, messagebox

def ensure(db):
    db.execute('CREATE TABLE IF NOT EXISTS department_master_v138 (name TEXT PRIMARY KEY COLLATE NOCASE, default_gst TEXT NOT NULL DEFAULT "GST 10%", notes TEXT NOT NULL DEFAULT "")')
    for name in ('General','Gifts','Stationery','Paper','Magazine','Newspaper','Greeting Cards','Books','Toys','Confectionery','Drinks','Other'):
        db.execute('INSERT OR IGNORE INTO department_master_v138(name) VALUES(?)',(name,))
    for (name,) in db.execute('SELECT DISTINCT category FROM products WHERE TRIM(COALESCE(category,""))<>""'):
        db.execute('INSERT OR IGNORE INTO department_master_v138(name) VALUES(?)',(name,))
    db.commit()

def choices(db,kind):
    ensure(db)
    table='supplier_master_v125' if kind=='supplier' else 'department_master_v138'
    return [r[0] for r in db.execute('SELECT name FROM '+table+' ORDER BY name COLLATE NOCASE')]

def create(app,kind,callback=None,parent=None,initial_name=""):
    from product_master_v125 import schema
    schema(app.db);ensure(app.db)
    win=tk.Toplevel(parent or app.root);win.title('New '+kind.title());win.geometry('650x480' if kind=='supplier' else '600x320');win.transient(parent or app.root)
    body=ttk.Frame(win,padding=18);body.pack(fill='both',expand=True)
    ttk.Label(body,text='New '+kind.title(),font=('Segoe UI',15,'bold')).grid(row=0,column=0,columnspan=2,sticky='w',pady=(0,14))
    specs=([('Name *',initial_name),('Contact',''),('Phone',''),('Email',''),('ABN',''),('Payment Terms',''),('Supplier Types','General Merchandise'),('Notes','')] if kind=='supplier' else [('Name *',initial_name),('Default GST','GST 10%'),('Notes','')])
    vars={}
    for i,(label,default) in enumerate(specs,1):
        ttk.Label(body,text=label).grid(row=i,column=0,sticky='w',padx=6,pady=6)
        var=tk.StringVar(value=default);vars[label]=var
        if label=='Default GST':w=ttk.Combobox(body,textvariable=var,values=('GST 10%','GST Free','GST Not Applicable'),state='readonly')
        else:w=ttk.Entry(body,textvariable=var)
        w.grid(row=i,column=1,sticky='ew',padx=6,pady=6)
        if i==1:w.focus_set()
    body.columnconfigure(1,weight=1)
    def save():
        name=vars['Name *'].get().strip()
        if not name:return messagebox.showwarning('Required','Name is required.',parent=win)
        try:
            with app.db:
                if kind=='supplier':
                    app.db.execute('INSERT INTO supplier_master_v125(name,capabilities) VALUES(?,?)',(name,vars['Supplier Types'].get().strip()))
                    app.db.execute('CREATE TABLE IF NOT EXISTS supplier_details_v138 (supplier_name TEXT PRIMARY KEY, contact TEXT, phone TEXT, email TEXT, abn TEXT, terms TEXT, notes TEXT)')
                    app.db.execute('INSERT INTO supplier_details_v138 VALUES(?,?,?,?,?,?,?)',(name,vars['Contact'].get(),vars['Phone'].get(),vars['Email'].get(),vars['ABN'].get(),vars['Payment Terms'].get(),vars['Notes'].get()))
                else:app.db.execute('INSERT INTO department_master_v138(name,default_gst,notes) VALUES(?,?,?)',(name,vars['Default GST'].get(),vars['Notes'].get()))
        except Exception as exc:return messagebox.showerror('Cannot save',str(exc),parent=win)
        win.destroy()
        if callback:callback(name)
    foot=ttk.Frame(body);foot.grid(row=len(specs)+1,column=0,columnspan=2,sticky='e',pady=12)
    ttk.Button(foot,text='Cancel',command=win.destroy).pack(side='right',padx=5)
    ttk.Button(foot,text='Save '+kind.title(),command=save).pack(side='right',padx=5)
    win.bind('<Control-s>',lambda e:save())

def attach(app,widget,var,kind,parent):
    from product_master_v125 import _attach_autocomplete
    widget._all_choices=choices(app.db,kind)
    widget._master_kind=kind
    def add(prefill=None):
        def done(name):
            var.set(name);widget._all_choices=choices(app.db,kind);widget.focus_set()
        create(app,kind,done,parent,initial_name=prefill or '')
    _attach_autocomplete(widget,var,widget.master,parent,quick_add=add)
    return add
