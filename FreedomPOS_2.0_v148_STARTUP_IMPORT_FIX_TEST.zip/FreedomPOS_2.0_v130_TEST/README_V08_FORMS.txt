Freedom POS 2.0 v0.8 — FORMS TEST (not production)

Changes:
- Staff Management > ADD STAFF now opens one complete form for name, two-digit PIN, role, inline validation, Save/Cancel.
- Email Settings includes the test recipient on the same form; no separate prompt to enter test recipient.
- Normal Gmail password is NOT supported for SMTP. Gmail App Password is needed; no credentials are bundled or saved.
- BUILD_TEST_EXE.bat now outputs FreedomPOS_Test_v08.exe.

Other legacy sequential dialogs still exist in the application and are NOT converted in this release.
This release is a targeted form conversion, not a completed POS or tested Windows executable.
