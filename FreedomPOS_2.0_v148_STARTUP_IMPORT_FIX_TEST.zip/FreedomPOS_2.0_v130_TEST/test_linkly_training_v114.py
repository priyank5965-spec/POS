import unittest
from linkly_purchase_v114 import build_purchase,parse_purchase_response,LinklyPurchaseError
class LinklyTrainingTests(unittest.TestCase):
 def test_request(self):
  b=build_purchase(1295,'F123456')
  self.assertEqual(len(b),161)
  self.assertEqual(b[:5],b'#0161')
  self.assertEqual(b[5:12],b'M000P10')
  self.assertEqual(b[21:30],b'000001295')
  self.assertEqual(b[158:161],b'000')
 def test_invalid_amount(self):
  for n in [0,-1,1.2,1000000000]:
   with self.assertRaises(ValueError):build_purchase(n,'F123')
 def test_approval(self):
  r=bytearray(b' '*257)
  r[:2]=b'M0';r[2:3]=b'1';r[3:5]=b'00';r[5:25]=b'APPROVED'.ljust(20)
  r[27:28]=b'P';r[44:53]=b'000001295';r[68:84]=b'F123456'.ljust(16)
  self.assertTrue(parse_purchase_response(bytes(r),1295,'F123456')['approved'])
  r[27:28]=b'p'
  self.assertTrue(parse_purchase_response(bytes(r),1295,'F123456')['approved'])
  r[27:28]=b'P'
  self.assertFalse(parse_purchase_response(bytes(r),1296,'F123456')['approved'])
  self.assertFalse(parse_purchase_response(bytes(r),1295,'F999')['approved'])
  r[3:5]=b'05'
  self.assertFalse(parse_purchase_response(bytes(r),1295,'F123456')['approved'])
 def test_incomplete(self):
  with self.assertRaises(LinklyPurchaseError):parse_purchase_response(b'M0',100,'F1')
if __name__=='__main__':unittest.main()
