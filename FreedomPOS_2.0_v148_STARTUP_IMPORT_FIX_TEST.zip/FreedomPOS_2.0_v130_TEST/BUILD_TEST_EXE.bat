@echo off
setlocal
cd /d "%~dp0"
where py >nul 2>nul
if %errorlevel%==0 (set "PY=py -3") else (set "PY=python")
echo Installing required dependencies for this build...
%PY% -m pip install --upgrade pyinstaller reportlab pillow google-api-python-client google-auth-oauthlib keyring
if errorlevel 1 goto failed
%PY% -c "import reportlab, PIL, PyInstaller; print('Required modules found')"
if errorlevel 1 goto failed
%PY% -m PyInstaller --noconfirm --clean --onefile --windowed --name FreedomPOS_Test_v013 --collect-all reportlab --collect-all PIL --collect-all googleapiclient --collect-all google_auth_oauthlib --collect-all google.auth --collect-all keyring --hidden-import=keyring.backends.Windows --hidden-import=google_auth_oauthlib.flow --hidden-import=reportlab.platypus --hidden-import=reportlab.lib.pagesizes --hidden-import=reportlab.lib.styles --hidden-import=reportlab.lib.colors freedom_pos.py
if errorlevel 1 goto failed
echo.
echo EXE created: dist\FreedomPOS_Test_v013.exe
echo IMPORTANT: Delete or stop using the old v0.6 EXE.
pause
exit /b 0
:failed
echo Build failed. See error above.
pause
exit /b 1
