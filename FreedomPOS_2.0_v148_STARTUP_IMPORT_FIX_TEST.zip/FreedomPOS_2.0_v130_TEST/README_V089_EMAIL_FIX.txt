Freedom POS v0.89 TEST ONLY — Previous Sales Email fix.
Fixed nonexistent customers.email lookup by joining customer_emails. Cash sales with no customer can enter recipient manually. Added visible error reporting for lookup failures, recipient focus and Esc close.
Email sends are real when Gmail OAuth is connected. Test only with your own address. This is a receipt, not an accounting invoice.
