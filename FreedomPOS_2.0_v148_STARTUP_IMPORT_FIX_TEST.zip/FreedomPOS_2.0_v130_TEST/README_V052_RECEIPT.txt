Freedom POS 2.0 v0.52 — TEST ONLY

Receipt window: 80mm or A4 only; renders inside the window using PyMuPDF and Pillow.
If the receipt is blank or dependencies are missing, close POS and run INSTALL_RECEIPT_PREVIEW.bat once on Windows.
Save PDF saves the selected layout. Print opens the Windows PDF viewer; use Ctrl+P to select the printer.
Business identity and GST fields have NOT been invented. Current source database does not provide receipt header settings or item GST breakdown; this build retains a TEST ONLY header.
Do not use generated receipts as official tax invoices until business settings and tax calculations are integrated and verified.
