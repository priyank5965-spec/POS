"""v0.37 held-sale recall and numbered sale grid; test-only."""
import tkinter as tk
from tkinter import ttk, messagebox
import json
from datetime import datetime

def merge_held(existing_cart, existing_discount, existing_customer, records):
    """Pure preparation: no mutation of the live cart or DB."""
    merged=[dict(x) for x in existing_cart]
    customers=[]
    for rec in records:
        items=json.loads(rec['cart'])
        if not isinstance(items,list) or not all(isinstance(x,dict) and isinstance(x.get('qty'),int) and isinstance(x.get('unit'),int) for x in items):
            raise ValueError('A held sale contains invalid item data.')
        items=[dict(x) for x in items]
        disc=int(rec['discount'] or 0)
        # Each hold has its own sale-level discount. When merging carts,
        # allocate that discount to its lines to preserve original totals.
        if disc:
            weights=[max(0,x['qty']*x['unit']-int(x.get('line_discount',0))) for x in items]
            if disc<0 or disc>sum(weights):raise ValueError('Invalid held-sale discount.')
            remainder=disc
            total_weight=sum(weights)
            for index,x in enumerate(items):
                allocation=(disc*weights[index]//total_weight) if index<len(items)-1 else remainder
                x['line_discount']=int(x.get('line_discount',0))+allocation
                remainder-=allocation
        merged.extend(items)
        customers.append(rec['customer_id'])
    if existing_cart:
        customer=existing_customer
    else:
        customer=customers[0] if customers and all(c==customers[0] for c in customers) else None
    return merged,existing_discount,customer

def install(cls):
    previous_pos=cls.pos
    previous_refresh=cls.refresh_cart
    def pos(self):
        previous_pos(self)
        tree=self.sale_tree
        columns=('No.','Qty','Description','Unit Price','Unit Discount','Total')
        tree.configure(columns=columns)
        for name,width,anchor in [('No.',48,'center'),('Qty',54,'center'),('Description',290,'w'),('Unit Price',100,'e'),('Unit Discount',105,'e'),('Total',105,'e')]:
            tree.heading(name,text=name)
            tree.column(name,width=width,minwidth=42,anchor=anchor,stretch=(name=='Description'))
        self.root.title('Freedom POS 2.0 — Recall & Numbered Grid v0.37 — TEST ONLY')
        self.refresh_cart()
    def refresh_cart(self):
        tree=getattr(self,'sale_tree',None)
        if tree is None or not tree.winfo_exists():return
        previous=tree.selection()
        tree.delete(*tree.get_children())
        for i,x in enumerate(self.cart):
            discount=int(x.get('line_discount',0))
            amount=x['qty']*x['unit']-discount
            tree.insert('','end',iid=str(i),values=(i+1,x['qty'],x['description'],f"${x['unit']/100:,.2f}",f"${discount/100:,.2f}",f"${amount/100:,.2f}"),tags=('refund',) if x['qty']<0 else ())
        if previous and previous[0] in tree.get_children():tree.selection_set(previous[0])
        self.total_label.config(text=f'Sub Total  ${self.total()/100:,.2f}')
        self.discount_label.config(text=f'Total Discount  ${(self.discount+sum(int(x.get("line_discount",0)) for x in self.cart))/100:,.2f}')
        if hasattr(self,'customer_label') and self.customer_label.winfo_exists():
            row=self.db.execute('SELECT name FROM customers WHERE id=?',(self.customer,)).fetchone() if self.customer else None
            self.customer_label.config(text=f"Customer: {row['name'] if row else 'Walk-in'}   |   OFFLINE TEST MODE — No real EFTPOS processing")
    def recall(self):
        if self.refund_origin is not None:
            return self.warn('Cannot recall held sales during a linked refund.')
        rows=self.db.execute('SELECT * FROM held ORDER BY id DESC').fetchall()
        if not rows:return self.warn('No held sales')
        w=tk.Toplevel(self.root)
        w.title('Recall Held Sales — click a row to add to register')
        w.geometry('940x480');w.minsize(760,360);w.transient(self.root)
        outer=tk.Frame(w,padx=14,pady=12,bg='white');outer.pack(fill='both',expand=True)
        tk.Label(outer,text='RECALL HELD SALES',anchor='w',font=('Segoe UI',17,'bold'),bg='white',fg='#111111').pack(fill='x',pady=(0,4))
        tk.Label(outer,text='Tap a row to recall it. Tick boxes to combine multiple held sales.',anchor='w',font=('Segoe UI',11,'bold'),bg='white',fg='#111111').pack(fill='x',pady=(0,8))
        # Keep action buttons visible regardless of DPI scaling or window height.
        footer=tk.Frame(outer,bg='white');footer.pack(side='bottom',fill='x',pady=(10,0))
        frame=tk.Frame(outer);frame.pack(side='top',fill='both',expand=True)
        columns=('Tick','Hold No.','Created','Reference','Items','Total')
        style=ttk.Style(w)
        style.configure('Recall.Bold.Treeview',font=('Segoe UI',11,'bold'),rowheight=43,foreground='#000000',background='#FFFFFF',fieldbackground='#FFFFFF')
        style.configure('Recall.Bold.Treeview.Heading',font=('Segoe UI',11,'bold'),foreground='#000000',background='#DDE7EC',padding=(8,9))
        style.map('Recall.Bold.Treeview',foreground=[('selected','#000000')],background=[('selected','#A5E2E7')])
        tree=ttk.Treeview(frame,columns=columns,show='headings',selectmode='browse',style='Recall.Bold.Treeview')
        for name,width in [('Tick',60),('Hold No.',90),('Created',175),('Reference',290),('Items',70),('Total',110)]:
            tree.heading(name,text=name)
            tree.column(name,width=width,anchor='center' if name in ('Tick','Hold No.','Items') else 'w',stretch=(name=='Reference'))
        sb=ttk.Scrollbar(frame,orient='vertical',command=tree.yview)
        tree.configure(yscrollcommand=sb.set);sb.pack(side='right',fill='y');tree.pack(fill='both',expand=True)
        checked=set()
        for r in rows:
            try:
                items=json.loads(r['cart']);total=sum(x['qty']*x['unit']-int(x.get('line_discount',0)) for x in items)-int(r['discount'] or 0)
                count=len(items)
            except (ValueError,TypeError,KeyError):total=0;count='?'
            tree.insert('','end',iid=str(r['id']),values=('☐',r['id'],r['created'],r['description'] or '',count,f'${total/100:,.2f}'))
        status=tk.StringVar(value='0 selected')
        tk.Label(footer,textvariable=status,anchor='w',font=('Segoe UI',10,'bold'),bg='white',fg='#111111').pack(fill='x',pady=(0,6))
        def return_focus():
            try:
                if self.code.winfo_exists():self.root.after_idle(self.code.focus_set)
            except tk.TclError:pass
        def add(ids):
            if not ids:return
            try:
                # Read and remove the exact set of holds in one DB transaction.
                self.db.execute('BEGIN IMMEDIATE')
                placeholders=','.join('?' for _ in ids)
                selected=self.db.execute('SELECT * FROM held WHERE id IN ('+placeholders+')',tuple(ids)).fetchall()
                if len(selected)!=len(ids):raise ValueError('A held sale has already been recalled. Please reopen Recall Sale.')
                selected.sort(key=lambda r:ids.index(r['id']))
                new_cart,new_discount,new_customer=merge_held(self.cart,self.discount,self.customer,selected)
                if len({r['customer_id'] for r in selected if r['customer_id'] is not None})>1 or (self.cart and self.customer is not None and any(r['customer_id'] not in (None,self.customer) for r in selected)):
                    if not messagebox.askyesno('Different customer accounts','The held sales have different customer accounts. Keep the current customer selection and combine items?',parent=w):
                        self.db.rollback();return
                self.db.execute('DELETE FROM held WHERE id IN ('+placeholders+')',tuple(ids))
                self.db.execute('INSERT INTO events(created,category,description) VALUES(?,?,?)',(datetime.now().isoformat(timespec='seconds'),'RECALL','Recalled holds '+','.join(map(str,ids))))
                self.db.commit()
            except Exception as exc:
                self.db.rollback()
                messagebox.showerror('Recall failed',str(exc),parent=w)
                return
            self.cart=new_cart;self.discount=new_discount;self.customer=new_customer
            self._armed_grid_row=None
            self.refresh_cart();w.destroy();return_focus()
        def on_click(event):
            row=tree.identify_row(event.y)
            if not row or tree.identify('region',event.x,event.y)!='cell':return
            column=tree.identify_column(event.x)
            if column=='#1':
                if row in checked:checked.remove(row)
                else:checked.add(row)
                tree.set(row,'Tick','☑' if row in checked else '☐')
                status.set(f'{len(checked)} selected')
                return 'break'
            # Clicking anywhere else on a row recalls it immediately.
            add([int(row)])
            return 'break'
        tree.bind('<Button-1>',on_click)
        controls=tk.Frame(footer,bg='white');controls.pack(fill='x')
        tk.Button(controls,text='ADD SELECTED TO SALE',font=('Segoe UI',11,'bold'),command=lambda:add([int(x) for x in tree.get_children() if x in checked]),width=24,height=2,bg='#51BDCB',fg='#000000',activebackground='#9EE2E8',relief='flat').pack(side='left',padx=(0,10))
        tk.Button(controls,text='CANCEL',font=('Segoe UI',11,'bold'),command=w.destroy,width=12,height=2,bg='#FFFFFF',fg='#000000',relief='flat').pack(side='left')
        w.protocol('WM_DELETE_WINDOW',w.destroy)
        w.bind('<Destroy>',lambda e:return_focus() if e.widget is w else None,add='+')
    cls.pos=pos
    cls.refresh_cart=refresh_cart
    cls.recall=recall
