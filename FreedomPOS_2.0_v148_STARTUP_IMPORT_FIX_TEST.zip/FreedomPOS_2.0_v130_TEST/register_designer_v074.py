"""Editable 4-column register layout, custom actions and department links. TEST ONLY."""
import json,os,tkinter as tk
from tkinter import simpledialog
from pathlib import Path
from tkinter import ttk,messagebox,colorchooser
from register_customizer_v045 import CONFIG,THEMES,apply_button_image
from department_navigation_v067 import departments

TYPES=('Product','Department','Submenu','Action','Payment')
ACTIONS={'STOCK LOOKUP':'stock_lookup','CUSTOMER':'register_customer','QUANTITY':'quantity_dialog',
         'EDIT LINE':'edit_line','HOLD SALE':'hold','RECALL SALE':'recall',
         'CANCEL SALE':'clear_cart','DELETE ITEM':'void','DISCOUNT':'set_discount',
         'PREVIOUS SALES':'previous','REFUND':'register_refund',
         'CUSTOMER PAYMENT':'register_account_payment','DEPARTMENTS':'register_departments',
         'SHIFT SALES DASHBOARD':'shift_sales_dashboard','E-PAY':'epay_window'}
PAYMENTS=('CASH','EFTPOS (TEST)','ACCOUNT SALE','SPLIT TENDER','TOTAL')

def read_cfg():
 try:
  data=json.loads(CONFIG.read_text(encoding='utf8'))
  return data if isinstance(data,dict) else {}
 except (OSError,ValueError):return {}

def write_cfg(data):
 temp=CONFIG.with_suffix('.tmp')
 temp.write_text(json.dumps(data,indent=2),encoding='utf8')
 os.replace(temp,CONFIG)

def action_for(app,item):
 typ=item.get('type');target=str(item.get('target',''))
 if typ=='Product':
  try:pid=int(target)
  except ValueError:return lambda:None
  return lambda:app.quick(pid)
 if typ=='Department':
  try:did=int(target)
  except ValueError:return lambda:None
  return lambda:app.show_department(did)
 if typ=='Submenu':
  try:did,cat=map(int,target.split(':',1))
  except (ValueError,TypeError):return lambda:None
  return lambda:app.show_department(did) if not hasattr(app,'_department_page') else _open_submenu(app,did,cat)
 if typ=='Payment':
  return {'CASH':app.register_cash,'EFTPOS (TEST)':lambda:app.checkout('EFTPOS SIMULATED'),
          'ACCOUNT SALE':lambda:app.checkout('ACCOUNT'),'SPLIT TENDER':app.split_payment,
          'TOTAL':lambda:__import__('register_tower_v022').show_total(app)}.get(target,lambda:None)
 if typ=='Action':
  if target=='QUANTITY':
   from register_tower_v022 import quantity_dialog
   return lambda:quantity_dialog(app)
  fn=getattr(app,ACTIONS.get(target,''),None)
  return fn if callable(fn) else lambda:messagebox.showwarning('Unavailable',f'{target} is unavailable in this build.',parent=app.root)
 return lambda:None

def _open_submenu(app,did,cat):
 app._department_page=('products',did,cat)
 app._department_product_page=0
 app.render_department_navigation() if hasattr(app,'render_department_navigation') else app.show_department(did)

def install(cls):
 old_apply=cls.apply_register_customization
 def apply(self):
  old_apply(self)
  tiles=getattr(self,'_register_tiles',{})
  if not tiles:return
  cfg=read_cfg();saved=cfg.get('designer_v074',{})
  if not isinstance(saved,dict):return
  positions=saved.get('positions',{})
  hidden=set(saved.get('hidden',[]))
  for key,t in tiles.items():
   b=t['widget']
   if key in hidden:b.grid_remove()
   else:
    b.grid()
    pos=positions.get(key)
    if isinstance(pos,int) and 0<=pos<40:b.grid_configure(row=pos//4,column=pos%4)
  parent=next(iter(tiles.values()))['widget'].master
  for b in getattr(self,'_designer_extra_buttons',[]):
   try:b.destroy()
   except tk.TclError:pass
  self._designer_extra_buttons=[]
  for item in saved.get('custom',[]):
   try:
    p=int(item['position']);assert 0<=p<40
    b=tk.Button(parent,text=item.get('label','BUTTON'),command=action_for(self,item),
                bg=item.get('bg') or '#c7c7c7',fg=item.get('fg') or '#1e1e1e',
                font=('Segoe UI',10,'bold'),wraplength=115,relief='solid',bd=1)
    b.grid(row=p//4,column=p%4,sticky='nsew',padx=2,pady=2)
    apply_button_image(b,item.get('image',''))
    self._designer_extra_buttons.append(b)
   except (KeyError,ValueError,AssertionError,tk.TclError):continue
 cls.apply_register_customization=apply

 def editor(self):
  tiles=getattr(self,'_register_tiles',{})
  if not tiles:
   messagebox.showwarning('Register','Open the Register first.',parent=self.root);return
  cfg=read_cfg();saved=cfg.get('designer_v074',{})
  hidden=set(saved.get('hidden',[]));positions={}
  occupied={}
  for key,t in tiles.items():
   if key in hidden:continue
   pos=saved.get('positions',{}).get(key,t['row']*4+t['col'])
   if not isinstance(pos,int) or not 0<=pos<40 or pos in occupied:continue
   occupied[pos]=dict(id=key,type='Built-in',label=cfg.get('buttons',{}).get(key,{}).get('label',t['label']),
                      bg=cfg.get('buttons',{}).get(key,{}).get('bg',''),fg=cfg.get('buttons',{}).get(key,{}).get('fg',''),image=cfg.get('buttons',{}).get(key,{}).get('image',''))
  for item in saved.get('custom',[]):
   p=item.get('position')
   if isinstance(p,int) and 0<=p<40 and p not in occupied:occupied[p]=dict(item)
  w=tk.Toplevel(self.root);w.title('Register Button Designer — Add / Edit / Remove — TEST ONLY')
  sw=w.winfo_screenwidth();sh=w.winfo_screenheight()
  w.geometry(f'{min(1450,sw-45)}x{min(850,sh-110)}')
  w.minsize(min(900,sw-45),min(590,sh-110));w.configure(bg='white');w.transient(self.root)
  heading=tk.Frame(w,bg='white');heading.pack(fill='x')
  tk.Label(heading,text='REGISTER BUTTON DESIGNER — BUSINESS DEFAULTS',font=('Segoe UI',16,'bold'),bg='white',fg='#111111',pady=13).pack(side='left',padx=15)
  footer=tk.Frame(w,bg='#e5eef1');footer.pack(side='bottom',fill='x',padx=12,pady=8)
  info=tk.StringVar(value='Click an empty position to add a button. Select an existing button to edit or remove.')
  tk.Label(w,textvariable=info,anchor='w',bg='#e5eef1',pady=7).pack(side='bottom',fill='x',padx=12)
  body=tk.Frame(w,bg='white');body.pack(fill='both',expand=True,padx=12,pady=8)
  left=tk.Frame(body,bg='white');left.pack(side='left',fill='both',expand=True)
  canvas=tk.Canvas(left,bg='#ffffff',highlightthickness=0);canvas.pack(side='left',fill='both',expand=True)
  scroll=ttk.Scrollbar(left,orient='vertical',command=canvas.yview);scroll.pack(side='right',fill='y');canvas.configure(yscrollcommand=scroll.set)
  board=tk.Frame(canvas,bg='#ffffff');canvas_id=canvas.create_window((0,0),window=board,anchor='nw')
  board.bind('<Configure>',lambda e:canvas.configure(scrollregion=canvas.bbox('all')))
  canvas.bind('<Configure>',lambda e:canvas.itemconfigure(canvas_id,width=e.width))
  panel=tk.Frame(body,bg='white',width=340);panel.pack(side='right',fill='y',padx=(10,0));panel.pack_propagate(False)
  selected=tk.IntVar(value=0);typ=tk.StringVar(value='Product');name=tk.StringVar();target=tk.StringVar();bg=tk.StringVar();fg=tk.StringVar();theme=tk.StringVar(value=cfg.get('theme','Freedom Classic'))
  for c in range(4):board.columnconfigure(c,weight=1,uniform='col')
  buttons=[]
  def repaint():
   for i,b in enumerate(buttons):
    item=occupied.get(i)
    b.configure(text=(item.get('label','BUTTON') if item else '+ ADD BUTTON'),
                bg=(item.get('bg') or '#c7c7c7') if item else '#edf6f7',
                fg=(item.get('fg') or '#1e1e1e') if item else '#2b7180',
                highlightthickness=3 if selected.get()==i else 1,
                highlightbackground='#08a9b4' if selected.get()==i else '#bdcbd1')
  def pick(i):
   selected.set(i);item=occupied.get(i)
   typ.set(item.get('type','Product') if item and item.get('type')!='Built-in' else ('Built-in' if item else 'Product'))
   name.set(item.get('label','') if item else '');target.set(str(item.get('target','')) if item else '')
   bg.set(item.get('bg','') if item else '');fg.set(item.get('fg','') if item else '')
   repaint();refresh_targets()
   if typ.get()=='Product':search_products()
   info.set(f'Position {i+1}: '+('Edit / Remove Button' if item else 'Choose a type and click Add Button'))
  for i in range(40):
   b=tk.Button(board,font=('Segoe UI',10,'bold'),wraplength=150,height=3,command=lambda p=i:pick(p))
   b.grid(row=i//4,column=i%4,sticky='nsew',padx=3,pady=3);buttons.append(b)
  tk.Label(panel,text='BUTTON EDITOR',bg='white',font=('Segoe UI',14,'bold'),fg='#111111').pack(pady=(12,8))
  tk.Label(panel,text='Button type',bg='white',anchor='w').pack(fill='x',padx=12)
  types=ttk.Combobox(panel,textvariable=typ,values=('Built-in',)+TYPES,state='readonly');types.pack(fill='x',padx=12,pady=4)
  tk.Label(panel,text='Button name',bg='white',anchor='w').pack(fill='x',padx=12)
  tk.Entry(panel,textvariable=name).pack(fill='x',padx=12,pady=4)
  tk.Label(panel,text='Linked product / department / action',bg='white',anchor='w',wraplength=300).pack(fill='x',padx=12)
  links=ttk.Combobox(panel,textvariable=target,state='readonly');links.pack(fill='x',padx=12,pady=4)
  tk.Label(panel,text='Search stock by name, barcode or product ID',bg='white',anchor='w').pack(fill='x',padx=12)
  product_search=tk.StringVar()
  search_entry=tk.Entry(panel,textvariable=product_search)
  search_entry.pack(fill='x',padx=12,pady=(2,3))
  product_results=tk.Listbox(panel,height=5,exportselection=False,font=('Segoe UI',9))
  product_results.pack(fill='x',padx=12,pady=(0,4))
  product_ids=[]
  def search_products(*_):
   product_results.delete(0,'end');product_ids.clear()
   if typ.get()!='Product':return
   term=product_search.get().strip()
   try:
    if term:
     rows=self.db.execute('SELECT id,name,barcode FROM products WHERE name LIKE ? OR barcode LIKE ? OR CAST(id AS TEXT)=? ORDER BY name LIMIT 60',('%'+term+'%','%'+term+'%',term)).fetchall()
    else:rows=self.db.execute('SELECT id,name,barcode FROM products ORDER BY name LIMIT 60').fetchall()
    for r in rows:
     product_ids.append(str(r['id']))
     product_results.insert('end',f'{r["name"]}  |  {r["barcode"]}  |  ID {r["id"]}')
   except Exception:pass
  def select_product(event=None):
   choice=product_results.curselection()
   if not choice:return
   i=choice[0]
   if i>=len(product_ids):return
   target.set(product_ids[i])
   if not name.get().strip():
    name.set(product_results.get(i).split('  |  ')[0])
  product_results.bind('<<ListboxSelect>>',select_product)
  product_search.trace_add('write',search_products)

  options=[]
  def refresh_targets(event=None):
   nonlocal options
   t=typ.get();options=[]
   if t=='Product':
    try:options=[(f'{r["name"]} [ID {r["id"]}]',str(r['id'])) for r in self.db.execute('SELECT id,name FROM products ORDER BY name LIMIT 3000')]
    except Exception:pass
   elif t=='Department':options=[(f'{r["name"]} [ID {r["id"]}]',str(r['id'])) for r in departments(self)]
   elif t=='Submenu':
    try:
     options=[(f'{r["department"]} / {r["name"]}',f'{r["department_id"]}:{r["id"]}') for r in self.db.execute('SELECT c.id,c.name,c.department_id,d.name department FROM department_categories c JOIN departments_master d ON d.id=c.department_id WHERE c.active=1 ORDER BY d.name,c.name')]
    except Exception:pass
   elif t=='Action':options=[(k,k) for k in ACTIONS]
   elif t=='Payment':options=[(k,k) for k in PAYMENTS]
   links['values']=[x[0] for x in options]
   if options:
    existing=next((label for label,val in options if val==target.get()),None)
    if existing:target.set(existing)
    elif target.get() not in [x[0] for x in options]:target.set('')
   else:links['values']=[]
  types.bind('<<ComboboxSelected>>',lambda e:(refresh_targets(),search_products()))
  for title,var in [('Background colour',bg),('Text colour',fg)]:
   row=tk.Frame(panel,bg='white');row.pack(fill='x',padx=12,pady=5)
   tk.Label(row,text=title,bg='white').pack(anchor='w')
   entry=tk.Entry(row,textvariable=var);entry.pack(side='left',fill='x',expand=True)
   def choose(v=var):
    value=colorchooser.askcolor(color=v.get() or '#c7c7c7',parent=w)[1]
    if value:v.set(value)
   tk.Button(row,text='Choose',command=choose).pack(side='left')
  def validate_fields():
   if not name.get().strip():raise ValueError('Enter a button name.')
   for v in (bg,fg):
    if v.get().strip():w.winfo_rgb(v.get().strip())
   t=typ.get();raw=target.get();mapped=next((value for label,value in options if label==raw),raw)
   if t not in ('Built-in',) and not mapped:raise ValueError('Select the linked product, department or action.')
   if t=='Product':
    if not str(mapped).isdigit() or not self.db.execute('SELECT 1 FROM products WHERE id=?',(int(mapped),)).fetchone():
     raise ValueError('Select a valid stock item from search results.')
   return dict(type=t,label=name.get().strip(),target=mapped,bg=bg.get().strip(),fg=fg.get().strip())
  def upsert():
   p=selected.get();old=occupied.get(p)
   if old and old.get('type')=='Built-in':
    item=dict(old);item.update(label=name.get().strip(),bg=bg.get().strip(),fg=fg.get().strip())
    if not item['label']:messagebox.showwarning('Name','Enter a name.',parent=w);return
   else:
    try:item=validate_fields()
    except (ValueError,tk.TclError) as e:messagebox.showwarning('Button',str(e),parent=w);return
   if old and old.get('type')=='Built-in' and typ.get()!='Built-in':
    messagebox.showwarning('Built-in Button','Remove the built-in button first, then add a new button.',parent=w);return
   occupied[p]=item;repaint();info.set('Button updated in preview. Click Save Layout to keep it.')
  def remove():
   p=selected.get()
   if p not in occupied:return
   occupied.pop(p);pick(p);info.set('Button removed from preview. Save Layout to keep changes.')
  def move():
   p=selected.get();destination=simpledialog.askinteger('Move Button','Move to position (1–40):',initialvalue=p+1,minvalue=1,maxvalue=40,parent=w)
   if destination is None:return
   q=destination-1
   occupied[p],occupied[q]=occupied.get(q),occupied.get(p)
   for n in (p,q):
    if occupied[n] is None:occupied.pop(n)
   pick(q)
  tk.Button(panel,text='ADD / UPDATE BUTTON',command=upsert,bg='#20b7ba',font=('Segoe UI',10,'bold'),pady=8).pack(fill='x',padx=12,pady=(16,4))
  tk.Button(panel,text='REMOVE BUTTON',command=remove,pady=7).pack(fill='x',padx=12,pady=4)
  tk.Button(panel,text='MOVE / SWAP POSITION',command=move,pady=7).pack(fill='x',padx=12,pady=4)
  tk.Label(panel,text='Removing a button does not delete the product. Changes apply to every register (Business Defaults).',wraplength=290,bg='white',fg='#536478').pack(padx=12,pady=12)
  def save():
   positions={};hidden=[];custom=[]
   for p,item in occupied.items():
    if item['type']=='Built-in':
     positions[item['id']]=p
     cfg.setdefault('buttons',{}).setdefault(item['id'],{}).update(label=item['label'],bg=item.get('bg',''),fg=item.get('fg',''))
    else:custom.append(dict(item,position=p))
   hidden=[k for k in tiles if k not in positions]
   cfg['designer_v074']={'positions':positions,'hidden':hidden,'custom':custom}
   try:write_cfg(cfg)
   except OSError as e:messagebox.showerror('Save failed',str(e),parent=w);return
   self.apply_register_customization();w.destroy()
  tk.Button(footer,text='CANCEL',command=w.destroy,padx=18,pady=9).pack(side='right',padx=4)
  tk.Button(footer,text='SAVE LAYOUT',command=save,bg='#20b7ba',font=('Segoe UI',10,'bold'),padx=18,pady=9).pack(side='right',padx=4)
  tk.Button(footer,text='RESTORE DEFAULT',command=lambda:restore(),padx=12,pady=9).pack(side='left',padx=4)
  def restore():
   if not messagebox.askyesno('Restore Default','Restore all original Register buttons and remove custom buttons?',parent=w):return
   occupied.clear()
   for key,t in tiles.items():
    p=t['row']*4+t['col'];occupied[p]=dict(id=key,type='Built-in',label=t['label'],bg='',fg='',image='')
   pick(0)
  pick(0)
 cls.register_customizer=editor
