"""Weekday newspaper product editor. TEST ONLY."""
import tkinter as tk
from tkinter import ttk, messagebox
from decimal import Decimal, ROUND_HALF_UP

DAYS=('Monday','Tuesday','Wednesday','Thursday','Friday','Saturday','Sunday')

def cents(s):
    n=Decimal(s.strip().replace('$','') or '0')
    if not n.is_finite() or n<0: raise ValueError('Prices must be non-negative numbers')
    return int((n*100).quantize(Decimal('1'),rounding=ROUND_HALF_UP))

def schema(db):
    db.execute('''CREATE TABLE IF NOT EXISTS newspaper_weekdays_v134 (
       title TEXT NOT NULL, day INTEGER NOT NULL, product_id INTEGER NOT NULL UNIQUE,
       cost_cents INTEGER NOT NULL DEFAULT 0, active INTEGER NOT NULL DEFAULT 1,
       PRIMARY KEY(title,day))''')
    db.execute('''CREATE TABLE IF NOT EXISTS newspaper_metadata_v135 (title TEXT PRIMARY KEY,plu TEXT NOT NULL,department TEXT NOT NULL,frequency TEXT NOT NULL,supplier TEXT NOT NULL,supplier_code TEXT NOT NULL)''')
    db.execute('''CREATE TABLE IF NOT EXISTS quick_sell_codes_v136 (code TEXT PRIMARY KEY COLLATE NOCASE, product_id INTEGER, newspaper_title TEXT, CHECK ((product_id IS NULL) != (newspaper_title IS NULL)))''')
    db.commit()

def editor(app,title=None,refresh=None):
    db=app.db;schema(db)
    win=tk.Toplevel(app.root)
    win.configure(bg='white')
    win.title('Freedom POS — Newspaper Product Setup')
    win.geometry('1180x735')
    win.minsize(990,620)
    win.state('zoomed') if win.tk.call('tk','windowingsystem')=='win32' else None
    style=ttk.Style(win)
    style.configure('PM.White.TNotebook',background='#f5f6f8',borderwidth=0)
    style.configure('PM.White.TNotebook.Tab',background='#f2f2f2',foreground='#111111',
                    padding=(12,7),font=('Segoe UI',10))
    style.map('PM.White.TNotebook.Tab',background=[('selected','white')],foreground=[('selected','#000000')])
    nav=tk.Frame(win,bg='#253344',height=43)
    nav.pack(fill='x')
    nav.pack_propagate(False)
    tk.Label(nav,text='Freedom POS',bg='#253344',fg='white',
             font=('Segoe UI',12,'bold')).pack(side='left',padx=(15,24))
    tk.Label(nav,text='BACK OFFICE  /  PRODUCTS',bg='#253344',
             fg='#dbe3ec',font=('Segoe UI',9)).pack(side='left')
    head=tk.Frame(win,bg='white')
    head.pack(fill='x')
    tk.Label(head,text='Newspaper Product Setup',bg='white',
             font=('Segoe UI',13,'bold')).pack(side='left',padx=15,pady=10)
    tk.Label(head,text='New newspaper' if not title else 'Edit newspaper',bg='white',fg='#758293',font=('Segoe UI',10)).pack(side='left')
    tk.Frame(win,bg='#d8dde3',height=1).pack(fill='x')
    # Footer is outside the notebook so it never scrolls off-screen.
    footer=tk.Frame(win,bg='white',padx=12,pady=9,height=53)
    footer.pack(side='bottom',fill='x')
    notebook=ttk.Notebook(win,style='PM.White.TNotebook')
    notebook.pack(fill='both',expand=True,padx=12,pady=(10,6))
    panel=tk.Frame(notebook,bg='white',padx=14,pady=10)
    notebook.add(panel,text='General')
    weekday_panel=tk.Frame(notebook,bg='white',padx=14,pady=10)
    notebook.add(weekday_panel,text='Weekday Barcodes & Pricing')
    tk.Label(panel,text='Newspaper details',font=('Segoe UI',12,'bold'),
             bg='white').grid(row=0,column=0,columnspan=4,sticky='w',pady=(0,6))
    fields={}
    def field(label,row,col,default='',options=None):
        tk.Label(panel,text=label,bg='white',font=('Segoe UI',10)).grid(row=row,column=col,sticky='w',pady=4)
        var=tk.StringVar(value=default)
        widget=(ttk.Combobox(panel,textvariable=var,values=options,state='readonly' if label=='Frequency' else 'normal') if options is not None else ttk.Entry(panel,textvariable=var))
        widget.grid(row=row,column=col+1,sticky='ew',padx=(5,20),pady=4)
        fields[label]=var
        return widget
    first=field('Newspaper name',1,0);field('PLU',1,2)
    dept_widget=field('Department',2,0,'Newspaper');field('Frequency',2,2,'Daily',['Daily','Weekly'])
    from shared_masters_v138 import attach, choices
    suppliers=choices(db,'supplier')
    supp_widget=field('Supplier',3,0,options=suppliers);field('Supplier code',3,2)
    for kind,w,key in (('supplier',supp_widget,'Supplier'),('department',dept_widget,'Department')):
        attach(app,w,fields[key],kind,win)
    field('Register Shortcut Key',4,0)
    titles=[r[0] for r in db.execute('SELECT title FROM newspaper_metadata_v135 UNION SELECT DISTINCT title FROM newspaper_weekdays_v134 ORDER BY title')]
    tk.Label(weekday_panel,text='Weekday configuration',bg='white',font=('Segoe UI',12,'bold')).grid(row=0,column=0,columnspan=4,sticky='w',pady=(9,5))
    for c in (1,3):panel.columnconfigure(c,weight=1)
    for c in (1,3):weekday_panel.columnconfigure(c,weight=1)
    grid=tk.Frame(weekday_panel,bg='white');grid.grid(row=1,column=0,columnspan=4,sticky='nsew',pady=(8,4));weekday_panel.rowconfigure(1,weight=1)
    for j,h in enumerate(('Day','Barcode','Cost ($ ex GST)','Retail ($ inc GST)')):
        tk.Label(grid,text=h,bg='#e7ecf1',font=('Segoe UI',10,'bold'),padx=8,pady=8,anchor='w').grid(row=0,column=j,sticky='ew',padx=2)
        grid.columnconfigure(j,weight=1)
    rows=[];order=[]
    from product_master_v125 import make_barcode
    for i,day in enumerate(DAYS):
        active=tk.BooleanVar(value=i<6);barcode=tk.StringVar();cost=tk.StringVar();retail=tk.StringVar()
        ttk.Checkbutton(grid,text=day,variable=active).grid(row=i+1,column=0,sticky='w',padx=8,pady=4)
        entries=[]
        for j,var in enumerate((barcode,cost,retail),1):
            e=ttk.Entry(grid,textvariable=var,width=20);e.grid(row=i+1,column=j,sticky='ew',padx=6,pady=4);entries.append(e);order.append(e)
        def toggle(*_,active=active,entries=entries):
            for e in entries:e.configure(state='normal' if active.get() else 'disabled')
        active.trace_add('write',toggle);toggle()
        rows.append((active,barcode,cost,retail))
    for i,w in enumerate(order):
        w.bind('<Tab>',lambda e,i=i:(next((x for x in order[i+1:]+order[:i+1] if str(x.cget('state'))=='normal'),w).focus_set(),'break')[1])
        w.bind('<Shift-Tab>',lambda e,i=i:(next((x for x in list(reversed(order[:i]))+list(reversed(order[i:])) if str(x.cget('state'))=='normal'),w).focus_set(),'break')[1])
        w.bind('<ISO_Left_Tab>',lambda e,i=i:(next((x for x in list(reversed(order[:i]))+list(reversed(order[i:])) if str(x.cget('state'))=='normal'),w).focus_set(),'break')[1])
    def generate_weekday():
        focused=win.focus_get()
        for active,barcode,cost,retail in rows:
            if focused in order and focused is order[order.index(focused)] and focused in order:
                idx=order.index(focused)//3
                if rows[idx][0].get() and not rows[idx][1].get().strip():rows[idx][1].set(make_barcode(db))
                return 'break'
        for active,barcode,cost,retail in rows:
            if active.get() and not barcode.get().strip():barcode.set(make_barcode(db));break
        return 'break'
    tk.Button(weekday_panel,text='Generate weekday barcode (Alt + R)',command=generate_weekday,bg='#e1e9f0',relief='solid',bd=1).grid(row=0,column=2,columnspan=2,sticky='e')
    win.bind('<Alt-r>',lambda e:generate_weekday());win.bind('<Alt-R>',lambda e:generate_weekday())
    def load(event=None):
        if not title:return
        fields['Newspaper name'].set(title)
        quick=db.execute('SELECT code FROM quick_sell_codes_v136 WHERE newspaper_title=?',(title,)).fetchone()
        fields['Register Shortcut Key'].set(quick[0] if quick else '')
        meta=db.execute('SELECT plu,department,frequency,supplier,supplier_code FROM newspaper_metadata_v135 WHERE title=?',(title,)).fetchone()
        if meta:
            for key,value in zip(('PLU','Department','Frequency','Supplier','Supplier code'),meta):fields[key].set(value)
        data=db.execute('''SELECT n.day,n.active,n.cost_cents,p.barcode,p.price,p.supplier,p.supplier_code
          FROM newspaper_weekdays_v134 n JOIN products p ON p.id=n.product_id WHERE n.title=?''',(title,)).fetchall()
        if data:fields['Supplier'].set(data[0][5]);fields['Supplier code'].set(data[0][6])
        for a,b,c,r in rows:a.set(False);b.set('');c.set('');r.set('')
        for day,active,cost,barcode,price,supplier,code in data:
            a,b,c,r=rows[day];a.set(bool(active));b.set('' if barcode.startswith('INTERNAL-') else barcode);c.set(f'{cost/100:.2f}');r.set(f'{price/100:.2f}')
    if title and title in titles:
        load()
    tk.Label(weekday_panel,text='One product per active weekday. Saving does not change existing stock quantities.',bg='white',fg='#556070').grid(row=2,column=0,columnspan=4,sticky='w',pady=12)
    def save():
        try:
            title=fields['Newspaper name'].get().strip();plu=fields['PLU'].get().strip()
            supplier=fields['Supplier'].get().strip();department=fields['Department'].get().strip()
            if not title:raise ValueError('Newspaper name is required')
            from quick_sell_v136 import validate_code
            quick=validate_code(db,fields['Register Shortcut Key'].get(),exclude_title=title)
            selected=[]
            for i,(a,b,c,r) in enumerate(rows):
                if a.get():
                    selected.append((i,b.get().strip(),cents(c.get()),cents(r.get())))
            # Title may be saved before any publication days are configured.
            provided=[x[1] for x in selected if x[1]]
            if len(set(provided))!=len(provided):raise ValueError('Duplicate weekday barcodes')
            current=dict(db.execute('SELECT day,product_id FROM newspaper_weekdays_v134 WHERE title=?',(title,)).fetchall())
            for day,barcode,cost,price in selected:
                pid=current.get(day,-1)
                if barcode and db.execute('SELECT 1 FROM products WHERE barcode=? AND id<>?',(barcode,pid)).fetchone():raise ValueError('Barcode already used: '+barcode)
                if barcode and db.execute('SELECT 1 FROM product_barcodes WHERE barcode=? AND product_id<>?',(barcode,pid)).fetchone():raise ValueError('Additional barcode already used: '+barcode)
            with db:
                db.execute('''INSERT INTO newspaper_metadata_v135(title,plu,department,frequency,supplier,supplier_code) VALUES(?,?,?,?,?,?)
                  ON CONFLICT(title) DO UPDATE SET plu=excluded.plu,department=excluded.department,frequency=excluded.frequency,supplier=excluded.supplier,supplier_code=excluded.supplier_code''',
                  (title,plu,department,fields['Frequency'].get(),supplier,fields['Supplier code'].get().strip()))
                db.execute('DELETE FROM quick_sell_codes_v136 WHERE newspaper_title=?',(title,))
                if quick:db.execute('INSERT INTO quick_sell_codes_v136(code,newspaper_title) VALUES(?,?)',(quick,title))
                for day,barcode,cost,price in selected:
                    description=title+' - '+DAYS[day]
                    if day in current:
                        pid=current[day]
                        if not barcode:
                            old=db.execute('SELECT barcode FROM products WHERE id=?',(pid,)).fetchone()[0]
                            barcode=old if old.startswith('INTERNAL-') else old
                        db.execute('UPDATE products SET barcode=?,name=?,price=?,category=?,supplier=?,supplier_code=? WHERE id=?',
                                   (barcode,description,price,department,supplier,fields['Supplier code'].get().strip(),pid))
                    else:
                        # The legacy products table requires a unique non-null barcode.
                        # Internal ID is used when staff leave the external barcode blank.
                        import uuid
                        stored_barcode=barcode or ('INTERNAL-'+uuid.uuid4().hex.upper())
                        pid=db.execute('INSERT INTO products(barcode,name,price,stock,category,supplier,supplier_code) VALUES(?,?,?,0,?,?,?)',
                                       (stored_barcode,description,price,department,supplier,fields['Supplier code'].get().strip())).lastrowid
                    db.execute('INSERT OR REPLACE INTO newspaper_weekdays_v134(title,day,product_id,cost_cents,active) VALUES(?,?,?,?,1)',(title,day,pid,cost))
                for day in current:
                    if day not in [s[0] for s in selected]:db.execute('UPDATE newspaper_weekdays_v134 SET active=0 WHERE title=? AND day=?',(title,day))
            messagebox.showinfo('Newspaper saved',f'{title}: {len(selected)} weekday records saved. Stock quantities preserved.',parent=win)
            win.destroy()
            if refresh:refresh()
        except Exception as exc:messagebox.showerror('Newspaper setup',str(exc),parent=win)
    # Persistent bottom action bar matches Product Master.
    tk.Button(footer,text='Cancel',command=win.destroy,bg='#e9e9e9',width=12,relief='solid',bd=1).pack(side='right',padx=6)
    tk.Button(footer,text='Save Newspaper (Ctrl+S)',command=save,bg='#e9e9e9',width=24,relief='solid',bd=1).pack(side='right',padx=6)
    win.bind('<Control-s>',lambda e:save());first.focus_set()

def install(cls):
    cls.newspaper_product_setup=editor
    old=cls.products
    def products(self):
        old(self)
        bar=tk.Frame(self.root,bg='white');bar.pack(fill='x',padx=12,pady=4)
        tk.Button(bar,text='NEWSPAPER PRODUCT SETUP',command=lambda:self.newspaper_product_setup(),bg='#e1e9f0',fg='#172b40',bd=1,relief='solid',font=('Segoe UI',10,'bold'),padx=12,pady=4).pack(side='left')
    cls.products=products
