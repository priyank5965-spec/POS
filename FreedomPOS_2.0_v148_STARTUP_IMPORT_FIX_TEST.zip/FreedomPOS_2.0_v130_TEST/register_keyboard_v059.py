"""Configurable register shortcuts, scoped to the active register. TEST ONLY."""
import json
import tkinter as tk
from tkinter import ttk, messagebox
from pathlib import Path

FILE=Path(__file__).resolve().parent/'keyboard_shortcuts_v059.json'
ACTIONS=[('Stock Lookup','?'),('Quantity','F2'),('Discount','F3'),('Hold Sale','F4'),('Recall Sale','F5'),('Customer Lookup','F6'),('Cash Payment','F8'),('EFTPOS','F9'),('Delete Selected Item','Delete'),('Clear Sale','Ctrl+Delete')]
DEFAULTS=dict(ACTIONS)

def canonical(value):
    s=str(value).strip().replace(' ','').replace('Control+','Ctrl+').replace('Control-','Ctrl+').replace('Ctrl-','Ctrl+')
    bits=s.split('+'); modifiers=[]
    for bit in bits[:-1]:
        if bit.lower() in ('ctrl','control'): modifiers.append('Ctrl')
        elif bit.lower()=='shift': modifiers.append('Shift')
        elif bit.lower()=='alt': modifiers.append('Alt')
        else: raise ValueError('Unknown modifier: '+bit)
    key=bits[-1]
    if not key:raise ValueError('Choose a key')
    if key.lower() in ('question','?'):key='?'
    elif key.lower() in ('delete','del'):key='Delete'
    elif key.lower().startswith('f') and key[1:].isdigit() and 1<=int(key[1:])<=12:key='F'+str(int(key[1:]))
    elif len(key)==1 and key.isalpha():key=key.upper()
    elif len(key)==1 and key.isdigit():pass
    else:raise ValueError('Use ?, F1–F12, Delete, or a letter/number with modifiers')
    if key.isalnum() and len(key)==1 and not modifiers:raise ValueError('Single letters/digits interfere with barcode entry; add Ctrl or Alt')
    if key=='?' and modifiers:raise ValueError('Use ? without modifiers')
    if len(modifiers)!=len(set(modifiers)):raise ValueError('Repeated modifier')
    return '+'.join([x for x in ('Ctrl','Alt','Shift') if x in modifiers]+[key])

def validate(mapping):
    seen={}
    for action,_ in ACTIONS:
        key=canonical(mapping[action])
        if key in seen:raise ValueError('Duplicate shortcut '+key+': '+seen[key]+' and '+action)
        seen[key]=action
    return {a:canonical(mapping[a]) for a,_ in ACTIONS}

def load():
    try:
        saved=json.loads(FILE.read_text(encoding='utf-8'))
        if isinstance(saved,dict):return validate({**DEFAULTS,**{k:v for k,v in saved.items() if k in DEFAULTS}})
    except (OSError,ValueError,KeyError,TypeError):pass
    return DEFAULTS.copy()

def from_event(event):
    key=event.keysym
    if event.char=='?' or key=='question':key='?'
    elif key in ('Delete','KP_Delete'):key='Delete'
    elif key.lower().startswith('f') and key[1:].isdigit():key='F'+key[1:]
    elif len(key)==1 and key.isalnum():key=key.upper()
    else:return None
    mods=[]
    if event.state & 0x0004:mods.append('Ctrl')
    if event.state & 0x0008:mods.append('Alt')
    if event.state & 0x0001 and key!='?':mods.append('Shift')
    return '+'.join(mods+[key])

def install(cls):
    original_pos=cls.pos
    original_settings=cls.settings
    def pos(self):
        original_pos(self)
        self._shortcut_mapping=load()
        def on_key(event):
            if not self.code.winfo_exists() or not self.sale_tree.winfo_exists():return
            focus=self.root.focus_get()
            if focus is None or focus.winfo_toplevel()!=self.root:return
            key=from_event(event)
            if key is None:return
            action=next((name for name,assigned in self._shortcut_mapping.items() if assigned==key),None)
            if action is None:return
            # Stop pending scanner debounce before executing a shortcut.
            job=getattr(self,'_barcode_scan_job',None)
            if job is not None:
                try:self.root.after_cancel(job)
                except tk.TclError:pass
                self._barcode_scan_job=None
            commands={
              'Stock Lookup':lambda:self.stock_lookup(),
              'Quantity':lambda:__import__('register_tower_v022').quantity_dialog(self),
              'Discount':self.set_discount,
              'Hold Sale':self.hold,
              'Recall Sale':self.recall,
              'Customer Lookup':self.register_customer,
              'Cash Payment':self.register_cash,
              'EFTPOS':lambda:self.checkout('EFTPOS SIMULATED'),
              'Delete Selected Item':self.void,
              'Clear Sale':self.clear_cart,
            }
            commands[action]()
            return 'break'
        # Bind to both barcode field and root; Tk bindtags prevent double dispatch
        # when the entry binding returns 'break'.
        self.code.bind('<KeyPress>',on_key,add='+')
        self.root.bind('<KeyPress>',on_key,add='+')
    def shortcut_settings(self):
        window=tk.Toplevel(self.root)
        window.title('Keyboard Shortcut Settings — TEST ONLY')
        window.transient(self.root)
        window.geometry('600x590')
        window.minsize(460,420)
        window.configure(bg='white')
        tk.Label(window,text='KEYBOARD SHORTCUT SETTINGS',bg='white',fg='#111111',font=('Segoe UI',16,'bold'),anchor='w',padx=15,pady=15).pack(fill='x')
        tk.Label(window,text='Choose a shortcut from each dropdown. Duplicates are not allowed.',bg='white',anchor='w',padx=16,pady=8).pack(fill='x')
        bottom=tk.Frame(window,bg='#e8eef2',padx=12,pady=12);bottom.pack(side='bottom',fill='x')
        outer=tk.Frame(window,bg='white');outer.pack(fill='both',expand=True,padx=16,pady=8)
        canvas=tk.Canvas(outer,highlightthickness=0,bg='white');scroll=ttk.Scrollbar(outer,orient='vertical',command=canvas.yview)
        scroll.pack(side='right',fill='y');canvas.pack(side='left',fill='both',expand=True);canvas.configure(yscrollcommand=scroll.set)
        rows=tk.Frame(canvas,bg='white');item=canvas.create_window((0,0),window=rows,anchor='nw')
        rows.bind('<Configure>',lambda e:canvas.configure(scrollregion=canvas.bbox('all')))
        canvas.bind('<Configure>',lambda e:canvas.itemconfigure(item,width=e.width))
        options=['?']+[f'F{i}' for i in range(1,13)]+['Delete','Ctrl+Delete']+[f'Ctrl+{k}' for k in 'ABCDEFGHIJKLMNOPQRSTUVWXYZ']+['Ctrl+F'+str(i) for i in range(1,13)]+['Alt+F'+str(i) for i in range(1,13)]
        vars={}
        for i,(name,default) in enumerate(ACTIONS):
            tk.Label(rows,text=name,font=('Segoe UI',11),bg='white',anchor='w').grid(row=i,column=0,sticky='ew',pady=7)
            v=tk.StringVar(value=load()[name]);vars[name]=v
            ttk.Combobox(rows,textvariable=v,values=options,state='readonly',width=22).grid(row=i,column=1,sticky='e',padx=8,pady=7)
        rows.grid_columnconfigure(0,weight=1)
        def save():
            try: values=validate({a:v.get() for a,v in vars.items()})
            except (ValueError,KeyError) as e:messagebox.showerror('Shortcut conflict',str(e),parent=window);return
            try:FILE.write_text(json.dumps(values,indent=2),encoding='utf-8')
            except OSError as e:messagebox.showerror('Save failed',str(e),parent=window);return
            self._shortcut_mapping=values
            window.destroy()
        def reset():
            for a,v in vars.items():v.set(DEFAULTS[a])
        tk.Button(bottom,text='Cancel',command=window.destroy,width=12).pack(side='right',padx=5)
        tk.Button(bottom,text='Save Shortcuts',command=save,width=16,bg='#50c1ce').pack(side='right',padx=5)
        tk.Button(bottom,text='Restore Defaults',command=reset,width=16).pack(side='left',padx=5)
        window.grab_set()
    def settings(self):
        # Add to the existing settings menu without replacing other modules.
        original_layout=self.layout
        def patched_layout(title,items):
            if title=='SETTINGS & TOOLS':items=[('Keyboard Shortcuts',self.shortcut_settings)]+list(items)
            return original_layout(title,items)
        self.layout=patched_layout
        try:return original_settings(self)
        finally:self.layout=original_layout
    cls.pos=pos
    cls.settings=settings
    cls.shortcut_settings=shortcut_settings
