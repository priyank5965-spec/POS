"""Load a verified sale's remaining returnable quantities into the register cart."""
from tkinter import messagebox

def load_refund_to_grid(app, sale_id, parent=None):
    parent = parent or app.root
    if app.cart:
        messagebox.showwarning('Refund / Exchange', 'Complete or hold the current cart before loading a refund.', parent=parent)
        return False
    sale = app.db.execute('SELECT id,kind FROM sales WHERE id=?', (sale_id,)).fetchone()
    if not sale or sale['kind'] != 'SALE':
        messagebox.showwarning('Refund / Exchange', 'Select an original sale, not a refund transaction.', parent=parent)
        return False
    lines = app.db.execute('SELECT * FROM lines WHERE sale_id=? AND product_id IS NOT NULL AND qty>0 ORDER BY id', (sale_id,)).fetchall()
    new = []
    for line in lines:
        refunded = app.db.execute('SELECT COALESCE(SUM(-qty),0) FROM lines WHERE original_line=? AND qty<0', (line['id'],)).fetchone()[0]
        available = int(line['qty']) - int(refunded)
        if available > 0:
            new.append(dict(product_id=line['product_id'], description=line['description']+' [RETURN]', qty=-available, unit=line['unit'], kind='PRODUCT', original_line=line['id']))
    if not new:
        messagebox.showwarning('Refund / Exchange', 'No refundable items remain on this sale.', parent=parent)
        return False
    app.cart = new
    app.discount = 0
    app.refund_origin = sale_id
    app.refresh_cart()
    return True
