# Freedom POS 2.0 — recovered requirements and gaps

Sources reviewed: attached recovered 17-section requirements; Freedom POS 2.0 User Manual Draft v0.1; earlier user conversations recovered for SMTP decisions; v0.5 code.

## Implemented in v0.6 (TEST ONLY)
- Settings & Tools > Email Settings with sender, business name, ABN, SMTP host/port/SSL-TLS or STARTTLS, reply-to, signature, owner email and payment details.
- Gmail App Password entered for current session only; not persisted in plaintext.
- Test email via real SMTP (only on explicit button press).
- Customer email address edit, account-sale invoice PDF preview, statement PDF preview, explicit send confirmation, SMTP acceptance/failure history and local PDF archive.

## Not yet complete (do not represent as working)
- Preserving the previously agreed exact tax invoice layout; sequential immutable invoice issuance, GST and adjustments, ABN display validation, invoice terms, A4/A5/80mm variants.
- Customer account statements with reliable opening/closing balances, date range, returns, fees, adjustments and corrections.
- Generate & Email All, statement scheduling weekly/fortnightly/monthly, queued retries and missing-email report.
- Customer receipt options (print, PDF, email, email+print, none) at checkout; barcode retrieval for receipts and statements.
- Owner notification email for refund, cancellation, stock adjustment, EOD and stocktake; templates and audit.
- epay recharge, voucher, gift cards, activation, reversals, status and reprint (vendor integration not authorised).
- Perpetual licensing and multistore rollout (only concept/prototypes; not production-ready).
- Full staff permission matrix and PIN policies; Previous Sales actions; XchangeIT DD2/RTF/RTD/SL2; newspaper supplier reconciliation; delivery rounds; magazine putaways; blind multi-device stocktake; Android APK; Linkly EFTPOS; real lottery integration.
- WooCommerce deferred by user.

## Critical safeguards
- Never send customer email without explicit user confirmation.
- SMTP acceptance is not proof of inbox delivery.
- Avoid ordinary Gmail account passwords and plaintext storage.
- No real sales, tax invoices, EFTPOS, lottery, epay or stocktake production operations on this build.
