Freedom POS 2.0 v0.84 TEST
Fix: The Register SCAN / BARCODE input now permits the decimal point (.) so department amount shortcuts can use cents (e.g. 2.50).
This does not convert arbitrary typed amounts into sales; use an existing department shortcut or department button.
All prior test-only and e-pay restrictions remain.
