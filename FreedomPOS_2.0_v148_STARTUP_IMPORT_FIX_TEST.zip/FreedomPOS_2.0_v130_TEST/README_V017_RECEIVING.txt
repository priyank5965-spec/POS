Freedom POS 2.0 v0.17 — Supplier Stock Receiving (TEST ONLY)

Purchasing > Supplier Invoices > NEW STOCK RECEIPT.
Full invoice header + barcode/name lookup + receiving grid + editable quantities/cost/GST + running totals.
Double-click invoiced qty, received qty, unit cost, or GST to edit; scan same barcode repeatedly to increment quantities.
Save Draft does NOT change stock. Review & Finalise updates stock quantities once in one SQLite transaction; finalised invoices are read-only. Duplicate supplier/invoice number blocked.

IMPORTANT: This is an offline prototype using sample data. No real supplier/accounting/EDI integrations. Customer putaway allocation, supplier invoice PDFs, labels, cost-to-retail calculations, returns, supplier payable posting, permissions, and automatic email are NOT yet implemented. Invoice totals are entered cost amounts, not independently validated GST-inclusive accounting totals. Retail prices are NOT changed automatically. Back up your test_data folder before upgrading; don't use real business data.

Run START_FREEDOM_POS.bat from freedom_v04 directory.
