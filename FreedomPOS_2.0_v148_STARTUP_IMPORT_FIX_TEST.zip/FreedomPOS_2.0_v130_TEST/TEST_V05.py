import tempfile, pathlib, sqlite3
from operations_v05 import GAMES,pin_hash
assert len(GAMES)==11 and len({x[0] for x in GAMES})==11
assert pin_hash('99','00'*16)==pin_hash('99','00'*16)
assert pin_hash('98','00'*16)!=pin_hash('99','00'*16)
import freedom_pos
assert freedom_pos.ExtendedApp.lottery.__module__=='operations_v05'
assert freedom_pos.ExtendedApp.staff_management.__module__=='operations_v05'
print('PASS: lottery codes, PIN hashing, staff management and POS hooks imported')
