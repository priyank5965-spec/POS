from linkly_receipt_v119 import training_receipt_lines
"""Tower-inspired Previous Sales window for Freedom POS offline test database.
Read-only search plus receipt preview, CSV export and existing refund cart integration.
"""
import tkinter as tk
from tkinter import ttk, messagebox, filedialog, simpledialog
import csv, datetime, os, tempfile, threading, calendar

def show_previous_sales(self):
    def money(c): return f"${c/100:,.2f}"
    w=tk.Toplevel(self.root);w.title('Freedom POS 2.0 — Previous Sales');w.geometry('1320x790');w.minsize(1080,690)
    w.transient(self.root)
    navy='#12324A'; bg='#f3f5f7'
    tk.Label(w,text='Previous Sales',bg=navy,fg='white',font=('Segoe UI',15,'bold'),pady=7).pack(fill='x')
    tk.Label(w,text='Search previous sales, inspect item details and payments, preview receipts and load refunds. TEST DATA ONLY.',font=('Segoe UI',9,'italic'),anchor='w').pack(fill='x',padx=8)
    body=tk.Frame(w,bg=bg);body.pack(fill='both',expand=True,padx=8,pady=4)
    # Dock the controls before the expanding grids, so they cannot be pushed off-screen.
    footer=tk.Frame(body,bg=bg);footer.pack(side='bottom',fill='x')
    summary=tk.LabelFrame(body,text='1  Summary of Sales',bg=bg,font=('Segoe UI',10,'bold'));summary.pack(fill='both',expand=True)
    columns=['Sale Stamp','Date','Time','Staff','Terminal','Amount','Discount','Tendered','Cust Number','Customer Name','Description','Balance','Due Date','Store Name','Order Number']
    sizes=[105,88,70,55,78,90,85,85,85,145,115,80,90,90,105]
    upper=tk.Frame(summary);upper.pack(fill='both',expand=True)
    st=ttk.Treeview(upper,columns=columns,show='headings',height=9,selectmode='browse')
    for name,size in zip(columns,sizes):st.heading(name,text=name);st.column(name,width=size,minwidth=45,stretch=False)
    sy=ttk.Scrollbar(upper,orient='vertical',command=st.yview);sx=ttk.Scrollbar(upper,orient='horizontal',command=st.xview)
    st.configure(yscrollcommand=sy.set,xscrollcommand=sx.set)
    st.grid(row=0,column=0,sticky='nsew');sy.grid(row=0,column=1,sticky='ns');sx.grid(row=1,column=0,sticky='ew');upper.rowconfigure(0,weight=1);upper.columnconfigure(0,weight=1)
    middle=tk.Frame(body,bg=bg);middle.pack(fill='both',expand=True,pady=(4,0))
    lf=tk.LabelFrame(middle,text='2  Details of Selected Sale',bg=bg,font=('Segoe UI',10,'bold'));lf.pack(side='left',fill='both',expand=True,padx=(0,3))
    rf=tk.LabelFrame(middle,text='3  Payment Details of Selected Sale',bg=bg,font=('Segoe UI',10,'bold'));rf.pack(side='left',fill='both',expand=True,padx=(3,0))
    def grid_tree(parent,fields,widths):
        wrap=tk.Frame(parent);wrap.pack(fill='both',expand=True)
        tree=ttk.Treeview(wrap,columns=fields,show='headings',height=5)
        for col,width in zip(fields,widths):tree.heading(col,text=col);tree.column(col,width=width,stretch=True)
        scroll=ttk.Scrollbar(wrap,orient='vertical',command=tree.yview);tree.configure(yscrollcommand=scroll.set)
        tree.pack(side='left',fill='both',expand=True);scroll.pack(side='right',fill='y');return tree
    detail=grid_tree(lf,['Item','Quantity','Barcode','Amount','Discount','Description','Serial','Excl'],[50,70,120,85,75,280,85,50])
    payment=grid_tree(rf,['Amount','Payment Type','Reference'],[110,180,200])
    flags=tk.Frame(footer,bg=bg);flags.pack(fill='x',pady=3)
    today=tk.BooleanVar(value=True);refund_only=tk.BooleanVar(value=False)
    tk.Checkbutton(flags,text="Today's Sales (not considered when searching for sales)",variable=today,bg=bg).pack(side='left')
    tk.Checkbutton(flags,text='Show Refund Transactions Only',variable=refund_only,bg=bg).pack(side='left',padx=10)
    count_label=tk.Label(flags,text='',fg='#a32121',bg=bg);count_label.pack(side='left',padx=8)
    filters=tk.LabelFrame(footer,text='4  Locate Sales Based On The Following Search Requirements',bg=bg,font=('Segoe UI',9,'bold'));filters.pack(fill='x',pady=(0,3))
    for i in range(10):filters.columnconfigure(i,weight=1)
    fields={}
    def entry(name,row,col,width=15,default=''):
        tk.Label(filters,text=name,bg=bg,font=('Segoe UI',9)).grid(row=row,column=col,sticky='e',padx=(4,2),pady=2)
        v=tk.StringVar(value=default);tk.Entry(filters,textvariable=v,width=width).grid(row=row,column=col+1,sticky='ew',padx=2,pady=2)
        fields[name]=v
    active_calendar = {'popup': None}
    def date_picker(name, anchor):
        # Compact drop-down attached to the date input, not a separate dialog.
        old = active_calendar['popup']
        if old is not None and old.winfo_exists():
            old.destroy()
            active_calendar['popup'] = None
        raw = fields[name].get().strip()
        chosen = next((datetime.datetime.strptime(raw,fmt).date()
                       for fmt in ('%d/%m/%Y','%Y-%m-%d','%d/%m/%y')
                       if _valid_date(raw,fmt)), datetime.date.today())
        popup = tk.Toplevel(w)
        active_calendar['popup'] = popup
        popup.overrideredirect(True)
        popup.configure(bg='#999999',padx=1,pady=1)
        year = tk.IntVar(value=chosen.year)
        month = tk.IntVar(value=chosen.month)
        inner = tk.Frame(popup,bg='white');inner.pack(fill='both',expand=True)
        head = tk.Frame(inner,bg='white');head.pack(fill='x',padx=5,pady=(5,2))
        label = tk.Label(head,font=('Segoe UI',10,'bold'),bg='white')
        tk.Button(head,text='◀',width=3,command=lambda:shift(-1)).pack(side='left')
        label.pack(side='left',fill='x',expand=True)
        tk.Button(head,text='▶',width=3,command=lambda:shift(1)).pack(side='right')
        grid = tk.Frame(inner,bg='white');grid.pack(padx=5,pady=3)
        def close():
            if popup.winfo_exists():popup.destroy()
            if active_calendar['popup'] is popup:active_calendar['popup']=None
        def pick(day):
            fields[name].set(day.strftime('%d/%m/%Y'))
            close()
        def shift(delta):
            m=year.get()*12+month.get()-1+delta
            year.set(m//12);month.set(m%12+1);render()
        def render():
            for child in grid.winfo_children():child.destroy()
            label.config(text=f'{calendar.month_name[month.get()]} {year.get()}')
            for col,day in enumerate(('Mo','Tu','We','Th','Fr','Sa','Su')):
                tk.Label(grid,text=day,width=4,bg='white',fg='#777777',font=('Segoe UI',8)).grid(row=0,column=col)
            for row,week in enumerate(calendar.monthcalendar(year.get(),month.get()),1):
                for col,day in enumerate(week):
                    if day:
                        current=datetime.date(year.get(),month.get(),day)
                        is_today=current==datetime.date.today()
                        tk.Button(grid,text=str(day),width=3,relief='flat',
                                  bg='#d9f2f4' if is_today else 'white',
                                  fg='#aa2525' if is_today else '#12324A',
                                  command=lambda d=current:pick(d)).grid(row=row,column=col,padx=1,pady=1)
        render()
        today_var=tk.BooleanVar(value=False)
        tk.Checkbutton(inner,text='Today: '+datetime.date.today().strftime('%d/%m/%Y'),
                       variable=today_var,bg='white',fg='#111111',
                       command=lambda:pick(datetime.date.today()) if today_var.get() else None).pack(anchor='w',padx=9,pady=(3,7))
        popup.update_idletasks()
        x=anchor.winfo_rootx()
        y=anchor.winfo_rooty()+anchor.winfo_height()
        screen_w=popup.winfo_screenwidth();screen_h=popup.winfo_screenheight()
        x=min(x,max(0,screen_w-popup.winfo_reqwidth()-6))
        if y+popup.winfo_reqheight()>screen_h-12:
            y=anchor.winfo_rooty()-popup.winfo_reqheight()
        popup.geometry(f'+{max(0,x)}+{max(0,y)}')
        popup.bind('<Escape>',lambda _e:close())
        popup.bind('<FocusOut>',lambda _e:popup.after(120,lambda:close() if popup.winfo_exists() and popup.focus_displayof() is None else None))
        popup.focus_set()
    def _valid_date(value,fmt):
        try:datetime.datetime.strptime(value,fmt);return True
        except ValueError:return False
    entry('Start Date',0,0,12);entry('End Date',0,2,12);entry('Sale Type',0,4);entry('Sale Amount',0,6,11);entry('Order Number',0,8,12)
    for name,col in (('Start Date',1),('End Date',3)):
        date_entry=next((child for child in filters.grid_slaves(row=0,column=col) if isinstance(child,tk.Entry)),None)
        if date_entry is not None:
            date_entry.bind('<Button-1>',lambda _e,n=name,ent=date_entry:date_picker(n,ent))
            date_entry.bind('<Return>',lambda _e,n=name,ent=date_entry:date_picker(n,ent))
            # Dropdown arrow beside the editable date field.
            tk.Button(filters,text='▾',width=2,command=lambda n=name,ent=date_entry:date_picker(n,ent)).grid(row=0,column=col,sticky='e',padx=(0,2))

    entry('Start Time',1,0,12,'00:00');entry('End Time',1,2,12,'23:59');entry('Stock Item Sold',1,4);entry('Tender Amount',1,6,11);entry('Sale Stamp',1,8,12)
    entry('Customer Number',2,0,12);entry('Staff Member',2,2,12);entry('Serial Number',2,4);entry('Payment Type',2,6,11);entry('Source',2,8,12)
    hint=tk.Frame(filters,bg=bg);hint.grid(row=3,column=0,columnspan=10,sticky='ew',pady=3)
    tk.Label(hint,text='Hint: Enter one or more search requirements. Dates: DD/MM/YYYY or YYYY-MM-DD. Amounts: dollars.',bg=bg,fg='#9b2c88',font=('Segoe UI',9,'italic')).pack(side='left',padx=5)
    tk.Label(footer,text='Note: Staff, terminal, serial, order number and source are not recorded in v0.3 sales; those filters return no matches until capture is implemented.',bg=bg,fg='#945322',font=('Segoe UI',8)).pack(anchor='w')
    actions=tk.Frame(footer,bg=bg);actions.pack(fill='x',pady=5)
    state={'rows':[]}
    def selected_id():
        selection=st.selection();return int(selection[0]) if selection else None
    def receipt_text(sid,gift=False):
        r=self.db.execute('SELECT * FROM sales WHERE id=?',(sid,)).fetchone()
        if not r:return ''
        lines=self.db.execute('SELECT * FROM lines WHERE sale_id=?',(sid,)).fetchall()
        pays=self.db.execute('SELECT * FROM payments WHERE sale_id=?',(sid,)).fetchall()
        output=['FREEDOM POS 2.0 — TEST RECEIPT','Receipt #'+str(sid),r['created'],'']
        for line in lines:
            output.append(f"{line['qty']} x {line['description']}"+( '' if gift else f"  {money(line['qty']*line['unit']-line['line_discount'])}"))
        if not gift:
            output.extend(['',f"Line Discounts: {money(sum(l['line_discount'] for l in lines))}",f"Sale Discount: {money(r['discount'])}",f"Total: {money(r['total'])}"])
            output.extend(f"{p['method']}: {money(p['amount'])}" for p in pays)
            output.extend(training_receipt_lines(self.db,sid))
        else:output.extend(['','GIFT / EXCHANGE RECEIPT — PRICES HIDDEN'])
        output.append('TEST ONLY — NOT A TAX INVOICE');return '\n'.join(output)
    def show(event=None):
        for tree in (detail,payment):tree.delete(*tree.get_children())
        sid=selected_id()
        if sid is None:return
        for idx,l in enumerate(self.db.execute('SELECT l.*,p.barcode FROM lines l LEFT JOIN products p ON p.id=l.product_id WHERE l.sale_id=?',(sid,)).fetchall(),1):
            detail.insert('','end',values=(idx,l['qty'],l['barcode'] or '',money(l['qty']*l['unit']-l['line_discount']),money(l['line_discount']),l['description'],'',''))
        for p in self.db.execute('SELECT * FROM payments WHERE sale_id=?',(sid,)).fetchall():payment.insert('','end',values=(money(p['amount']),p['method'],p['note']))
    def parse_date(s):
        if not s:return None
        for fmt in ('%d/%m/%Y','%Y-%m-%d','%d/%m/%y'):
            try:return datetime.datetime.strptime(s,fmt).date()
            except ValueError:pass
        raise ValueError('Invalid date: '+s)
    def amount(s):
        if not s:return None
        try:return round(float(s.replace('$','').replace(',',''))*100)
        except ValueError:raise ValueError('Invalid amount: '+s)
    def search():
        try:
            criteria={k:v.get().strip() for k,v in fields.items()}
            start=parse_date(criteria['Start Date']);end=parse_date(criteria['End Date'])
            if start and end and start>end:raise ValueError('Start Date is after End Date')
            t1=criteria['Start Time'];t2=criteria['End Time']
            for t in (t1,t2):
                if t:datetime.datetime.strptime(t,'%H:%M')
            sale_amt=amount(criteria['Sale Amount']);tender_amt=amount(criteria['Tender Amount'])
            if criteria['Customer Number']:int(criteria['Customer Number'])
        except (ValueError,TypeError) as e:return messagebox.showwarning('Invalid search',str(e),parent=w)
        st.delete(*st.get_children());detail.delete(*detail.get_children());payment.delete(*payment.get_children())
        sql='SELECT s.*,c.name AS customer_name FROM sales s LEFT JOIN customers c ON c.id=s.customer_id WHERE 1=1';params=[]
        if refund_only.get():sql+=' AND s.kind LIKE ?';params.append('%REFUND%')
        # Date range, times and optional filters applied below to support legacy test data.
        sql+=' ORDER BY s.id DESC LIMIT 10000'
        result=[]
        for r in self.db.execute(sql,params):
            date=r['created'][:10];clock=r['created'][11:16];stamp=str(r['id']);sale_type=r['kind'] or 'SALE'
            if start and date<start.isoformat():continue
            if end and date>end.isoformat():continue
            if not start and not end and today.get() and not any(criteria[k] for k in criteria if k not in ('Start Time','End Time')) and date!=datetime.date.today().isoformat():continue
            if t1 and clock<t1:continue
            if t2 and clock>t2:continue
            if criteria['Sale Type'] and criteria['Sale Type'].lower() not in sale_type.lower():continue
            if sale_amt is not None and r['total']!=sale_amt:continue
            if criteria['Sale Stamp'] and criteria['Sale Stamp'].lower() not in (stamp+' S'+stamp.zfill(9)).lower():continue
            if criteria['Customer Number'] and r['customer_id']!=int(criteria['Customer Number']):continue
            if criteria['Payment Type'] and criteria['Payment Type'].lower() not in r['payment'].lower():
                if not self.db.execute('SELECT 1 FROM payments WHERE sale_id=? AND lower(method) LIKE ?',(r['id'],'%'+criteria['Payment Type'].lower()+'%')).fetchone():continue
            if tender_amt is not None and not self.db.execute('SELECT 1 FROM payments WHERE sale_id=? AND amount=?',(r['id'],tender_amt)).fetchone():continue
            if criteria['Stock Item Sold']:
                q='%'+criteria['Stock Item Sold']+'%'
                if not self.db.execute('SELECT 1 FROM lines l LEFT JOIN products p ON l.product_id=p.id WHERE l.sale_id=? AND (l.description LIKE ? OR p.barcode LIKE ? OR CAST(l.product_id AS TEXT)=?)',(r['id'],q,q,criteria['Stock Item Sold'])).fetchone():continue
            # Fields not recorded by the test database cannot match a nonempty filter.
            if any(criteria[k] for k in ('Staff Member','Serial Number','Order Number','Source')):continue
            result.append(r)
        for r in result:
            stamp='S'+str(r['id']).zfill(9);d=r['created'][:10];tm=r['created'][11:19]
            pay=self.db.execute('SELECT COALESCE(SUM(amount),0) FROM payments WHERE sale_id=?',(r['id'],)).fetchone()[0]
            st.insert('','end',iid=str(r['id']),values=(stamp,d,tm,'—','—',money(r['total']),money(r['discount']),money(pay),r['customer_id'] or '0',r['customer_name'] or '',r['kind'],money(0),'—','TEST', '—'))
        count_label.configure(text=f'{len(result)} Previous Sales Found')
        state['rows']=[r['id'] for r in result]
        if result:st.selection_set(str(result[0]['id']));st.focus(str(result[0]['id']));show()
    def clear():
        for v in fields.values():v.set('')
        fields['Start Time'].set('00:00');fields['End Time'].set('23:59');today.set(True);refund_only.set(False);search()
    def preview(gift=False):
        sid=selected_id()
        if sid is None:return messagebox.showinfo('Previous Sales','Select a sale first.',parent=w)
        d=tk.Toplevel(w);d.title('Gift Receipt Preview' if gift else 'Receipt Preview');d.geometry('500x560')
        txt=tk.Text(d,font=('Consolas',11),wrap='word');txt.pack(fill='both',expand=True,padx=8,pady=8)
        txt.insert('1.0',receipt_text(sid,gift));txt.configure(state='disabled')
    def export():
        if not state['rows']:return messagebox.showinfo('Export','No matching sales to export.',parent=w)
        path=filedialog.asksaveasfilename(parent=w,defaultextension='.csv',initialfile='Previous_Sales_Search.csv',filetypes=[('CSV','*.csv')])
        if not path:return
        with open(path,'w',newline='',encoding='utf-8-sig') as f:
            writer=csv.writer(f);writer.writerow(columns)
            for iid in st.get_children():writer.writerow(st.item(iid,'values'))
        messagebox.showinfo('Export',f'Exported {len(state["rows"])} sales.',parent=w)
    def refund():
        sid=selected_id()
        if sid is None:return
        if self.cart:return messagebox.showwarning('Refund','Hold or complete the current sale first.',parent=w)
        lines=self.db.execute('SELECT * FROM lines WHERE sale_id=? AND product_id IS NOT NULL AND qty>0',(sid,)).fetchall()
        if not lines:return messagebox.showwarning('Refund','No eligible retail lines.',parent=w)
        from refund_grid_v055 import load_refund_to_grid
        if load_refund_to_grid(self,sid,parent=w):
            w.destroy()
    def require_selected():
        sid=selected_id()
        if sid is None:messagebox.showwarning('Previous Sales','Select a sale in Summary of Sales first.',parent=w)
        return sid
    def receipt_pdf(sid,gift=False,fmt='80mm'):
        from sale_documents_v090 import create_sale_pdf
        return create_sale_pdf(self,sid,fmt,gift)
    def choose_document(title,callback,initial='80mm'):
        sid=require_selected()
        if sid is None:return
        d=tk.Toplevel(w);d.title(title);d.geometry('440x270');d.transient(w);d.grab_set()
        d.bind('<Escape>',lambda _e:d.destroy())
        tk.Label(d,text=f'Sale S{sid:09d} — Choose document',font=('Segoe UI',12,'bold')).pack(pady=(16,10))
        fmt=tk.StringVar(value=initial)
        tk.Radiobutton(d,text='80mm Receipt PDF (thermal size)',variable=fmt,value='80mm').pack(anchor='w',padx=35,pady=5)
        tk.Radiobutton(d,text='A4 Invoice-style PDF (full page)',variable=fmt,value='A4').pack(anchor='w',padx=35,pady=5)
        tk.Label(d,text='Test sale PDFs are not certified tax invoices.\nTEST ONLY — GST details are not calculated.',fg='#9b542b',justify='left').pack(pady=8)
        bar=tk.Frame(d);bar.pack(pady=7)
        def proceed():
            selected=fmt.get();d.destroy();callback(sid,selected)
        tk.Button(bar,text='CONTINUE',command=proceed,width=15).pack(side='left',padx=5)
        tk.Button(bar,text='CANCEL',command=d.destroy,width=12).pack(side='left',padx=5)
    def preview_pdf():
        def run(sid,fmt):
            try:
                path=receipt_pdf(sid,gift_flag.get(),fmt)
                if os.name=='nt':os.startfile(path)
                else:messagebox.showinfo('PDF created','PDF preview file: '+path,parent=w)
            except Exception as exc:messagebox.showerror('Preview failed',str(exc),parent=w)
        choose_document('Preview Sale Document',run)
    def reprint():
        """Open the existing barcode receipt preview; printing is chosen there."""
        sid=require_selected()
        if sid is None:return
        if gift_flag.get():
            return messagebox.showwarning('Gift receipt',
                'Price-hiding for Gift / Exchange receipts is not yet supported. Untick Gift / Exchange to preview and print.',parent=w)
        try:
            from receipt_preview_v051 import preview_receipt
            preview_receipt(self,sid)
        except Exception as exc:
            messagebox.showerror('Reprint preview failed',str(exc),parent=w)
    def email_receipt():
        sid=require_selected()
        if sid is None:return
        # Email addresses live in customer_emails, not customers. Cash sales
        # may have no customer; still allow an explicitly typed recipient.
        try:
            r=self.db.execute('''SELECT s.customer_id,COALESCE(ce.email,'') AS email
                FROM sales s LEFT JOIN customer_emails ce ON ce.customer_id=s.customer_id
                WHERE s.id=?''',(sid,)).fetchone()
        except Exception as exc:
            return messagebox.showerror('Email receipt unavailable',
                'Could not load recipient details: '+str(exc),parent=w)
        if r is None:
            return messagebox.showerror('Sale not found',
                'The selected sale no longer exists.',parent=w)
        default=r['email'] or ''
        dialog=tk.Toplevel(w);dialog.title('Email Receipt — Selected Sale');dialog.geometry('610x365');dialog.transient(w)
        dialog.lift();dialog.grab_set()
        dialog.bind('<Escape>',lambda _e:dialog.destroy())
        tk.Label(dialog,text=f'Email sale document #{sid}',font=('Segoe UI',13,'bold')).pack(anchor='w',padx=18,pady=(14,8))
        frm=tk.Frame(dialog);frm.pack(fill='x',padx=18)
        tk.Label(frm,text='Recipient email').grid(row=0,column=0,sticky='w',pady=5)
        recipient=tk.StringVar(value=default)
        recipient_entry=tk.Entry(frm,textvariable=recipient,width=42)
        recipient_entry.grid(row=0,column=1,padx=12,pady=5)
        dialog.after_idle(recipient_entry.focus_set)
        tk.Label(frm,text='Document format').grid(row=1,column=0,sticky='w',pady=5)
        format_choice=tk.StringVar(value='80mm')
        tk.Radiobutton(frm,text='80mm Receipt PDF',variable=format_choice,value='80mm').grid(row=1,column=1,sticky='w')
        tk.Radiobutton(frm,text='A4 Invoice-style PDF',variable=format_choice,value='A4').grid(row=2,column=1,sticky='w')
        gift=tk.BooleanVar(value=gift_flag.get());tk.Checkbutton(frm,text='Gift / Exchange — hide all prices',variable=gift).grid(row=3,column=0,columnspan=2,sticky='w',pady=5)
        tk.Label(dialog,text='A4 test invoice-style summary; GST breakdown unavailable in test data.',fg='#9b542b').pack(anchor='w',padx=18)
        def preview_attachment():
            try:
                path=receipt_pdf(sid,gift.get(),format_choice.get())
                if os.name=='nt':os.startfile(path)
                else:messagebox.showinfo('PDF created',path,parent=dialog)
            except Exception as exc:messagebox.showerror('PDF preview error',str(exc),parent=dialog)

        status=tk.StringVar(value='Enter recipient and click SEND RECEIPT to send immediately.');tk.Label(dialog,textvariable=status,fg='#84551c',wraplength=510).pack(anchor='w',padx=18,pady=7)
        def send_now():
            from email_workflows_v06 import valid_email
            addr=recipient.get().strip()
            if not valid_email(addr):return messagebox.showwarning('Invalid email','Enter a valid recipient email address.',parent=dialog)
            try:path=receipt_pdf(sid,gift.get(),format_choice.get())
            except Exception as exc:return messagebox.showerror('PDF error',str(exc),parent=dialog)
            send_button.config(state='disabled');status.set('Sending via connected Google account...')
            def worker():
                try:
                    from email_workflows_v06 import send
                    send(self,'RECEIPT',addr,f'Sale document #{sid} ({format_choice.get()})',f'Please find sale document #{sid} attached.\n\n{self.mail_cfg.get("signature", "")}',path,r['customer_id'] if r else None)
                    dialog.after(0,lambda:(status.set('Accepted by Gmail (delivery not guaranteed).'),send_button.config(state='normal')))
                except Exception as exc:
                    error=str(exc)
                    dialog.after(0,lambda:(status.set('Failed: '+error),send_button.config(state='normal')))
            threading.Thread(target=worker,daemon=True).start()
        buttons=tk.Frame(dialog);buttons.pack(pady=7)
        tk.Button(buttons,text='PREVIEW PDF',command=preview_attachment,width=16).pack(side='left',padx=5)
        send_button=tk.Button(buttons,text='SEND RECEIPT',command=send_now,width=18);send_button.pack(side='left',padx=8)
        tk.Button(buttons,text='CANCEL',command=dialog.destroy,width=12).pack(side='left',padx=8)
    def permanent_delete():
        sid=require_selected()
        if sid is None:return
        sale=self.db.execute('SELECT * FROM sales WHERE id=?',(sid,)).fetchone()
        if sale is None:return messagebox.showwarning('Sale missing','This sale has already been removed.',parent=w)
        # The prototype has no reliable production accounting reversal. Restrict deletion
        # to standalone offline test cash/card sales; never corrupt linked accounts/refunds.
        if sale['customer_id'] or sale['payment']=='ACCOUNT':
            return messagebox.showwarning('Linked account sale','Account-linked sales cannot be permanently deleted in this test build.',parent=w)
        linked=self.db.execute('SELECT 1 FROM sales WHERE reference=? LIMIT 1',(sid,)).fetchone()
        line_link=self.db.execute('''SELECT 1 FROM lines WHERE original_line IN
            (SELECT id FROM lines WHERE sale_id=?) LIMIT 1''',(sid,)).fetchone()
        if linked or line_link:
            return messagebox.showwarning('Linked refund','This sale is referenced by a refund/exchange and cannot be permanently deleted.',parent=w)
        if not messagebox.askyesno('Permanently delete TEST sale',
            f'Permanently delete TEST sale S{sid:09d} ({money(sale["total"])})?\n\n'
            'This removes its sale lines and payments from the TEST database and reports.\n'
            'It cannot be undone. It does not reverse stock or emails already sent.',parent=w):return
        try:
            with self.db:
                self.db.execute('DELETE FROM payments WHERE sale_id=?',(sid,))
                self.db.execute('DELETE FROM lines WHERE sale_id=?',(sid,))
                self.db.execute('DELETE FROM sales WHERE id=?',(sid,))
            search()
        except Exception as exc:
            messagebox.showerror('Delete failed',str(exc),parent=w)
    def unavailable(label):messagebox.showinfo(label,label+' is not connected in this test build. No external email, printing, invoice modification or irreversible deletion was performed.',parent=w)
    def action(label,fn):tk.Button(actions,text=label,command=fn,font=('Segoe UI',9),padx=8,pady=5).pack(side='left',padx=2)
    gift_flag=tk.BooleanVar(value=False)
    action('Delete',permanent_delete)
    action('Preview',preview_pdf);action('Reprint',reprint);action('Refund',refund)
    action('Email',email_receipt)
    tk.Checkbutton(actions,text='Gift/Exchange Receipt (hide prices)',variable=gift_flag,bg=bg).pack(side='left',padx=4)
    action('Export CSV',export);action('Close',w.destroy)
    tk.Button(hint,text='Search Now',command=search).pack(side='right',padx=3)
    tk.Button(hint,text='Clear Requirements',command=clear).pack(side='right',padx=3)
    tk.Button(hint,text='Open in Inv. Management',command=lambda:unavailable('Linked invoice management')).pack(side='right',padx=3)
    st.bind('<<TreeviewSelect>>',show)
    today.trace_add('write',lambda *_:search());refund_only.trace_add('write',lambda *_:search())
    search()
