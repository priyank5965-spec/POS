import unittest, sqlite3
from pathlib import Path
from linkly_payment_v111 import setup, get, set_value
from linkly_purchase_v114 import build_refund, parse_refund_response

class V121RefundRoutingTests(unittest.TestCase):
    def test_default_and_persistence(self):
        db=sqlite3.connect(':memory:'); setup(db)
        self.assertEqual(get(db,'mode'),'LINKLY TRAINING')
        set_value(db,'mode','TEST');setup(db)
        self.assertEqual(get(db,'mode'),'TEST')
    def test_existing_status_mode_migrated_once(self):
        db=sqlite3.connect(':memory:')
        db.execute('CREATE TABLE eft_settings(key TEXT PRIMARY KEY,value TEXT NOT NULL)')
        db.execute("INSERT INTO eft_settings VALUES('mode','LINKLY STATUS')")
        setup(db);self.assertEqual(get(db,'mode'),'LINKLY TRAINING')
        set_value(db,'mode','LINKLY STATUS');setup(db)
        self.assertEqual(get(db,'mode'),'LINKLY STATUS')
    def test_refund_positive_cents_and_type(self):
        req=build_refund(599,'R123456789012345')
        self.assertEqual(req[9:10],b'R')
        self.assertIn(b'000000599',req)
        with self.assertRaises(ValueError):build_refund(-599,'R123456789012345')
    def test_checkout_refund_guard(self):
        s=Path(__file__).with_name('freedom_pos.py').read_text()
        self.assertIn("getattr(self,'_linkly_verified_refund',False)",s)
        self.assertIn('max(0,sum(',s)
        q=Path(__file__).with_name('linkly_payment_v111.py').read_text()
        self.assertIn('test_refund(-eft_amount)',q)
        self.assertIn('self._linkly_verified_refund = is_refund',q)

if __name__=='__main__':unittest.main()
