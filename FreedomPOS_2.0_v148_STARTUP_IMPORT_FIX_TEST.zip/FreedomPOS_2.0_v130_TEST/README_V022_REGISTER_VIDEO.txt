Freedom POS 2.0 v0.22 — REGISTER VIDEO LAYOUT TEST

Based on the user's Tower Systems register video (Video Project 2 (1).mp4).
The main register now uses a teal CASH SALE header, uninterrupted scanner/PLU bar, large left-side sales grid, fixed right-side touchscreen tile matrix, and dark permanent totals strip.
Included: quantity for next item, quick product tiles, register customer/stock/department access, prior sales, last receipt, discount, refund entry, hold/recall, cash test tender, simulated EFTPOS.

This is a visual/workflow approximation, not a pixel-identical copy of Tower's proprietary software or licensed button artwork. Quick product labels use existing test database records. Some functions still use older prototype screens. Department ~PLU sale posting remains disabled until safe GST/audit handling exists. Payment devices are not integrated. No production use.

Start with START_FREEDOM_POS.bat from the freedom_v04 folder.
