FREEDOM POS 2.0 v0.7 — NAVIGATION CORRECTION (TEST ONLY)

Extract this ZIP into a NEW folder. Do not reuse an old EXE.
Open freedom_v04/START_FREEDOM_POS.bat to run the Python build.
To create a Windows EXE, run BUILD_TEST_EXE.bat, then run dist/FreedomPOS_Test_v07.exe.
The window title must say v0.7 NAVIGATION TEST ONLY.

Navigation:
Home > Management > Staff Management / Staff Activity / Activity Logs
Home > Orders & Invoices > Invoice Management / Customer Invoices & Statements
Home > Settings & Tools > Email Settings / Email History

Invoice Management opens the existing customer invoice and statement test workflow.
It is NOT a complete tax invoice/accounts receivable management module.
Supplier Invoices explicitly reports that it is not implemented.
Email settings use a Gmail app password entered for each session. SMTP is not tested here.
All modules remain development-only. Do not use for live business transactions.
