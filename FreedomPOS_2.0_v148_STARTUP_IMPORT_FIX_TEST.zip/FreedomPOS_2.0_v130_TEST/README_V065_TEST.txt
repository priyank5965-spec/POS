Freedom POS 2.0 v0.65 — SETTINGS STORAGE TEST ONLY

Settings & Tools > Register Settings opens the new three-level settings manager.
Business defaults, register-specific overrides, and reserved user preferences are stored in SQLite test_data/settings_v065.sqlite3.
Save validates inputs and writes audit history; Export/Import uses versioned JSON. Restore Defaults clears only the selected scope.
OTHER REGISTER OPTIONS opens the previous v0.64 Register Settings screen, preserving access to receipts, shortcuts, custom actions, themes and backup.

LIMITATIONS:
- Existing Register runtime still reads test_data/register_settings_v063.json. The manager synchronises effective settings for one active register; simultaneous multiple register sessions are not supported.
- User-specific preferences are reserved, not yet connected to runtime.
- Only existing functional controls are editable. Some legacy settings are still stored outside the new SQLite store (receipt details, theme, shortcuts and custom actions) and are NOT yet migrated.
- Import does not overwrite unrelated records, and does not include existing receipt images or transactional data.
- Windows GUI and hardware not tested. TEST ONLY.
