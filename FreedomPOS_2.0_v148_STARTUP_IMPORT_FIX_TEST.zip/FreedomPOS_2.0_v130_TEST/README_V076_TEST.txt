Freedom POS 2.0 v0.76 — E-PAY OFFLINE FOUNDATION (TEST ONLY)

Settings & Tools > e-pay Integration (Setup): configure nonsecret business identifiers and endpoint; credentials/passwords are NOT saved.
Register > E-PAY: offline preview only. On first opening the Register an E-PAY action button is seeded in an available position without replacing existing buttons. It can be edited/removed using the Button Designer.

NO LIVE EPAY CONNECTION. No voucher sale, top-up, activation, refund, reversal, reconciliation or terminal communication. Obtain official e-pay V2 API specification, product catalogue format and secure authentication instructions before enabling transactions.

The prior screenshot contained a password: rotate those credentials with e-pay. Do not enter credentials into TEST builds.

Windows GUI, live service and hardware are NOT tested.
