Freedom POS 2.0 Register Shortcut v0.30 — TEST ONLY

From the active register, press Shift + / (the ? key) to open Stock Lookup.
Works with register focus, including the barcode field. Plain / does not open lookup.
Other windows do not trigger the shortcut. A pending barcode autoscan timer is
cancelled when the shortcut opens Stock Lookup.
No visual changes to register or Stock Lookup. Staff PIN remains disabled for testing.
