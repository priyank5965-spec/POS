"""Freedom POS 2.0 v0.2 - OFFLINE TEST-ONLY desktop prototype."""
import tkinter as tk
from tkinter import ttk, messagebox, simpledialog, filedialog
import sqlite3, os, csv, datetime, shutil, zipfile, json, subprocess, sys
from decimal import Decimal, InvalidOperation, ROUND_HALF_UP
from pathlib import Path
BASE=Path(__file__).resolve().parent
DATA=BASE/'test_data'; DATA.mkdir(exist_ok=True)
DB=DATA/'freedom_test_v03.db'
BLUE='#111111'; BG='#ffffff'; WHITE='white'
NAV=['Point of Sale','Products & Stock','Purchasing','Newsagency','Customers','Sales & Reports','Orders & Invoices','Management','Settings & Tools']
def now():return datetime.datetime.now().isoformat(timespec='seconds')
def money(c):return f'${c/100:,.2f}'
def cents(v):
 try:return int((Decimal(str(v).strip().replace('$','').replace(',',''))*100).quantize(Decimal('1'),rounding=ROUND_HALF_UP))
 except (InvalidOperation,ValueError):raise ValueError('Enter a valid dollar amount')
def dbinit():
 c=sqlite3.connect(DB);c.row_factory=sqlite3.Row;c.execute('PRAGMA foreign_keys=ON');c.execute('PRAGMA journal_mode=WAL');c.execute('PRAGMA busy_timeout=5000')
 c.executescript('''CREATE TABLE IF NOT EXISTS products(id INTEGER PRIMARY KEY,barcode TEXT UNIQUE NOT NULL,name TEXT NOT NULL,price INTEGER NOT NULL,stock INTEGER NOT NULL DEFAULT 0,supplier TEXT DEFAULT '',supplier_code TEXT DEFAULT '',category TEXT DEFAULT 'General');
 CREATE TABLE IF NOT EXISTS customers(id INTEGER PRIMARY KEY,name TEXT NOT NULL,phone TEXT DEFAULT '',balance INTEGER NOT NULL DEFAULT 0);
 CREATE TABLE IF NOT EXISTS sales(id INTEGER PRIMARY KEY,created TEXT NOT NULL,total INTEGER NOT NULL,payment TEXT NOT NULL,customer_id INTEGER,kind TEXT DEFAULT 'SALE',reference INTEGER,discount INTEGER DEFAULT 0,voided INTEGER DEFAULT 0);
 CREATE TABLE IF NOT EXISTS lines(id INTEGER PRIMARY KEY,sale_id INTEGER NOT NULL,product_id INTEGER,description TEXT NOT NULL,qty INTEGER NOT NULL,unit INTEGER NOT NULL,kind TEXT DEFAULT 'PRODUCT',original_line INTEGER,FOREIGN KEY(sale_id) REFERENCES sales(id));
 CREATE TABLE IF NOT EXISTS payments(id INTEGER PRIMARY KEY,sale_id INTEGER,customer_id INTEGER,created TEXT NOT NULL,method TEXT NOT NULL,amount INTEGER NOT NULL,note TEXT DEFAULT '');
 CREATE TABLE IF NOT EXISTS held(id INTEGER PRIMARY KEY,created TEXT NOT NULL,description TEXT,cart TEXT NOT NULL,discount INTEGER DEFAULT 0,customer_id INTEGER);
 CREATE TABLE IF NOT EXISTS events(id INTEGER PRIMARY KEY,created TEXT NOT NULL,category TEXT NOT NULL,description TEXT NOT NULL);
 CREATE TABLE IF NOT EXISTS magazine_issues(id INTEGER PRIMARY KEY,title TEXT NOT NULL,issue TEXT NOT NULL,barcode TEXT,qty INTEGER NOT NULL DEFAULT 0,price INTEGER NOT NULL DEFAULT 0,recall TEXT,UNIQUE(title,issue));
 CREATE TABLE IF NOT EXISTS newspaper_arrivals(id INTEGER PRIMARY KEY,day TEXT NOT NULL,title TEXT NOT NULL,supplier TEXT NOT NULL,received INTEGER NOT NULL,UNIQUE(day,title,supplier));
 CREATE TABLE IF NOT EXISTS putaways(id INTEGER PRIMARY KEY,customer_id INTEGER NOT NULL,title TEXT NOT NULL,issue TEXT DEFAULT '',qty INTEGER NOT NULL DEFAULT 1,status TEXT DEFAULT 'RESERVED');
 CREATE TABLE IF NOT EXISTS stocktake(id INTEGER PRIMARY KEY,created TEXT NOT NULL,status TEXT DEFAULT 'COUNTING');
 CREATE TABLE IF NOT EXISTS stock_counts(id INTEGER PRIMARY KEY,session_id INTEGER NOT NULL,product_id INTEGER NOT NULL,qty INTEGER NOT NULL,UNIQUE(session_id,product_id));
 CREATE TABLE IF NOT EXISTS supplier_invoices(id INTEGER PRIMARY KEY,supplier TEXT NOT NULL,number TEXT NOT NULL,created TEXT NOT NULL,amount INTEGER NOT NULL,status TEXT DEFAULT 'DRAFT',UNIQUE(supplier,number));
 CREATE TABLE IF NOT EXISTS stock_adjustments(id INTEGER PRIMARY KEY,created TEXT NOT NULL,product_id INTEGER NOT NULL,delta INTEGER NOT NULL,reason TEXT NOT NULL);
 ''')
 # Permanent sale-number high-water mark. Never derive the next number only from
 # existing sales: the highest sale may have been permanently deleted.
 c.execute('CREATE TABLE IF NOT EXISTS sale_number_sequence (singleton INTEGER PRIMARY KEY CHECK(singleton=1), last_issued INTEGER NOT NULL)')
 c.execute('INSERT OR IGNORE INTO sale_number_sequence(singleton,last_issued) SELECT 1,COALESCE(MAX(id),0) FROM sales')
 c.execute('UPDATE sale_number_sequence SET last_issued=MAX(last_issued,(SELECT COALESCE(MAX(id),0) FROM sales)) WHERE singleton=1')
 if 'line_discount' not in [r[1] for r in c.execute('PRAGMA table_info(lines)')]:c.execute('ALTER TABLE lines ADD COLUMN line_discount INTEGER NOT NULL DEFAULT 0')
 if not c.execute('SELECT 1 FROM products LIMIT 1').fetchone():
  c.executemany('INSERT INTO products(barcode,name,price,stock,category) VALUES(?,?,?,?,?)',[('9300000000001','Sample Greeting Card',599,50,'Cards'),('9300000000002','Sample Gift Bag',450,25,'Gifts'),('9300000000003','Sample Notebook',795,40,'Stationery'),('9300000000004','Sample Pen',250,100,'Stationery'),('9300000000005','Sample Toy Car',1295,12,'Toys')])
 if not c.execute('SELECT 1 FROM customers LIMIT 1').fetchone():c.execute("INSERT INTO customers(name,balance) VALUES('Sample Customer',0)")
 c.commit();return c
class App:
 def __init__(self,root):
  self.root=root;root.title('Freedom POS 2.0 — v0.21 TEST ONLY');root.geometry(f'{min(1260,max(700,root.winfo_screenwidth()-24))}x{min(790,max(540,root.winfo_screenheight()-100))}');root.minsize(min(980,max(700,root.winfo_screenwidth()-24)),min(650,max(540,root.winfo_screenheight()-100)));root.configure(bg=BG)
  self.db=dbinit();self.cart=[];self.discount=0;self.customer=None;self.refund_origin=None
  st=ttk.Style();st.theme_use('clam');st.configure('Treeview',rowheight=29,font=('Segoe UI',10),background='white',foreground='#111111',fieldbackground='white',bordercolor='#c9c9c9');st.map('Treeview',background=[('selected','#e1e5e9')],foreground=[('selected','#111111')]);st.configure('Treeview.Heading',font=('Segoe UI',10,'bold'),background='#f3f3f3',foreground='#111111');st.configure('TFrame',background='white');st.configure('TLabel',background='white',foreground='#111111');st.configure('TNotebook',background='white');st.configure('TNotebook.Tab',background='#f2f2f2',foreground='#111111');st.map('TNotebook.Tab',background=[('selected','white')]);st.configure('TEntry',fieldbackground='white',foreground='#111111');st.configure('TCombobox',fieldbackground='white',foreground='#111111')
  self.home()
 def log(self,category,description):self.db.execute('INSERT INTO events(created,category,description) VALUES(?,?,?)',(now(),category,description));self.db.commit()
 def clear(self):
  for w in self.root.winfo_children():w.destroy()
 def header(self,title):
  h=tk.Frame(self.root,bg='white',height=64);h.pack(fill='x');h.pack_propagate(False)
  tk.Label(h,text='FREEDOM POS 2.0  /  '+title,bg='white',fg='#111111',font=('Segoe UI',18,'bold')).pack(side='left',padx=17,pady=13)
  tk.Button(h,text='HOME',command=self.home,bg='white',fg='#111111',font=('Segoe UI',11,'bold'),width=11).pack(side='right',padx=14)
 def btn(self,p,t,fn,**kw):return tk.Button(p,text=t,command=fn,bg=kw.get('bg',WHITE),fg=kw.get('fg',BLUE),font=('Segoe UI',kw.get('size',11),'bold'),height=kw.get('height',2),wraplength=230,relief='raised',bd=2,activebackground='#cbddea',activeforeground='#142f49',highlightthickness=1,highlightbackground='#8798a7',cursor='hand2')
 def info(self,title,text):messagebox.showinfo(title,text,parent=self.root)
 def warn(self,text):messagebox.showwarning('Freedom POS TEST',text,parent=self.root)
 def home(self):
  self.clear();self.header('HOME');tk.Label(self.root,text='OFFLINE TEST DATA ONLY  •  NO REAL EFTPOS / LOTTERY TERMINAL / XCHANGEIT CONNECTION',bg=BG,fg='#9b3229',font=('Segoe UI',11,'bold')).pack(pady=12)
  f=tk.Frame(self.root,bg=BG);f.pack(expand=True,fill='both',padx=24,pady=8)
  for i,n in enumerate(NAV):self.btn(f,n,lambda x=n:self.module(x),size=15,height=5).grid(row=i//3,column=i%3,sticky='nsew',padx=8,pady=8)
  for i in range(3):f.rowconfigure(i,weight=1);f.columnconfigure(i,weight=1)
  tk.Label(self.root,text='v0.7 navigation test · Some advanced integrations are not yet implemented · Use sample data only',bg=BG,fg='#576775').pack(pady=8)
 def module(self,n):
  return {'Point of Sale':self.pos,'Products & Stock':self.products,'Purchasing':self.purchasing,'Newsagency':self.newsagency,'Customers':self.customers,'Sales & Reports':self.sales,'Orders & Invoices':self.orders,'Management':self.management,'Settings & Tools':self.settings}[n]()
 def layout(self,title,buttons):
  self.clear();self.header(title);f=tk.Frame(self.root,bg=BG);f.pack(fill='both',expand=True,padx=24,pady=24)
  for i,(name,fn) in enumerate(buttons):self.btn(f,name,fn,size=13,height=4).grid(row=i//3,column=i%3,sticky='nsew',padx=8,pady=8)
  for i in range(3):f.columnconfigure(i,weight=1)
  for i in range((len(buttons)+2)//3):f.rowconfigure(i,weight=1)
 def tree(self,parent,cols,widths=None,height=14):
  t=ttk.Treeview(parent,columns=cols,show='headings',height=height,selectmode='browse')
  for i,k in enumerate(cols):t.heading(k,text=k);t.column(k,width=(widths[i] if widths else 120),anchor='w')
  t.pack(fill='both',expand=True,padx=12,pady=10);return t
 def prompt(self,title,label,initial=None):return simpledialog.askstring(title,label,initialvalue=initial,parent=self.root)
 def ask_money(self,title,label,initial='0.00'):
  s=self.prompt(title,label,initial)
  if s is None:return None
  try:return cents(s)
  except ValueError as e:self.warn(str(e));return None
 def product_by_code(self,code):return self.db.execute('SELECT * FROM products WHERE barcode=?',(code,)).fetchone()
 def add_to_cart(self,p,qty=1,negative=False,origin_line=None):
  if qty<=0:return
  # Negative inventory is permitted; do not block register sales.
  # Combine identical normal scans, preserving edited prices/descriptions and discounts.
  if not negative and origin_line is None:
   for line in self.cart:
    if (line.get('product_id')==p['id'] and line.get('kind')=='PRODUCT'
        and line.get('qty',0)>0 and line.get('description')==p['name']
        and line.get('unit')==p['price'] and not line.get('line_discount',0)
        and line.get('original_line') is None):
     line['qty']+=qty
     self.refresh_cart()
     return
  self.cart.append(dict(product_id=p['id'],description=p['name'],qty=(-qty if negative else qty),unit=p['price'],kind='PRODUCT',original_line=origin_line))
  self.refresh_cart()
 def total(self):return sum(x['qty']*x['unit'] for x in self.cart)-self.discount
 def pos(self):
  self.clear();self.header('POINT OF SALE');main=tk.Frame(self.root,bg=BG);main.pack(fill='both',expand=True,padx=10,pady=10)
  left=tk.Frame(main,bg=BG);left.pack(side='left',fill='both',expand=True)
  right=tk.Frame(main,bg=BG,width=290);right.pack(side='right',fill='y',padx=(10,0));right.pack_propagate(False)
  tk.Label(left,text='CURRENT SALE',bg=BG,fg='#111111',font=('Segoe UI',14,'bold')).pack(anchor='w')
  self.sale_tree=self.tree(left,['Product','Qty','Unit','Total'],[340,65,100,120],11);self.sale_tree.bind('<Double-1>',lambda e:self.edit_line())
  row=tk.Frame(left,bg=BG);row.pack(fill='x',pady=3)
  tk.Label(row,text='SCAN / BARCODE',bg=BG,font=('Segoe UI',10,'bold')).pack(side='left')
  self.code=tk.Entry(row,font=('Segoe UI',14));self.code.pack(side='left',fill='x',expand=True,padx=8);self.code.bind('<Return>',lambda e:self.scan())
  self.btn(row,'ADD',self.scan,size=10,height=1).pack(side='right')
  self.total_label=tk.Label(left,bg='white',fg='#111111',font=('Segoe UI',20,'bold'),anchor='e',padx=14,pady=10);self.total_label.pack(fill='x',pady=6)
  self.customer_label=tk.Label(left,bg=BG,fg='#111111',font=('Segoe UI',10));self.customer_label.pack(anchor='w')
  controls=tk.Frame(left,bg=BG);controls.pack(fill='x')
  items=[('DISCOUNT',self.set_discount),('HOLD SALE',self.hold),('RECALL SALE',self.recall),('VOID ITEM',self.void),('CLEAR SCREEN',self.clear_cart),('PREVIOUS SALES',self.previous),('EDIT QTY / PRICE',self.edit_line),('STOCK LOOKUP',self.stock_lookup),('CUSTOMER',self.select_customer)]
  for i,(name,fn) in enumerate(items):self.btn(controls,name,fn,size=9,height=1).grid(row=i//3,column=i%3,sticky='ew',padx=2,pady=2)
  for i in range(3):controls.columnconfigure(i,weight=1)
  tk.Label(right,text='QUICK PRODUCTS',bg=BG,fg='#111111',font=('Segoe UI',13,'bold')).pack(pady=5)
  for p in self.db.execute('SELECT id,name FROM products ORDER BY id LIMIT 5').fetchall():self.btn(right,p['name'],lambda id=p['id']:self.quick(id),size=10,height=1).pack(fill='x',pady=2)
  for name,fn,col in [('LOTTERY',self.lottery,'white'),('CASH PAYMENT',self.register_cash, '#d9efdf'),('EFTPOS (SIMULATED)',lambda:self.checkout('EFTPOS SIMULATED'),'white'),('ACCOUNT',lambda:self.checkout('ACCOUNT'),'white'),('SPLIT TENDER',self.split_payment,'white'),('ACCOUNT PAYMENT',self.account_payment,'white'),('LAST RECEIPT',self.last_receipt,'white')]:self.btn(right,name,fn,size=10,height=1,bg=col).pack(fill='x',pady=2)
  self.refresh_cart();self.code.focus_set()
 def refresh_cart(self):
  if not hasattr(self,'sale_tree') or not self.sale_tree.winfo_exists():return
  self.sale_tree.delete(*self.sale_tree.get_children())
  for i,x in enumerate(self.cart):self.sale_tree.insert('','end',iid=str(i),values=(x['description'],x['qty'],money(x['unit']),money(x['qty']*x['unit'])))
  self.total_label.config(text=f'TOTAL  {money(self.total())}'+(f'   (Discount {money(self.discount)})' if self.discount else ''))
  self.customer_label.config(text='Customer: '+(self.db.execute('SELECT name FROM customers WHERE id=?',(self.customer,)).fetchone()['name'] if self.customer else 'Walk-in'))
 def scan(self):
  code=self.code.get().strip();self.code.delete(0,'end');p=self.product_by_code(code)
  if p:self.add_to_cart(p)
  elif code:self.warn('Barcode not found. Add the product under Products & Stock.')
  self.code.focus_set()
 def quick(self,pid):self.add_to_cart(self.db.execute('SELECT * FROM products WHERE id=?',(pid,)).fetchone())
 def selected_line(self):
  s=self.sale_tree.selection();return int(s[0]) if s else None
 def void(self):
  i=self.selected_line()
  if i is None:return self.warn('Select an item first')
  self.cart.pop(i);self.refresh_cart()
 def edit_line(self):
  i=self.selected_line()
  if i is None:return self.warn('Select a line to edit')
  x=self.cart[i];q=simpledialog.askinteger('Quantity','Enter quantity (negative values for refund lines):',initialvalue=x['qty'],parent=self.root)
  if q is None or q==0:return
  if x.get('original_line') and q>=0:return self.warn('Returned items must have a negative quantity. Delete the line to cancel it')
  if x.get('original_line') and q<0 and abs(q)>abs(x['qty']):return self.warn('Refund quantity cannot be increased here')
  if x['product_id'] and q>0:
   p=self.db.execute('SELECT stock FROM products WHERE id=?',(x['product_id'],)).fetchone()
   if not p:return self.warn('Product no longer exists')
  x['qty']=q;self.refresh_cart()
 def clear_cart(self):
  if self.cart and not messagebox.askyesno('Clear sale','Clear the current sale?',parent=self.root):return
  self.cart=[];self.discount=0;self.customer=None;self.refund_origin=None;self.refresh_cart()
 def set_discount(self):
  if not self.cart:return self.warn('Add an item first')
  n=self.ask_money('Discount','Discount amount ($):',f'{self.discount/100:.2f}')
  if n is None:return
  if n<0 or n>sum(x['qty']*x['unit'] for x in self.cart) or self.refund_origin:return self.warn('Invalid discount for this sale')
  self.discount=n;self.refresh_cart()
 def hold(self):
  if not self.cart:return self.warn('No sale to hold')
  name=self.prompt('Hold Sale','Reference / customer name:','Held sale')
  if name is None:return
  self.db.execute('INSERT INTO held(created,description,cart,discount,customer_id) VALUES(?,?,?,?,?)',(now(),name,json.dumps(self.cart),self.discount,self.customer));self.db.commit();self.log('HOLD','Sale placed on hold: '+name)
  self.cart=[];self.discount=0;self.customer=None;self.refund_origin=None;self.refresh_cart();self.info('Hold','Sale saved to the shared test database.')
 def recall(self):
  if self.cart:return self.warn('Finish or hold the current sale first')
  rows=self.db.execute('SELECT * FROM held ORDER BY id DESC').fetchall()
  if not rows:return self.warn('No held sales')
  w=tk.Toplevel(self.root);w.title('Recall Held Sale');w.geometry('650x400');t=self.tree(w,['ID','Created','Reference','Total'],[55,190,220,100])
  for r in rows:
   amount=sum(x['qty']*x['unit'] for x in json.loads(r['cart']))-r['discount'];t.insert('','end',iid=str(r['id']),values=(r['id'],r['created'],r['description'],money(amount)))
  def go():
   s=t.selection()
   if not s:return
   r=self.db.execute('SELECT * FROM held WHERE id=?',(int(s[0]),)).fetchone()
   if not r:return
   with self.db:self.db.execute('DELETE FROM held WHERE id=?',(r['id'],))
   self.cart=json.loads(r['cart']);self.discount=r['discount'];self.customer=r['customer_id'];self.log('RECALL',f'Recalled hold #{r["id"]}');w.destroy();self.refresh_cart()
  self.btn(w,'RECALL SELECTED',go).pack(pady=5)
 def stock_lookup(self):
  term=self.prompt('Stock Lookup','Enter barcode or part of product name:')
  if not term:return
  rows=self.db.execute('SELECT * FROM products WHERE barcode=? OR name LIKE ? LIMIT 30',(term,'%'+term+'%')).fetchall()
  self.info('Stock Lookup','\n'.join(f'{r["barcode"]} | {r["name"]} | {money(r["price"])} | Stock {r["stock"]}' for r in rows) or 'No matches')
 def choose_customer(self):
  rows=self.db.execute('SELECT * FROM customers ORDER BY name').fetchall()
  if not rows:return None
  s=self.prompt('Customer','Enter customer ID:\n'+'\n'.join(f'{r["id"]}: {r["name"]} (balance {money(r["balance"])})' for r in rows[:25]))
  if not s:return None
  try:cid=int(s)
  except ValueError:return None
  return cid if self.db.execute('SELECT 1 FROM customers WHERE id=?',(cid,)).fetchone() else None
 def select_customer(self):
  cid=self.choose_customer()
  if cid:self.customer=cid;self.refresh_cart()
 def lottery(self):
  w=tk.Toplevel(self.root);w.title('Lottery — TEST ONLY');w.geometry('420x400');w.configure(bg=BG)
  tk.Label(w,text='LOTTERY (MANUAL TEST ENTRY)',font=('Segoe UI',15,'bold'),bg=BG,fg='#111111').pack(pady=14)
  for title,sign,kind in [('Lotto Sale',1,'LOTTO SALE'),('Lotto Payout',-1,'LOTTO PAYOUT'),('Scratch-It Sale',1,'SCRATCH SALE'),('Scratch-It Payout',-1,'SCRATCH PAYOUT')]:
   def add(title=title,sign=sign,kind=kind):
    n=self.ask_money(title,'Amount ($):')
    if n is None:return
    if n<=0:return self.warn('Amount must be positive')
    self.cart.append(dict(product_id=None,description=title,qty=sign,unit=n,kind=kind,original_line=None));w.destroy();self.refresh_cart()
   self.btn(w,title,add).pack(fill='x',padx=24,pady=5)
  tk.Label(w,text='Not connected to The Lott. Enter amounts verified on the lottery terminal.\nPayouts reduce the cash due in this test.',bg=BG,fg='#a13d30',wraplength=380).pack(pady=9)
 def checkout(self,method,split=None):
  if not self.cart:return self.warn('No items in the sale')
  unlinked_return = any(x['qty']<0 and x.get('product_id') is not None and not x.get('original_line') for x in self.cart)
  if unlinked_return and not (getattr(self,'_linkly_verified_refund',False) and getattr(self,'_linkly_verified_checkout',False) and self.refund_origin is None and self.total()<0):
   return self.warn('Unlinked negative quantities require a verified OFFLINE Linkly training refund. No sale posted.')
  if any(int(x.get('line_discount',0))<0 or int(x.get('line_discount',0))>max(0,x['qty']*x['unit']) for x in self.cart):return self.warn('Invalid line discount; correct it before checkout.')
  if self.discount<0 or self.discount>max(0,sum(x['qty']*x['unit']-int(x.get('line_discount',0)) for x in self.cart)):return self.warn('Invalid sale discount; correct it before checkout.')
  total=self.total()
  if total<0 and method not in ('CASH','EFTPOS SIMULATED') and not ('EFTPOS' in method.upper() and getattr(self,'_linkly_verified_refund',False)):
   return self.warn('Negative total: use a supported refund tender in this test')
  if method=='ACCOUNT' and not self.customer:
   self.customer=self.choose_customer()
   if not self.customer:return
  tender=getattr(self,'_pending_cash_tender',None) if method=='CASH' else None
  if tender is not None and tender<total:return self.warn('Cash tender is less than amount due')
  if tender is None and not getattr(self,'_skip_test_payment_confirmation',False) and not messagebox.askyesno('TEST PAYMENT',f'{method}\nTotal: {money(total)}\n\nSIMULATED ONLY — no real money moves. Continue?',parent=self.root):return
  try:
   with self.db:
    self.db.execute('UPDATE sale_number_sequence SET last_issued=last_issued+1 WHERE singleton=1')
    sid=self.db.execute('SELECT last_issued FROM sale_number_sequence WHERE singleton=1').fetchone()[0]
    cur=self.db.execute('INSERT INTO sales(id,created,total,payment,customer_id,kind,reference,discount) VALUES(?,?,?,?,?,?,?,?)',(sid,now(),total,method,self.customer,'REFUND/EXCHANGE' if self.refund_origin else ('UNLINKED TEST REFUND' if unlinked_return else 'SALE'),self.refund_origin,self.discount))
    for x in self.cart:
     if x.get('original_line'):
      original=self.db.execute('SELECT sale_id,product_id,qty FROM lines WHERE id=?',(x['original_line'],)).fetchone()
      if not original or original['sale_id']!=self.refund_origin or original['product_id']!=x['product_id'] or x['qty']>=0:
       raise ValueError('Invalid refund reference or quantity')
      used=self.db.execute('SELECT COALESCE(SUM(-qty),0) FROM lines WHERE original_line=? AND qty<0',(x['original_line'],)).fetchone()[0]
      if -x['qty']>original['qty']-used:raise ValueError('Refund quantity exceeds the remaining original purchase')
    for x in self.cart:
     pid=x['product_id'];q=x['qty'];k=x['kind']
     if pid is not None:
      if q>0:
       update=self.db.execute('UPDATE products SET stock=stock-? WHERE id=?',(q,pid))
       if update.rowcount!=1:raise ValueError('Product no longer exists: '+x['description'])
      elif q<0:self.db.execute('UPDATE products SET stock=stock+? WHERE id=?',(-q,pid))
     self.db.execute('INSERT INTO lines(sale_id,product_id,description,qty,unit,kind,original_line,line_discount) VALUES(?,?,?,?,?,?,?,?)',(sid,pid,x['description'],q,x['unit'],k,x.get('original_line'),int(x.get('line_discount',0))))
    if self.customer and method=='ACCOUNT':self.db.execute('UPDATE customers SET balance=balance+? WHERE id=?',(total,self.customer))
    if split:
     for m,amount in split:self.db.execute('INSERT INTO payments(sale_id,created,method,amount) VALUES(?,?,?,?)',(sid,now(),m,amount))
    elif method!='ACCOUNT':self.db.execute('INSERT INTO payments(sale_id,created,method,amount) VALUES(?,?,?,?)',(sid,now(),method,total))
   if tender is not None:
    with self.db:self.db.execute('UPDATE payments SET note=? WHERE sale_id=? AND method=?',(f'Cash tendered {money(tender)}; change {money(tender-total)}',sid,'CASH'))
   self._pending_cash_tender=None
   self.log('SALE',f'#{sid} {method} {money(total)}');self.cart=[];self.discount=0;self.customer=None;self.refund_origin=None;self.refresh_cart();return True
  except Exception as e:self._pending_cash_tender=None;self.warn('Transaction rolled back: '+str(e));return False
 def split_payment(self):
  if not self.cart:return self.warn('No items in sale')
  total=self.total()
  if total<0:return self.warn('Negative split refunds are not supported in this test')
  cash=self.ask_money('Split Tender',f'Total {money(total)}\nEnter CASH portion ($):')
  if cash is None:return
  if cash<0 or cash>total:return self.warn('Cash portion is invalid')
  self.checkout('SPLIT CASH/EFTPOS',split=[('CASH',cash),('EFTPOS SIMULATED',total-cash)])
 def account_payment(self):
  cid=self.customer or self.choose_customer()
  if not cid:return
  n=self.ask_money('Customer Account Payment','Payment amount ($):')
  if n is None or n<=0:return
  method=self.prompt('Payment method','Enter CASH or EFTPOS SIMULATED:','CASH')
  if not method:return
  with self.db:
   self.db.execute('UPDATE customers SET balance=balance-? WHERE id=?',(n,cid))
   self.db.execute('INSERT INTO payments(customer_id,created,method,amount,note) VALUES(?,?,?,?,?)',(cid,now(),method,n,'Account collection (not new sales revenue)'))
  self.log('ACCOUNT',f'Customer #{cid} payment {money(n)}');self.info('Account Payment',f'Recorded TEST account payment of {money(n)}')
 def last_receipt(self):
  r=self.db.execute('SELECT id FROM sales ORDER BY id DESC LIMIT 1').fetchone()
  if r:self.receipt(r['id'])
  else:self.warn('No receipts')
 def receipt(self,sid):
  r=self.db.execute('SELECT * FROM sales WHERE id=?',(sid,)).fetchone()
  if not r:return
  lines=self.db.execute('SELECT * FROM lines WHERE sale_id=?',(sid,)).fetchall()
  payments=self.db.execute('SELECT method,amount FROM payments WHERE sale_id=?',(sid,)).fetchall()
  body=f'RECEIPT #{sid}\n{r["created"]}\n{r["payment"]}\n\n'+'\n'.join(f'{x["qty"]} × {x["description"]} @ {money(x["unit"])} = {money(x["qty"]*x["unit"])}' for x in lines)+f'\n\nDiscount: {money(r["discount"])}\nTOTAL: {money(r["total"])}'
  if payments:body+='\n\nPayments:\n'+'\n'.join(f'{p["method"]}: {money(p["amount"])}' for p in payments)
  from linkly_receipt_v119 import training_receipt_lines
  eft_details=training_receipt_lines(self.db,sid)
  if eft_details:body+='\n\n'+'\n'.join(eft_details)
  self.info('Receipt details',body)
 def previous(self):
  w=tk.Toplevel(self.root);w.title('Previous Sales — Search / Details / Payments / Refund');w.geometry('1050x650')
  top=tk.Frame(w);top.pack(fill='x',pady=7,padx=10);tk.Label(top,text='Search receipt # / date / tender').pack(side='left');v=tk.StringVar();tk.Entry(top,textvariable=v,width=35).pack(side='left',padx=9)
  t=self.tree(w,['Receipt','Date','Type','Payment','Total'],[90,200,150,220,130],12)
  details=tk.Text(w,height=9,font=('Consolas',10));details.pack(fill='x',padx=12,pady=4)
  def populate(*args):
   t.delete(*t.get_children());q='%'+v.get().strip()+'%'
   for r in self.db.execute('SELECT * FROM sales WHERE CAST(id AS TEXT) LIKE ? OR created LIKE ? OR payment LIKE ? ORDER BY id DESC LIMIT 500',(q,q,q)).fetchall():t.insert('','end',iid=str(r['id']),values=(r['id'],r['created'],r['kind'],r['payment'],money(r['total'])))
  def selected():
   s=t.selection();return int(s[0]) if s else None
  def show(event=None):
   sid=selected()
   if not sid:return
   r=self.db.execute('SELECT * FROM sales WHERE id=?',(sid,)).fetchone();lines=self.db.execute('SELECT * FROM lines WHERE sale_id=?',(sid,)).fetchall();pays=self.db.execute('SELECT * FROM payments WHERE sale_id=?',(sid,)).fetchall()
   details.delete('1.0','end');details.insert('end',f'RECEIPT #{sid} | {r["created"]} | {r["payment"]} | TOTAL {money(r["total"])}\n')
   for l in lines:details.insert('end',f'  Line {l["id"]}: {l["qty"]} x {l["description"]} @ {money(l["unit"])} = {money(l["qty"]*l["unit"])}\n')
   for p in pays:details.insert('end',f'  Payment: {p["method"]} {money(p["amount"])}\n')
  def refund():
   sid=selected()
   if not sid:return
   if self.cart:return self.warn('Finish or hold the current sale before loading a refund')
   lines=self.db.execute('SELECT * FROM lines WHERE sale_id=? AND product_id IS NOT NULL AND qty>0',(sid,)).fetchall()
   if not lines:return self.warn('No eligible retail product lines')
   chosen=self.prompt('Refund Lines','Enter line ID(s) to refund, separated by commas:\n'+'\n'.join(f'{l["id"]}: {l["description"]} x {l["qty"]}' for l in lines))
   if not chosen:return
   try:ids={int(x.strip()) for x in chosen.split(',')}
   except ValueError:return self.warn('Invalid line IDs')
   new=[]
   for l in lines:
    if l['id'] not in ids:continue
    already=self.db.execute('SELECT COALESCE(SUM(-qty),0) AS n FROM lines WHERE original_line=? AND qty<0',(l['id'],)).fetchone()['n']
    available=l['qty']-already
    if available<=0:return self.warn('Already fully refunded: '+l['description'])
    qty=simpledialog.askinteger('Refund quantity',f'{l["description"]}: refundable {available}\nQuantity:',initialvalue=available,minvalue=1,maxvalue=available,parent=w)
    if qty is None:return
    new.append(dict(product_id=l['product_id'],description=l['description']+' [RETURN]',qty=-qty,unit=l['unit'],kind='PRODUCT',original_line=l['id']))
   if not new:return
   self.cart=new;self.discount=0;self.refund_origin=sid;w.destroy();self.refresh_cart();self.info('Refund loaded','Refund lines are now negative in POS. Add positive exchange products if needed, then complete a simulated refund payment.')
  v.trace_add('write',populate);t.bind('<<TreeviewSelect>>',show);populate()
  bar=tk.Frame(w);bar.pack(fill='x',padx=12,pady=7)
  for name,fn in [('VIEW DETAILS',show),('OPEN RECEIPT',lambda:self.receipt(selected()) if selected() else None),('LOAD REFUND / EXCHANGE',refund),('CLOSE',w.destroy)]:self.btn(bar,name,fn,size=9,height=1).pack(side='left',padx=4)
  tk.Label(w,text='Functional: search, view details/payments, receipt, load retail refunds/exchanges. Advanced Tower Previous Sales actions remain for later builds.',fg='#98511a').pack()
 def products(self):
  self.clear();self.header('PRODUCTS & STOCK');bar=tk.Frame(self.root,bg=BG);bar.pack(fill='x',padx=12,pady=9)
  for name,fn in [('Add Product',self.add_product),('Edit Product',self.edit_product),('Adjust Stock',self.adjust_stock),('Supplier CSV Import',self.import_csv),('Stocktake',self.stocktake),('Refresh',self.products)]:self.btn(bar,name,fn,size=9,height=1).pack(side='left',padx=3)
  self.prod_tree=self.tree(self.root,['ID','Barcode','Product','Price','Stock','Supplier','Category'],[45,170,260,95,65,150,130])
  for r in self.db.execute('SELECT * FROM products ORDER BY name'):self.prod_tree.insert('','end',iid=str(r['id']),values=(r['id'],r['barcode'],r['name'],money(r['price']),r['stock'],r['supplier'],r['category']))
 def add_product(self):
  barcode=self.prompt('Add Product','Barcode:')
  if not barcode:return
  name=self.prompt('Add Product','Product name:')
  if not name:return
  price=self.ask_money('Add Product','Selling price ($):')
  if price is None:return
  stock=simpledialog.askinteger('Stock','Starting TEST stock:',minvalue=0,parent=self.root)
  if stock is None:return
  try:
   with self.db:self.db.execute('INSERT INTO products(barcode,name,price,stock) VALUES(?,?,?,?)',(barcode.strip(),name.strip(),price,stock))
   self.log('PRODUCT','Created '+barcode);self.products()
  except sqlite3.IntegrityError:self.warn('Barcode already exists')
 def chosen_product(self):
  s=self.prod_tree.selection() if hasattr(self,'prod_tree') and self.prod_tree.winfo_exists() else []
  return self.db.execute('SELECT * FROM products WHERE id=?',(int(s[0]),)).fetchone() if s else None
 def edit_product(self):
  p=self.chosen_product()
  if not p:return self.warn('Select a product first')
  name=self.prompt('Edit Product','Name:',p['name'])
  if not name:return
  price=self.ask_money('Edit Product','Selling price ($):',str(p['price']/100))
  if price is None:return
  with self.db:self.db.execute('UPDATE products SET name=?,price=? WHERE id=?',(name,price,p['id']))
  self.log('PRODUCT',f'Updated {p["barcode"]} name/price');self.products()
 def adjust_stock(self):
  p=self.chosen_product()
  if not p:return self.warn('Select a product first')
  delta=simpledialog.askinteger('Manual Stock Adjustment',f'{p["name"]} — Current {p["stock"]}\nChange by (+/- quantity):',parent=self.root)
  if delta is None or delta==0:return
  if p['stock']+delta<0:return self.warn('Cannot make stock negative')
  reason=self.prompt('Mandatory Reason','Reason (damaged, missing, supplier correction, other):')
  if not reason or not reason.strip():return self.warn('Reason is mandatory')
  with self.db:
   self.db.execute('UPDATE products SET stock=stock+? WHERE id=?',(delta,p['id']))
   self.db.execute('INSERT INTO stock_adjustments(created,product_id,delta,reason) VALUES(?,?,?,?)',(now(),p['id'],delta,reason))
  self.log('STOCK',f'{p["name"]} {delta:+d}: {reason}');self.products()
  self.info('Test adjustment','Saved and audited. Owner email notifications are NOT configured in this prototype.')
 def import_csv(self):
  path=filedialog.askopenfilename(title='Supplier Stock CSV',filetypes=[('CSV files','*.csv')])
  if not path:return
  try:
   with open(path,encoding='utf-8-sig',newline='') as f:rows=list(csv.DictReader(f))
   if not rows:return self.warn('CSV has no rows')
   keys=list(rows[0]);self.info('CSV Columns','Found: '+', '.join(keys[:30]))
   def match(candidates):return next((k for k in keys if k.strip().lower().replace(' ','').replace('_','') in candidates),None)
   b=match({'barcode','ean','ean13','upc','gtin'});n=match({'name','description','productname','itemdescription'});p=match({'rrp','price','retailprice','sellingprice'})
   if not b or not n or not p:return self.warn('Required barcode/name/price columns not recognised. CSV preview only; no changes made.')
   supplier=self.prompt('Supplier','Supplier name:','John Sands')
   if not supplier:return
   changes=[];errors=[]
   for i,r in enumerate(rows,2):
    try:
     code=r[b].strip();name=r[n].strip();price=cents(r[p]);assert code and name and price>=0
     old=self.product_by_code(code);changes.append((code,name,price,old))
    except Exception:errors.append(i)
   if not messagebox.askyesno('REVIEW IMPORT',f'Rows: {len(rows)}\nValid: {len(changes)}\nInvalid: {len(errors)}\nNew: {sum(x[3] is None for x in changes)}\nExisting: {sum(x[3] is not None for x in changes)}\n\nImport names and prices? Existing stock quantities WILL NOT change.\nReview prices before using live.',parent=self.root):return
   with self.db:
    for code,name,price,old in changes:
     if old:self.db.execute('UPDATE products SET name=?,price=?,supplier=? WHERE barcode=?',(name,price,supplier,code))
     else:self.db.execute('INSERT INTO products(barcode,name,price,stock,supplier) VALUES(?,?,?,0,?)',(code,name,price,supplier))
   self.log('CSV',f'Imported {len(changes)} rows from {Path(path).name}, supplier {supplier}');self.products()
  except Exception as e:self.warn('Import failed: '+str(e))
 def stocktake(self):
  self.clear();self.header('BLIND STOCKTAKE');bar=tk.Frame(self.root,bg=BG);bar.pack(fill='x',padx=12,pady=9)
  sessions=self.db.execute('SELECT * FROM stocktake ORDER BY id DESC').fetchall();active=next((x for x in sessions if x['status']=='COUNTING'),None)
  def new():
   if active:return self.warn('Finish existing stocktake first')
   with self.db:self.db.execute('INSERT INTO stocktake(created) VALUES(?)',(now(),))
   self.stocktake()
  self.btn(bar,'NEW SESSION',new,size=10,height=1).pack(side='left',padx=4)
  tk.Label(bar,text=('Active session #'+str(active['id']) if active else 'No active session'),bg=BG,font=('Segoe UI',12,'bold')).pack(side='left',padx=12)
  if active:
   f=tk.Frame(self.root,bg=BG);f.pack(fill='x',padx=15,pady=9)
   tk.Label(f,text='Barcode:',bg=BG).pack(side='left');code=tk.Entry(f,width=28,font=('Segoe UI',12));code.pack(side='left',padx=5)
   tk.Label(f,text='Count:',bg=BG).pack(side='left');q=tk.Entry(f,width=9,font=('Segoe UI',12));q.pack(side='left',padx=5)
   def save():
    p=self.product_by_code(code.get().strip())
    if not p:return self.warn('Unknown barcode')
    try:count=int(q.get());assert count>=0
    except Exception:return self.warn('Count must be 0 or more')
    with self.db:self.db.execute('INSERT INTO stock_counts(session_id,product_id,qty) VALUES(?,?,?) ON CONFLICT(session_id,product_id) DO UPDATE SET qty=excluded.qty',(active['id'],p['id'],count))
    code.delete(0,'end');q.delete(0,'end');self.stocktake()
   self.btn(f,'SAVE COUNT',save,size=10,height=1).pack(side='left',padx=5)
   self.btn(f,'OWNER REVIEW / FINALISE',lambda:self.owner_review(active['id']),size=10,height=1).pack(side='left',padx=5)
   tk.Label(self.root,text='STAFF BLIND VIEW — expected stock and variance are intentionally hidden. Owner review requires owner credentials in production.',bg=BG,fg='#995522').pack(pady=6)
   t=self.tree(self.root,['Barcode','Product','Counted'],[220,450,120])
   for r in self.db.execute('SELECT p.barcode,p.name,c.qty FROM stock_counts c JOIN products p ON p.id=c.product_id WHERE c.session_id=? ORDER BY p.name',(active['id'],)):t.insert('','end',values=tuple(r))
  else:
   t=self.tree(self.root,['Session','Created','Status'],[130,240,160])
   for s in sessions:t.insert('','end',values=(s['id'],s['created'],s['status']))
 def owner_review(self,sid):
  pin=self.prompt('Owner Review — TEST ONLY','Enter demo owner PIN (default 9999):')
  if pin!='9999':return self.warn('Owner PIN incorrect')
  w=tk.Toplevel(self.root);w.title('Owner Stocktake Variance Review');w.geometry('780x550')
  t=self.tree(w,['Barcode','Product','System','Counted','Variance'],[170,230,100,100,100])
  rows=self.db.execute('SELECT p.*,c.qty AS counted FROM stock_counts c JOIN products p ON p.id=c.product_id WHERE c.session_id=?',(sid,)).fetchall()
  for p in rows:t.insert('','end',values=(p['barcode'],p['name'],p['stock'],p['counted'],p['counted']-p['stock']))
  def finish():
   if not rows:return self.warn('No counted items')
   if not messagebox.askyesno('OWNER FINALISE','Adjust ONLY counted items to counted quantities?\nUncounted items remain unchanged.\n\nTEST DATA ONLY.',parent=w):return
   with self.db:
    for p in rows:
     delta=p['counted']-p['stock']
     if delta:
      self.db.execute('UPDATE products SET stock=? WHERE id=?',(p['counted'],p['id']))
      self.db.execute('INSERT INTO stock_adjustments(created,product_id,delta,reason) VALUES(?,?,?,?)',(now(),p['id'],delta,'Owner-approved stocktake #'+str(sid)))
    self.db.execute("UPDATE stocktake SET status='FINALISED' WHERE id=?",(sid,))
   self.log('STOCKTAKE',f'Owner finalised #{sid} with {len(rows)} counted products');w.destroy();self.stocktake()
  self.btn(w,'OWNER APPROVE & FINALISE',finish,size=11).pack(pady=10)
 def purchasing(self):
  self.layout('PURCHASING',[('Incoming Invoices',self.incoming_invoices)])
 def supplier_invoices(self):
  self.clear();self.header('SUPPLIER INVOICES');bar=tk.Frame(self.root,bg=BG);bar.pack(fill='x',padx=12,pady=8)
  def create():
   supplier=self.prompt('Supplier Invoice','Supplier name:')
   if not supplier:return
   number=self.prompt('Supplier Invoice','Invoice number:')
   if not number:return
   amount=self.ask_money('Supplier Invoice','Invoice amount ($):')
   if amount is None:return
   try:
    with self.db:self.db.execute('INSERT INTO supplier_invoices(supplier,number,created,amount) VALUES(?,?,?,?)',(supplier,number,now(),amount))
    self.log('PURCHASING',f'Created invoice {supplier}/{number} DRAFT');self.supplier_invoices()
   except sqlite3.IntegrityError:self.warn('Duplicate supplier invoice')
  self.btn(bar,'NEW INVOICE (HEADER ONLY)',create,size=9,height=1).pack(side='left',padx=5)
  t=self.tree(self.root,['ID','Supplier','Invoice #','Date','Amount','Status'],[55,210,180,190,120,110])
  for r in self.db.execute('SELECT * FROM supplier_invoices ORDER BY id DESC'):t.insert('','end',values=(r['id'],r['supplier'],r['number'],r['created'],money(r['amount']),r['status']))
  tk.Label(self.root,text='TEST LIMITATION: invoice headers only. Line-item receiving, reconciliation and payable posting are not yet implemented.',bg=BG,fg='#9b3229').pack(pady=8)
 def newsagency(self):
  self.layout('NEWSAGENCY',[('Magazine Arrivals',self.magazines),('Magazine Returns',self.magazine_returns),('Customer Putaways',self.putaways),('Newspaper Arrivals',self.newspapers),('Newspaper Standing Orders',self.putaways),('Delivery Rounds',lambda:self.info('Delivery Rounds','Not yet implemented in v0.2.')),('Subagent Dockets',lambda:self.info('Subagents','Not yet implemented in v0.2.')),('XchangeIT File Status',lambda:self.info('XchangeIT','No live XchangeIT connection. DD2/RTF/RTD/SL2 automation remains for a later build.'))])
 def magazines(self):
  self.clear();self.header('MAGAZINE ISSUE ARRIVALS');bar=tk.Frame(self.root,bg=BG);bar.pack(fill='x',padx=12,pady=10)
  def add():
   title=self.prompt('Magazine Arrival','Title:')
   if not title:return
   issue=self.prompt('Magazine Arrival','Issue identifier:')
   if not issue:return
   barcode=self.prompt('Magazine Arrival','Issue barcode (optional):') or ''
   qty=simpledialog.askinteger('Magazine Arrival','Received quantity:',minvalue=0,parent=self.root)
   if qty is None:return
   price=self.ask_money('Magazine Arrival','Retail price ($):')
   if price is None:return
   try:
    with self.db:self.db.execute('INSERT INTO magazine_issues(title,issue,barcode,qty,price) VALUES(?,?,?,?,?)',(title,issue,barcode,qty,price))
    self.log('MAGAZINE',f'Arrived {title} {issue} qty {qty}');self.magazines()
   except sqlite3.IntegrityError:self.warn('Issue already exists')
  self.btn(bar,'MANUAL ARRIVAL',add,size=10,height=1).pack(side='left',padx=5)
  self.btn(bar,'CUSTOMER PUTAWAYS',self.putaways,size=10,height=1).pack(side='left',padx=5)
  t=self.tree(self.root,['Title','Issue','Barcode','Received/On Hand','Price'],[290,180,200,130,110])
  for r in self.db.execute('SELECT * FROM magazine_issues ORDER BY id DESC'):t.insert('','end',values=(r['title'],r['issue'],r['barcode'],r['qty'],money(r['price'])))
  tk.Label(self.root,text='Manual magazine issue tracking works. DD2 import, automatic putaway matching and Zebra printing are not yet implemented.',bg=BG,fg='#98511a').pack(pady=8)
 def magazine_returns(self):
  self.clear();self.header('MAGAZINE RETURNS');t=self.tree(self.root,['ID','Title','Issue','On Hand'],[70,320,230,140]);rows=self.db.execute('SELECT * FROM magazine_issues ORDER BY title').fetchall()
  for r in rows:t.insert('','end',iid=str(r['id']),values=(r['id'],r['title'],r['issue'],r['qty']))
  def ret():
   s=t.selection()
   if not s:return self.warn('Select an issue')
   r=self.db.execute('SELECT * FROM magazine_issues WHERE id=?',(int(s[0]),)).fetchone()
   qty=simpledialog.askinteger('Return','Quantity returned:',minvalue=0,maxvalue=r['qty'],parent=self.root)
   if qty is None:return
   with self.db:self.db.execute('UPDATE magazine_issues SET qty=qty-? WHERE id=?',(qty,r['id']))
   self.log('MAGAZINE RETURN',f'{r["title"]} {r["issue"]} returned {qty}');self.magazine_returns()
  self.btn(self.root,'RECORD MANUAL RETURN',ret).pack(pady=7)
  tk.Label(self.root,text='Manual test returns only. RTF/RTD supplier files and credit claims are not yet implemented.',bg=BG,fg='#98511a').pack(pady=5)
 def putaways(self):
  self.clear();self.header('CUSTOMER PUTAWAYS');bar=tk.Frame(self.root,bg=BG);bar.pack(fill='x',padx=12,pady=8)
  def add():
   cid=self.choose_customer()
   if not cid:return
   title=self.prompt('Putaway','Newspaper or magazine title:')
   if not title:return
   issue=self.prompt('Putaway','Issue (blank for newspaper):') or ''
   qty=simpledialog.askinteger('Putaway','Quantity:',initialvalue=1,minvalue=1,parent=self.root)
   if qty is None:return
   with self.db:self.db.execute('INSERT INTO putaways(customer_id,title,issue,qty) VALUES(?,?,?,?)',(cid,title,issue,qty))
   self.log('PUTAWAY',f'Customer #{cid} {title} {issue}');self.putaways()
  self.btn(bar,'ADD PUTAWAY',add,size=10,height=1).pack(side='left',padx=5)
  t=self.tree(self.root,['ID','Customer','Title','Issue','Qty','Status'],[65,220,230,130,70,120])
  for r in self.db.execute('SELECT a.*,c.name FROM putaways a JOIN customers c ON c.id=a.customer_id ORDER BY a.id DESC'):t.insert('','end',iid=str(r['id']),values=(r['id'],r['name'],r['title'],r['issue'],r['qty'],r['status']))
  def collected():
   s=t.selection()
   if not s:return
   with self.db:self.db.execute("UPDATE putaways SET status='COLLECTED' WHERE id=?",(int(s[0]),))
   self.log('PUTAWAY','Collected #'+s[0]);self.putaways()
  self.btn(self.root,'MARK COLLECTED',collected).pack(pady=6)
 def newspapers(self):
  self.clear();self.header('NEWSPAPER ARRIVALS');bar=tk.Frame(self.root,bg=BG);bar.pack(fill='x',padx=12,pady=9)
  def add():
   day=self.prompt('Newspaper Arrival','Supply date (YYYY-MM-DD):',datetime.date.today().isoformat())
   if not day:return
   title=self.prompt('Newspaper Arrival','Newspaper title:','Courier-Mail')
   if not title:return
   supplier=self.prompt('Newspaper Arrival','Supplier:','Newspaper Supplier')
   if not supplier:return
   qty=simpledialog.askinteger('Newspaper Arrival','Physical docket quantity:',minvalue=0,parent=self.root)
   if qty is None:return
   with self.db:self.db.execute('INSERT INTO newspaper_arrivals(day,title,supplier,received) VALUES(?,?,?,?) ON CONFLICT(day,title,supplier) DO UPDATE SET received=excluded.received',(day,title,supplier,qty))
   self.log('NEWSPAPER',f'{day} {title} {qty}');self.newspapers()
  self.btn(bar,'RECORD DOCKET ARRIVAL',add,size=10,height=1).pack(side='left',padx=5)
  t=self.tree(self.root,['Date','Title','Supplier','Received'],[170,260,240,110])
  for r in self.db.execute('SELECT * FROM newspaper_arrivals ORDER BY day DESC,title'):t.insert('','end',values=(r['day'],r['title'],r['supplier'],r['received']))
  tk.Label(self.root,text='Manual docket recording works. Standing-order allocations and provisional supplier reconciliation are not yet implemented.',bg=BG,fg='#98511a').pack(pady=8)
 def customers(self):
  self.clear();self.header('CUSTOMERS & ACCOUNTS');bar=tk.Frame(self.root,bg=BG);bar.pack(fill='x',padx=12,pady=9)
  def add():
   name=self.prompt('Customer','Customer name:')
   if not name:return
   with self.db:self.db.execute('INSERT INTO customers(name) VALUES(?)',(name,))
   self.log('CUSTOMER','Added '+name);self.customers()
  self.btn(bar,'ADD CUSTOMER',add,size=10,height=1).pack(side='left',padx=4)
  self.btn(bar,'RECORD PAYMENT',self.account_payment,size=10,height=1).pack(side='left',padx=4)
  self.btn(bar,'CUSTOMER PUTAWAYS',self.putaways,size=10,height=1).pack(side='left',padx=4)
  t=self.tree(self.root,['ID','Name','Phone','Balance Owing (+) / Credit (-)'],[75,300,190,290])
  for r in self.db.execute('SELECT * FROM customers ORDER BY name'):t.insert('','end',values=(r['id'],r['name'],r['phone'],money(r['balance'])))
  tk.Label(self.root,text='Account sales and payments update balances. Statement printing and delivery billing are not yet implemented.',bg=BG,fg='#98511a').pack(pady=8)
 def sales(self):
  self.clear();self.header('SALES & REPORTS');bar=tk.Frame(self.root,bg=BG);bar.pack(fill='x',padx=12,pady=9)
  self.btn(bar,'PREVIOUS SALES',self.previous,size=10,height=1).pack(side='left',padx=5)
  self.btn(bar,'EXPORT SALES CSV',self.export_sales,size=10,height=1).pack(side='left',padx=5)
  t=self.tree(self.root,['Receipt','Date','Payment','Total','Type'],[110,220,230,130,170])
  for r in self.db.execute('SELECT * FROM sales ORDER BY id DESC'):t.insert('','end',values=(r['id'],r['created'],r['payment'],money(r['total']),r['kind']))
  sales=self.db.execute("SELECT COALESCE(SUM(total),0) FROM sales WHERE kind='SALE'").fetchone()[0]
  tk.Label(self.root,text=f'TEST SALE TOTAL: {money(sales)}   •   Account collections are recorded separately',bg=BG,font=('Segoe UI',12,'bold')).pack(pady=10)
 def export_sales(self):
  path=filedialog.asksaveasfilename(defaultextension='.csv',filetypes=[('CSV','*.csv')],initialfile='FreedomPOS_Test_Sales.csv')
  if not path:return
  with open(path,'w',newline='',encoding='utf-8-sig') as f:
   w=csv.writer(f);w.writerow(['Receipt','Date','Payment','Total cents','Kind'])
   for r in self.db.execute('SELECT * FROM sales ORDER BY id'):w.writerow([r['id'],r['created'],r['payment'],r['total'],r['kind']])
  self.info('Export','Saved test sales CSV.')
 def orders(self):self.layout('ORDERS & INVOICES',[('Customer Accounts',self.customers),('Customer Putaways',self.putaways),('Previous Sales / Receipts',self.previous),('WooCommerce Orders',lambda:self.info('WooCommerce','Not connected in v0.2.')),('Customer Statements',lambda:self.info('Statements','Not implemented in v0.2.')),('Invoice Printing',lambda:self.info('Invoices','Not implemented in v0.2.'))])
 def management(self):
  self.clear();self.header('MANAGEMENT / AUDIT LOG');t=self.tree(self.root,['Date','Category','Action'],[200,170,760])
  for r in self.db.execute('SELECT * FROM events ORDER BY id DESC LIMIT 1000'):t.insert('','end',values=(r['created'],r['category'],r['description']))
 def settings(self):self.layout('SETTINGS & TOOLS',[('Backup & Restore',self.backup),('RustDesk Remote Support',self.rustdesk),('Mobile Stocktake APK',lambda:self.info('Mobile Stocktake','Android APK is not built yet.')),('WooCommerce Integration',lambda:self.info('WooCommerce','Not connected in v0.2.')),('XchangeIT Integration',lambda:self.info('XchangeIT','Not connected in v0.2.')),('Printers / EFTPOS',lambda:self.info('Hardware','No hardware integrations in v0.2.'))])
 def backup(self):
  self.clear();self.header('BACKUP & RESTORE');tk.Label(self.root,text='Test database backup — no live business data',bg=BG,font=('Segoe UI',14,'bold')).pack(pady=25)
  def save():
   path=filedialog.asksaveasfilename(defaultextension='.db',filetypes=[('SQLite database','*.db')],initialfile='FreedomPOS_Test_Backup_'+datetime.date.today().isoformat()+'.db')
   if not path:return
   target=sqlite3.connect(path)
   try:self.db.backup(target)
   finally:target.close()
   self.log('BACKUP','Manual backup saved');self.info('Backup','Verified SQLite backup saved to:\n'+path)
  def restore():
   path=filedialog.askopenfilename(filetypes=[('SQLite database','*.db')])
   if not path:return
   try:
    src=sqlite3.connect(f'file:{Path(path).as_posix()}?mode=ro',uri=True)
    result=src.execute('PRAGMA integrity_check').fetchone()[0];src.close()
    if result!='ok':return self.warn('Backup integrity check failed')
   except Exception as e:return self.warn('Cannot read backup: '+str(e))
   if not messagebox.askyesno('DANGEROUS — TEST RESTORE','Replace the current TEST database? All changes since backup will be lost.\n\nProceed?',parent=self.root):return
   try:
    src=sqlite3.connect(path);self.db.close();target=sqlite3.connect(DB)
    src.backup(target);target.close();src.close();self.db=dbinit();self.info('Restore','Test database restored.');self.home()
   except Exception as e:self.warn('Restore failed: '+str(e));self.db=dbinit()
  for name,fn in [('BACKUP NOW',save),('RESTORE TEST BACKUP',restore)]:self.btn(self.root,name,fn,size=13).pack(pady=8)
  tk.Label(self.root,text='Scheduled automatic backups, external rotation and full archive backups remain for production development.',bg=BG,fg='#98511a').pack(pady=12)
 def rustdesk(self):
  if not messagebox.askyesno('RustDesk','Open RustDesk if installed?\n\nOnly allow remote access to a technician you trust.',parent=self.root):return
  try:
   if os.name=='nt':os.startfile('rustdesk.exe')
   else:subprocess.Popen(['rustdesk'])
  except Exception:self.info('RustDesk','RustDesk was not found automatically. Install it separately and launch from Windows. No remote session has been started.')


class ExtendedApp(App):
 def __init__(self,root):
  super().__init__(root)
  with self.db:
   self.db.executescript("""CREATE TABLE IF NOT EXISTS newspaper_titles(id INTEGER PRIMARY KEY,title TEXT NOT NULL,supplier TEXT NOT NULL,weekdays TEXT NOT NULL,price INTEGER NOT NULL DEFAULT 0,UNIQUE(title,supplier));
   CREATE TABLE IF NOT EXISTS scheduled_prices(id INTEGER PRIMARY KEY,title TEXT NOT NULL,effective TEXT NOT NULL,new_price INTEGER NOT NULL,applied INTEGER NOT NULL DEFAULT 0);
   CREATE TABLE IF NOT EXISTS stock_file_history(id INTEGER PRIMARY KEY,created TEXT NOT NULL,filename TEXT NOT NULL,rows INTEGER NOT NULL,kind TEXT NOT NULL);
   CREATE TABLE IF NOT EXISTS news_standing_orders(id INTEGER PRIMARY KEY,customer_id INTEGER NOT NULL,title TEXT NOT NULL,qty INTEGER NOT NULL DEFAULT 1,days TEXT NOT NULL DEFAULT 'Mon,Tue,Wed,Thu,Fri,Sat,Sun',method TEXT NOT NULL DEFAULT 'SHOP',active INTEGER NOT NULL DEFAULT 1);
   """)
  self.apply_scheduled_prices()
 def apply_scheduled_prices(self):
  today=datetime.date.today().isoformat()
  with self.db:
   rows=self.db.execute('SELECT * FROM scheduled_prices WHERE applied=0 AND effective<=?',(today,)).fetchall()
   for r in rows:
    self.db.execute('UPDATE newspaper_titles SET price=? WHERE title=?',(r['new_price'],r['title']))
    self.db.execute('UPDATE scheduled_prices SET applied=1 WHERE id=?',(r['id'],))
    self.db.execute('INSERT INTO events(created,category,description) VALUES(?,?,?)',(now(),'NEWSPAPER PRICE',f"{r['title']} price effective {r['effective']}"))
 def newsagency(self):
  self.layout('NEWSAGENCY',[('Magazine Arrivals',self.magazines),('DD2 Invoice Preview',self.dd2_preview),('Magazine Returns',self.magazine_returns),('Customer Putaways',self.putaways),('Express Newspaper Arrivals',self.express_newspapers),('Newspaper Title Setup',self.newspaper_setup),('Standing Newspaper Orders',self.news_orders),('Scheduled Newspaper Prices',self.schedule_price),('Delivery Rounds / Subagents',lambda:self.info('Pending integration','Delivery rounds and subagent docket automation are not yet built.')),('XchangeIT Status',lambda:self.info('Pending integration','DD2 preview works. Automatic DD2 receiving, RTF/RTD and SL2 are not connected.'))])
 def newspaper_setup(self):
  self.clear();self.header('NEWSPAPER TITLE SETUP')
  from newspaper_product_v134 import schema, DAYS
  schema(self.db)
  bar=tk.Frame(self.root,bg=BG);bar.pack(fill='x',padx=12,pady=8)
  def edit():
   selected=t.selection()
   title=t.item(selected[0],'values')[0] if selected else None
   self.newspaper_product_setup(title=title,refresh=self.newspaper_setup)
  tk.Button(bar,text='ADD NEW NEWSPAPER',command=lambda:self.newspaper_product_setup(refresh=self.newspaper_setup),
            bg='#e1e9f0',fg='#172b40',relief='solid',bd=1,font=('Segoe UI',10,'bold'),padx=16,pady=9).pack(side='left',padx=4)
  tk.Button(bar,text='EDIT SELECTED NEWSPAPER',command=edit,
            bg='#e1e9f0',fg='#172b40',relief='solid',bd=1,font=('Segoe UI',10,'bold'),padx=16,pady=9).pack(side='left',padx=4)
  t=self.tree(self.root,['Title','Supplier','Delivery Days','Weekday Prices'],[300,240,270,300])
  for title in [r[0] for r in self.db.execute('SELECT DISTINCT title FROM newspaper_weekdays_v134 ORDER BY title')]:
   data=self.db.execute('''SELECT n.day,p.supplier,p.price FROM newspaper_weekdays_v134 n
         JOIN products p ON p.id=n.product_id WHERE n.title=? AND n.active=1 ORDER BY n.day''',(title,)).fetchall()
   days=', '.join(DAYS[r[0]][:3] for r in data)
   prices=', '.join(DAYS[r[0]][:3]+' '+money(r[2]) for r in data)
   t.insert('','end',values=(title,data[0][1] if data else '',days,prices))
  t.bind('<Double-1>',lambda e:edit())
 def news_orders(self):
  self.clear();self.header('NEWSPAPER STANDING ORDERS')
  def add():
   cid=self.choose_customer()
   if not cid:return
   title=self.prompt('Newspaper order','Title:')
   if not title:return
   qty=simpledialog.askinteger('Standing order','Copies:',minvalue=1,parent=self.root)
   if qty is None:return
   days=self.prompt('Days','Delivery days:', 'Mon,Tue,Wed,Thu,Fri,Sat,Sun')
   method=self.prompt('Fulfilment','SHOP, HOME or SUBAGENT:', 'SHOP')
   if not days or method not in ('SHOP','HOME','SUBAGENT'):return self.warn('Invalid delivery days or method')
   with self.db:self.db.execute('INSERT INTO news_standing_orders(customer_id,title,qty,days,method) VALUES(?,?,?,?,?)',(cid,title,qty,days,method))
   self.news_orders()
  self.btn(self.root,'ADD STANDING ORDER',add).pack(pady=7)
  t=self.tree(self.root,['Customer','Title','Qty','Days','Fulfilment'],[220,250,60,240,130])
  for r in self.db.execute('SELECT c.name,o.* FROM news_standing_orders o JOIN customers c ON c.id=o.customer_id WHERE o.active=1 ORDER BY c.name'):t.insert('','end',values=(r['name'],r['title'],r['qty'],r['days'],r['method']))
 def express_newspapers(self):
  self.clear();self.header('EXPRESS NEWSPAPER ARRIVALS')
  top=tk.Frame(self.root,bg=BG);top.pack(fill='x',padx=12,pady=7)
  datevar=tk.StringVar(value=datetime.date.today().isoformat())
  tk.Label(top,text='Supply date YYYY-MM-DD:',bg=BG).pack(side='left');tk.Entry(top,textvariable=datevar,width=17).pack(side='left',padx=6)
  t=self.tree(self.root,['Title','Supplier','Expected Putaways','Received Qty','Price'],[280,200,170,150,100])
  entries={}
  def load():
   t.delete(*t.get_children());entries.clear()
   try:day=datetime.date.fromisoformat(datevar.get()).strftime('%a')
   except ValueError:return self.warn('Enter a valid date YYYY-MM-DD')
   for r in self.db.execute('SELECT * FROM newspaper_titles ORDER BY supplier,title'):
    if day not in [d.strip() for d in r['weekdays'].split(',')]:continue
    expected=self.db.execute('SELECT COALESCE(SUM(qty),0) FROM news_standing_orders WHERE title=? AND active=1 AND (days LIKE ? OR days=?)',(r['title'],'%'+day+'%', 'ALL')).fetchone()[0]
    old=self.db.execute('SELECT received FROM newspaper_arrivals WHERE day=? AND title=? AND supplier=?',(datevar.get(),r['title'],r['supplier'])).fetchone()
    received=old['received'] if old else ''
    key=str(r['id']);entries[key]=r;t.insert('','end',iid=key,values=(r['title'],r['supplier'],expected,received,money(r['price'])))
  def record():
   sel=t.selection()
   if not sel:return self.warn('Select a title')
   r=entries[sel[0]]
   qty=simpledialog.askinteger('Docket count',f"{r['title']} — physical quantity received:",minvalue=0,parent=self.root)
   if qty is None:return
   with self.db:self.db.execute('INSERT INTO newspaper_arrivals(day,title,supplier,received) VALUES(?,?,?,?) ON CONFLICT(day,title,supplier) DO UPDATE SET received=excluded.received',(datevar.get(),r['title'],r['supplier'],qty))
   self.log('NEWSPAPER',f"Docket {datevar.get()} {r['title']} qty {qty}");load()
  self.btn(top,'LOAD EXPECTED TITLES',load,size=9,height=1).pack(side='left',padx=5)
  self.btn(top,'RECORD SELECTED QUANTITY',record,size=9,height=1).pack(side='left',padx=5)
  tk.Label(self.root,text='Docket quantities saved. Allocation, provisional supplier invoice and finalisation are NOT yet automated.',bg=BG,fg='#9b3229').pack(pady=7)
  load()
 def schedule_price(self):
  self.clear();self.header('SCHEDULED NEWSPAPER PRICE CHANGES')
  def add():
   title=self.prompt('Scheduled price','Exact newspaper title:')
   if not title:return
   day=self.prompt('Scheduled price','Effective date YYYY-MM-DD:')
   try:datetime.date.fromisoformat(day)
   except (ValueError,TypeError):return self.warn('Invalid date')
   price=self.ask_money('Scheduled price','New selling price:')
   if price is None:return
   with self.db:self.db.execute('INSERT INTO scheduled_prices(title,effective,new_price) VALUES(?,?,?)',(title,day,price))
   self.apply_scheduled_prices();self.schedule_price()
  self.btn(self.root,'SCHEDULE PRICE',add).pack(pady=7)
  t=self.tree(self.root,['Title','Effective Date','New Price','Applied'],[330,200,150,120])
  for r in self.db.execute('SELECT * FROM scheduled_prices ORDER BY effective DESC'):t.insert('','end',values=(r['title'],r['effective'],money(r['new_price']),'Yes' if r['applied'] else 'No'))
  tk.Label(self.root,text='Test limitation: scheduled price updates newspaper setup records, not POS newspaper barcode aliases or customer billing.',bg=BG,fg='#9b3229').pack(pady=7)
 def dd2_preview(self):
  path=filedialog.askopenfilename(title='Choose supplier DD2 file',filetypes=[('DD2 files','*.dd2'),('All files','*.*')])
  if not path:return
  try:
   with open(path,newline='',encoding='utf-8-sig',errors='replace') as f:rows=list(csv.reader(f))
   headers=[r for r in rows if len(r)>1 and r[1]=='H']
   details=[r for r in rows if len(r)>1 and r[1]=='D']
   if not details:raise ValueError('No DD2 detail records found')
   w=tk.Toplevel(self.root);w.title('DD2 PREVIEW — READ ONLY');w.geometry('1050x600')
   tk.Label(w,text=f'{Path(path).name} | {len(details)} detail records | {len(headers)} header records | NO STOCK POSTED',font=('Segoe UI',12,'bold')).pack(pady=8)
   t=self.tree(w,['Supplier Code','Description','Barcode','Raw Quantity Field','Raw RRP Field'],[150,360,190,140,140])
   for r in details:
    get=lambda n:r[n] if len(r)>n else ''
    t.insert('','end',values=(get(3),get(5),get(10),get(13),get(28)))
   tk.Label(w,text='DD2 columns vary by supplier. This is a RAW PREVIEW only; field mapping and stock receiving require verification.',fg='#9b3229').pack(pady=7)
  except Exception as e:self.warn('DD2 preview failed: '+str(e))
 def products(self):
  super().products()
  bar=tk.Frame(self.root,bg=BG);bar.pack(fill='x',padx=12,pady=5)
  self.btn(bar,'NEWSPAPER SETUP',self.newspaper_setup,size=9,height=1).pack(side='left',padx=3)
  self.btn(bar,'CSV STOCK FILE',self.import_csv,size=9,height=1).pack(side='left',padx=3)
 def sales(self):
  super().sales()
  self.btn(self.root,'EXPORT TRANSACTION LINES CSV',self.export_transaction_lines,size=10,height=1).pack(pady=8)
 def export_transaction_lines(self):
  path=filedialog.asksaveasfilename(defaultextension='.csv',initialfile='FreedomPOS_Transaction_Lines.csv',filetypes=[('CSV','*.csv')])
  if not path:return
  rows=self.db.execute('SELECT s.id AS receipt,s.created,s.payment,s.kind,l.description,l.qty,l.unit,l.qty*l.unit AS line_total FROM sales s JOIN lines l ON l.sale_id=s.id ORDER BY s.id,l.id').fetchall()
  with open(path,'w',newline='',encoding='utf-8-sig') as f:
   out=csv.writer(f);out.writerow(['Receipt','Date','Tender','Sale Type','Product','Quantity','Unit Cents','Line Total Cents'])
   for r in rows:out.writerow(tuple(r))
  self.info('Export complete',f'Exported {len(rows)} transaction lines.')

from previous_sales_window import show_previous_sales
from operations_v05 import install
ExtendedApp.previous = show_previous_sales
install(ExtendedApp)
from email_workflows_v06 import install as install_email
install_email(ExtendedApp)
from navigation_v07 import install as install_navigation
install_navigation(ExtendedApp)

from gmail_oauth_v09 import install as install_gmail_oauth
install_gmail_oauth(ExtendedApp)

from product_grid_v012 import install as install_product_grid
install_product_grid(ExtendedApp)

from customer_forms_v013 import install as install_customer_forms
install_customer_forms(ExtendedApp)

from master_forms_v014 import install as install_master_forms
install_master_forms(ExtendedApp)

from stock_screen_v015 import install as install_stock_screen
install_stock_screen(ExtendedApp)


from supplier_receiving_v017 import install as install_supplier_receiving
install_supplier_receiving(ExtendedApp)

from linked_maintenance_v099 import install as install_linked_maintenance_v099
install_linked_maintenance_v099(ExtendedApp)

from register_v018 import install as install_register_v018
install_register_v018(ExtendedApp)

from departments_categories_v019 import install as install_departments_categories
install_departments_categories(ExtendedApp)

from register_foundations_v020 import install as install_register_foundations_v020
install_register_foundations_v020(ExtendedApp)

from register_tower_v022 import install as install_register_tower_v022
install_register_tower_v022(ExtendedApp)

from register_pin_v023 import install as install_register_pin_v023
# v0.28 TEST ONLY: temporarily disable the register staff PIN gate.
# Restore by uncommenting the following line after register workflow testing.
# install_register_pin_v023(ExtendedApp)
from stock_add_v028 import install as install_stock_add_v028
install_stock_add_v028(ExtendedApp)

# Apply register input validation LAST, after the final register screen override.
from register_shortcut_v016 import install as install_register_shortcut
install_register_shortcut(ExtendedApp)

from register_grid_v034 import install as install_register_grid_v034
install_register_grid_v034(ExtendedApp)

# v0.35: return focus to barcode after delete / clear, without stealing focus inside dialogs.
def _install_register_focus_v035(cls):
    for method_name in ('void','clear_cart'):
        old=getattr(cls,method_name)
        def wrap(self,*args,_old=old,**kwargs):
            try:return _old(self,*args,**kwargs)
            finally:
                self._armed_grid_row=None
                if hasattr(self,'code') and self.code.winfo_exists():
                    self.root.after_idle(lambda:self.code.focus_set() if self.code.winfo_exists() else None)
        setattr(cls,method_name,wrap)
_install_register_focus_v035(ExtendedApp)

from register_recall_v037 import install as install_register_recall_v037
install_register_recall_v037(ExtendedApp)

from register_discount_v038 import install as install_register_discount_v038
install_register_discount_v038(ExtendedApp)

from modern_ui_v040 import install as install_modern_ui_v040
install_modern_ui_v040(ExtendedApp)

from modern_dialogs_v042 import install as install_modern_dialogs_v042
install_modern_dialogs_v042()

from modern_input_v043 import install as install_modern_input_v043
install_modern_input_v043(ExtendedApp)

from register_customizer_v045 import install as install_register_customizer_v044
install_register_customizer_v044(ExtendedApp)

from receipt_preview_v051 import preview_receipt
ExtendedApp.receipt=lambda self,sid:preview_receipt(self,sid)

from receipt_business_v054 import install as install_receipt_business_v054
install_receipt_business_v054(ExtendedApp)

from register_keyboard_v060 import install as install_keyboard_shortcuts_v059
install_keyboard_shortcuts_v059(ExtendedApp)

from custom_actions_v062 import install as install_custom_actions_v062
install_custom_actions_v062(ExtendedApp)

from register_settings_v063 import install as install_register_settings_v063
install_register_settings_v063(ExtendedApp)
from settings_store_v065 import install as install_settings_store_v065
install_settings_store_v065(ExtendedApp)
from department_navigation_v067 import install as install_department_navigation_v067
install_department_navigation_v067(ExtendedApp)

from shift_sales_v072 import install as install_shift_sales_v072
install_shift_sales_v072(ExtendedApp)
from register_designer_v074 import install as install_register_designer_v074
install_register_designer_v074(ExtendedApp)
from epay_integration_v076 import install as install_epay_v076
install_epay_v076(ExtendedApp)
from epay_connection_diagnostic_v079 import install as install_epay_diagnostic_v079
install_epay_diagnostic_v079(ExtendedApp)
from epay_connection_v080 import install as install_epay_connection_v080
install_epay_connection_v080(ExtendedApp)

from epay_category_browser_v081 import install as install_epay_browser_v081
install_epay_browser_v081(ExtendedApp)

from split_tender_v083 import install as install_split_tender_v083
install_split_tender_v083(ExtendedApp)
from popup_keyboard_v086 import install as install_popup_keyboard_v086
install_popup_keyboard_v086(ExtendedApp)
from register_quantity_cash_v087 import install as install_quantity_cash_v087
install_quantity_cash_v087(ExtendedApp)

from linkly_setup_v110 import install as install_linkly_v110
install_linkly_v110(ExtendedApp)
from linkly_payment_v111 import install as install_linkly_payment_v111
install_linkly_payment_v111(ExtendedApp)

from product_master_v125 import install as install_product_master_v125
install_product_master_v125(ExtendedApp)


from newspaper_product_v134 import install as install_newspaper_product_v134
install_newspaper_product_v134(ExtendedApp)

from quick_sell_v136 import install as install_quick_sell_v136
install_quick_sell_v136(ExtendedApp)

from newspaper_seed_v140 import install as install_newspaper_seed_v140
install_newspaper_seed_v140(ExtendedApp)

from common_settings_v145 import install as install_common_settings_v145
install_common_settings_v145(ExtendedApp)


# Shared product/newspaper shortcut manager v146
from unified_shortcuts_v146 import install as install_unified_shortcuts_v146
install_unified_shortcuts_v146(ExtendedApp)

if __name__=='__main__':
 from responsive_windows_v056 import install as install_responsive_windows
 install_responsive_windows()
 root=tk.Tk()
 try:
  maxw=max(700,root.winfo_screenwidth()-24);maxh=max(540,root.winfo_screenheight()-100)
  root.minsize(min(980,maxw),min(650,maxh))
  root.geometry(f'{min(1260,maxw)}x{min(790,maxh)}+0+0')
 except tk.TclError:pass
 ExtendedApp(root);root.mainloop()

