Freedom POS 2.0 — Google Sign-in TEST v0.9
==========================================
1. Extract the ZIP into a NEW folder. Do not overwrite an existing live POS database.
2. Open freedom_v04, double-click START_FREEDOM_POS.bat (Python 3 and internet needed for first-time dependency installation).
3. Settings & Tools > Email Settings.
4. ONE-TIME Google configuration (there is no supported way around this without an already registered application):
   - Visit https://console.cloud.google.com/
   - Create/select a project, enable Gmail API.
   - Google Auth Platform: configure consent screen. For personal Gmail choose External and add your Gmail account as a test user if required.
   - Create OAuth client ID of type DESKTOP APP, download JSON file.
   - Browse to the JSON file in Email Settings; click SIGN IN WITH GOOGLE.
   - Sign in using Google's browser page; grant requested permissions.
5. Enter a test recipient and click SEND TEST EMAIL. Sending is confirmed by user.
6. Customer Invoices / Statements can use the connected Gmail API for PDF sending after confirmation; financial documents remain TEST ONLY.

Tokens: Stored in Windows Credential Manager for current Windows user via Python keyring. No Gmail password requested or stored.
Disconnect removes locally saved tokens (Google access may also be revoked at https://myaccount.google.com/permissions).
Do not send OAuth client JSON or Gmail password to support/chat.

EXE build: BUILD_TEST_EXE.bat. Output dist/FreedomPOS_Test_v09.exe.
NOTE: Not tested on Windows here. The Google Cloud OAuth consent setup and Google account authorization cannot be completed on your behalf.
NOTE: If Google consent app is in Testing mode, Google may expire refresh tokens after 7 days; reconnect as necessary.
NOTE: SMTP fields are not used when Google OAuth is connected. Earlier test builds used SMTP App Passwords.
