"""Test-only staff identity and coded lottery workflow extension."""
import tkinter as tk
from tkinter import ttk, messagebox, simpledialog
import hashlib, hmac, secrets, datetime

GAMES=[('01','Saturday Gold Lotto'),('02','Oz Lotto'),('04','Super 66'),('06','Monday & Wednesday Gold Lotto'),('07','Lucky Lotteries Super Jackpot'),('08','Lucky Lotteries Mega Jackpot'),('09','Lotto Strike'),('11','Keno'),('12','Keno Coin Toss'),('13','Set for Life'),('52','Powerball')]

def pin_hash(pin,salt):return hashlib.pbkdf2_hmac('sha256',pin.encode(),bytes.fromhex(salt),180000).hex()
def install(app_class):
 old_init=app_class.__init__;old_pos=app_class.pos;old_checkout=app_class.checkout;old_management=app_class.management
 def init(self,root):
  old_init(self,root)
  self.db.executescript('''CREATE TABLE IF NOT EXISTS staff(id INTEGER PRIMARY KEY,name TEXT NOT NULL,role TEXT NOT NULL CHECK(role IN ('CASHIER','SUPERVISOR','MANAGER','OWNER')),salt TEXT NOT NULL,pin_hash TEXT NOT NULL,active INTEGER NOT NULL DEFAULT 1);
  CREATE TABLE IF NOT EXISTS lottery_games(code TEXT PRIMARY KEY,name TEXT NOT NULL,active INTEGER NOT NULL DEFAULT 1);
  CREATE TABLE IF NOT EXISTS staff_events(id INTEGER PRIMARY KEY,created TEXT NOT NULL,staff_id INTEGER,action TEXT NOT NULL,detail TEXT NOT NULL);
  CREATE TABLE IF NOT EXISTS lottery_sale_lines(line_id INTEGER PRIMARY KEY,game_code TEXT NOT NULL,staff_id INTEGER);
  CREATE TABLE IF NOT EXISTS sale_staff(sale_id INTEGER PRIMARY KEY,staff_id INTEGER);
  ''')
  self.db.executemany('INSERT OR IGNORE INTO lottery_games(code,name) VALUES(?,?)',GAMES)
  if not self.db.execute('SELECT 1 FROM staff LIMIT 1').fetchone():
   salt=secrets.token_hex(16);self.db.execute('INSERT INTO staff(name,role,salt,pin_hash) VALUES(?,?,?,?)',('Demo Owner','OWNER',salt,pin_hash('99',salt)))
  self.db.commit();self.staff_id=None;self.staff_name=None;self._lottery_code_queue=[]
  self.root.title('Freedom POS 2.0 — v0.7 NAVIGATION TEST ONLY')
 def audit(self,action,detail):
  self.db.execute('INSERT INTO staff_events(created,staff_id,action,detail) VALUES(?,?,?,?)',(datetime.datetime.now().isoformat(timespec='seconds'),self.staff_id,action,detail));self.db.commit()
 def pin_dialog(self):
  w=tk.Toplevel(self.root);w.title('Staff PIN — TEST');w.transient(self.root);w.grab_set();w.geometry('350x225');w.resizable(False,False)
  tk.Label(w,text='ENTER YOUR 2-DIGIT STAFF PIN',font=('Segoe UI',12,'bold')).pack(pady=15)
  pin=tk.StringVar();entry=tk.Entry(w,textvariable=pin,show='●',font=('Segoe UI',20),justify='center',width=7);entry.pack(pady=8);entry.focus_set()
  tk.Label(w,text='First test login: Demo Owner PIN 99',fg='#9b3229').pack(pady=5)
  def submit():
   val=pin.get().strip()
   if len(val)!=2 or not val.isdigit():messagebox.showerror('PIN','Enter exactly two digits',parent=w);return
   found=None
   for row in self.db.execute('SELECT * FROM staff WHERE active=1'):
    if hmac.compare_digest(pin_hash(val,row['salt']),row['pin_hash']):found=row;break
   if not found:
    self.audit('LOGIN_DENIED','Invalid staff PIN');messagebox.showerror('PIN','Incorrect PIN',parent=w);pin.set('');return
   self.staff_id=found['id'];self.staff_name=found['name'];self.audit('LOGIN',self.staff_name);w.destroy()
  tk.Button(w,text='LOGIN',command=submit,width=16).pack(pady=8);entry.bind('<Return>',lambda e:submit());w.protocol('WM_DELETE_WINDOW',lambda:w.destroy());self.root.wait_window(w)
  return self.staff_id is not None
 def pos(self):
  old_pos(self)
  self.staff_id=None;self.staff_name=None
  if not self.pin_dialog():self.home()
 def checkout(self,method,split=None):
  # TEST ONLY: register PIN is intentionally disabled. Do not create a fake staff identity.
  # Restore cashier authentication before production use.
  prior=self.db.execute('SELECT COALESCE(MAX(id),0) FROM sales').fetchone()[0]
  pending=[(x.get('game_code'),i) for i,x in enumerate(self.cart) if x.get('game_code')]
  result=old_checkout(self,method,split)
  new=self.db.execute('SELECT COALESCE(MAX(id),0) FROM sales').fetchone()[0]
  if new>prior:
   if self.staff_id is not None:
    with self.db:
     self.db.execute('INSERT OR REPLACE INTO sale_staff(sale_id,staff_id) VALUES(?,?)',(new,self.staff_id))
     lines=self.db.execute('SELECT id,kind FROM lines WHERE sale_id=? ORDER BY id',(new,)).fetchall()
     for code,index in pending:
      if index<len(lines):self.db.execute('INSERT OR REPLACE INTO lottery_sale_lines(line_id,game_code,staff_id) VALUES(?,?,?)',(lines[index]['id'],code,self.staff_id))
    self.audit('CHECKOUT',f'Sale #{new} by {self.staff_name}; {method}')
   else:
    self.audit('TEST CHECKOUT',f'Sale #{new}; cashier PIN bypassed in TEST ONLY; {method}')
  return result
 def lottery(self):
  # TEST ONLY: lottery entry is available without staff login.
  # Production mode must enforce cashier/lottery permissions separately.
  w=tk.Toplevel(self.root);w.title('LOTTERY — TEST ONLY');w.geometry('550x590');w.configure(bg='#f2f5f8')
  tk.Label(w,text='LOTTERY — FOUR FUNCTIONS',font=('Segoe UI',15,'bold'),bg='#f2f5f8').pack(pady=10)
  def enter(kind,sign,code=None,name=None):
   amount=self.ask_money('Lottery '+kind,'Enter amount verified on lottery terminal ($):')
   if amount is None:return
   if amount<=0:return self.warn('Amount must be positive')
   description=(code+' '+name) if code else kind
   self.cart.append(dict(product_id=None,description=description,qty=sign,unit=amount,kind=kind,original_line=None,game_code=code))
   self.audit('LOTTERY_ENTRY',f'{kind} {description} {amount} cents (not yet completed)')
   w.destroy();self.refresh_cart()
  def choose_game():
   for child in w.winfo_children():child.destroy()
   tk.Label(w,text='LOTTO SALE — SELECT GAME CODE',font=('Segoe UI',14,'bold')).pack(pady=8)
   box=tk.Frame(w);box.pack(fill='both',expand=True,padx=14)
   games=self.db.execute('SELECT code,name FROM lottery_games WHERE active=1 ORDER BY code').fetchall()
   for i,r in enumerate(games):
    tk.Button(box,text=r['code']+'  '+r['name'],command=lambda c=r['code'],n=r['name']:enter('LOTTO SALE',1,c,n),anchor='w').grid(row=i,column=0,sticky='ew',pady=2)
   box.columnconfigure(0,weight=1)
   tk.Button(w,text='BACK',command=lambda:(w.destroy(),self.lottery())).pack(pady=8)
  for title,fn in [('Lotto Sale — select game code',choose_game),('Lotto Payout — 40',lambda:enter('LOTTO PAYOUT',-1,'40','Lotto Payout')),('Scratch-It Sale — 30',lambda:enter('SCRATCH SALE',1,'30','Scratch-It Sale')),('Scratch-It Payout — 41',lambda:enter('SCRATCH PAYOUT',-1,'41','Scratch-It Payout'))]:
   tk.Button(w,text=title,command=fn,font=('Segoe UI',12,'bold'),height=2).pack(fill='x',padx=22,pady=8)
  tk.Label(w,text='MANUAL TEST ONLY — no The Lott validation or payment integration',fg='#9b3229',bg='#f2f5f8',wraplength=450).pack(pady=15)
 def staff_management(self):
  if self.staff_id is None:
   if not self.pin_dialog():return
  role=self.db.execute('SELECT role FROM staff WHERE id=?',(self.staff_id,)).fetchone()['role']
  if role not in ('OWNER','MANAGER'):return self.warn('Manager or Owner access required')
  w=tk.Toplevel(self.root);w.title('STAFF MANAGEMENT — TEST');w.geometry('690x470')
  t=ttk.Treeview(w,columns=('ID','Name','Role','Active'),show='headings');t.pack(fill='both',expand=True,padx=12,pady=12)
  for col in ('ID','Name','Role','Active'):t.heading(col,text=col)
  def refresh():
   t.delete(*t.get_children())
   for r in self.db.execute('SELECT id,name,role,active FROM staff ORDER BY id'):t.insert('','end',iid=str(r['id']),values=(r['id'],r['name'],r['role'],'Yes' if r['active'] else 'No'))
  def add():
   form=tk.Toplevel(w);form.title('NEW STAFF — COMPLETE FORM');form.geometry('540x385');form.transient(w);form.grab_set()
   panel=ttk.Frame(form,padding=20);panel.pack(fill='both',expand=True)
   ttk.Label(panel,text='New Staff Member',font=('Segoe UI',17,'bold')).grid(row=0,column=0,columnspan=2,sticky='w',pady=(0,14))
   name=tk.StringVar();pin=tk.StringVar();role=tk.StringVar(value='CASHIER')
   for index,(label,var) in enumerate([('Staff name',name),('Unique 2-digit PIN',pin)],1):
    ttk.Label(panel,text=label).grid(row=index,column=0,sticky='w',pady=9)
    ttk.Entry(panel,textvariable=var,show='*' if index==2 else '').grid(row=index,column=1,sticky='ew',pady=9)
   ttk.Label(panel,text='Access level').grid(row=3,column=0,sticky='w',pady=9)
   ttk.Combobox(panel,textvariable=role,values=('CASHIER','SUPERVISOR','MANAGER','OWNER'),state='readonly').grid(row=3,column=1,sticky='ew',pady=9)
   error=tk.StringVar();ttk.Label(panel,textvariable=error,foreground='#b42318',wraplength=470).grid(row=4,column=0,columnspan=2,sticky='w',pady=8)
   def save_staff():
    n=name.get().strip();code=pin.get()
    if not n or len(code)!=2 or not code.isdigit():error.set('Enter a staff name and exactly two PIN digits.');return
    for r in self.db.execute('SELECT salt,pin_hash FROM staff WHERE active=1'):
     if hmac.compare_digest(pin_hash(code,r['salt']),r['pin_hash']):error.set('This PIN is already assigned to an active employee.');return
    salt=secrets.token_hex(16)
    with self.db:self.db.execute('INSERT INTO staff(name,role,salt,pin_hash) VALUES(?,?,?,?)',(n,role.get(),salt,pin_hash(code,salt)))
    self.audit('STAFF_CREATED',n+' '+role.get());refresh();form.destroy()
   buttons=ttk.Frame(panel);buttons.grid(row=5,column=0,columnspan=2,sticky='e',pady=15)
   ttk.Button(buttons,text='CANCEL',command=form.destroy).pack(side='right',padx=5)
   ttk.Button(buttons,text='SAVE STAFF',command=save_staff).pack(side='right',padx=5)
   panel.columnconfigure(1,weight=1)
  def disable():
   if not t.selection():return
   sid=int(t.selection()[0]);r=self.db.execute('SELECT role FROM staff WHERE id=?',(sid,)).fetchone()
   if sid==self.staff_id:return messagebox.showerror('Staff','Cannot disable your own current account',parent=w)
   if r['role']=='OWNER' and self.db.execute("SELECT COUNT(*) FROM staff WHERE role='OWNER' AND active=1").fetchone()[0]<=1:return messagebox.showerror('Staff','Cannot disable the last active owner',parent=w)
   with self.db:self.db.execute('UPDATE staff SET active=0 WHERE id=?',(sid,))
   self.audit('STAFF_DISABLED',str(sid));refresh()
  bar=tk.Frame(w);bar.pack(pady=10)
  tk.Button(bar,text='ADD STAFF',command=add).pack(side='left',padx=7)
  tk.Button(bar,text='DISABLE SELECTED',command=disable).pack(side='left',padx=7)
  refresh()
 def management(self):
  old_management(self)
  self.btn(self.root,'STAFF MANAGEMENT',self.staff_management,size=11,height=1).pack(pady=5)
  self.btn(self.root,'STAFF ACTIVITY',self.staff_activity,size=11,height=1).pack(pady=5)
 def staff_activity(self):
  if self.staff_id is None:
   if not self.pin_dialog():return
  role=self.db.execute('SELECT role FROM staff WHERE id=?',(self.staff_id,)).fetchone()['role']
  if role not in ('OWNER','MANAGER'):return self.warn('Manager or Owner access required')
  w=tk.Toplevel(self.root);w.title('Staff Activity');w.geometry('950x500')
  t=ttk.Treeview(w,columns=('Date','Staff','Action','Detail'),show='headings');t.pack(fill='both',expand=True)
  for c in ('Date','Staff','Action','Detail'):t.heading(c,text=c)
  for r in self.db.execute('SELECT e.created,COALESCE(s.name,\'Unknown\') name,e.action,e.detail FROM staff_events e LEFT JOIN staff s ON s.id=e.staff_id ORDER BY e.id DESC LIMIT 2000'):t.insert('','end',values=(r['created'],r['name'],r['action'],r['detail']))
 app_class.__init__=init;app_class.audit=audit;app_class.pin_dialog=pin_dialog;app_class.pos=pos;app_class.checkout=checkout;app_class.lottery=lottery;app_class.staff_management=staff_management;app_class.management=management;app_class.staff_activity=staff_activity
