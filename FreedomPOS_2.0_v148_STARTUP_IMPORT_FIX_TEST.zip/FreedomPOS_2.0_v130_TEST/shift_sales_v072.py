"""Shift sales reporting (TEST): derived from committed sales and line items."""
import tkinter as tk
from tkinter import ttk,messagebox,filedialog
import csv
from datetime import datetime

def install(cls):
    old_sales=cls.sales
    old_settings=cls.settings
    def setup(self):
        self.db.execute("CREATE TABLE IF NOT EXISTS shift_eos(id INTEGER PRIMARY KEY, closed_at TEXT NOT NULL, last_sale_id INTEGER NOT NULL, note TEXT DEFAULT '')")
        self.db.commit()
    def gather(self,period):
        setup(self)
        last=self.db.execute('SELECT last_sale_id,closed_at FROM shift_eos ORDER BY id DESC LIMIT 1').fetchone()
        if period=='Shift':
            where='s.id > ?';args=(last['last_sale_id'] if last else 0,)
        elif period=='Today':
            where='substr(s.created,1,10)=?';args=(datetime.now().strftime('%Y-%m-%d'),)
        else:
            prev=self.db.execute('SELECT last_sale_id FROM shift_eos ORDER BY id DESC LIMIT 1 OFFSET 1').fetchone()
            if not last:return [],0,0
            where='s.id > ? AND s.id <= ?';args=(prev['last_sale_id'] if prev else 0,last['last_sale_id'])
        query="""SELECT s.id AS sale_id,s.total AS sale_total,s.discount AS sale_discount,s.created,
            l.product_id,l.description,l.kind,l.qty,l.unit,COALESCE(l.line_discount,0) AS line_discount,
            p.category AS product_category, p.department_id AS product_department,
            dm.name AS department_name
            FROM sales s JOIN lines l ON l.sale_id=s.id
            LEFT JOIN products p ON p.id=l.product_id
            LEFT JOIN departments_master dm ON dm.id=p.department_id
            WHERE s.voided=0 AND """+where+' ORDER BY s.id,l.id'
        try:rows=self.db.execute(query,args).fetchall()
        except Exception:
            query=query.replace('p.department_id AS product_department,','NULL AS product_department,').replace('dm.name AS department_name','NULL AS department_name').replace('LEFT JOIN departments_master dm ON dm.id=p.department_id','')
            rows=self.db.execute(query,args).fetchall()
        totals={};ids={};all_ids=set();sale_totals={};sale_discounts={}
        for r in rows:
            sid=r['sale_id'];all_ids.add(sid);sale_totals[sid]=r['sale_total'];sale_discounts[sid]=r['sale_discount']
            kind=str(r['kind'] or '').upper();description=str(r['description'] or '')
            if kind=='DEPARTMENT SALE':dept=description
            elif 'PAYOUT' in kind:dept='LOTTO PAYOUTS' if 'LOTTO' in kind else 'INSTANT PAYOUTS'
            elif 'LOTTO' in kind:dept='LOTTO'
            elif 'SCRATCH' in kind:dept='INSTANTS'
            else:dept=r['department_name'] or r['product_category'] or 'Unassigned'
            amount=r['qty']*r['unit']-r['line_discount']
            totals[dept]=totals.get(dept,0)+amount
            ids.setdefault(dept,set()).add(sid)
        return [(k,v,len(ids[k])) for k,v in sorted(totals.items())],sum(sale_totals.values()),len(all_ids)
    def payment_breakdown(self, period):
        setup(self)
        last=self.db.execute('SELECT last_sale_id,closed_at FROM shift_eos ORDER BY id DESC LIMIT 1').fetchone()
        if period=='Shift':
            sale_where='s.id > ?';sale_args=(last['last_sale_id'] if last else 0,)
            payment_where='p.created > ?';payment_args=(last['closed_at'] if last else '0000-01-01',)
        elif period=='Today':
            day=datetime.now().strftime('%Y-%m-%d')
            sale_where='substr(s.created,1,10)=?';sale_args=(day,)
            payment_where='substr(p.created,1,10)=?';payment_args=(day,)
        else:
            prev=self.db.execute('SELECT last_sale_id,closed_at FROM shift_eos ORDER BY id DESC LIMIT 1 OFFSET 1').fetchone()
            if not last:return [],0,0,0
            sale_where='s.id > ? AND s.id <= ?';sale_args=(prev['last_sale_id'] if prev else 0,last['last_sale_id'])
            payment_where='p.created > ? AND p.created <= ?';payment_args=(prev['closed_at'] if prev else '0000-01-01',last['closed_at'])
        # Only payments linked to non-voided sales count as sale tenders.
        sale_payments=self.db.execute('''SELECT UPPER(TRIM(p.method)) method, SUM(p.amount) amount,
            COUNT(DISTINCT p.sale_id) receipts FROM payments p JOIN sales s ON s.id=p.sale_id
            WHERE s.voided=0 AND '''+sale_where+''' GROUP BY UPPER(TRIM(p.method))''',sale_args).fetchall()
        # Account sales have no tender payment at sale time. They represent receivables.
        account_sales=self.db.execute('''SELECT COALESCE(SUM(s.total),0) FROM sales s
            WHERE s.voided=0 AND UPPER(TRIM(s.payment))='ACCOUNT' AND '''+sale_where,sale_args).fetchone()[0]
        # Account collections are money received, but NOT new sales revenue.
        collections=self.db.execute('''SELECT UPPER(TRIM(p.method)) method, SUM(p.amount) amount,
            COUNT(*) receipts FROM payments p WHERE p.sale_id IS NULL
            AND p.customer_id IS NOT NULL AND '''+payment_where+''' GROUP BY UPPER(TRIM(p.method))''',payment_args).fetchall()
        data={}
        def add(name,amount,count):
            current=data.setdefault(name,[0,0]);current[0]+=int(amount or 0);current[1]+=int(count or 0)
        for r in sale_payments:
            method=r['method'] or 'OTHER'
            label='CASH' if method=='CASH' else 'CARD / EFTPOS' if 'EFTPOS' in method or 'CARD' in method else method
            add(label,r['amount'],r['receipts'])
        if account_sales:add('ON ACCOUNT (UNPAID)',account_sales,0)
        for r in collections:
            method=r['method'] or 'OTHER'
            label='ACCOUNT COLLECTION — CASH' if method=='CASH' else 'ACCOUNT COLLECTION — CARD' if ('CARD' in method or 'EFTPOS' in method) else 'ACCOUNT COLLECTION — '+method
            add(label,r['amount'],r['receipts'])
        cash=sum(v[0] for k,v in data.items() if k=='CASH' or k=='ACCOUNT COLLECTION — CASH')
        card=sum(v[0] for k,v in data.items() if k=='CARD / EFTPOS' or k=='ACCOUNT COLLECTION — CARD')
        return [(k,*v) for k,v in sorted(data.items())],cash,card,int(account_sales or 0)
    def show(self):
        setup(self)
        existing=getattr(self,'_shift_dashboard_window',None)
        if existing is not None and existing.winfo_exists():
            existing.deiconify();existing.lift();existing.focus_force();return
        w=tk.Toplevel(self.root);self._shift_dashboard_window=w
        w.title('Shift Sales Dashboard — TEST');w.geometry('1040x730');w.minsize(760,500)
        main=ttk.Frame(w,padding=12);main.pack(fill='both',expand=True)
        ttk.Label(main,text='SHIFT SALES DASHBOARD',font=('Segoe UI',17,'bold')).pack(anchor='w')
        controls=ttk.Frame(main);controls.pack(fill='x',pady=8)
        period=tk.StringVar(value='Shift');ttk.Label(controls,text='View:').pack(side='left',padx=(0,6))
        ttk.Combobox(controls,textvariable=period,values=['Shift','Today','Previous Shift'],state='readonly',width=18).pack(side='left')
        summary=ttk.Label(main,text='',font=('Segoe UI',11,'bold'));summary.pack(anchor='w',pady=8)
        tabs=ttk.Notebook(main);tabs.pack(fill='both',expand=True)
        dept_frame=ttk.Frame(tabs);pay_frame=ttk.Frame(tabs)
        tabs.add(dept_frame,text='Department Sales');tabs.add(pay_frame,text='Payments / Cash / Card / Account')
        def table(frame,columns):
            tr=ttk.Treeview(frame,columns=[c[0] for c in columns],show='headings',selectmode='browse')
            for key,label,width,anchor in columns:
                tr.heading(key,text=label);tr.column(key,width=width,anchor=anchor)
            sb=ttk.Scrollbar(frame,orient='vertical',command=tr.yview);tr.configure(yscrollcommand=sb.set)
            tr.pack(side='left',fill='both',expand=True);sb.pack(side='right',fill='y');return tr
        dept_tree=table(dept_frame,[('department','Department / Dissection',400,'w'),('amount','Total (AUD)',160,'e'),('count','Transactions',140,'e')])
        pay_tree=table(pay_frame,[('method','Payment / Account Type',420,'w'),('amount','Amount (AUD)',180,'e'),('count','Receipts / Payments',150,'e')])
        pay_summary=ttk.Label(main,text='',font=('Segoe UI',11,'bold'));pay_summary.pack(anchor='w',pady=(8,0))
        footer=ttk.Frame(main);footer.pack(fill='x',pady=(10,0))
        cache={'departments':[],'payments':[]}
        def refresh():
            for tr in (dept_tree,pay_tree):
                for i in tr.get_children():tr.delete(i)
            rows,total,count=gather(self,period.get());cache['departments']=rows
            for name,amount,n in rows:dept_tree.insert('','end',values=(name,f'{amount/100:,.2f}',n))
            pays,cash,card,account=payment_breakdown(self,period.get());cache['payments']=pays
            for name,amount,n in pays:pay_tree.insert('','end',values=(name,f'{amount/100:,.2f}',n))
            last=self.db.execute('SELECT closed_at FROM shift_eos ORDER BY id DESC LIMIT 1').fetchone()
            anchor=last['closed_at'] if last else 'No EOS recorded — all recorded sales'
            summary.configure(text=f'{period.get()}  |  Net sales: ${total/100:,.2f}  |  Transactions: {count}  |  Last EOS: {anchor}')
            pay_summary.configure(text=f'Cash received: ${cash/100:,.2f}    Card received: ${card/100:,.2f}    Charged to account: ${account/100:,.2f}')
        def export():
            path=filedialog.asksaveasfilename(parent=w,defaultextension='.csv',filetypes=[('CSV','*.csv')],initialfile='Shift_Sales_Report.csv')
            if not path:return
            with open(path,'w',newline='',encoding='utf-8-sig') as f:
                writer=csv.writer(f);writer.writerow(['Period','Section','Name','Amount AUD','Transactions'])
                for name,amount,n in cache['departments']:writer.writerow([period.get(),'Department',name,f'{amount/100:.2f}',n])
                for name,amount,n in cache['payments']:writer.writerow([period.get(),'Payment',name,f'{amount/100:.2f}',n])
            messagebox.showinfo('Export complete','CSV exported.',parent=w)
        def end_shift():
            if not messagebox.askyesno('End of Shift','Close this shift now? Future shift reports will begin after the last completed sale. This does not settle cash or process EFTPOS.',parent=w):return
            last_id=self.db.execute('SELECT COALESCE(MAX(id),0) FROM sales').fetchone()[0]
            with self.db:self.db.execute("INSERT INTO shift_eos(closed_at,last_sale_id,note) VALUES(datetime('now','localtime'),?,'Manual dashboard EOS')",(last_id,))
            refresh()
        period.trace_add('write',lambda *_:refresh())
        ttk.Button(footer,text='Refresh',command=refresh).pack(side='left',padx=4)
        ttk.Button(footer,text='Export CSV',command=export).pack(side='left',padx=4)
        ttk.Button(footer,text='End of Shift',command=end_shift).pack(side='left',padx=4)
        ttk.Button(footer,text='Close',command=w.destroy).pack(side='right',padx=4)
        ttk.Label(main,text='TEST ONLY. Account charges are unpaid receivables, not cash/card received. Account collections are shown separately and are not new sales. Department totals exclude order-level discounts.',wraplength=950,foreground='#765b22').pack(anchor='w',pady=(8,0))
        w.bind('<Escape>',lambda e:w.destroy())
        refresh()
    def sales(self):
        old_sales(self)
        ttk.Button(self.root,text='SHIFT SALES DASHBOARD',command=lambda:show(self)).pack(pady=5)
    def settings(self):
        old_layout=self.layout
        def wrapped(title,items):
            if title=='SETTINGS & TOOLS':items=list(items)+[('Shift Sales Dashboard',lambda:show(self))]
            return old_layout(title,items)
        self.layout=wrapped
        try:return old_settings(self)
        finally:self.layout=old_layout
    old_init=cls.__init__
    def init(self,*args,**kwargs):
        old_init(self,*args,**kwargs)
        def dashboard_hotkey(event):
            show(self)
            return 'break'
        # Bind on the scanner input first (before its Entry class binding), and
        # on the application tag for buttons/other focused widgets.
        self.root.bind_all('<Control-d>',dashboard_hotkey,add='+')
        self.root.bind_all('<Control-D>',dashboard_hotkey,add='+')
        if hasattr(self,'code'):
            self.code.bind('<Control-d>',dashboard_hotkey,add='+')
            self.code.bind('<Control-D>',dashboard_hotkey,add='+')
    cls.__init__=init
    cls.shift_sales_dashboard=show
    cls.sales=sales
    cls.settings=settings
