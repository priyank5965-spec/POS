Freedom POS 2.0 v0.79 — e-pay Component Connection Diagnostic (TEST ONLY)

Open Register > E-PAY > Test e-pay Components (Read Only).
Browse to the folder containing epayREST.dll / epayXML.dll / EPAPICOM.dll and click Inspect Components.
Save Report and share it after reviewing for personal paths.

This check does NOT load DLLs, activate COM, contact e-pay, install services, process vouchers or alter POS Browser.
The diagnostic reports DLL bitness, managed/native status, file presence and existing COM ProgID names.
These checks DO NOT confirm connectivity. Live e-pay sales, cancellations and printing remain DISABLED.
Do not install or register unverified components. Keep current POS Browser unchanged.
All other v0.78 features remain included. Windows GUI interaction remains untested in this environment.
