"""Test register PIN gate. Two-digit PINs are not production-grade authentication."""
import tkinter as tk
from tkinter import messagebox
import hashlib, hmac, os, re

def _hash(pin,salt):
    return hashlib.pbkdf2_hmac('sha256',pin.encode(),bytes.fromhex(salt),180000).hex()

def install(cls):
    old_pos=cls.pos
    old_checkout=cls.checkout
    old_home=cls.home
    def setup(self):
        # Staff are managed in Management > Staff, not a second register_staff table.
        self.db.execute('SELECT id FROM staff LIMIT 1').fetchone()
    def gate(self):
        existing=getattr(self,'_pin_window',None)
        if existing is not None and existing.winfo_exists():
            existing.lift();return
        setup(self)
        w=tk.Toplevel(self.root);self._pin_window=w
        w.title('Staff Login — Management PIN')
        # The original fixed-height dialog clipped the 0, OK and CLEAR keys on Windows.
        # Keep every control visible at normal Windows display scaling.
        ww,hh=440,590
        sw,sh=w.winfo_screenwidth(),w.winfo_screenheight()
        ww=min(ww,max(340,sw-50));hh=min(hh,max(420,sh-90))
        w.geometry(f'{ww}x{hh}+{max(0,(sw-ww)//2)}+{max(0,(sh-hh)//2)}')
        w.minsize(340,420);w.resizable(True,True)
        w.transient(self.root);w.grab_set();w.protocol('WM_DELETE_WINDOW',lambda:None)
        frame=tk.Frame(w,bg='#e8f0f4',padx=22,pady=15);frame.pack(fill='both',expand=True)
        tk.Label(frame,text='STAFF PIN',font=('Segoe UI',18,'bold'),bg='#e8f0f4',fg='#111111').pack(pady=(0,8))
        tk.Label(frame,text='Use your PIN from Management > Staff',bg='#e8f0f4',fg='#a03932').pack()
        pin=tk.StringVar()
        tk.Label(frame,text='Enter 2-digit PIN',bg='#e8f0f4').pack(pady=(12,3))
        entry=tk.Entry(frame,textvariable=pin,show='●',font=('Segoe UI',24),justify='center',width=8)
        entry.pack()
        error=tk.Label(frame,text='',bg='#e8f0f4',fg='#ac2020');error.pack(pady=5)
        def submit(event=None):
            value=pin.get()
            if not re.fullmatch(r'\d{2}',value):error.config(text='Enter exactly 2 digits');pin.set('');return
            staff=None
            for row in self.db.execute('SELECT * FROM staff WHERE active=1'):
                if hmac.compare_digest(row['pin_hash'],_hash(value,row['salt'])):staff=row;break
            if not staff:error.config(text='Incorrect PIN');pin.set('');return
            self._active_cashier=(staff['id'],staff['name'])
            self.staff_id=staff['id'];self.staff_name=staff['name']
            self.db.execute('INSERT INTO events(created,category,description) VALUES(datetime("now"),?,?)',('REGISTER LOGIN',f"Cashier #{staff['id']} {staff['name']}"));self.db.commit()
            w.grab_release();w.destroy();self._pin_window=None
            if hasattr(self,'code') and self.code.winfo_exists():self.code.focus_set()
        keypad=tk.Frame(frame,bg='#e8f0f4');keypad.pack(pady=8)
        for i,digit in enumerate('123456789'):
            tk.Button(keypad,text=digit,font=('Segoe UI',14,'bold'),width=5,height=1,command=lambda x=digit:pin.set((pin.get()+x)[:2])).grid(row=i//3,column=i%3,padx=3,pady=3)
        tk.Button(keypad,text='CLEAR',command=lambda:pin.set(''),width=5).grid(row=3,column=0,padx=3)
        tk.Button(keypad,text='0',font=('Segoe UI',14,'bold'),command=lambda:pin.set((pin.get()+'0')[:2]),width=5).grid(row=3,column=1,padx=3)
        tk.Button(keypad,text='OK',command=submit,width=5,bg='#c9ead3').grid(row=3,column=2,padx=3)
        entry.bind('<Return>',submit)
        tk.Button(frame,text='LAST RECEIPT',command=self.last_receipt,bg='white').pack(fill='x',pady=3)
        entry.focus_set()
    def pos(self):
        self._active_cashier=None
        self._pos_entering=True
        try:old_pos(self)
        finally:self._pos_entering=False
        self.root.after_idle(lambda:gate(self))
    def checkout(self,method,split=None):
        if not getattr(self,'_active_cashier',None):
            gate(self);return
        before=self.db.execute('SELECT COALESCE(MAX(id),0) FROM sales').fetchone()[0]
        self._checkout_processing=True
        try:result=old_checkout(self,method,split)
        finally:self._checkout_processing=False
        new=self.db.execute('SELECT COALESCE(MAX(id),0) FROM sales').fetchone()[0]
        if new>before:
            cashier=self._active_cashier
            with self.db:self.db.execute('INSERT INTO events(created,category,description) VALUES(datetime("now"),?,?)',('CASHIER SALE',f'Sale #{new} staff #{cashier[0]} {cashier[1]}'))
            self._active_cashier=None
            self.staff_id=None;self.staff_name=None
            self.root.after_idle(lambda:gate(self))
        return result
    def home(self):
        self._active_cashier=None
        return old_home(self)
    def legacy_pin_dialog(self):
        # The older operations module called its own separate PIN dialog.
        # Suppress it only while entering the register or finishing checkout.
        if getattr(self,'_pos_entering',False) or getattr(self,'_checkout_processing',False):return True
        gate(self)
        return False
    cls.pin_dialog=legacy_pin_dialog
    cls.pos=pos;cls.checkout=checkout;cls.home=home
