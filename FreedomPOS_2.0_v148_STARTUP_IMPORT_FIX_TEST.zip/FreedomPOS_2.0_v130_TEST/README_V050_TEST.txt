Freedom POS 2.0 v0.50 TEST ONLY
Fixed 4-column button sizes; button images auto-fit; Apply and Save pinned at bottom; thin unobtrusive resizable divider without grip/handle. Existing register operations retained.
Run START_FREEDOM_POS.bat. Keep prior backup and test with test data.
