Freedom POS 2.0 v0.85 TEST ONLY
Fix: Split Tender now reads self.total() directly as cents, preventing a 100x inflated amount. Example: grid $24.32 -> split tender $24.32.
No changes to live payment processing. Windows GUI interaction remains to be tested.
