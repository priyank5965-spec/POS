"""Supplier-specific CSV/XLSX mapping engine. Offline TEST ONLY."""
import csv,json,re,sqlite3
from pathlib import Path
from decimal import Decimal,InvalidOperation,ROUND_HALF_UP

FIELDS=('supplier_code','barcode','description','qty','cost','amount_ex','gst_amount','gst_rate','discount','rrp')
ALIASES={
 'supplier_code':('stockcode','suppliercode','itemcode','productcode','sku'),
 'barcode':('barcode','ean','gtin','upc'),
 'description':('description','productdescription','itemname','productname'),
 'qty':('qty','quantity','suppliedqty','quantitysupplied'),
 'cost':('priceexgst','unitcost','wholesaleprice','costexgst','price'),
 'amount_ex':('amountexgst','lineamount','lineexgst','totalexgst','netamount'),
 'gst_amount':('gst','gstamount','taxamount'),
 'gst_rate':('gstrate','gstpercent','taxrate'),
 'discount':('discount','disc','discountpercent'),
 'rrp':('rrp','recommendedretailprice','retailprice'),
}
def norm(x):return ''.join(c for c in str(x).casefold() if c.isalnum())
def decimal(v):
 s=str(v or '').replace('$','').replace(',','').replace('%','').strip()
 if not s:return Decimal('0')
 try:
  d=Decimal(s)
  if not d.is_finite():raise ValueError()
  return d
 except (InvalidOperation,ValueError):raise ValueError('Invalid numeric value: '+repr(v))
def cents(v):return int((decimal(v)*100).quantize(Decimal('1'),rounding=ROUND_HALF_UP))
def ensure(db):
 db.execute('CREATE TABLE IF NOT EXISTS receiving_import_templates(supplier TEXT PRIMARY KEY,format TEXT NOT NULL,header_row INTEGER NOT NULL,mapping TEXT NOT NULL,updated TEXT DEFAULT CURRENT_TIMESTAMP)')
 db.commit()
def read_matrix(path):
 path=Path(path);suffix=path.suffix.lower()
 if suffix=='.xlsx':
  try:import openpyxl
  except ImportError:raise ValueError('Excel import requires openpyxl. Run: pip install openpyxl')
  # Non-read-only mode is intentional: some supplier workbooks incorrectly claim dimension A1.
  wb=openpyxl.load_workbook(path,data_only=True,read_only=False)
  try:return [[str(v).strip() if v is not None else '' for v in row] for row in wb.active.values]
  finally:wb.close()
 if suffix=='.csv':
  for encoding in ('utf-8-sig','cp1252'):
   try:
    with path.open(encoding=encoding,newline='') as f:
     sample=f.read(8192);f.seek(0)
     try:dialect=csv.Sniffer().sniff(sample,delimiters=',;\t|')
     except csv.Error:dialect=csv.excel
     return [[v.strip() for v in row] for row in csv.reader(f,dialect)]
   except UnicodeDecodeError:continue
  raise ValueError('Could not decode CSV')
 raise ValueError('Use a CSV or XLSX file for this template importer.')
def suggest(rows):
 best=(-1,0,{})
 for i,row in enumerate(rows[:40]):
  mapping={}
  for field,aliases in ALIASES.items():
   for j,val in enumerate(row):
    if norm(val) in aliases:mapping[field]=j;break
  score=len(mapping)
  if score>best[0]:best=(score,i,mapping)
 return best[1],best[2]
def invoice_number(rows):
 for row in rows[:12]:
  for i,v in enumerate(row[:-1]):
   if norm(v) in ('invoiceno','invoicenumber','taxinvoiceno','invoicenum') and row[i+1]:return row[i+1]
 return ''
def parse(rows,header_row,mapping,supplier='',number=''):
 if not {'qty','description','cost'}.issubset(mapping) and not {'qty','description','amount_ex'}.issubset(mapping):
  raise ValueError('Map Description, Qty and either Unit Cost or Line Amount.')
 lines=[];warnings=[];charges=[]
 def get(row,key):
  col=mapping.get(key)
  return row[col].strip() if isinstance(col,int) and col<len(row) else ''
 for index,row in enumerate(rows[header_row+1:],header_row+2):
  desc=get(row,'description');code=get(row,'supplier_code');barcode=get(row,'barcode');raw_qty=get(row,'qty')
  if not (desc or code or barcode):continue
  # Numeric-only summary rows (e.g. subtotal/GST/total values) are not products.
  if not barcode and code and desc:
   try:
    decimal(code);decimal(desc);decimal(raw_qty)
    continue
   except ValueError:pass
  if not raw_qty:continue
  if norm(desc) in ('total','subtotal','gst','tax','grandtotal','invoicetotal','totalincgst','totals') or norm(code) in ('total','subtotal','gst','tax','grandtotal','invoicetotal','totalincgst','totals'):continue
  # Summary lines in supplier spreadsheets often contain amounts but no quantity.
  if any(norm(str(v)) in ('subtotal','grandtotal','invoicetotal','totalincgst') for v in row):continue
  try:
   q=decimal(raw_qty)
   if q!=q.to_integral_value():raise ValueError('Fractional qty')
   qty=int(q)
  except (ValueError,InvalidOperation):
   # Invoice footers (totals, GST, payment terms) must not become products.
   if not barcode and not code and any(t in norm(desc) for t in ('total','gst','balance','amountdue','freight','invoice')):continue
   warnings.append(f'Row {index}: invalid quantity');continue
  if qty==0:continue
  if qty<0:raise ValueError(f'Row {index}: negative quantity; import as supplier return, not stock arrival.')
  if norm(desc) in ('freight','delivery','surcharge','handling','postage') or norm(code) in ('freight','delivery','surcharge','handling','postage'):
   charges.append({'row':index,'description':desc,'amount':get(row,'amount_ex')});continue
  if not desc: warnings.append(f'Row {index}: missing description')
  amount_raw=get(row,'amount_ex');cost_raw=get(row,'cost');discount_raw=get(row,'discount')
  try:
   amount=cents(amount_raw) if amount_raw else None
   unit=cents(cost_raw) if cost_raw else None
   if amount is not None:
    # Invoice extended amount is authoritative: already reflects discounts.
    effective=int((Decimal(amount)/qty).quantize(Decimal('1'),rounding=ROUND_HALF_UP))
    if effective*qty!=amount:warnings.append(f'Row {index}: line amount rounding differs by {amount-effective*qty} cents')
   elif unit is not None:
    disc=decimal(discount_raw)
    effective=int((Decimal(unit)*(100-disc)/100).quantize(Decimal('1'),rounding=ROUND_HALF_UP))
   else:effective=0;warnings.append(f'Row {index}: missing wholesale price')
   gst_raw=get(row,'gst_rate');tax_raw=get(row,'gst_amount')
   gst=int(decimal(gst_raw)) if gst_raw else (int((decimal(tax_raw)*100/decimal(amount_raw)).quantize(Decimal('1'))) if tax_raw and amount_raw and decimal(amount_raw)>0 else 10)
   if gst not in (0,10):warnings.append(f'Row {index}: GST {gst}% requires review')
   rrp=cents(get(row,'rrp')) if get(row,'rrp') else 0
  except (ValueError,InvalidOperation,ZeroDivisionError) as e:raise ValueError(f'Row {index}: {e}')
  lines.append(dict(barcode=barcode,supplier_code=code,description=desc,qty=qty,cost=effective,gst=gst,needs_cost=not bool(cost_raw or amount_raw),rrp=rrp,source_row=index,discount_note=discount_raw))
 if not lines:raise ValueError('No product rows found. Check header row and column mappings.')
 supplier_total=''
 for i,row in enumerate(rows):
  if i+1>=len(rows):break
  for j,value in enumerate(row):
   if norm(value) in ('totalincgst','invoicetotal','grandtotal') and j<len(rows[i+1]):
    candidate=rows[i+1][j]
    try:supplier_total=str(decimal(candidate))
    except ValueError:pass
   if norm(value)=='total' and j<len(rows[i+1]) and not supplier_total:
    try:supplier_total=str(decimal(rows[i+1][j]))
    except ValueError:pass
 return dict(supplier=supplier,number=number or invoice_number(rows),invoice_date='',supplier_total=supplier_total,lines=lines,warnings=warnings,charges=charges)
