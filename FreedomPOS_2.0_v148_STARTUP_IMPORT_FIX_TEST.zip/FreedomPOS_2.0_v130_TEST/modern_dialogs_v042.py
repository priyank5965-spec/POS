"""Consistent, touchscreen-friendly Tk message dialogs. TEST ONLY."""
import tkinter as tk
from tkinter import messagebox

NAVY='#12324A'; TEAL='#51BDCB'; BG='#F3F7FA'; WHITE='#FFFFFF'
ORIGINAL={name:getattr(messagebox,name) for name in ('showinfo','showwarning','showerror','askyesno','askokcancel','askretrycancel','askyesnocancel','askquestion')}

def _dialog(kind,title,message,parent=None,detail=None,default=None,**kwargs):
    host=parent
    try:
        if host is None or not host.winfo_exists():host=tk._default_root
        if host is None or not host.winfo_exists():return ORIGINAL[kind](title,message,parent=parent,detail=detail,default=default,**kwargs)
        win=tk.Toplevel(host)
        win.withdraw();win.title(str(title or 'Freedom POS 2.0'))
        win.configure(bg=BG);win.resizable(False,False)
        win.transient(host)
        result={'value':None}
        if kind in ('askyesno','askquestion'): choices=[('NO',False),('YES',True)]
        elif kind=='askyesnocancel':choices=[('CANCEL',None),('NO',False),('YES',True)]
        elif kind=='askokcancel':choices=[('CANCEL',False),('OK',True)]
        elif kind=='askretrycancel':choices=[('CANCEL',False),('RETRY',True)]
        else:choices=[('OK','ok')]
        fallback=None if kind=='askyesnocancel' else (False if kind.startswith('ask') else 'ok')
        def finish(value):
            result['value']=value
            try:win.grab_release()
            except tk.TclError:pass
            win.destroy()
        win.protocol('WM_DELETE_WINDOW',lambda:finish(fallback))
        header=tk.Frame(win,bg=NAVY,height=64);header.pack(fill='x');header.pack_propagate(False)
        tk.Label(header,text=str(title or 'Freedom POS 2.0'),font=('Segoe UI',17,'bold'),bg=NAVY,fg=WHITE,anchor='w').pack(side='left',padx=22,fill='y')
        body=tk.Frame(win,bg=WHITE,padx=22,pady=20);body.pack(fill='both',expand=True)
        symbol='!' if kind in ('showwarning','showerror') else ('?' if kind.startswith('ask') else 'i')
        colour='#C65B24' if kind=='showwarning' else ('#BD3840' if kind=='showerror' else TEAL)
        icon=tk.Label(body,text=symbol,font=('Segoe UI',19,'bold'),bg=colour,fg=WHITE,width=3,height=2)
        icon.pack(side='left',anchor='n',padx=(0,18))
        content=tk.Frame(body,bg=WHITE);content.pack(side='left',fill='both',expand=True)
        tk.Label(content,text=str(message),font=('Segoe UI',12),bg=WHITE,fg='#182B3A',justify='left',anchor='w',wraplength=475).pack(anchor='w',fill='x')
        if detail:tk.Label(content,text=str(detail),font=('Segoe UI',10),bg=WHITE,fg='#526776',justify='left',wraplength=475).pack(anchor='w',pady=(12,0))
        footer=tk.Frame(win,bg=BG,padx=18,pady=15);footer.pack(fill='x')
        for label,value in choices:
            primary=(label in ('YES','OK','RETRY'))
            btn=tk.Button(footer,text=label,command=lambda v=value:finish(v),font=('Segoe UI',11,'bold'),bg=TEAL if primary else WHITE,fg=NAVY,activebackground='#B8E7EA',relief='flat',bd=0,highlightthickness=1,highlightbackground='#B7CBD4',width=12,height=2,cursor='hand2')
            btn.pack(side='right',padx=(9,0))
            if primary:win.bind('<Return>',lambda event,v=value:finish(v))
        win.bind('<Escape>',lambda event:finish(fallback))
        win.update_idletasks()
        width=max(450,min(690,win.winfo_reqwidth()))
        height=max(220,win.winfo_reqheight())
        screen_w=win.winfo_screenwidth();screen_h=win.winfo_screenheight()
        x=max(0,(screen_w-width)//2);y=max(0,(screen_h-height)//2)
        win.geometry(f'{width}x{height}+{x}+{y}')
        win.deiconify();win.lift();win.grab_set();win.focus_force();win.wait_window()
        return result['value']
    except Exception:
        # Fall back to native dialog if themed rendering fails.
        try:return ORIGINAL[kind](title,message,parent=parent,detail=detail,default=default,**kwargs)
        except Exception:raise

def install():
    for name in ORIGINAL:
        setattr(messagebox,name,lambda title=None,message=None,_kind=name,**kw:_dialog(_kind,title,message,**kw))
