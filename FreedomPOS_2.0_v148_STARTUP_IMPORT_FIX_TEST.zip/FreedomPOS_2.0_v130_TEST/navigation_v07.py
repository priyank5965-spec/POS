"""Visible navigation correction for Freedom POS development build."""
def install(cls):
    def management(self):
        self.layout('MANAGEMENT', [
            ('Staff Management',self.staff_management),
            ('Staff Activity',self.staff_activity),
            ('Activity Logs',self.activity_logs_v07),
        ])
    def activity_logs(self):
        self.clear();self.header('MANAGEMENT / ACTIVITY LOGS')
        t=self.tree(self.root,['Date','Category','Action'],[200,170,760])
        for r in self.db.execute('SELECT * FROM events ORDER BY id DESC LIMIT 1000'):
            t.insert('','end',values=(r['created'],r['category'],r['description']))
    def orders(self):
        self.layout('ORDERS & INVOICES', [
            ('Invoice Management',self.customer_email_center),
            ('Customer Invoices / Statements',self.customer_email_center),
            ('Customer Accounts',self.customers),
            ('Customer Putaways',self.putaways),
            ('Previous Sales / Receipts',self.previous),
            ('Supplier Invoices',self.supplier_invoices_v07),
        ])
    def supplier_invoices(self):
        self.info('Supplier Invoices','Supplier invoice approval, accounts payable and reconciliation are not implemented in this test build. No stock or financial posting has occurred.')
    def settings(self):
        self.layout('SETTINGS & TOOLS', [
            ('Email Settings',self.email_settings),
            ('Email History',self.email_history),
            ('Backup & Restore',self.backup),
            ('RustDesk Remote Support',self.rustdesk),
            ('XchangeIT Integration',lambda:self.info('XchangeIT','Integration not connected in this test build.')),
            ('Printers / EFTPOS',lambda:self.info('Hardware','Hardware integration not connected in this test build.')),
            ('Mobile Stocktake APK',lambda:self.info('Mobile Stocktake','Android APK is not built yet.')),
        ])
    cls.management=management
    cls.activity_logs_v07=activity_logs
    cls.orders=orders
    cls.supplier_invoices_v07=supplier_invoices
    cls.settings=settings
