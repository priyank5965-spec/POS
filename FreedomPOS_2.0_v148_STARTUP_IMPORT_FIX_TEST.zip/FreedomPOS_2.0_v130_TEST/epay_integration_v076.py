"""E-PAY integration foundation. Offline setup only; never sends live transactions."""
import json,os,csv,tkinter as tk
from pathlib import Path
from tkinter import ttk,messagebox,filedialog
from register_customizer_v045 import CONFIG
from epay_catalog_v077 import import_file,search,history
SETTINGS=Path(__file__).resolve().parent/'test_data'/'epay_business_v076.json'
FIELDS=('merchant_number','retailer_id','terminal_id','endpoint','username','timeout_ms','department','creditor')
DEFAULT={'merchant_number':'','retailer_id':'','terminal_id':'','endpoint':'','username':'','timeout_ms':'25000','department':'Default Payment Dissection','creditor':'epay - epay'}
def load_settings():
 try:
  obj=json.loads(SETTINGS.read_text(encoding='utf8'))
  if isinstance(obj,dict):return {k:str(obj.get(k,v)) for k,v in DEFAULT.items()}
 except (OSError,ValueError,TypeError):pass
 return dict(DEFAULT)
def save_settings(values):
 data={k:str(values.get(k,'' )).strip() for k in FIELDS}
 try:timeout=int(data['timeout_ms'])
 except ValueError:raise ValueError('Timeout must be a number of milliseconds.')
 if not 1000<=timeout<=120000:raise ValueError('Timeout must be between 1000 and 120000 ms.')
 if data['endpoint'] and not data['endpoint'].startswith('https://'):raise ValueError('Server URL must begin with https://')
 SETTINGS.parent.mkdir(parents=True,exist_ok=True)
 tmp=SETTINGS.with_suffix('.tmp');tmp.write_text(json.dumps(data,indent=2),encoding='utf8');os.replace(tmp,SETTINGS)
 return data

def seed_button():
 """Add one optional E-PAY action to an unused cell, never replace user buttons."""
 try:cfg=json.loads(CONFIG.read_text(encoding='utf8'))
 except (OSError,ValueError):cfg={}
 design=cfg.setdefault('designer_v074',{})
 custom=design.setdefault('custom',[])
 if any(str(x.get('target',''))=='E-PAY' for x in custom):return
 # Respect users who deliberately removed the default button.
 if design.get('epay_seeded'):return
 taken={p for p in design.get('positions',{}).values() if isinstance(p,int)}
 taken.update(x.get('position') for x in custom)
 # Original built-ins occupy their original positions when no saved positions exist.
 if not design.get('positions'):
  taken.update(range(29))
 slot=next((i for i in range(29,40) if i not in taken),None)
 if slot is None:return
 custom.append(dict(type='Action',target='E-PAY',label='E-PAY',position=slot,bg='#dceaf5',fg='#111111'))
 design['epay_seeded']=True
 tmp=CONFIG.with_suffix('.tmp');tmp.write_text(json.dumps(cfg,indent=2),encoding='utf8');os.replace(tmp,CONFIG)

def install(cls):
 old_settings=cls.settings
 old_pos=cls.pos
 def setup(self):
  w=tk.Toplevel(self.root);w.title('e-pay Integration — Business Defaults — OFFLINE TEST');w.geometry('920x690');w.minsize(690,510)
  head=tk.Frame(w,bg='white');head.pack(fill='x');tk.Label(head,text='E-PAY INTEGRATION SETTINGS',font=('Segoe UI',16,'bold'),bg='white',fg='#111111',pady=14).pack(anchor='w',padx=15)
  ttk.Label(w,text='Configuration only — NO LIVE CONNECTION OR VOUCHER ACTIVATION',foreground='#a33421',font=('Segoe UI',10,'bold')).pack(anchor='w',padx=15,pady=9)
  footer=ttk.Frame(w,padding=12);footer.pack(side='bottom',fill='x')
  frame=ttk.Frame(w,padding=14);frame.pack(fill='both',expand=True)
  fields=load_settings();variables={k:tk.StringVar(value=fields[k]) for k in FIELDS}
  labels={'merchant_number':'Merchant number','retailer_id':'Retailer ID (Version 2)','terminal_id':'Terminal ID','endpoint':'Version 2 HTTPS endpoint','username':'Username','timeout_ms':'Timeout (milliseconds)','department':'Sales department / dissection','creditor':'Creditor'}
  for i,key in enumerate(FIELDS):
   ttk.Label(frame,text=labels[key]).grid(row=i,column=0,sticky='w',padx=8,pady=8)
   ttk.Entry(frame,textvariable=variables[key],width=55).grid(row=i,column=1,sticky='ew',padx=8,pady=8)
  frame.columnconfigure(1,weight=1)
  ttk.Label(frame,text='Password: NOT stored here. Live authentication requires a supported secure credential store and official e-pay API specification.',wraplength=720,foreground='#8b4b18').grid(row=len(FIELDS),column=0,columnspan=2,sticky='w',pady=16)
  def save():
   try:save_settings({k:v.get() for k,v in variables.items()})
   except (ValueError,OSError) as e:messagebox.showerror('e-pay Settings',str(e),parent=w);return
   messagebox.showinfo('Saved','Business Defaults saved. Live e-pay integration remains disabled.',parent=w)
  ttk.Button(footer,text='Cancel',command=w.destroy).pack(side='right',padx=5)
  ttk.Button(footer,text='Save Business Defaults',command=save).pack(side='right',padx=5)
 def epay(self):
  existing=getattr(self,'_epay_window',None)
  if existing and existing.winfo_exists():existing.lift();existing.focus_force();return
  w=tk.Toplevel(self.root);self._epay_window=w;w.title('E-PAY — Offline Integration Preview');w.geometry('900x600');w.minsize(660,460)
  top=tk.Frame(w,bg='white');top.pack(fill='x');tk.Label(top,text='E-PAY',bg='white',fg='#111111',font=('Segoe UI',17,'bold'),pady=12).pack(side='left',padx=14)
  ttk.Label(w,text='NOT CONNECTED: No top-ups, voucher issuance, activation, reversal or payment processing.',foreground='#a33421',wraplength=800).pack(anchor='w',padx=14,pady=12)
  tabs=ttk.Notebook(w);tabs.pack(fill='both',expand=True,padx=12,pady=8)
  product_page=ttk.Frame(tabs,padding=10);tabs.add(product_page,text='Products')
  tools=ttk.Frame(product_page);tools.pack(fill='x',pady=(0,8))
  ttk.Label(tools,text='Search product / barcode / group:').pack(side='left',padx=5)
  query=tk.StringVar();searchbox=ttk.Entry(tools,textvariable=query,width=38);searchbox.pack(side='left',padx=5)
  status=tk.StringVar(value='Offline catalogue only. No activation, recharge or voucher sale.')
  ttk.Label(product_page,textvariable=status,foreground='#93471b',wraplength=770).pack(anchor='w',pady=5)
  cols=('code','title','value','category','group','barcode')
  area=ttk.Frame(product_page);area.pack(fill='both',expand=True)
  grid=ttk.Treeview(area,columns=cols,show='headings',selectmode='browse')
  for key,title,width in [('code','Product code',125),('title','Product',260),('value','Face value',85),('category','Category',130),('group','Group',160),('barcode','Barcode',150)]:
   grid.heading(key,text=title);grid.column(key,width=width,stretch=(key in ('title','group')))
  vs=ttk.Scrollbar(area,orient='vertical',command=grid.yview);hs=ttk.Scrollbar(area,orient='horizontal',command=grid.xview)
  grid.configure(yscrollcommand=vs.set,xscrollcommand=hs.set)
  grid.grid(row=0,column=0,sticky='nsew');vs.grid(row=0,column=1,sticky='ns');hs.grid(row=1,column=0,sticky='ew');area.rowconfigure(0,weight=1);area.columnconfigure(0,weight=1)
  def refresh(*_):
   rows=search(query.get())
   for iid in grid.get_children():grid.delete(iid)
   for item in rows:grid.insert('', 'end',values=(item['product_code'],item['title'],item['face_value'],item['category'],item['group_name'],item['barcode']))
   status.set(f'{len(rows)} products shown (maximum 500). OFFLINE catalogue — cannot issue or activate vouchers.')
  def do_import():
   filename=filedialog.askopenfilename(parent=w,title='Import e-pay Product CSV',filetypes=[('CSV Files','*.csv'),('All Files','*.*')])
   if not filename:return
   try:result=import_file(filename)
   except (OSError,ValueError) as exc:messagebox.showerror('e-pay CSV Import',str(exc),parent=w);return
   refresh();messagebox.showinfo('e-pay CSV Import',f"Imported {result['total']} rows\nNew: {result['created']}\nUpdated: {result['updated']}\nUnchanged: {result['unchanged']}\n\nOffline catalogue only.",parent=w)
  ttk.Button(tools,text='Import e-pay CSV',command=do_import).pack(side='left',padx=8)
  ttk.Button(tools,text='Refresh',command=refresh).pack(side='left',padx=4)
  query.trace_add('write',refresh)
  refresh()
  histpage=ttk.Frame(tabs,padding=12);tabs.add(histpage,text='Import History')
  histbox=tk.Text(histpage,height=15,width=95,wrap='word');histbox.pack(fill='both',expand=True)
  def show_history():
   histbox.config(state='normal');histbox.delete('1.0','end')
   for record in history():histbox.insert('end',f"{record['imported_at']} | {record['filename']} | Total {record['total']} | New {record['created']} | Updated {record['updated']} | Unchanged {record['unchanged']}\n")
   histbox.config(state='disabled')
  ttk.Button(histpage,text='Refresh Import History',command=show_history).pack(anchor='w',pady=5);show_history()
  # Read-only local component inspection: does not load or execute DLLs, or contact e-pay.
  diagnostics=ttk.Frame(tabs,padding=12);tabs.add(diagnostics,text='Connector Diagnostics')
  ttk.Label(diagnostics,text='READ-ONLY CHECK — No DLL is loaded or executed; no e-pay request is sent.',foreground='#a33421',wraplength=750).pack(anchor='w',pady=(0,10))
  ttk.Label(diagnostics,text='Choose the folder containing your existing e-pay DLLs (epayREST.dll, epayXML.dll, EPAPICOM.dll).').pack(anchor='w')
  folder_var=tk.StringVar(value='')
  folder_line=ttk.Frame(diagnostics);folder_line.pack(fill='x',pady=8)
  ttk.Entry(folder_line,textvariable=folder_var).pack(side='left',fill='x',expand=True)
  def choose_folder():
   path=filedialog.askdirectory(parent=w,title='Select existing e-pay component folder')
   if path:folder_var.set(path)
  ttk.Button(folder_line,text='Browse',command=choose_folder).pack(side='left',padx=6)
  results=tk.Text(diagnostics,height=15,wrap='word');results.pack(fill='both',expand=True,pady=8)
  results.insert('end','Select a folder and click Inspect Files.\nNo changes will be made to your working POS Browser installation.\n')
  results.config(state='disabled')
  def inspect_files():
   from pathlib import Path
   import hashlib
   folder=Path(folder_var.get())
   lines=['e-pay component presence check (READ ONLY)']
   if not folder.is_dir():lines.append('Please select an existing folder.')
   else:
    for name in ('epayREST.dll','epayREST.tlb','epayXML.dll','epayXML.tlb','EPAPICOM.dll','EpayMaintDoc.dll'):
     candidate=folder/name
     if not candidate.is_file():lines.append(f'{name}: NOT FOUND');continue
     try:
      size=candidate.stat().st_size
      with candidate.open('rb') as fh:signature=fh.read(2)
      lines.append(f'{name}: found ({size:,} bytes, MZ={signature==bytes([77,90])})')
     except OSError as exc:lines.append(f'{name}: unable to inspect ({exc})')
   lines+=['','Connection: NOT TESTED','Product enquiry: NOT TESTED','Voucher sale: DISABLED','Voucher cancellation: DISABLED','Printing: NOT CONNECTED','','Live transactions require verified API signatures, authorised credentials and a test procedure.']
   results.config(state='normal');results.delete('1.0','end');results.insert('end','\n'.join(lines));results.config(state='disabled')
  ttk.Button(diagnostics,text='Inspect Files (No Execution)',command=inspect_files).pack(anchor='w',pady=4)
  for title,desc in [('Transactions','No e-pay transactions have been submitted. Live transaction history requires authorised e-pay integration.'),('Reconciliation','Live reconciliation is unavailable until e-pay transactions can be verified.')]:
   page=ttk.Frame(tabs,padding=20);tabs.add(page,text=title);ttk.Label(page,text=desc,wraplength=680).pack(anchor='w',pady=10)
  bar=ttk.Frame(w,padding=12);bar.pack(fill='x',side='bottom')
  ttk.Button(bar,text='e-pay Settings',command=lambda:setup(self)).pack(side='left')
  ttk.Button(bar,text='Close',command=w.destroy).pack(side='right')
 def settings(self):
  original_layout=self.layout
  def layout(title,items):
   if title=='SETTINGS & TOOLS':items=list(items)+[('e-pay Integration (Setup)',lambda:setup(self))]
   return original_layout(title,items)
  self.layout=layout
  try:return old_settings(self)
  finally:self.layout=original_layout
 def pos(self):
  try:seed_button()
  except OSError:pass
  return old_pos(self)
 cls.epay_settings=setup;cls.epay_window=epay;cls.settings=settings;cls.pos=pos
