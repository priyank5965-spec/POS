"""Experimental Linkly TRAINING-mode purchase probe. NEVER finalises a POS sale.
Requires locally installed Linkly offline-development Virtual PINpad. Do not use on live equipment.
"""
import socket
import uuid
import logging
from pathlib import Path
from linkly_status_v112 import frame, receive_frame, LinklyStatusError

class LinklyPurchaseError(Exception):
    pass

def build_purchase(amount_cents, reference):
    if type(amount_cents) is not int or not 1 <= amount_cents <= 999999999:
        raise ValueError('Invalid purchase amount in cents')
    if not isinstance(reference,str) or not (1 <= len(reference) <= 16) or not reference.isascii() or not reference.isalnum():
        raise ValueError('Invalid unique transaction reference')
    # Linkly TCP/IP transaction request: positions are relative to the full #LLLL frame.
    fields = ['M0','00','P','1','0', '000000000',f'{amount_cents:09d}',
              ' '*6, reference.ljust(16),'9','0',' ', ' '*20,' '*4,' '*40,
              ' ','00',' '*12,' '*3,' ',' '*6,' '*6,' '*8,'000']
    payload=''.join(fields)
    assert len(payload)==156, len(payload)  # frame header adds 5 -> PAD length at byte 158
    return frame(payload)

def parse_purchase_response(payload, amount_cents, reference):
    if not payload.startswith(b'M0') or len(payload)<257:
        raise LinklyPurchaseError('No complete Linkly purchase response; outcome UNKNOWN')
    def ascii_at(start,end):
        return payload[start-5:end-5].decode('ascii','replace')
    success=ascii_at(7,8)=='1'
    code=ascii_at(8,10)
    message=ascii_at(10,30).strip()
    txn_type=ascii_at(32,33)
    amount=ascii_at(49,58)
    txn_ref=ascii_at(73,89).strip()
    approved=(success and code=='00' and txn_type.upper()=='P' and amount.isdigit() and int(amount)==amount_cents and txn_ref==reference)
    # Only record non-sensitive field checks; NEVER dump raw Linkly responses/card data.
    if not approved:
        try:
            with (Path(__file__).parent/'linkly_training_diagnostics.log').open('a',encoding='utf-8') as log:
                log.write(f'code={code!r} message={message!r} success={success} '
                          f'type={txn_type!r} type_ok={txn_type.upper()=="P"} '
                          f'amount_ok={amount.isdigit() and int(amount)==amount_cents} '
                          f'reference_ok={txn_ref==reference} response_len={len(payload)}\n')
        except OSError:
            pass
    return {'approved':approved,'code':code,'message':message,'amount_cents':int(amount) if amount.isdigit() else None,'reference':txn_ref,'outcome':'APPROVED' if approved else 'DECLINED OR UNVERIFIED'}

def _log_intermediate(kind, response):
    # Record only the message type and length, never card or account information.
    try:
        with (Path(__file__).parent/'linkly_training_diagnostics.log').open('a', encoding='utf-8') as log:
            log.write(f'{kind} intermediate_M0 response_len={len(response)}\n')
    except OSError:
        pass


def test_purchase(amount_cents, host='127.0.0.1', port=2011, timeout=90):
    if host not in ('127.0.0.1','localhost','::1'):
        raise LinklyPurchaseError('Training probe permits loopback Linkly only.')
    reference='F'+uuid.uuid4().hex[:15].upper()
    request=build_purchase(amount_cents,reference)
    try:
        with socket.create_connection((host,int(port)),timeout=5) as conn:
            conn.settimeout(timeout)
            conn.sendall(request)
            for _ in range(80):
                response=receive_frame(conn)
                if response.startswith(b'M0'):
                    if len(response) < 257:
                        _log_intermediate('PURCHASE', response)
                        continue
                    return parse_purchase_response(response,amount_cents,reference)
            raise LinklyPurchaseError('No final purchase response; outcome UNKNOWN. Check Linkly history before retrying.')
    except (OSError,TimeoutError,LinklyStatusError) as exc:
        raise LinklyPurchaseError('Transaction result UNKNOWN: '+str(exc)+'; do not retry before checking Linkly history.') from exc


def build_refund(amount_cents, reference):
    """Offline-development Linkly refund request; positive cents and transaction type R."""
    request = bytearray(build_purchase(amount_cents, reference))
    assert request[9:10] == b'P'
    request[9:10] = b'R'
    return bytes(request)

def parse_refund_response(payload, amount_cents, reference):
    if not payload.startswith(b'M0') or len(payload) < 257:
        raise LinklyPurchaseError('No complete Linkly refund response; outcome UNKNOWN')
    def at(a,b): return payload[a-5:b-5].decode('ascii','replace')
    code=at(8,10); message=at(10,30).strip(); success=at(7,8)=='1'
    kind=at(32,33).upper(); amount=at(49,58); ref=at(73,89).strip()
    approved=success and code=='00' and kind=='R' and amount.isdigit() and int(amount)==amount_cents and ref==reference
    if not approved:
        try:
            with (Path(__file__).parent/'linkly_training_diagnostics.log').open('a',encoding='utf-8') as log:
                log.write(f'REFUND code={code!r} success={success} type_ok={kind=="R"} amount_ok={amount.isdigit() and int(amount)==amount_cents} reference_ok={ref==reference} response_len={len(payload)}\n')
        except OSError: pass
    return {'approved':approved,'code':code,'message':message,'amount_cents':int(amount) if amount.isdigit() else None,'reference':ref,'outcome':'APPROVED' if approved else 'DECLINED OR UNVERIFIED'}

def test_refund(amount_cents, host='127.0.0.1', port=2011, timeout=90):
    if host not in ('127.0.0.1','localhost','::1'):
        raise LinklyPurchaseError('Refund training permits loopback Linkly only.')
    reference='R'+uuid.uuid4().hex[:15].upper()
    request=build_refund(amount_cents,reference)
    try:
        with socket.create_connection((host,int(port)),timeout=5) as conn:
            conn.settimeout(timeout)
            conn.sendall(request)
            for _ in range(80):
                response=receive_frame(conn)
                if response.startswith(b'M0'):
                    if len(response) < 257:
                        _log_intermediate('REFUND', response)
                        continue
                    return parse_refund_response(response,amount_cents,reference)
            raise LinklyPurchaseError('No complete Linkly refund response; outcome UNKNOWN. Check Linkly history.')
    except (OSError,TimeoutError,LinklyStatusError) as exc:
        raise LinklyPurchaseError('Refund outcome UNKNOWN: '+str(exc)+'; check Linkly history before retrying.') from exc
