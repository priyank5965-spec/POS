v0.43 TEST ONLY: register opens maximised; larger bold summary figures; modern Hold Sale input dialog. Other business logic unchanged. Run START_FREEDOM_POS.bat. Test on Windows.
