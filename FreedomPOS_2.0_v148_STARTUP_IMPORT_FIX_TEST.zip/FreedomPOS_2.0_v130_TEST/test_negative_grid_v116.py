import unittest
from pathlib import Path

class NegativeGridSafetyTests(unittest.TestCase):
    def test_negative_grid_entry_is_supported(self):
        s=Path(__file__).with_name('register_grid_v034.py').read_text()
        self.assertIn('if not -9999<=q<=9999 or q==0',s)
        self.assertIn("x['qty']=q",s)
        self.assertIn("x['training_return_unlinked']=True",s)
    def test_unlinked_returns_require_verified_training_refund(self):
        s=Path(__file__).with_name('freedom_pos.py').read_text()
        check=s.index("if unlinked_return and not (getattr(self,'_linkly_verified_refund',False)")
        insert=s.index("INSERT INTO sales(id,created,total,payment")
        self.assertLess(check,insert)
    def test_linked_refunds_still_protected(self):
        s=Path(__file__).with_name('register_grid_v034.py').read_text()
        self.assertIn("if x.get('original_line'):",s)
        self.assertIn('Use Previous Sales to edit linked refund quantities.',s)
if __name__=='__main__':unittest.main()
