"""Non-sensitive Linkly training receipt information."""
def training_receipt_lines(db, sale_id):
    exists=db.execute("SELECT 1 FROM sqlite_master WHERE type='table' AND name='linkly_training_posted'").fetchone()
    if not exists:return []
    row=db.execute("SELECT reference,amount_cents,status FROM linkly_training_posted WHERE sale_id=? AND status='POSTED' ORDER BY rowid DESC LIMIT 1",(sale_id,)).fetchone()
    if not row:return []
    return ['EFTPOS: LINKLY TRAINING (TEST ONLY)', 'Result: APPROVED (verified)', 'Response code: 00', 'Transaction reference: '+str(row[0]), 'Approved amount: $'+format(row[1]/100,'.2f'), 'No real payment processed']
