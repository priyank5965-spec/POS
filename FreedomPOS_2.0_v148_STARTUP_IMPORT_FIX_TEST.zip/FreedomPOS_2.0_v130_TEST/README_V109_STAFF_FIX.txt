Freedom POS 2.0 v0.109 TEST ONLY
Fixed staff selection when Staff Maintenance records have NULL initials or names.
Staff without initials can be selected by name.
This addresses the reported receiving_error.log traceback at supplier_receiving_v017.py line 428.
This is not a guarantee that other invoice validation or Windows UI issues are resolved.
Back up your test data and check invoice status before finalising to avoid duplicate posting.
