"""Receipt business settings and scanned receipt action; offline test only."""
import json, shutil, tkinter as tk
from tkinter import filedialog, messagebox, ttk
from pathlib import Path

ROOT=Path(__file__).resolve().parent
DATA=ROOT/'test_data'
SETTINGS=DATA/'receipt_business.json'
DEFAULT={'business_name':'TEST BUSINESS','trading_name':'','abn':'00 000 000 000 (TEST)',
         'address':'TEST ADDRESS - AUSTRALIA','phone':'TEST PHONE','email':'',
         'bank_name':'TEST BANK','account_name':'TEST ACCOUNT','bsb':'000-000 (TEST)',
         'account_number':'000000000 (TEST)','logo':'',
         'receipt_footer':'Thank you for shopping local!\nWe appreciate your support.'}

def load_business():
    data=DEFAULT.copy()
    try:
        stored=json.loads(SETTINGS.read_text(encoding='utf-8'))
        if isinstance(stored,dict):data.update({k:v for k,v in stored.items() if k in data and isinstance(v,str)})
    except (OSError,ValueError):pass
    return data

def edit_business(self):
    w=tk.Toplevel(self.root);w.title('Business & Receipt Settings — TEST ONLY')
    w.geometry('800x730');w.minsize(600,580);w.transient(self.root)
    top=tk.Frame(w,bg='white');top.pack(fill='x')
    tk.Label(top,text='BUSINESS & RECEIPT SETTINGS',bg='white',fg='#111111',font=('Segoe UI',15,'bold')).pack(padx=14,pady=12)
    footer=tk.Frame(w);footer.pack(side='bottom',fill='x',padx=12,pady=12)
    body=tk.Frame(w);body.pack(fill='both',expand=True,padx=20,pady=8)
    settings=load_business();fields={}
    labels=[('business_name','Business / company name'),('trading_name','Trading name'),('abn','ABN'),
            ('address','Business address'),('phone','Phone'),('email','Email'),
            ('bank_name','Bank name (A4)'),('account_name','Bank account name (A4)'),
            ('bsb','BSB (A4)'),('account_number','Account number (A4)'),
            ('receipt_footer','Receipt footer message (use \n for new line)')]
    for i,(key,label) in enumerate(labels):
        tk.Label(body,text=label,anchor='w',font=('Segoe UI',10)).grid(row=i,column=0,sticky='w',padx=5,pady=5)
        var=tk.StringVar(value=settings[key]);fields[key]=var
        tk.Entry(body,textvariable=var,font=('Segoe UI',10)).grid(row=i,column=1,sticky='ew',padx=5,pady=5)
    body.columnconfigure(1,weight=1)
    logo=tk.StringVar(value=settings['logo'])
    tk.Label(body,text='Receipt logo',anchor='w').grid(row=len(labels),column=0,sticky='w',padx=5,pady=7)
    tk.Label(body,textvariable=logo,anchor='w',wraplength=360).grid(row=len(labels),column=1,sticky='w',padx=5)
    def choose_logo():
        path=filedialog.askopenfilename(parent=w,title='Choose receipt logo',filetypes=[('Images','*.png *.jpg *.jpeg')])
        if path:logo.set(path)
    controls=tk.Frame(body);controls.grid(row=len(labels)+1,column=1,sticky='w')
    tk.Button(controls,text='UPLOAD LOGO',command=choose_logo).pack(side='left',padx=3)
    tk.Button(controls,text='REMOVE LOGO',command=lambda:logo.set('')).pack(side='left',padx=3)
    tk.Label(body,text='Logo is scaled to fit the 80mm and A4 receipts. Use PNG/JPG.\nTEST ONLY — verify legal invoice requirements before real use.',fg='#9b3229',justify='left').grid(row=len(labels)+2,column=0,columnspan=2,sticky='w',pady=8)
    def save():
        result={k:v.get().strip() for k,v in fields.items()}
        if not result['business_name']:
            return messagebox.showwarning('Required','Business name is required.',parent=w)
        result['logo']=''
        if logo.get():
            source=Path(logo.get())
            if not source.is_file():return messagebox.showerror('Logo','Selected logo is missing.',parent=w)
            if source.suffix.lower() not in ('.png','.jpg','.jpeg'):
                return messagebox.showerror('Logo','Choose a PNG or JPEG image.',parent=w)
            if source.stat().st_size>5_000_000:
                return messagebox.showerror('Logo','Logo must be smaller than 5MB.',parent=w)
            DATA.mkdir(exist_ok=True)
            dest=DATA/('receipt_logo'+source.suffix.lower())
            if source.resolve()!=dest.resolve():shutil.copy2(source,dest)
            result['logo']=str(dest)
        DATA.mkdir(exist_ok=True)
        SETTINGS.write_text(json.dumps(result,indent=2),encoding='utf-8')
        messagebox.showinfo('Saved','Receipt business details and logo saved.',parent=w);w.destroy()
    tk.Button(footer,text='SAVE SETTINGS',command=save,bg='#52bfca',font=('Segoe UI',10,'bold'),padx=12,pady=8).pack(side='left')
    tk.Button(footer,text='CANCEL',command=w.destroy,padx=12,pady=8).pack(side='right')

def receipt_barcode_action(self,code):
    digits=code[1:]
    if not digits.isdigit() or not digits:
        return messagebox.showwarning('Receipt barcode','Invalid receipt barcode. Expected @ followed by receipt number.',parent=self.root)
    sale_id=int(digits)
    sale=self.db.execute('SELECT * FROM sales WHERE id=?',(sale_id,)).fetchone()
    if sale is None:
        return messagebox.showwarning('Receipt not found',f'No transaction exists for {code}.',parent=self.root)
    w=tk.Toplevel(self.root);w.title(f'Receipt Actions — {sale_id:010d}');w.geometry('460x365');w.transient(self.root)
    tk.Label(w,text=f'RECEIPT {sale_id:010d}',font=('Segoe UI',16,'bold')).pack(pady=(14,5))
    tk.Label(w,text=f'{sale["created"]}   |   {sale["payment"]}   |   ${sale["total"]/100:,.2f}',font=('Segoe UI',10)).pack(pady=5)
    def action(fn):w.destroy();fn()
    def open_refund():
        from refund_grid_v055 import load_refund_to_grid
        load_refund_to_grid(self,sale_id,parent=self.root)
    def account():
        if sale['payment']!='ACCOUNT':
            messagebox.showinfo('Account action','This is not an account sale.',parent=self.root)
        else:
            messagebox.showinfo('Account action','Account credit/payment from a scanned receipt is not implemented in this TEST build. Use existing customer account workflows.',parent=self.root)
    for label,fn in [('REPRINT / PREVIEW RECEIPT',lambda:self.receipt(sale_id)),
                     ('REFUND / EXCHANGE',open_refund),('ACCOUNT CREDIT / PAYMENT',account),
                     ('VIEW PREVIOUS SALES',self.previous),('CLOSE',lambda:None)]:
        if label=='CLOSE':tk.Button(w,text=label,command=w.destroy).pack(fill='x',padx=45,pady=4)
        else:tk.Button(w,text=label,command=lambda f=fn:action(f),font=('Segoe UI',10,'bold'),pady=5).pack(fill='x',padx=45,pady=3)

def install(cls):
    original=cls.settings
    def settings(self):
        self.layout('SETTINGS & TOOLS',[
            ('Business & Receipt Settings',lambda:edit_business(self)),
            ('Email Settings',self.email_settings),('Email History',self.email_history),
            ('Backup & Restore',self.back),
            ('RustDesk Remote Support',self.rustdesk),
            ('XchangeIT Integration',lambda:self.info('XchangeIT','Not connected in TEST build.')),
            ('Printers / EFTPOS',lambda:self.info('Hardware','Not connected in TEST build.')),
            ('Mobile Stocktake APK',lambda:self.info('Mobile Stocktake','Not built yet.'))])
    # preserve the working backup method, which is named backup in the app.
    def settings_fixed(self):
        self.layout('SETTINGS & TOOLS',[
            ('Business & Receipt Settings',lambda:edit_business(self)),
            ('Email Settings',self.email_settings),('Email History',self.email_history),
            ('Backup & Restore',self.backup),('RustDesk Remote Support',self.rustdesk),
            ('XchangeIT Integration',lambda:self.info('XchangeIT','Not connected in TEST build.')),
            ('Printers / EFTPOS',lambda:self.info('Hardware','Not connected in TEST build.')),
            ('Mobile Stocktake APK',lambda:self.info('Mobile Stocktake','Not built yet.'))])
    cls.settings=settings_fixed
