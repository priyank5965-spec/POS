Freedom POS 2.0 v0.45 — TEST ONLY

Register gear opens Advanced Layout & Themes.
New themes: Aronium-Inspired Light and Modern Touch (original designs inspired by supplied screenshots, not copies).
Resize buttons with Width and Height controls in grid cells, then Apply to Preview. Space must be available; occupied cells are protected.
Drag to empty space or swap compatible buttons. Rename and recolour remain available. Save Layout persists settings in register_layout_v044.json (compatible with v0.44).
Theme selection changes button palette, not the underlying sales logic. Cancel discards changes. Restore Default resets preview, save to persist.

Known limitations: Not an exact reproduction of Aronium UI. Does not restructure the register into a top-toolbar layout; layout remains a 5-column, 7-row button grid. Enlarging a button requires moving or shrinking neighbours first. No adding arbitrary new buttons, no resize handles, no custom shortcut assignment yet.

TEST ONLY. No live EFTPOS certification. Verify Windows UI and all POS workflows before live use.
