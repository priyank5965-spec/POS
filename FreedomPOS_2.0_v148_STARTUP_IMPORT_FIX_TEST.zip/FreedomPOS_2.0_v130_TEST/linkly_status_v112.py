"""Read-only Linkly TCP status inquiry. Never issues financial requests."""
import socket

DEFAULT_HOST = '127.0.0.1'
DEFAULT_PORT = 2011

class LinklyStatusError(Exception):
    pass

def frame(command):
    data = command.encode('ascii')
    length = 5 + len(data)
    return b'#' + f'{length:04d}'.encode('ascii') + data

def receive_frame(sock):
    head = b''
    while len(head) < 5:
        part = sock.recv(5-len(head))
        if not part: raise LinklyStatusError('Linkly closed the connection before replying.')
        head += part
    if head[:1] != b'#' or not head[1:5].isdigit():
        raise LinklyStatusError('Linkly returned an unrecognised message header.')
    size = int(head[1:5])
    if size < 7 or size > 65535:
        raise LinklyStatusError('Linkly returned an invalid message length.')
    data = bytearray(head)
    while len(data) < size:
        part = sock.recv(min(4096,size-len(data)))
        if not part: raise LinklyStatusError('Linkly disconnected during the status response.')
        data.extend(part)
    return bytes(data[5:])

def query_pinpad(host=DEFAULT_HOST,port=DEFAULT_PORT,timeout=4.0):
    """Query status with K0 00 00. Only returns informational state, never approval."""
    if not host or not str(host).strip():raise ValueError('Linkly host is required')
    port=int(port)
    if not 1 <= port <= 65535:raise ValueError('Invalid Linkly port')
    try:
        with socket.create_connection((str(host).strip(),port),timeout=timeout) as conn:
            conn.settimeout(timeout)
            conn.sendall(frame('K00000'))  # K, subcode 0, merchant 00, application 00
            for _ in range(12):
                payload=receive_frame(conn)
                if payload.startswith(b'K'):
                    if len(payload)<5:raise LinklyStatusError('Incomplete Linkly status response.')
                    success=payload[2:3]==b'1'
                    code=payload[3:5].decode('ascii','replace').strip()
                    desc=payload[5:25].decode('ascii','replace').strip() or 'No description'
                    return {'online':success,'code':code,'message':desc}
            raise LinklyStatusError('No status response received from Linkly.')
    except (OSError,TimeoutError) as exc:
        raise LinklyStatusError('Linkly connection/status failed: '+str(exc)) from exc
