v147 TEST: unified Department / Product / Newspaper shortcuts. Settings renamed. Windows runtime not verified.
