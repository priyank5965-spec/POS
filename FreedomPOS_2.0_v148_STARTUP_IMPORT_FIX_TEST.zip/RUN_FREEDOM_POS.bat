@echo off
setlocal
cd /d "%~dp0FreedomPOS_2.0_v130_TEST"
if not exist "freedom_pos.py" (
 echo ERROR: Freedom POS program folder was not found.
 pause
 exit /b 1
)
where py >nul 2>nul
if not errorlevel 1 (
 py -3 freedom_pos.py
) else (
 python freedom_pos.py
)
if errorlevel 1 (
 echo.
 echo Freedom POS could not start. Check Python and required packages.
 pause
)
endlocal
